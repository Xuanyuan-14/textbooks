# 复变函数论 (钟玉泉)

> 源文件：`复变函数论 (钟玉泉).pdf_by_PaddleOCR-VL-1.6.json`
> 共 395 页，由 PaddleOCR-VL-1.6 从 PDF 转出。
> 页码锚点格式 `<!-- page: N -->`，N 为 PDF 页码（从 1 起）。
> 图片位于 `../images/`，已本地化。

## 章节索引

- **复变函数论** — 第 1 页
- **第三版** — 第 2 页
- **第一章 复数与复变函数** — 第 19 页
- **第一章习题** — 第 58 页
- **第二章 解析函数** — 第 63 页
- **第二章 习题** — 第 106 页
- **第三章 复变函数的积分** — 第 112 页
- **第三章 习题** — 第 157 页
- **第四章 解析函数的幂级数表示法** — 第 163 页
- **第四章 习题** — 第 194 页
- **第五章 解析函数的洛朗 (Laurent)展式与孤立奇点** — 第 200 页
- **第五章 习题** — 第 233 页
- **第六章 留数理论及其应用** — 第 241 页
- **第六章习题** — 第 285 页
- **第七章 共形映射** — 第 293 页
- **第七章 习题** — 第 333 页
- **第八章 解析延拓** — 第 340 页
- **第八章 习题** — 第 379 页
- **第九章 调和函数** — 第 383 页
- **第九章习题** — 第 393 页
- **本书第一版荣获第一届国家教委 高等学校优秀教材二等奖** — 第 395 页

---

<!-- page: 1 -->

高等学校教材

# 复变函数论

（第三版）

钟玉泉 编

<div style="text-align: center;"><img src="images/p0001_img_in_image_box_0_2355_4310_6008.jpg" alt="Image" width="96%" /></div>


高等教育出版社

<!-- page: 2 -->

高等学校教材

### 复变函数论

# 第三版

钟玉泉 编

高等教育出版社

<!-- page: 3 -->

图书在版编目（CIP）数据

复变函数论 / 钟玉泉编. —3 版. —北京: 高等教育出版社, 2004.1

ISBN 7-04-012943-4

Ⅰ. 复... Ⅱ. 钟... Ⅲ. 复变函数 - 高等学校 -

教材 Ⅳ. O174.5

中国版本图书馆 CIP 数据核字（2003）第 095839 号

出版发行 高等教育出版社

购书热线 010-64054588

社址 北京市西城区德外大街4号

免费咨询 800-810-0598



邮政编码 100011

网址 http://www.hep.edu.cn

总机010-82028899

http://www.hep.com.cn

经销新华书店北京发行所

印刷 高等教育出版社印刷厂

开本  $ 850 \times 1168 $ 1/32

版 次 1979 年 8 月 第 1 版

2004年1月第3版

印 张 12.375

印次 2004 年 4 月第 3 次印刷

字数 310 000

定 价 18.70 元

本书如有缺页、倒页、脱页等质量问题，请到所购图书销售部门联系调换。

期权所有侵权必究

<!-- page: 4 -->

##### 内容提要

本书第三版是在第二版的基础上，集撷作者多年教学心得和科研成果，并根据1988年全国复变函数编写提纲讨论会精神修订的。此次修订着眼于进一步提高质量，更加适应多数学校的教学需要，保留第二版阐述细致，便于自学的特点，对已发现的错误和不妥之处，予以改正。

本书内容包括：复数与复变函数、解析函数、复变函数的积分、解析函数的幂级数表示法、解析函数的洛朗展式与孤立奇点、留数理论及其应用、共形映射、解析延拓和调和函数共九章。对于加上 * 号内容，供学有余力的学生选学。

本书可作为高等师范院校数学系的教材，也可为其他理工院校、教育学院所选用。

<!-- page: 5 -->

### 第三版序

本书第二版自1988年5月出版以来，迄今已重印22次，累计印数达45万余册。使用后普遍反映良好。为使教材能与时俱进，不断提高质量，遂对第二版进行了修订。修订中集撷了本人的若干教学和科研成果[见附1~7]，针对规范的数学名词已颁布，顺便作了规范化勘正。修订的另一重要依据是1988年11月底的郑州全国复变函数编写提纲讨论会精神。

我们在修订中所掌握的具体原则是：

1. 使原书中涉及的数学名词规范化；

2. 一般不增删原书的章、节、例题（只增了例 4.5(5)）、习题（只增了第一章习题（二） $ ^{*} $12）和图；

3. 对原书作进一步修整，并在一些地方适当引入[附1~7]的部分成果，以使其叙述更清楚、更精确、更易教易学，而基本理论又更扎实。

此外，拙编《复变函数学习指导书》，为国家教委“八五”高校规划教材，是拙编教材《复变函数论》(第二版)的配套教学用书，读者仍可以与第三版教材对照参考阅读。

编者于四川大学数学学院

2003年6月

<!-- page: 6 -->

附 1. 一个解析函数定理的推广. 四川大学学报(自然科学版),1990,27(1):86~87;

2. 一族与对称函数有关的解析函数的开始多项式.西南师范大学学报(自然科学版),1990,15(1):125~131;

3. 解析函数的单叶半径. 四川大学学报(自然科学版), 1991, 28(4): 545~547;

4. 解析函数的星象半径. 四川大学学报(自然科学版), 1993, 30(3): 405~407;

5. 解析函数的  $ \beta $ 级星象半径. 四川大学学报(自然科学版), 1995,32(2):121~127;

6. 复变函数学习指导书. 北京: 高等教育出版社, 1996 年 4 月;

7. 关于复变函数的教材改革与建设.香港:《现代教学论坛》杂志,2000年1期.

#### 书中符号说明

为了方便，我们引入以下符号：

“ $ \forall x $”表示“对每一个x”；

“ $ \exists x $”表示“存在 x”；

“ $ \exists 1x $”表示“惟一存在 x”；

“——→——”表示“若——，则——”；

“——⇔——”表示“——当且仅当——”；

“ $ \Rightarrow $”表示“必要性”；

“⇐”表示“充分性”.

<!-- page: 7 -->

### 第二版 序

本书自1979年出版以来已重印了八次，采用它作教材的学校，除一些综合大学、师范院校外，还有一些理工院校的应用数学专业、计算专业、师资班和研究生班等。许多教师和读者来信表示关切和鼓励，并对书中存在的不妥和错误之处予以指正，在此特向他们表示感谢。

这次修订着眼于进一步提高质量，更加适应多数学校的教学需要，保留第一版阐述细致，便于自学的特点，对已经发现的错误和不妥之处，予以改正。除此之外，第二版与第一版的主要区别可概括如下：

1. 将第二章§2解析函数与调和函数的关系后移至第三章，这样既可相对减轻第二章因讨论多值函数所引起的内容偏重，又可避免提前引用第三章中“解析函数”无穷可微性”。

2. 将共形映射这一章的前四节编成第七章列在解析延拓之前，把剩下的第5节对称原理及多角形区域的共形映射纳入解析延拓这一章，避免了原来将对称原理切成两段，分属两章.

3. 将施瓦茨引理从第八章提前到第五章，放在可去奇点之后，这样既可使它与第四章末的最大模原理靠近，又可让读者早些熟悉、掌握函数论中这两个重要的有关联的定理。

4. 含点 $ \infty $的区域上的柯西积分定理与柯西积分公式，原在第三章习题中，现后移至第五章习题中。因为这时已介绍了函数在点 $ \infty $解析的意义，读者就可以借助函数在点 $ \infty $去心邻域内的洛朗展式简捷地证明它们。

<!-- page: 8 -->

5. 为了第九章解单位圆内狄利克雷问题的需要，这一版在第三章§3末添了一小段柯西型积分，并加上*号。另外，由于综合大学数学专业复变函数教学大纲中列有单值性定理，这次也补写了一段，列入解析延拓这一章。

6. 出于教学方法上的考虑，以这几年的教学实践为基础，我改写了第二章初等多值函数以及第六章应用多值函数的积分，目的在于使读者更加易于接受，使多值函数这一教学难点能有所突破。至于其他改写之处，各章都有，就不在这里一一道及了。

7. 考虑到不同层次的学校与不同程度的学生在学习上的多种需要，我以这几年的教学实践为基础，对原有习题作了些调整之后将其编入各章习题（一）；另外，又适当慎选了一些较难的习题及与之相应的例题。新添的题目，将其编入各章习题（二）。经多次试用，它们虽较难些，但仍是紧扣教材的，有助于培养与增强学生的能力，学生可以根据自己的情况适当选作。

8. 根据综合大学数学专业复变函数教学大纲，在这一版中将解析函数对平面场的应用及多角形区域的共形映射公式这些节都加上 $ ^{*} $号，并对第一版中排小字的内容全都改排大字，除柯西积分定理的古莎证明外，其余改排大字的部分都加上 $ ^{*} $号。其他院校和其他专业，在使用本教材时，可根据各自的教学大纲决定取舍。

9. 这一版删去了第一版中的附录，整函数与亚纯函数近代理论简介，因为国内已有这方面的专著出版了。 $ ^{①} $

根据我的教学实践，教师使用本教材不必全讲，只需按教学大纲要求控制各章讲授学时和讲授内容，讲清楚基本理论、基本方法、重点和难点，其余还需要学生掌握的内容和例题就指定留给学生自学。这对于开发学生智力，培养学生能力是大有裨益的。

<!-- page: 9 -->

加 $ ^{*} $号的内容，自修的读者可以先不读它.

编者

1987年元旦

<!-- page: 10 -->

### 第一版序

本书是根据1977年理科数学教材会议上制订的复变函数教材编写大纲，在历年主讲该课使用的自编讲义基础上改编成的。全书系统地介绍了单复变函数的基本理论和基本方法。

考虑到复变函数论是数学专业的一门重要基础课，又是数学分析的后继课，在编写本书时，注意了下列几点：

1. 对与数学分析中平行的概念，如极限、连续、微分等，既指出其相似之处，更强调其不同之点，以免初学者疏忽。

2. 对复变函数论中的基本定理和重要定理，如柯西积分定理和关于本性奇点的魏尔斯特拉斯定理等，从叙述、证明到推广，均注意了科学性和严密性。这不仅反映了复变函数理论本身的系统性和严谨性，同时也可藉以锻炼读者思考问题和逻辑推理的能力。

3. 对多值解析函数这个教学上的难点，为使读者较易接受，本书把它分散在第二章、第六章及第七章内.并在第二章内，把求根式函数 $ \sqrt[n]{2} $的单值解析分支的方法写得较细，这样做或许能使读者举一反三.

4. 对解析函数在流体力学、机翼理论及电学等方面的应用，本书作了简明的介绍，藉以使读者了解复变函数论方法在解决实际问题上的重要性。

5. 配备了大量的例题和习题，习题大都附有答案或提示，以供教师选用，也便于读者自学.

6. 因限于篇幅或工具知识而不能给出证明的定理，大都指出参考资料.用小字排印的部分，对初学者可不作要求.

<!-- page: 11 -->

附录中简单介绍了我国青年数学家杨乐、张广厚的出色工作，以适应有些缺乏这方面资料的读者的要求。

使用本书作教材，大体可按6、10、8、8、8、10、6、12、4的顺序来分配各章讲授学时。如讲授学时少于72学时，教师可斟酌删去一些次要及较深部分的内容。例如，可删去克里斯托费尔——施瓦茨公式及最末一章等。

本书由武汉大学路见可教授主审。武汉大学、北京大学、南开大学、吉林大学、南京大学、上海师范大学、西南师范学院、四川师范学院、四川大学的同志参加了审查。他们提出了许多宝贵的意见，在此表示衷心感谢。特别是路见可教授不惮其烦，为编者复审修改了全部稿件，使原稿得到了很大改进，编者对他的这种负责精神表示敬佩和学习。

本书初稿曾经四川大学蒲保明教授和周纪溥、张茂孝两同志审阅，也在此一并致谢。

但限于编者水平，谬误之处仍然难免，敬请读者提出来批评指正。

编者于四川大学数学系

1978.9.

<!-- page: 12 -->

## 目录

引言 ..... 1    
第一章 复数与复变函数 ..... 3    
§1. 复数 ..... 3    
1. 复数域(3) 2. 复平面(5) 3. 复数的模与辐角(7)    
4. 复数的乘幂与方根(13) 5. 共轭复数(16)    
6. 复数在几何上的应用举例(18)    
§2. 复平面上的点集 ..... 21    
1. 平面点集的几个基本概念(21) 2. 区域与若尔当(Jordan)曲线(22)    
§3. 复变函数 ..... 28    
1. 复变函数的概念(28) 2. 复变函数的极限与连续性(33)    
§4. 复球面与无穷远点 ..... 38    
1. 复球面(38) 2. 扩充复平面上的几个概念(40)    
    
第一章习题 ..... 42    
第二章 解析函数 ..... 47    
§1. 解析函数的概念与柯西-黎曼方程 ..... 47    
1. 复变函数的导数与微分(47) 2. 解析函数及其简单性质(49) 3. 柯西-黎曼方程(51)    
§2. 初等解析函数 ..... 58    
1. 指数函数(58) 2. 三角函数与双曲函数(60)    
§3. 初等多值函数 ..... 64

<!-- page: 13 -->

1. 根式函数(65) 2. 对数函数(73) 3. 一般幂函数与一般指数函数(78) 4. 具有多个有限支点的情形(80) 5. 反三角函数与反双曲函数(87)    
    
第二章 习题 ..... 90    
第三章 复变函数的积分 ..... 96    
§1. 复积分的概念及其简单性质 ..... 96    
1. 复变函数积分的定义(96) 2. 复变函数积分的计算问题(99) 3. 复变函数积分的基本性质(100)    
§2. 柯西积分定理 ..... 103    
1. 柯西积分定理(103) 2. 柯西积分定理的古莎证明(106) 3. 不定积分(112) 4. 柯西积分定理的推广(114) 5. 柯西积分定理推广到复周线的情形(116)    
§3. 柯西积分公式及其推论 ..... 119    
1. 柯西积分公式(119) 2. 解析函数的无穷可微性(123) 3. 柯西不等式与刘维尔(Liouville)定理(126) 4. 摩勒拉(Morera)定理(128) *5. 柯西型积分(130)    
§4. 解析函数与调和函数的关系 ..... 131    
§5. 平面向量场——解析函数的应用(一) ..... 136    
1. 流量与环量(137) 2. 无源、漏的无旋流动(139) 3. 复势(139)    
    
第三章 习题 ..... 141    
第四章 解析函数的幂级数表示法 ..... 147    
§1. 复级数的基本性质 ..... 147    
1. 复数项级数(147) 2. 一致收敛的复函数项级数(150) 3. 解析函数项级数(153)    
§2. 幂级数 ..... 154    
1. 幂级数的敛散性(154) 2. 收敛半径 R 的求法、柯西－阿达马(Hadamard)公式(157) 3. 幂级数和的解析性(158)

<!-- page: 14 -->

§3. 解析函数的泰勒(Taylor)展式 …… 159    
1. 泰勒定理(159) 2. 幂级数的和函数在其收敛圆周上的状况(162) 3. 一些初等函数的泰勒展式(164)    
§4. 解析函数零点的孤立性及唯一性定理 …… 170    
1. 解析函数零点的孤立性(170) 2. 惟一性定理(173)    
3. 最大模原理(175)    
    
第四章习题 …… 178    
第五章 解析函数的洛朗(Laurent)展式与孤立奇点 … 184    
§1. 解析函数的洛朗展式 …… 184    
1. 双边幂级数(184) 2. 解析函数的洛朗展式(185)    
3. 洛朗级数与泰勒级数的关系(188) 4. 解析函数在孤立奇点邻域内的洛朗展式(189)    
§2. 解析函数的孤立奇点 …… 193    
1. 孤立奇点的三种类型(193) 2. 可去奇点(194)    
3. 施瓦茨(Schwarz)引理(195) 4. 极点(197) 5. 本质奇点(199) 6. 皮卡(Picard)定理(200)    
§3. 解析函数在无穷远点的性质 …… 203    
§4. 整函数与亚纯函数的概念 …… 209    
1. 整函数(209) 2. 亚纯函数(210)    
§5. 平面向量场——解析函数的应用(二) …… 212    
1. 奇点的流体力学意义(212) 2. 在电场中的应用举例(214)    
    
第五章习题 …… 217    
第六章 留数理论及其应用 …… 225    
§1. 留数 …… 225    
1. 留数的定义及留数定理(225) 2. 留数的求法(227)    
3. 函数在无穷远点的留数(231)    
§2. 用留数定理计算实积分 …… 234

<!-- page: 15 -->

1. 计算  $ \int_{0}^{2\pi} R(\cos\theta, \sin\theta) d\theta $ 型积分(234)    
2. 计算  $ \int_{-\infty}^{+\infty} \frac{P(x)}{Q(x)} dx $ 型积分(239)    
3. 计算  $ \int_{-\infty}^{+\infty} \frac{P(x)}{Q(x)} e^{i m x} dx $ 型积分(243)    
4. 计算积分路径上有奇点的积分(245) 5. 杂例(247)    
6. 应用多值函数的积分(251)    
§3. 辐角原理及其应用 ..... 259    
1. 对数函数(259) 2. 辐角原理(261)    
3. 儒歇(Rouché)定理(265)    
    
第六章习题 ..... 269    
    
第七章 共形映射 ..... 277    
§1. 解析变换的特性 ..... 277    
1. 解析变换的保域性(277) 2. 解析变换的保角性——导数的几何意义(279) 3. 单叶解析变换的共形性(283)    
§2. 分式线性变换 ..... 285    
1. 分式线性变换及其分解(285) 2. 分式线性变换的共形性(289) 3. 分式线性变换的保交比性(290)    
4. 分式线性变换的保圆周(圆)性(292) 5. 分式线性变换的保对称点性(294) 6. 分式线性变换的应用(296)    
§3. 某些初等函数所构成的共形映射 ..... 301    
1. 幂函数与根式函数(301) 2. 指数函数与对数函数(303) 3. 由圆弧构成的两角形区域的共形映射(306) *4. 机翼剖面函数及其反函数所构成的共形映射(308) 5. 儒可夫斯基函数的单叶性区域(311)    
§4. 关于共形映射的黎曼存在定理和边界对应定理 ..... 312    
1. 黎曼存在定理(312) 2. 边界对应定理(315)    
    
第七章习题 ..... 317

<!-- page: 16 -->

第八章 解析延拓 ..... 324    
§1. 解析延拓的概念与幂级数延拓 ..... 324    
1. 解析延拓的概念(324) 2. 解析延拓的幂级数方法(328)    
§2. 透弧解析延拓、对称原理 ..... 334    
1. 透弧直接解析延拓(334) 2. 黎曼－施瓦茨对称原理(335)    
§3. 完全解析函数及黎曼面的概念 ..... 341    
1. 完全解析函数(341) 2. 单值性定理(342)    
3. 黎曼面概念(345)    
* §4. 多角形区域的共形映射 ..... 350    
1. 克里斯托费尔(Christoffel)－施瓦茨变换(351)    
2. 退化情形(356) 3. 广义多角形举例(359)    
    
第八章习题 ..... 363    
第九章 调和函数 ..... 367    
§1. 平均值定理与极值原理 ..... 367    
1. 平均值定理(367) 2. 极值原理(368)    
§2. 泊松积分公式与狄利克雷问题 ..... 369    
1. 泊松积分公式(369) 2. 狄利克雷问题(370) 3. 单位圆内狄利克雷问题的解(371) 4. 上半平面内狄利克雷问题的解(374)    
    
第九章习题 ..... 377

<!-- page: 17 -->

## 引言

我们知道，在解实系数一元二次方程

 $$ a x^{2}+b x+c=0(a\neq0) $$ 

时, 如果判别式  $ b^{2}-4ac<0 $, 就会遇到负数开平方的问题. 最简单的一个例子, 是在解方程

 $$ x^{2}+1=0 $$ 

时，就会遇到 -1 开平方的问题.

16世纪中叶，意大利卡尔丹 $ ^{①} $在1545年解三次方程时，首先产生了负数开平方的思想。他把40看作 $ 5+\sqrt{-15} $与 $ 5-\sqrt{-15} $的乘积，然而这只不过是一种纯形式 $ ^{②} $的表示而已。当时，谁也说不上这样表示究竟有什么好处。

为了使负数开平方有意义，也就是要使上述这类方程有解，我们需要再一次扩大数系，于是，就引进了虚数，使实数域扩大到复数域。但最初，由于对复数的有关概念及性质了解得不清楚，用它们进行计算又得到一些矛盾，因而，长期以来，人们把复数看作不能接受的“虚数”。直到17世纪和18世纪，随着微积分的发明与发展，情况才逐渐有了改变。另外的原因，是由于这个时期复数有了几何的解释，并把它与平面向量对应起来解决实际问题的缘故。

关于复数理论最系统的叙述，是由瑞士数学家欧拉(Euler)作出的。他在1777年系统地建立了复数理论，发现了复指数函数和三角函数间的关系，创立了复变函数论的一些基本定理，并开始把

<!-- page: 18 -->

它们用到水力学和地图制图图学上。用符号“i”作为虚数的单位，也是他首创的。此后，复数才被人们广泛承认和使用。

在复数域内考虑问题往往比较方便.例如,一元 n 次方程

 $$ a_{0}x^{n}+a_{1}x^{n-1}+\cdots+a_{n-1}x+a_{n}=0\quad\left(a_{0}\neq0\right), $$ 

在复数域内恒有解，其中系数  $ a_{0}, a_{1}, \cdots, a_{n} $ 都是复数。这就是著名的代数学基本定理，它用复变函数理论来证明，是非常简洁的。又如，在实数域内负数的对数无意义，而在复数域内，我们就可以定义负数的对数。

在 19 世纪，复变函数的理论经过法国数学家柯西（Cauchy）、德国数学家黎曼（Riemann）和魏尔斯特拉斯（Weierstrass）的巨大努力，已经形成了非常系统的理论，并且深刻地渗入到代数学、解析数论、微分方程、概率统计、计算数学和拓扑学等数学分支；同时，它在热力学、流体力学和电学等方面也有很多的应用。

20世纪以来，复变函数已被广泛地应用在理论物理、弹性理论和天体力学等方面，与数学中其他分支的联系也日益密切。致使经典的复变函数理论，如整函数与亚纯函数理论、解析函数的边值问题等有了新的发展和应用。并且，还开辟了一些新的分支，如复变函数逼近论、黎曼曲面、单叶解析函数论、多复变函数论、广义解析函数论和拟共形映射等。另外，在种种抽象空间的理论中，复变函数还常常为我们提供新思想的模型。

复变函数研究的中心对象是所谓解析函数，因此，复变函数论又称为解析函数论，简称函数论.

复变函数是我国数学工作者从事研究最早也最有成效的数学分支之一.我国老一辈的数学家在单复变函数及多复变函数方面做过许多重要的工作,不少成果均已达到当时的国际水平.而今,在他们的热忱帮助下,我国许多中青年数学工作者,正在健康成长,不少人已在数学的各个领域中做出了许多优异的成绩.

<!-- page: 19 -->

## 第一章 复数与复变函数

复变函数就是自变量为复数的函数.复变函数论是分析学的一个分支，故又称复分析.我们研究的主要对象，是在某种意义下可导的复变函数，通常称为解析函数.为建立这种解析函数的理论基础，在这一章中，我们首先引入复数域与复平面的概念；其次引入复平面上的点集、区域、若尔当曲线以及复变函数的极限与连续等概念；最后，还要引入复球面与无穷远点的概念.这门学科的一切讨论都是在复数范围内进行的.

#### §1. 复. 数

### 1. 复数域 形如

 $$ z=x+iy 或 z=x+yi $$ 

的数，称为复数，其中 x 和 y 是任意的实数，实数单位为 1.i 满足  $ i^{2} = -1 $，称为虚数单位。电工学里是例外，在那里习惯用 j 表示，而不是用 i。

实数 x 和 y 分别称为复数 z 的实部和虚部，常记为：

 $$ x=\mathrm{R e}z^{\prime},\quad y=\mathrm{I m}z. $$ 

复数  $ z_{1}=x_{1}+iy_{1} $ 及  $ z_{2}=x_{2}+iy_{2} $ 相等，是指它们的实部与实部相等，虚部与虚部相等，即

 $$ x_{1}+\mathrm{i}y_{1}=x_{2}+\mathrm{i}y_{2} $$

<!-- page: 20 -->

必须且只须

 $$ x_{1}=x_{2},\quad y_{1}=y_{2}. $$ 

虚部为零的复数就可看作实数，即  $ x + i \cdot 0 = x $；因此，全体实数是全体复数的一部分。特别， $ 0 + i \cdot 0 = 0 $。

虚部不为零的复数称为虚数；实部为零且虚部不为零的复数称为纯虚数.

复数  $ x + iy $ 和 x - iy 称为互为共轭复数，即  $ x + iy $ 是 x - iy 的共轭复数，或 x - iy 是  $ x + iy $ 的共轭复数。复数 z 的共轭复数常记为  $ \overline{z} $，于是

 $$ x-iy=\overline{x+iy}. $$ 

对于这样定义的复数.我们必须规定其运算方法.由于实数是复数的特例,规定复数运算的一个基本要求是:复数运算的法则施行于实数特例时,能够和实数运算的结果相符合,同时也要求复数运算能够满足实数运算的一般定律.

复数的加(减)法可按实部与实部相加(减)，虚部与虚部相加(减).即复数  $ z_{1}=x_{1}+iy_{1}, z_{2}=x_{2}+iy_{2} $ 相加(减)的法则是：

 $$ \boldsymbol{z}_{1}\pm\boldsymbol{z}_{2}=\left(x_{1}\pm x_{2}\right)+\mathrm{i}\left(y_{1}\pm y_{2}\right), $$ 

结果仍是复数. 我们称复数  $ z_{1} + z_{2} $ 是复数  $ z_{1} $ 与  $ z_{2} $ 的和, 称复数  $ z_{1} - z_{2} $ 是复数  $ z_{1} $ 与  $ z_{2} $ 的差.

复数的加法遵守交换律与结合律，而且减法是加法的逆运算，这些都很容易验证.

两个复数  $ z_{1}=x_{1}+iy_{1} $ 及  $ z_{2}=x_{2}+iy_{2} $ 相乘，可按多项式乘法法则进行，只需将结果中的  $ i^{2} $ 换成 -1，即

 $$ z_{1}z_{2}=\left(x_{1}x_{2}-y_{1}y_{2}\right)+\mathrm{i}\left(x_{1}y_{2}+y_{1}x_{2}\right), $$ 

结果仍是复数,我们称它为  $ z_{1} $ 与  $ z_{2} $ 的积.

也易验证，复数的乘法遵守交换律与结合律，且遵守乘法对于加法的分配律.

两个复数  $ z_{1}=x_{1}+iy_{1} $ 及  $ z_{2}=x_{2}+iy_{2} $ 相除（除数 $ \neq0 $）时，可

<!-- page: 21 -->

先把它写成分式的形式,然后分子分母同乘以分母的共轭复数,再进行简化,即

 $$ \frac{z_{1}}{z_{2}}=\frac{x_{1}x_{2}+y_{1}y_{2}}{x_{2}^{2}+y_{2}^{2}}+\mathrm{i}\frac{y_{1}x_{2}-x_{1}y_{2}}{x_{2}^{2}+y_{2}^{2}}\quad\left(z_{2}\neq0\right), $$ 

结果仍是复数,我们称它为  $ z_{1} $ 与  $ z_{2} $ 的商.这里除法是乘法的逆运算.

全体复数并引进上述运算后就称为复数域，常用 C 表示。在复数域内，我们熟知的一切代数恒等式，如

 $$ \begin{aligned}\boldsymbol{a}^{2}-\boldsymbol{b}^{2}&=\left(\boldsymbol{a}+\boldsymbol{b}\right)\left(\boldsymbol{a}-\boldsymbol{b}\right),\\\boldsymbol{a}^{3}-\boldsymbol{b}^{3}&=\left(\boldsymbol{a}-\boldsymbol{b}\right)\left(\boldsymbol{a}^{2}+\boldsymbol{a}\boldsymbol{b}+\boldsymbol{b}^{2}\right)\end{aligned} $$ 

等等,仍然成立.实数域和复数域都是代数学中所研究的“域”的实例.和实数域不同的是,在复数域中不能规定复数像实数那样的大小关系.事实上,若有像实数那样的大小关系,由于非零实数的平方大于零,而  $ i \neq 0 $ 时,则应有  $ i^{2} > 0 $,即 -1 > 0,这是不可能的.

2. 复平面 一个复数  $ z = x + iy $ 本质上由一对有序实数  $ (x, y) $ 惟一确定， $ (x, y) $ 就称为复数 z 的实数对形式。于是能够建立平面上全部的点和全体复数间的一一对应关系。换句话说，我们可以借助于横坐标为 x、纵坐标为 y 的点来表示复数  $ z = x + iy $（图 1.1）。

由于 x 轴上的点对应着实数，故 x 轴称为实轴；y 轴上的非原点的点对应着纯虚数，故 y 轴称为虚轴。这样表示复数 z 的平

面积为复平面或 z 平面.复平面也常用 C 表示.

引进了复平面之后，我们在“数”和“点”之间建立了联系。以后在研究复变函数时，常可借助于几何直观，还可采用几何术语。这也为复变函数应用于实际提供了条件，丰富了复变函数论的内容。为了方便起见，今后我们不再区分“数”和

<div style="text-align: center;"><img src="images/p0021_img_in_image_box_2810_4628_4015_5762.jpg" alt="图1.1" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.1</div> </div>

<!-- page: 22 -->

“点”、“数集”和“点集”，说到“点”可以指它所代表的“数”，说到“数”也可以指这个数代表的“点”。例如，我们常说“点 $ 1+i $”，“顶点为 $ z_{1} $， $ z_{2} $， $ z_{3} $的三角形”等等。

在复平面上，从原点到点  $ z = x + iy $ 所引的向量与这个复数 z 也构成一一对应关系（复数 0 对应着零向量），这种对应关系使复数的加（减）法与向量的加（减）法之间保持一致。

例如，设  $ z_{1}=x_{1}+\mathrm{i}y_{1}, z_{2}=x_{2}+\mathrm{i}y_{2} $，则

 $$ \boldsymbol{z}_{1}+\boldsymbol{z}_{2}=\left(x_{1}+x_{2}\right)+\mathrm{i}\left(y_{1}+y_{2}\right). $$ 

由图 1.2 可以看出， $ z_{1} + z_{2} $ 所对应的向量，就是  $ z_{1} $ 所对应的向量与  $ z_{2} $ 所对应的向量的和向量.

又如，将  $ z_{1}-z_{2} $ 表成  $ z_{1}+(-z_{2}) $，可以看出， $ z_{1}-z_{2} $ 所对应的向量就是  $ z_{1} $ 所对应的向量与  $ (-z_{2}) $ 所对应的向量的和向量，也就是从  $ z_{2} $ 到  $ z_{1} $ 的向量（图 1.3）.

<div style="text-align: center;"><img src="images/p0022_img_in_chart_box_756_3245_2176_4496.jpg" alt="图1.2" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.2</div> </div>


<div style="text-align: center;"><img src="images/p0022_img_in_image_box_2599_3288_3703_4540.jpg" alt="图 1.3" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.3</div> </div>


例 1.1 考虑一条江面上的水在某时刻的流动. 假定在江面上取好一坐标系 xOy, 我们把江面上任意一点 P 的速度 v 的两个分量记为  $ v_{x} $ 与  $ v_{y} $, 则我们可以把速度向量 v 写成复数 (图 1.4)

 $$ v^{i}=v_{x}+\mathrm{i}v_{y}. $$ 

人们经过长期的摸索与研究发现,对于很多的平面问题(如流体力学与弹性力学中的平面问题等)来说,用复数及复变函数作工

<!-- page: 23 -->

具是十分有效的,这正是由于复数可以表示平面向量的缘故.

3. 复数的模与辐角 表示复数 z 的位置，也可以借助于点 z 的极坐标 r 和  $ \theta $ 来确定（图 1.1）. 这里使原点与直角坐标系的原点重合，极轴与正实轴重合.

<div style="text-align: center;"><img src="images/p0023_img_in_image_box_2547_590_4029_1805.jpg" alt="图1.4" width="33%" /></div>


上面我们用向量 $ \overrightarrow{Oz} $来表示复数 $ z=x+iy $，其中x,y顺次等于 $ \overrightarrow{Oz} $沿x

<div style="text-align: center;"><div style="text-align: center;">图1.4</div> </div>


轴与 y 轴的分量. 向量  $ \overrightarrow{Oz} $ 的长度称为复数 z 的模或绝对值, 以符号  $ \left|z\right| $ 或 r 表示, 因而有

 $$ r=\mid z\mid=\sqrt{x^{2}+y^{2}}\geqslant0, $$ 

且 $ \left|z\right|=0 $的充要条件是z=0.

这里引进的模的概念与对于实数的绝对值的概念是一致的。由于复数 z 的模  $ |z| $ 是非负实数，所以能够比较大小。同样，复数的实、虚部也能够比较大小。

根据图 1.1, 我们有不等式

 $$ \begin{array}{l}\mid x\mid\leqslant\mid z\mid,\mid y\mid\leqslant\mid z\mid,\mid z\mid\leqslant\mid x\mid+\mid y\mid,\\ -\mid z\mid\leqslant\mathrm{Re}z\leqslant\mid z\mid,-\mid z\mid\leqslant\mathrm{Im}z\leqslant\mid z\mid.\end{array} $$ 

及

根据图 1.2, 我们有不等式

$$  \begin{aligned}&\left|z_{1}+z_{2}\right|\leqslant\left|z_{1}\right|+\left|z_{2}\right|,\\&( 三角形两边之和大于第三边 )\end{aligned}   \tag*{(1.2)}$$

它称为三角不等式.

此外，根据图 1.3，我们还有不等式

$$  \mid\mid z_{1}\mid-\mid z_{2}\mid\mid\leqslant\mid z_{1}-z_{2}\mid.   \tag*{(1.3)}$$

（三角形两边之差小于第三边）

(1.2)及(1.3)中等号成立的几何意义是:复数  $ z_{1} $、 $ z_{2} $ 所表示的两个向量共线且同向.即

<!-- page: 24 -->

$$ z_{1}\ne0,z_{2}\ne0\  时 \ ,z_{1}=kz_{2}\left(k>0\right). $$ 

用数学归纳法可得推广了的三角不等式

$$  \mid\boldsymbol{z}_{1}+\boldsymbol{z}_{2}+\cdots+\boldsymbol{z}_{n}\mid\leqslant\mid\boldsymbol{z}_{1}\mid+\mid\boldsymbol{z}_{2}\mid+\cdots\div\mid\boldsymbol{z}_{n}\mid.   \tag*{(1.2)  ^{\prime} }$$

由图 1.3 可见， $ \left|z_{1}-z_{2}\right| $ 表示点  $ z_{1} $ 与点  $ z_{2} $ 的距离，记为

 $$ d\left(z_{1},z_{2}\right)=\left|z_{1}-z_{2}\right|. $$ 

两复数差的模的这个几何意义是非常重要的. 它还可以借助解析

几何中两点间的距离公式用解析方法得出：

 $$ \begin{aligned}\left|z_{1}-z_{2}\right|&=\left|\left(x_{1}+\mathrm{i}y_{1}\right)-\left(x_{2}+\mathrm{i}y_{2}\right)\right|\\&=\sqrt{\left(x_{1}-x_{2}\right)^{2}+\left(y_{1}-y_{2}\right)^{2}}.\end{aligned} $$ 

实轴正向到非零复数  $ z = x + iy $ 所对应的向量  $ \overrightarrow{Oz} $ 间的夹角  $ \theta $ 介于

 $$ \tan\theta=\frac{y}{x}, $$ 

称为复数 z 的辐角 (Argument)，记为

 $$ \theta=\mathrm{A r g}z. $$ 

我们知道，任一非零复数 z 有无穷多个辐角，今以  $ \underbrace{\arg z} $ 表示其中的一个特定值，并称合条件

$$  -\pi<\arg z\leq\pi   \tag*{(1.4)}$$

的一个为  $ \operatorname{Arg} z $ 的主值，或称之为 z 的主辐角. 于是

$$  \begin{aligned}\theta&=\operatorname{Arg}z=\arg z+2k\pi.\\&\left(k=0,\pm1,\pm2,\cdots\right)\end{aligned}   \tag*{(1.5)}$$

注意 当 z=0 时，辐角无意义.

当  $ \arg z (z \neq 0) $ 表  $ z $ 的主辐角时，它与反正切  $ \operatorname{Arctan} \frac{y}{x} $ 的主值  $ \arctan \frac{y}{x} $ 有如下关系（图 1.5, 1.6）（注意  $ -\pi < \arg z \leq \pi, -\frac{\pi}{2} < \arctan \frac{y}{x} < \frac{\pi}{2} $）：

<!-- page: 25 -->

$$ \begin{aligned}&\arg z=\left\{\begin{aligned}\\ &\arctan\frac{y}{x},& 当 x>0,y\leqslant0;\\&\frac{\pi}{2},& 当 x=0,y>0;\\&\arctan\frac{y}{x}+\pi, 当 x<0,y\geqslant0;\\&(z\neq0)\\&\arctan\frac{y}{x}-\pi, 当 x<0,y<0;\\&-\frac{\pi}{2},& 当 x=0,y<0.\\ &\end{aligned}\right.\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0025_img_in_image_box_591_2299_2069_3717.jpg" alt="图 1.5" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.5</div> </div>


<div style="text-align: center;"><img src="images/p0025_img_in_image_box_2368_2318_3927_3719.jpg" alt="图1.6" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.6</div> </div>


例 1.2 求  $ \operatorname{Arg}(2-2i) $ 及  $ \operatorname{Arg}(-3+4i) $.

 $$ \begin{array}{l}\operatorname{Arg}(2-2i)=\arg(2-2i)+2k\pi\\=\arctan\frac{-2}{2}+2k\pi\\=-\frac{\pi}{4}+2k\pi.\end{array} $$ 

 $$ (k=0,\pm1,\pm2,\cdots) $$ 

 $$ \begin{array}{r l r}{\mathrm{A r g}(-3+4\mathrm{i})}&{=\mathrm{a r g}(-3+4\mathrm{i})+2k\pi}\\ &{}&\\ &{,}&{=\arctan{\frac{4}{-3}}+\pi+2k\pi}\end{array} $$

<!-- page: 26 -->

$$ \begin{aligned}&=(2k+1)\pi-\arctan\frac{4}{3}.\\&(k=0,\pm1,\pm2,\cdots)\end{aligned} $$ 

例 1.3 已知流体在某点 M 的速度  $ v = -1 - i $，求其大小和方向.

解 大小： $ |v| = \sqrt{2} $;

 $$  方向 :\arg v=\arctan\frac{-1}{-1}-\pi=-\frac{3\pi}{4}. $$ 

从直角坐标与极坐标的关系,我们可以用复数的模与辐角来表示非零复数z,即(由图1.1)

$$  z=r\left(\cos\theta+\mathrm{i}\sin\theta\right).   \tag*{(1.6)}$$

特别，当 r=1 时有

 $$ z=\cos\theta+\mathrm{~i~}\sin\theta, $$ 

这种复数称为单位复数.

我们引出熟知的欧拉公式：

$$  \mathrm{e}^{\mathrm{i}\theta}=\cos\theta+\mathrm{i}\sin\theta,   \tag*{(1.7)}$$

并且容易验证

$$  \left.\begin{array}{l}{\mathrm{e}^{\mathrm{i}\theta_{1}}\mathrm{e}^{\mathrm{i}\theta_{2}}=\mathrm{e}^{\mathrm{i}\left(\theta_{1}+\theta_{2}\right)}\mathrm{~,~}}\\ {\frac{\mathrm{e}^{\mathrm{i}\theta_{1}}}{\mathrm{e}^{\mathrm{i}\theta_{2}}}=\mathrm{e}^{\mathrm{i}\left(\theta_{1}-\theta_{2}\right)}\mathrm{~.~}}\end{array}\right\}   \tag*{(1.8)}$$

利用公式(1.7)，就可以把(1.6)改写成

$$  z=r\mathrm{e}^{\mathrm{i}\theta}.   \tag*{(1.9)}$$

也就是说，任一非零复数 z 总可以表成

$$  z=\mid z\mid\mathrm{e}^{\mathrm{i a r g}z},   \tag*{(1.9)'}$$

这里的  $ \arg z $ 不必取主值.

我们分别称(1.6)及(1.9)(或(1.9) $ ^{1} $)式为非零复数 z 的三角形式和指数形式，并称  $ z = x + iy $ 为复数 z 的代数形式。复数的这三种表示法，可以互相转换，以适应讨论不同问题时的需要，且使用起来各有其便。

<!-- page: 27 -->

例 1.4

 $$ \begin{array}{c}1+\mathrm{i}=\sqrt{2}\left(\cos\frac{\pi}{4}+\mathrm{i}\sin\frac{\pi}{4}\right)=\sqrt{2}\mathrm{e}^{\frac{\pi}{4}\mathrm{i}};\\\mathrm{i}=1\cdot\left(\cos\frac{\pi}{2}+\mathrm{i}\sin\frac{\pi}{2}\right)=\mathrm{e}^{\frac{\pi}{2}\mathrm{i}};\\1=1\cdot(\cos0+\mathrm{i}\sin0)=\mathrm{e}^{0\cdot\mathrm{i}};\\-2=2(\cos\pi+\mathrm{i}\sin\pi)=2\mathrm{e}^{\pi\mathrm{i}};\\-3\mathrm{i}=3\left[\cos\left(-\frac{\pi}{2}\right)+\mathrm{i}\sin\left(-\frac{\pi}{2}\right)\right]=3\mathrm{e}^{-\frac{\pi}{2}\mathrm{i}}.\end{array} $$ 

还有  $ e^{-\frac{\pi}{2}i} = -i, e^{\pi i} = -1, e^{2k\pi i} = 1 $ (k 为整数).

例 1.5 将复数

 $$ 1-\cos\varphi+\mathrm{i}\sin\varphi\quad(0<\varphi\leqslant\pi) $$ 

化为指数形式.

 $$ \begin{aligned} 解 \quad 原式 &=2\sin^{2}\frac{\varphi}{2}+2i\sin\frac{\varphi}{2}\cos\frac{\varphi}{2}\\&=2\sin\frac{\varphi}{2}\left[\sin\frac{\varphi}{2}+i\cos\frac{\varphi}{2}\right]\\&=2\sin\frac{\varphi}{2}\left[\cos\left(\frac{\pi}{2}-\frac{\varphi}{2}\right)+i\sin\left(\frac{\pi}{2}-\frac{\varphi}{2}\right)\right]\\&=2\sin\frac{\varphi}{2}e^{\left(\frac{\pi}{2}-\frac{\varphi}{2}\right)i}.\end{aligned} $$ 

当  $ z = x + iy \neq 0 $，记  $ \arg z = \theta $（主值），则

 $$ \tan\frac{\theta}{2}=\frac{\sin\theta}{1+\cos\theta}=\frac{r\sin\theta}{r+r\cos\theta}=\frac{y}{x+\sqrt{x^{2}+y^{2}}}, $$ 

所以  $ \arg z = \theta $ (主值) =  $ 2\arctan \frac{y}{x + \sqrt{x^{2} + y^{2}}} $.

对于  $ z_{1}=r_{1}e^{\mathrm{i}\theta_{1}} $， $ z_{2}=r_{2}e^{\mathrm{i}\theta_{2}} $，则

 $ z_{1}=z_{2}\Leftrightarrow r_{1}=r_{2},\theta_{1}=\theta_{2} $（或  $ \theta_{1}=\theta_{2}+2k\pi,k $ 为整数）.

利用复数的指数形式作乘除法较简单. 因由(1.8)可立得

<!-- page: 28 -->

$$  \left.\begin{array}{l}{\mathcal{Z}_{1}\mathcal{Z}_{2}=r_{1}\mathrm{e}^{\mathrm{i}\theta_{1}}\;r_{2}\mathrm{e}^{\mathrm{i}\theta_{2}}=r_{1}r_{2}\mathrm{e}^{\mathrm{i}\left(\theta_{1}+\theta_{2}\right)}\;,}\\ {\displaystyle\frac{\mathcal{Z}_{1}}{\mathcal{Z}_{2}}=\frac{r_{1}\mathrm{e}^{\mathrm{i}\theta_{1}}}{r_{2}\mathrm{e}^{\mathrm{i}\theta_{2}}}=\frac{r_{1}}{r_{2}}\mathrm{e}^{\mathrm{i}\left(\theta_{1}-\theta_{2}\right)}\;,}\end{array}\right\}   \tag*{(1.10)}$$

所以

$$  \begin{align*}\left|z_{1}z_{2}\right|&=\left|z_{1}\right|\left|z_{2}\right|,\left|\frac{z_{1}}{z_{2}}\right|=\frac{\left|z_{1}\right|}{\left|z_{2}\right|}\left(z_{2}\neq0\right),\\\mathrm{Arg}\left(z_{1}z_{2}\right)&=\mathrm{Arg}z_{1}+\mathrm{Arg}z_{2},\\\mathrm{Arg}\frac{z_{1}}{z_{2}}&=\mathrm{Arg}z_{1}-\mathrm{Arg}z_{2}.\end{align*}   \tag*{(1.11)}$$

公式(1.10)的第一式说明， $ z_{1}z_{2} $所对应的向量是把 $ z_{1} $所对应

的向量伸缩  $ r_{2} = |z_{2}| $ 倍，然后再旋转一个角度  $ \theta_{2} = \arg z_{2} $ 得到的（图1.7）.

特别是，当  $ |z_{2}| = 1 $ 时，只需旋转一个角度  $ \theta_{2} = \arg z_{2} $ 就行了。这就是说，以单位复数乘任何数，几何上相当于将此数所对应的向量旋转一个角度。

<div style="text-align: center;"><img src="images/p0028_img_in_image_box_2616_2309_4026_3464.jpg" alt="图1.7" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.7</div> </div>


特别，iz 相当于将 z 所对应的向量  $ \overrightarrow{Oz} $ 沿反时针方向旋转  $ \frac{\pi}{2} $. 这里 i 称为旋转乘数, 另外.

 $$ \arg\left(\alpha z\right)=\arg z\quad\left(\alpha>0\right). $$ 

注1 在复平面上，一直线绕其上一定点旋转，可有两种旋转方向，一种是“反时针”的，一种是“顺时针”的。按惯例，我们规定反时针方向旋转的角度为正，顺时针方向旋转的角度为负。

注2 当把复数作为向量看待时,复数的乘法既不同于向量的点积(或纯量积),也不同于向量的叉积(或向量积).

上面关于辐角的两个等式(1.12)，两边各是无穷多个数(角度)的数集.例如，设(1.12)第一个等式右边

 $$ \mathrm{A r g}z_{1}=\left\{\frac{\pi}{6}+2n\pi\right\}_{n=0,\pm1,\cdots}, $$

<!-- page: 29 -->

$$ \mathrm{A r g}z_{2}=\left\{\frac{\pi}{4}+2m\pi\right\}_{m=0,\pm1,\cdots}, $$ 

则左边

 $$ \mathrm{A r g}z_{1}z_{2}=\left\{\frac{5\pi}{12}+2k\pi\right\}_{k=0,\pm1,\cdots}, $$ 

(1.12)的第一个等式意味着,在等式左边取出一个数值(相当于取定一个k值),等式右边也可以相应地分别找出m与n的值,使得右边的和数等于左边之值;反过来,也对.

注意 公式(1.12)的  $ \operatorname{Arg} z $ 可以换成  $ \arg z $，但  $ \arg z $ 应理解为辐角的某个特定值，不必是主值；若均理解为主值，则两端允许相差  $ 2\pi $ 的整倍数。即有

$$  \left.\begin{array}{l}{\arg z_{1}z_{2}=\arg z_{1}+\arg z_{2}+2k_{1}\pi,}\\ {\quad}\\ {\arg\frac{z_{1}}{z_{2}}=\cdot\arg z_{1}-\arg z_{2}+2k_{2}\pi,}\end{array}\right\}   \tag*{(1.12)  ^{\prime} }$$

其中  $ k_{1} $、 $ k_{2} $ 各表示某个适当整数， $ \arg z $ 表示主值.

例 1.6 对于复数  $ \alpha $、 $ \beta $，若  $ \alpha\beta=0 $，则  $ \alpha $、 $ \beta $ 至少有一为零。试证之。

证 若  $ \alpha\beta=0 $，则必  $ \left|\alpha\beta\right|=0 $，因而

 $$ \mid\alpha\mid\mid\beta\mid=0. $$ 

由实数域中的对应结果知  $ |\alpha| $、 $ |\beta| $ 至少有一为零。所以  $ \alpha $、 $ \beta $ 至少有一为零。

4. 复数的乘幂与方根 作为乘积的特例, 我们考虑非零复数 z 的正整数次幂  $ z^{n} $, 它是 n 个相同因子的乘积. 设  $ z = re^{i\theta} $, 则

 $$ z^{n}=r^{n}\mathrm{e}^{\mathrm{i}n\theta}=r^{n}\left(\cos n\theta+\mathrm{i}\sin n\theta\right), $$ 

从而有

 $$ |\mathrm{~z~}^{n}|=|\mathrm{~z~}|^{n}, $$ 

 $$ \operatorname{A r g}z^{n}=n\operatorname{A r g}z. $$ 

当 r=1 时，则得棣莫弗(De Moivre)公式

 $$ \left(\cos\theta+\mathrm{i}\sin\theta\right)^{n}=\cos n\theta+\mathrm{i}\sin n\theta. $$ 

求非零复数 z 的 n 次方根，相当于解二项方程

<!-- page: 30 -->

$$  w^{n}=z\quad(n\geqslant2, 整数 ).   \tag*{(1.13)}$$

今记其根的总体为 $ \sqrt[n]{z} $，下面我们来求它们.

设  $ z = re^{\mathrm{i}\theta} $,  $ w = \rho e^{\mathrm{i}\varphi} $，则(1.13)变形为

 $$ \rho^{n}\mathrm{e}^{\mathrm{i}n\varphi}=r\mathrm{e}^{\mathrm{i}\theta}\mathrm{,} $$ 

从而得两个方程

 $$ \rho^{n}=r,n\varphi=\theta+2k\pi, $$ 

解出得

 $$ \rho=\sqrt[n]{r}\left( 取算术根 \right),\varphi=\frac{\theta+2k\pi}{n}, $$ 

从而有

 $$ \left|\sqrt[n]{z}\right|=\sqrt[n]{|z|}, $$ 

 $$ \mathrm{A r g}\sqrt[n]{z}=\frac{\mathrm{A r g}z}{n}. $$ 

因此 z 的  $ n $ 次方根为

$$  \begin{align*}\mathcal{W}_{k}&=\left(\sqrt[n]{z}\right)_{k}=\sqrt[n]{r}\mathrm{e}^{\mathrm{i}\frac{\theta+2k\pi}{n}}\\&=\mathrm{e}^{\mathrm{i}\frac{2k\pi}{n}}\cdot\sqrt[n]{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{n}}.\end{align*}   \tag*{(1.14)}$$

这里 k 表面上可以取  $ 0, \pm 1, \pm 2\cdots $，但实际上只要取  $ k=0,1,\cdots $，n-1 就可得出 (1.13) 的总共 n 个不同的根。所以记号  $ \sqrt[n]{z} $ 与记号  $ \left(\sqrt[n]{z}\right)_{k}(k=0,1,2,\cdots,n-1) $ 是一致的。

现在.我们将(1.14)表为

 $$ \begin{array}{r}{\varpi_{k}=\left(\sqrt[n]{\mathcal{z}}\right)_{k}=\mathrm{e}^{\mathrm{i}\frac{2k\pi}{n}}\cdot\varpi_{0},}\end{array} $$ 

其中  $ \omega_{0}=\sqrt[n]{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{n}} $ 。为了在复数平面上表示  $ \sqrt[n]{z} $ 的不同值  $ \omega_{k} $，可由  $ \omega_{0} $ 依次绕原点旋转

 $$ \frac{2\pi}{n},2\cdot\frac{2\pi}{n},3\cdot\frac{2\pi}{n},\cdots, $$ 

但当 k 取到 n 时，又与  $ w_{0} $ 重合了。故非零复数 z 的 n 次方根共有 n 个，它们沿中心在原点、半径为  $ \sqrt[n]{r} $（取算术根）的圆周均匀地分布着，即它们是内接于该圆周的正 n 边形的 n 个顶点（图 1.8 是 n

<!-- page: 31 -->

=6 的情形).

<div style="text-align: center;"><img src="images/p0031_img_in_image_box_1463_750_2986_2254.jpg" alt="图1.8" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.8</div> </div>


(1.14)中  $ \mathrm{e}^{\mathrm{i}\frac{2k\pi}{n}}(k=0,1,2,\cdots,n-1) $ 为 1 的 n 个  $ n $ 次方根，通常记为  $ 1,\omega,\omega^{2},\cdots,\omega^{n-1} $ ( $ \omega=\mathrm{e}^{\mathrm{i}\frac{2\pi}{n}} $). 从而  $ z\neq0 $ 的 n 个 n 次方根为：

 $$ \begin{array}{r}{\mathcal{w}_{0},\omega\mathcal{w}_{0},\omega^{2}\mathcal{w}_{0},\cdots,\omega^{n-1}\mathcal{w}_{0}.}\end{array} $$ 

还有  $ 1 + \omega + \omega^{2} + \cdots + \omega^{n-1} = 0, \omega^{n} = 1 $.

因为  $ \omega $ 为二项方程  $ w^{n}=1 $ 之根，即

 $$ \omega^{n}=1\Longleftrightarrow(1-\omega)\left(1+\omega+\omega^{2}+\cdots+\omega^{n-1}\right)=0. $$ 

特别，当 n=3 时， $ \omega=e^{\frac{2\pi}{3}\mathrm{i}}=-\frac{1}{2}+\frac{\sqrt{3}}{2}\mathrm{i} $

且有  $ \omega^{3}=1,1+\omega+\omega^{2}=0 $.

例 1.7 求  $ \cos 3\theta $ 及  $ \sin 3\theta $ 用  $ \cos \theta $ 与  $ \sin \theta $ 表示的式子.

解 由棣莫弗公式

 $$ \begin{aligned}\cos3\theta+\mathrm{i}\sin3\theta&=(\cos\theta+\mathrm{i}\sin\theta)^{3}\\&=\cos^{3}\theta+3\mathrm{i}\cos^{2}\theta\cdot\sin\theta-3\cos\theta\cdot\sin^{2}\theta-\mathrm{i}\sin^{3}\theta,\end{aligned} $$ 

因此  $ \cos 3\theta = \cos^{3}\theta - 3\cos\theta \cdot \sin^{2}\theta = 4\cos^{3}\theta - 3\cos\theta $,

及  $ \sin 3\theta = 3\cos^{2}\theta\sin\theta - \sin^{3}\theta = 3\sin\theta - 4\sin^{3}\theta $

例 1.8 计算  $ \sqrt[3]{-8} $.

<!-- page: 32 -->

解 因 -8 = 8 ( $ \cos \pi + i \sin \pi $), 故

 $$ \begin{aligned}\left(\sqrt[3]{-8}\right)_{k}=&\sqrt[3]{8}\left(\cos\frac{\pi+2k\pi}{3}+\mathrm{i}\sin\frac{\pi+2k\pi}{3}\right).\\&\left(k=0,1,2\right)\end{aligned} $$ 

当 k=0 时， $ \left(\sqrt[3]{-8}\right)_{0}=\sqrt[3]{8}\left(\cos\frac{\pi}{3}+i\sin\frac{\pi}{3}\right) $

 $ =2\left(\frac{1}{2}+\frac{\sqrt{3}}{2}i\right)=1+\sqrt{3}i; $

当 k=1 时， $ \left(\sqrt[3]{-8}\right)_{1}=2\left(\cos\pi+\mathrm{i}\sin\pi\right)=-2 $;

 $$ \begin{aligned}\left(\sqrt[3]{-8}\right)_{2}&=2\left(\cos\frac{5\pi}{3}+\mathrm{i}\sin\frac{5\pi}{3}\right)\\&=2\left(\cos\frac{\pi}{3}-\mathrm{i}\sin\frac{\pi}{3}\right)\\&=1-\sqrt{3}\mathrm{i}.\end{aligned} $$ 

注 在实数域内，规定 -8 的三次方根为 -2，即规定  $ \sqrt[3]{-8} = -\sqrt[3]{8} = -2 $。这时  $ \sqrt[3]{-8} $ 就只取上述三值之一的实值  $ \left(\sqrt[3]{-8}\right)_{1} $。

5. 共轭复数 设  $ z = x + iy $，则 z 的共轭复数为  $ \overline{z} = x - \langle  $ 显然

$$  \mid\overline{z}\mid=\mid z\mid,\operatorname{Arg}\overline{z}=-\operatorname{Arg}z.   \tag*{(1.15)}$$

这表明在复平面上,z 与  $ \overline{z} $ 两点对于实轴是对称点.

我们也容易验证下列公式：

(1)  $ \overline{(\overline{z})}=z $,  $ \overline{z_{1}\pm z_{2}}=\overline{z_{1}\pm z_{2}} $.

(2)

 $$ \overline{{z_{1}z_{2}}}=\overline{{z_{1}}}\overline{{z_{2}}},\overline{{\left(\frac{z_{1}}{z_{2}}\right)}}=\frac{\overline{{z_{1}}}}{\overline{{z_{2}}}}\quad\left(z_{2}\neq0\right). $$ 

(3)  $ \left|z\right|^{2}=zz $, Re  $ z=\frac{z+z}{2} $, Im  $ z=\frac{z-z}{2i} $.

（4）设  $ R(a, b, c, \cdots) $ 表示对于复数 a, b, c, c,  $ \cdots $ 的任一有理运算；则

 $$ \overline{R(a,b,c,\cdots)}=R(\overline{a},\overline{b},\overline{c},\cdots). $$

<!-- page: 33 -->

熟练、灵活地运用这些简单公式，对化简计算、解答问题都会带来方便.

例 1.9 求复数

 $$ w=\frac{1+z}{1-z}\quad( 复数 z\neq1) $$ 

的实部、虚部和模.

解 （1）因为

 $$ \begin{aligned}w&=\frac{1+z}{1-z}=\frac{(1+z)(1-\overline{z})}{(1-z)\overline{(1-z)}}=\frac{1-z\overline{z}+z-\overline{z}}{|1-z|^2}\\&=\frac{1-|z|^2+2i\mathrm{Im}z}{|1-z|^2},\end{aligned} $$ 

所以

 $$ \mathrm{R e}~\omega=\frac{1-|z|^{2}}{|1-z|^{2}},\qquad\mathrm{I m}~\omega=\frac{2\mathrm{I m}~z}{|1-z|^{2}}. $$ 

（2）因为

 $$ \begin{aligned}|\boldsymbol{w}|^{2}&=\boldsymbol{w}\overline{\boldsymbol{w}}=\frac{1+z}{1-z}\cdot\frac{1+\overline{z}}{1-z}=\frac{1+z\overline{z}+z+\overline{z}}{|1-z|^{2}}\\&=\frac{1+|z|^{2}+2\mathrm{Re}z}{|1-z|^{2}},\end{aligned} $$ 

所以

 $$ \mid\mathrm{~w~}\mid=\frac{\sqrt{1+\mid z\mid^{2}+2\mathrm{R e}z}}{1-z}. $$ 

例 1.10 设  $ z_{1} $ 及  $ z_{2} $ 是两个复数，试证

 $$ \mid z_{1}+z_{2}\mid^{2}=\mid z_{1}\mid^{2}+\mid z_{2}\mid^{2}+2\mathrm{R e}\left(z_{1}\overline{z_{2}}\right), $$ 

并应用此等式证明三角不等式(1.2).

证

 $$ \begin{align*}\left|z_{1}+z_{2}\right|^{2}&=\left(z_{1}+z_{2}\right)\overline{\left(z_{1}+z_{2}\right)}\\&=\left(z_{1}+z_{2}\right)\overline{\left(z_{1}+\overline{z_{2}}\right)}\\&=\overline{z_{1}z_{1}}+z_{2}\overline{z_{2}}+z_{1}\overline{z_{2}}+\overline{z_{1}z_{2}}\\&=\left|z_{1}\right|^{2}+\left|z_{2}\right|^{2}+z_{1}\overline{z_{2}}+\overline{z_{1}z_{2}}\\&=\left|z_{1}\right|^{2}+\left|z_{2}\right|^{2}+2\mathrm{Re}\left(z_{1}\overline{z_{2}}\right).\end{align*} $$

<!-- page: 34 -->

其次，由所证等式以及

 $$ \mathbf{R e}\left(\boldsymbol{z}_{1}\overline{\boldsymbol{z}_{2}}\right)\leqslant\left|\boldsymbol{z}_{1}\overline{\boldsymbol{z}_{2}}\right|=\left|\boldsymbol{z}_{1}\right|\left|\boldsymbol{z}_{2}\right| $$ 

就可导出三角不等式(1.2).

例 1.11 若  $ \left|a\right|<1,\left|b\right|<1 $ ，试证

 $$ \left|\frac{a-b}{1-\overline{ab}}\right|<1. $$ 

证 两端平方，比较  $ \left|\frac{a-b}{1-ab}\right|^{2} $ 与 1 的大小，即比较  $ \left|a-b\right|^{2} $ 与  $ \left|1-\overline{ab}\right|^{2} $ 的大小. 由上例可知

 $$ |a-b|^{2}=|a|^{2}+|b|^{2}-2\mathrm{R e}(\overline{ab}), $$ 

 $$ \mid1-\overline{ab}\mid^{2}=1+\mid a\mid^{2}\mid b\mid^{2}-2\mathrm{Re}(\overline{ab}), $$ 

则

 $$ \begin{aligned}I&=|\boldsymbol{1}-\overline{\boldsymbol{a}}\boldsymbol{b}|^{2}-|\boldsymbol{a}-\boldsymbol{b}|^{2}\\&=1+|\boldsymbol{a}|^{2}|\boldsymbol{b}|^{2}-|\boldsymbol{a}|^{2}-|\boldsymbol{b}|^{2}\\&=\left(\boldsymbol{1}-\mid\boldsymbol{a}\mid^{2}\right)\left(\boldsymbol{1}-\mid\boldsymbol{b}\mid^{2}\right).\end{aligned} $$ 

由假设  $ \left|a\right|<1,\left|b\right|<1 $ ,则 I>0 ,故得证.

6. 复数在几何上的应用举例 下面我们举例说明两方面的问题:怎样用复数所适合的方程(或不等式)来刻画适合某种几何条件的平面图形;怎样从复数所适合的方程(或不等式)来确定平面图形的特征.

（1）曲线的复数方程 $ ^{①} $

例 1.12 连接  $ z_{1} $ 及  $ z_{2} $ 两点的线段的参数方程为

 $$ z=z_{1}+t\left(z_{2}-z_{1}\right)\quad\left(0\leqslant t\leqslant1\right). $$ 

过  $ z_{1} $ 及  $ z_{2} $ 两点的直线(图 1.9)的参数方程为

 $$ z=z_{1}+t\left(z_{2}-z_{1}\right)\quad\left(-\infty<t<+\infty\right). $$ 

由此可知，三点  $ z_{1} $、 $ z_{2} $、 $ z_{3} $ 共线的充要条件为

 $$ \frac{z_{3}-z_{1}}{z_{2}-z_{1}}=t\ (t\  为一非零实数 ). $$

<!-- page: 35 -->

<div style="text-align: center;"><img src="images/p0035_img_in_image_box_1454_609_3039_1886.jpg" alt="图1.9" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.9</div> </div>


 $$ \left(\Leftrightarrow\operatorname{Im}\left(\frac{\mathcal{Z}_{3}-\mathcal{Z}_{1}}{\mathcal{Z}_{2}-\mathcal{Z}_{1}}\right)=0.\right) $$ 

例 1.13 z 平面上以原点为心, R 为半径的圆周的方程为

 $$ \left|z\right|=R\quad\left( 图 1.10(a)\right). $$ 

z 平面上以  $ z_{0} \neq 0 $ 为心，R 为半径的圆周的方程为

 $$ \left|z-z_{0}\right|=R\quad\left( 图 1.10(b)\right). $$ 

z 平面上实轴的方程为  $ \text{Im } z = 0 $;

虚轴的方程为  $ \mathrm{Re} z = 0 $.

<div style="text-align: center;"><img src="images/p0035_img_in_image_box_615_3874_2060_5238.jpg" alt="(a)" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0035_img_in_image_box_2426_3840_3874_5069.jpg" alt="(b)" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 1.10</div> </div>


注 由本章习题(一)7、8、10 可见，直线和圆周等平面曲线皆可用多种形式给出其方程.

<!-- page: 36 -->

##### （2）应用复数证明几何问题

例 1.14 求证: 三个复数  $ z_{1}, z_{2}, z_{3} $ 成为一个等边三角形的三顶点的充要条件是它们适合等式

 $$ \begin{array}{r}{\boldsymbol{z}_{1}^{2}+\boldsymbol{z}_{2}^{2}+\boldsymbol{z}_{3}^{2}=\boldsymbol{z}_{2}\boldsymbol{z}_{3}+\boldsymbol{z}_{3}\boldsymbol{z}_{1}+\boldsymbol{z}_{1}\boldsymbol{z}_{2}.}\end{array} $$ 

证  $ \triangle z_{1}z_{2}z_{3} $ 是等边三角形的充要条件为: 向量  $ \overrightarrow{z_{1}z_{2}} $ 绕  $ z_{1} $ 旋转  $ \frac{\pi}{3} $ 或  $ -\frac{\pi}{3} $ 即得向量  $ \overrightarrow{z_{1}z_{3}} $，也就是

 $$ z_{3}-z_{1}=\left(z_{2}-z_{1}\right)\mathrm{e}^{\pm\frac{\pi}{3}\mathrm{i}}, $$ 

即

 $$ \frac{z_{3}-z_{1}}{z_{2}-z_{1}}=\frac{1}{2}\pm\frac{\sqrt{3}}{2}\mathrm{i}, $$ 

即

 $$ \frac{z_{3}-z_{1}}{z_{2}-z_{1}}-\frac{1}{2}=\pm\frac{\sqrt{3}}{2}\mathrm{i}, $$ 

两端平方化简，即得

 $$ \boldsymbol{z}_{1}^{2}+\boldsymbol{z}_{2}^{2}+\boldsymbol{z}_{3}^{2}=\boldsymbol{z}_{2}\boldsymbol{z}_{3}+\boldsymbol{z}_{3}\boldsymbol{z}_{1}+\boldsymbol{z}_{1}\boldsymbol{z}_{2}. $$ 

例 1.15 证明三角形的内角和等于  $ \pi $.

证 设三角形的三个顶点分别为  $ z_{1}, z_{2}, z_{3} $; 对应的三个顶角分别为  $ \alpha, \beta, \gamma $ (如图 1.11). 于是

<div style="text-align: center;"><img src="images/p0036_img_in_image_box_1325_4445_3115_5213.jpg" alt="图 1.11" width="40%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.11</div> </div>


 $$ \alpha=\arg\frac{z_{2}-z_{1}}{z_{3}-z_{1}}, $$

<!-- page: 37 -->

$$ \beta=\arg\frac{\dot{z}_{3}-\dot{z}_{2}}{z_{1}-\dot{z}_{2}}, $$ 

 $$ \gamma=\arg\frac{z_{1}-z_{3}}{z_{2}-z_{3}}. $$ 

由于

 $$ \frac{z_{2}-z_{1}}{z_{3}-z_{1}}\bullet\frac{z_{3}-z_{2}}{z_{1}-z_{2}}\bullet\frac{z_{1}-z_{3}}{z_{2}-z_{3}}=-1, $$ 

根据公式 $  (1.12)^{\prime}  $,

 $$ \begin{aligned}&\arg\frac{z_{2}-z_{1}}{z_{3}-z_{1}}+\arg\frac{z_{3}-z_{2}}{z_{1}-z_{2}}+\arg\frac{z_{1}-z_{3}}{z_{2}-z_{3}}\\ &=\arg(-1)+2k\pi=\pi+2k\pi(k 为某个整数 ).\\ \end{aligned} $$ 

由假设  $ 0 < \alpha < \pi, 0 < \beta < \pi, 0 < \gamma < \pi $，所以

 $$ 0<\alpha+\beta+\gamma<3\pi, $$ 

故必 k=0 ，因而  $ \alpha + \beta + \gamma = \pi $.

#### §2. 复平面上的点集

我们在上节中提到的复平面上的线段、直线和圆周等都是复平面上的点集。今后，我们的研究对象——解析函数，其定义域和值域都是复平面上的某个点集。

### 1. 平面点集的几个基本概念

定义 1.1 由不等式  $ \left|z - z_{0}\right| < \rho $ 所确定的平面点集（以后平面点集均简称点集），就是以  $ z_{0} $ 为心，以  $ \rho $ 为半径的圆，称为点  $ z_{0} $ 的  $ \rho $ - 邻域，常记为  $ N_{\rho}(z_{0}) $；并称  $ 0 < |z - z_{0}| < \rho $ 为点  $ z_{0} $ 的去心  $ \rho $ 邻域，常记为  $ N_{\rho}(z_{0}) - \{z_{0}\} $。它们是复数列和复变函数极限论的基础。

定义 1.2 考虑点集 E. 若平面上一点  $ z_{0} $ (不必属于 E) 的任意邻域都有 E 的无穷多个点，则称  $ z_{0} $ 为 E 的聚点或极限点；若  $ z_{0} $ 属于 E，但非 E 的聚点，则称  $ z_{0} $ 为 E 的孤立点；若  $ z_{0} $ 不属于 E，又

<!-- page: 38 -->

非 E 的聚点，则称  $ z_{0} $ 为 E 的外点.

点集 E 的全部聚点所成集用  $ E' $ 表示.

定义 1.3 若点集 E 的每个聚点皆属于 E，即  $ E^{\prime} \subseteq E $，则称 E 为闭集；若点集 E 的点  $ z_{0} $ 有一邻域全含于 E 内，则称  $ z_{0} $ 为 E 的内点；若点集 E 的点皆为内点，则称 E 为开集；若在点  $ z_{0} $ 的任意邻域内，同时有属于点集 E 和不属于 E 的点，则称  $ z_{0} $ 为 E 的边界点；点集 E 的全部边界点所组成的点集称为 E 的边界。

点集 E 的边界常记成  $ \partial E $.

点集 E 的孤立点必是 E 的边界点.

定义 1.4 若有正数 M，对于点集 E 内的点 z 皆合  $ |z| \leq M $，即若 E 全含于一圆之内，则称 E 为有界集，否则称 E 为无界集。

以下五种说法是彼此等价的：

（1） $ z_{0} $ 为 E 的聚点或极限点；

(2)  $ z_{0} $ 的任一邻域含有 E 的无穷多个点 ( $ z_{0} $ 不必属于 E);

（3） $ z_{0} $的任一邻域含有异于 $ z_{0} $而属于E的一个点；

（4） $ z_{0} $ 的任一邻域含有 E 的两个点；

(5) 可从 E 取出点列  $ z_{1}, z_{2}, \cdots, z_{n} \cdots $，而以  $ z_{0} $ 为极限。即对任给  $ \varepsilon > 0 $，存在正整数 N = N ( $ \varepsilon $)，使当 n > N 时，恒有  $ \left|z_{n} - z_{0}\right| < \varepsilon $。

2. 区域与若尔当(Jordan)曲线 复变函数论的基础几何概念

之一是区域的概念.

定义 1.5 具备下列性质的非空

点集 D 称为区域:



（1）D 为开集.

（2）D 中任意两点可用全在 D 中的折线连接（图 1.12）.

定义 1.6 区域 D 加上它的边界 C 称为闭域, 记为

<div style="text-align: center;"><img src="images/p0038_img_in_image_box_2543_4655_3993_5770.jpg" alt="图 1.12" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.12</div> </div>

<!-- page: 39 -->

$$ \overline{D}=D+C. $$ 

注意 区域都是开的,不包含它的边界点.

例 1.16 试证: 点集 E 的边界  $ \partial E $ 是闭集. 即证

 $$ (\partial E)^{\prime}\subseteq\partial E. $$ 

 $ ^{*} $ 证 设  $ z $ 为  $ \partial E $ 的聚点。取  $ z $ 的任意  $ \varepsilon $ 邻域  $ N_{\varepsilon}(z) $，则存在  $ z_{0}(\neq z) $ 使得  $ N_{\varepsilon}(z)\ni z_{0}\in\partial E $。在  $ N_{\varepsilon}(z) $ 内能画出以  $ z_{0} $ 为心，充分小半径的圆。这时由  $ z_{0}\in\partial E $ 可见，在此圆内属于 E 的点和不属于 E 的点都存在。于是，在  $ N_{\varepsilon}(z) $ 内属于 E 的点和不属于 E 的点都存在，故  $ z\in\partial E $。因此  $ \partial E $ 是闭集。

应用关于复数 z 的不等式来表示 z 平面上的区域,有时是很方便的.

例 1.17 z 平面上以原点为心，R 为半径的圆（即圆形区域）：

 $$ \left|z\right|<R, $$ 

以及 z 平面上以原点为心，R 为半径的闭圆（即圆形闭域）：

 $$ |z|\leqslant R, $$ 

它们都以圆周  $ |z|=R $ 为边界,且都是有界的.

我们称

 $$ \left|z\right|<1\quad 为单位圆； $$ 

 $$ \left|z\right|=1\quad 为单位圆周 . $$ 

例 1.18 z 平面上以实轴  $ \mathrm{Im} z = 0 $ 为边界的两个无界区域是

 $$  上半 z 平面 \operatorname{Im}z>0, $$ 

及

 $$ \begin{aligned}& 下半 z 平面 \operatorname{Im}z<0.\end{aligned} $$ 

z 平面上以虚轴 Re z=0 为边界的两个无界区域是

 $$  左半 z 平面 \operatorname{Re}z<0, $$ 

 $$  右半 z 平面 \operatorname{Re}z>0. $$ 

例 1.19 图 1.13 所示为单位圆周的外部含在上半 z 平面的部分,表为

<!-- page: 40 -->

$$ \left\{\begin{array}{l}\left|z\right|>1,\\ \\ \operatorname{I m}z>0.\end{array}\right. $$ 

<div style="text-align: center;"><img src="images/p0040_img_in_image_box_511_1073_2098_2076.jpg" alt="图 1.13" width="35%" /></div>


<div style="text-align: center;"><img src="images/p0040_img_in_image_box_2318_989_3932_2038.jpg" alt="图 1.14" width="36%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.13</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 1.14</div> </div>


例 1.20 图 1.14 所示的带形区域表为

 $$ y_{1}<\mathrm{I m}z<y_{2}. $$ 

例 1.21 图 1.15 所示的同心圆环（即圆环形区域）表为

 $$ r<|z|<R. $$ 

<div style="text-align: center;"><img src="images/p0040_img_in_image_box_1462_3350_3049_4917.jpg" alt="图 1.15" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.15</div> </div>


我们定义有界集 E 的直径为

 $$ d\left(E\right)=\sup\left\{\mid z-z_{i}^{^{\prime}}\mid\mid z\in E,z^{^{\prime}}\in E\right\}. $$ 

复变函数的基础几何概念还有曲线.

定义 1.7 设  $ x(t) $ 及  $ y(t) $ 是实变数 t 的两个实函数，在闭区

<!-- page: 41 -->

间 $ [\alpha,\beta] $上连续，则由方程组

 $$ \left\{\begin{aligned}x&=x\left(t\right),\\ y&=y\left(t\right),\end{aligned}\right.\qquad\left(\alpha\leqslant t\leqslant\beta\right) $$ 

或由复数方程

$$  \begin{aligned}z=x\left(t\right)+i y\left(t\right)\quad&\left(\alpha\leqslant t\leqslant\beta\right)\ $  简记为 z=z\left(t\right))\quad&\cdot\end{aligned}   \tag*{(1.16)}$$

所决定的点集 C，称为 z 平面上的一条连续曲线。式(1.16)称为 C 的参数方程， $ z(\alpha) $ 及  $ z(\beta) $ 分别称为 C 的起点和终点；对满足  $ \alpha < t_{1} < \beta $， $ \alpha \leq t_{2} \leq \beta $， $ t_{1} \neq t_{2} $ 的  $ t_{1} $ 及  $ t_{2} $，当  $ z(t_{1}) = z(t_{2}) $ 成立时，点  $ z(t_{1}) $ 称为此曲线 C 的重点；凡无重点的连续曲线，称为简单曲线或若尔当曲线； $ z(\alpha) = z(\beta) $ 的简单曲线称为简单闭曲线。

简单曲线是 z 平面上的一个有界闭集.

例如，线段、圆弧和抛物线弧段等都是简单曲线；圆周和椭圆周等都是简单闭曲线。

定义 1.8 设连续弧 AB 的参数方程为

 $$ z=z\left(t\right),\left(a\leqslant t\leqslant\beta\right) $$ 

任取实数列  $ \{t_{n}\} $:

$$  \alpha=t_{0}<t_{1}<t_{2}<\cdots<t_{n-1}<t_{n}=\beta,   \tag*{(1.17)}$$

并且考虑 AB 弧上对应的点列：

 $$ z_{j}=z\left(t_{j}\right)\quad\left(j=0,1,2,\cdots,n\right), $$ 

将它们用一折线  $ Q_{n} $ 连接起来， $ Q_{n} $ 的长度

 $$ I_{n}=\sum_{j=1}^{n}\left|z(t_{j})-z(t_{j-1})\right|. $$ 

如果对于所有的数列(1.17)， $ I_{n} $有上界，则 AB 孤称为可求长的.

上确界  $ L = \sup I_{n} $ 称为 AB 弧的长度.

定义 1.9 设简单(或简单闭)曲线 C 的参数方程为

 $$ z=x\left(t\right)+\mathrm{i}y\left(t\right)\quad\left(\alpha\leqslant t\leqslant\beta\right), $$

<!-- page: 42 -->

又在  $ a \leqslant t \leqslant \beta $ 上， $ x'(t) $ 及  $ y'(t) $ 存在、连续且不全为零 $ ^{①} $，则 C 称为光滑(闭) $ ^{②} $曲线.

光滑(闭)曲线 C 具有连续转动的切线.

定义 1.10 由有限条光滑曲线衔接而成的连续曲线称为逐段光滑曲线.

特别，简单折线是逐段光滑曲线.

逐段光滑曲线必是可求长曲线,但简单曲线(或简单闭曲线)却不一定可求长.

 $ ^{*} $例1.22 设简单曲线J的参数方程为

 $$ \left\{\begin{aligned}x&=x\left(t\right)=t\\ y&=y\left(t\right)=\left\{\begin{aligned}&t\sin\frac{1}{t},t\neq0 时 ,\\ &0,\end{aligned}\quad\begin{aligned}&(0\leqslant t\leqslant1)\end{aligned}\right.\end{aligned}\right. $$ 

显然  $ A_{n}\left(\frac{1}{2n\pi+\frac{\pi}{2}},\frac{1}{2n\pi+\frac{\pi}{2}}\right) $， $ B_{n}\left(\frac{1}{2n\pi},0\right) $皆为曲线 J 上的点，且连接  $ A_{n} $ 及  $ B_{n} $ 两点线段之长

 $$ \begin{align*}\overline{A_{n} B_{n}}&=\sqrt{\left(\frac{1}{2n\pi+\frac{\pi}{2}}-\frac{1}{2n\pi}\right)^{2}+\left(\frac{1}{2n\pi+\frac{\pi}{2}}\right)^{2}}\\&\geq\frac{1}{\left(2n+\frac{1}{2}\right)\pi}=\frac{1}{2\left(n+\frac{1}{4}\right)\pi}>\frac{1}{2(n+1)\pi},\end{align*} $$ 

因为 $ \sum_{n=1}^{\infty}\frac{1}{n} $是发散的，所以 $ \sum_{n=1}^{\infty}\overline{A_{n}B_{n}} $也是发散的，从而知简单曲线 $ J $是不可求长的.

我们容易看出，圆周  $ |z| = R $ 把 z 平面分为两个不相连接的

<!-- page: 43 -->

区域 $ \{z\}<R $和 $ \{z\}>R $。这个结果是下面所谓若尔当定理的特例。

定理1.1（若尔当定理）任一简单闭曲线 C 将 z 平面惟一地分成 C、I(C) 及 E(C) 三个点集（图 1.16），它们具有如下性质：

（1）彼此不交；

(2) $ \cdot I(C) $是一个有界区域(称为C的内部);

(3)  $ E(C) $ 是一个无界区域(称为 C 的外部);

(4) 若简单折线 P 的一个端点属于  $ I(C) $，另一个端点属于  $ E(C) $，则 P 必与 C 有交点.

<div style="text-align: center;"><img src="images/p0043_img_in_image_box_2450_1149_3989_2254.jpg" alt="图 1.16" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.16</div> </div>


此定理的证明 $ ^{①②} $虽有多种，但都包含若干拓扑学的知识和术语，非简短篇幅所能说明。因此略去证明。不过这个定理的直观意义是很清楚的。

沿着一条简单闭曲线 C 有两个相反的方向，其中一个方向是：当观察者顺此方向沿 C 前进一周时，C 的内部一直在 C 的左方，即“反时针”方向，称为正方向；另一个方向是：当观察者顺此方向沿 C 前进一周时，C 的外部一直在 C 的左方，即“顺时针”方向，称为负方向（图 1.16）。

在简单闭曲线 C 的内部  $ I(C) $ 无论怎样画简单闭曲线  $ \Gamma $，则  $ \Gamma $ 的内部  $ I(\Gamma) $ 必全含于  $ I(C) $。这一性质的一般化，即是

定义 1.11 设 D 为复平面上的区域. 若在 D 内无论怎样画简单闭曲线, 其内部仍全含于 D, 则称 D 为单连通区域; 非单连通的区域称为多连通区域.

<!-- page: 44 -->

所含不止一个点的闭集 E，如果不能划分为两个无公共点的非空闭集，则称 E 为连续点集。空集与所含只有一个点的集，称为退化连续点集。

若区域 D 的边界为一个连续点集（包括退化情形），则称 D 为单连通区域（也就是所谓没有“洞”的区域，这个说法与前面关于单连通区域的定义是等价的）；非单连通的区域称为多连通区域。

若区域 D 的边界是互不相交的两个、三个、 $ \cdots $、n 个连续点集，则分别称 D 为二连通、三连通、 $ \cdots $、n 连通的区域.

简单闭曲线 C 的内部  $ I(C) $ 就是单连通区域。我们在例 1.17 至例 1.20 中所列举的区域也是单连通的。而例 1.21 所列举的圆环形区域  $ D: r < |z| < R $ ( $ r \geqslant 0, R \leqslant +\infty $)——它包括去心的圆  $ (r = 0, R < +\infty) $、一个圆周的外部  $ (r > 0, R = +\infty) $、去掉原点的  $ z $ 平面  $ (r = 0, R = +\infty) $ 三种特例——就不是单连通的，因为，如果取  $ \Gamma $ 为圆周  $ |z| = \rho (r < \rho < R) $，它的内部就不能全含于这个圆环形区域内（请读者自己作图思考）。还因为它们的边界都是两个不相交的连续点集，所以都是二连通的。

注 若实数集不囿于上(下)，则称“广义的数”+ $ \infty $(- $ \infty $)为它们的上(下)界，关于这些“广义的”数或“无穷的”数，我们有

 $$ \begin{aligned}&-\infty<+\infty\quad 及 \quad-\infty<a<+\infty,\end{aligned} $$ 

其中  $ \alpha $ 是不论怎样的（有限的）实数.

符号 $ +\infty $和 $ -\infty $读着“正无穷”和“负无穷”.

#### §3. 复变函数

1. 复变函数的概念 复变函数的定义, 形式上和数学分析中单元函数的定义一样, 不过自变量和函数都取复数值(当然也包括取实数值).

定义 1.12 设 E 为一复数集，若对 E 内每一复数 z，有惟一确定的复数 w 与之对应，则称在 E 上确定了一个单值函数  $ w =  $

<!-- page: 45 -->

$ f(z)(z\in E) $.如对 E 内每一复数 z，有几个或无穷多个 w 与之对应，则称在 E 上确定了一个多值函数  $ w=f(z)(z\in E) $.E 称为函数  $ w=f(z) $ 的定义域.对于 E，w 值的全体所成集 M 称为函数  $ w=f(z) $ 的值域.

例 1.23  $ \omega = |z| $,  $ \omega = \overline{z} $,  $ \omega = z^{2} $ 及

 $$ w=\frac{z+1}{z-1}\quad(z\neq1) $$ 

均为 z 的单值函数；

 $$ w=\sqrt[n]{z}\quad(z\neq0,n\geqslant2 整数 ) $$ 

及

 $$ w=\arg z\quad(z\neq0) $$ 

均为z的多值函数.

注 今后如不特别声明，所提到的函数都指单值函数.

设  $ w = f(z) $ 是定义于点集 E 上的单值或多值函数，并令

 $$ z=x+\mathrm{i}y,w=u+\mathrm{i}v, $$ 

则 u、v 皆随 x, y 而确定，因而  $ w = f(z) $ 又常写成

$$  \boldsymbol{w}=\boldsymbol{u}(\boldsymbol{x},\boldsymbol{y})+\mathrm{i}\boldsymbol{v}(\boldsymbol{x},\boldsymbol{y}),   \tag*{(1.18)}$$

其中  $ u(x,y) $ 及  $ v(x,y) $ 是二元实函数.

如将 z 表为指数形式  $ z = re^{i\theta} $，函数  $ w = f(z) $ 又可表为

 $$ \begin{array}{r}{\mathcal{w}=P(r,\theta)+\mathrm{i}Q(r,\theta).}\end{array} $$ 

可见，单复变的复函数

$$  w=f(z)   \tag*{(1.19)}$$

等价于两个相应的二元实函数

$$  u=\phi(x,y),v=\psi(x,y).   \tag*{(1.20)}$$

既然如此，究竟为什么我们还要去考虑一元复函数呢？实函数不是更为人所熟知吗？如果一个复函数等价于一对实函数，那么引进较不熟悉的复函数，其目的在哪里？

如果两个实函数 u 与 v 是随意选定的，二者之间没有什么特别联系，那么确实没有必要将它们结合起来作为一个复函数。然而，在两个实函数是紧密相关的一些情况下，把两个关系式(1.20)

<!-- page: 46 -->

缩写成一个关系式(1.19)更为有利.

例 1.24 设函数  $ w = z^{2} + 2 $，当 z = x + iy 时，w 可以写成

 $$ \begin{array}{r}{\dot{w}=\dot{x}^{2}-\dot{y}^{2}+2+2x\dot{y}\mathrm{i},}\end{array} $$ 

因而

 $$ u\left(x,y\right)=x^{2}-y^{2}+2,v\left(x,y\right)=2xy. $$ 

当  $ z = re^{i\theta} $ 时，w 又可以写成

 $$ \begin{array}{r}{\omega=r^{2}(\cos2\theta+\mathrm{~i~}\sin2\theta)+2,}\end{array} $$ 

因而  $ P(r,\theta)=r^{2}\cos 2\theta+2, Q(r,\theta)=r^{2}\sin 2\theta. $

在数学分析中，我们常常把函数用几何图形表示出来，在研究函数的性质时，这些几何图形给我们很多直观的帮助。现在，我们就不能借助于同一个平面或同一个三维空间中的几何图形来表示复变函数。因由(1.18)式， $ f(x+iy)=u+iv $，要描出 $ w=f(z) $的图形，必须采用四维空间，也就是 $ (u,v,x,y) $空间，为了避免这个困难，我们取两张复平面，分别称为z平面和w平面（在个别情形下，为了方便，也可将它们叠成一张平面，如图1.8）。注意到，在复平面上不区分“点”和“数”，也不再区分“点集”和“数集”，我们把复变函数理解为两个复平面上的点集间的对应（映射或变换）。具体地说，复变函数 $ w=f(z) $给出了从z平面上的点集E到w平面上的点集F间的一个对应关系（图1.17）。与点 $ z\in E $对应的点 $ w=f(z) $称为点z的像点，同时点z就称为点 $ w=f(z) $的原像。为了方便，以后也不再区分函数、映射和变换。

必须指出，像点的原像可能不只一点，例如  $ w = z^{2} $，则  $ z = \pm 1 $ 的像点均为 w = 1，因此 w = 1 的原像是两个点  $ z = \pm 1 $.

定义 1.13 如对 z 平面上点集 E 的任一点 z，有 w 平面上点集 F 的点 w，使得  $ w = f(z) $，则称  $ w = f(z) $ 把 E 变（映）入 F（简记为  $ f(E) \subseteq F $，或称 w = f(z) 是 E 到 F 的入变换.

定义 1.14 如果  $ f(E) \subseteq F $，且对 F 的任一点 w，有 E 的点 z，使得  $ w = f(z) $，则称  $ w = f(z) $ 把  $ \dot{E} $ 变（映）成  $ F $（简记为  $ f(E) = F $），或称  $ w = f(z) $ 是  $ \cdot E $ 到 F 的满变换.

对于满变换这种对应关系  $ w = f(z) $，F 就是  $ w = f(z) $ 能取

<!-- page: 47 -->

到的所有值所构成的点集，它显然具有下列两条性质：

（1）对于点集 E 中的每一点 z，相应的点  $ w = f(z) $ 是点集 F 中的一个点；

(2) 对于点集 F 中的每一点 w，在 E 中至少有一个点 z 与之对应，即满足  $ w = f(z) $.

定义 1.15 若  $ w = f(z) $ 是点集 E 到 F 的满变换，且对 F 中的每一点 w，在 E 中有一个（或至少有两个）点与之相对应，则在 F 上确定了一个单值（或多值）函数，记作  $ z = f^{-1}(w) $，它就称为函数  $ w = f(z) $ 的反函数或称为变换  $ w = f(z) $ 的逆变换；若 z =  $ f^{-1}(w) $ 也是 F 到 E 的单值变换，则称 w = f(z) 是 E 到 F 的双方单值变换或一一变换。

从上述反函数的定义可以看出,对于任意的  $ w \in F $,有

 $$ \begin{array}{r}{\omega=f\left[f^{-1}\left(\omega\right)\right],}\end{array} $$ 

且当反函数也是单值函数时，还有

 $$ z=f^{-1}\left[f(z)\right],z\in E. $$ 

上面映射这一概念的引入，对于复变函数论的进一步发展，特别是在解析函数的几何理论方面起到重要作用，因为它给出了函数的分析表示和几何表示的综合。这个综合是函数论发展的基础和新问题不断出现的源泉之一，在物理学的许多领域有着重要的应用。

<div style="text-align: center;"><img src="images/p0047_img_in_image_box_720_4437_3744_5569.jpg" alt="图1.17" width="67%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.17</div> </div>

<!-- page: 48 -->

例 1.25 设有函数  $ w = z^{2} $，试问它把  $ z $ 平面上的下列曲线分别变成  $ w $ 平面上的何种曲线？

<div style="text-align: center;"><img src="images/p0048_img_in_image_box_482_956_4011_2406.jpg" alt="图 1.18" width="78%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.18</div> </div>


（1）以原点为心，2为半径，在第一象限里的圆弧；

(2) 倾角  $ \theta = \frac{\pi}{3} $ 的直线 (可以看成两条射线  $ \arg z = \frac{\pi}{3} $ 及  $ \arg z = \pi + \frac{\pi}{3} $);

（3）双曲线  $ x^{2}-y^{2}=4 $.

解 设  $ z = x + i y = r (\cos \theta + i \sin \theta) $,

 $$ w=u+\mathrm{i}v=R\left(\cos\varphi+\mathrm{i}\sin\varphi\right), $$ 

则

 $$ R=r^{2},\varphi=2\theta, $$ 

由此，(1)(如图1.18)当z的模为2，辐角由0变至 $ \frac{\pi}{2} $时，对应的w的模为4，辐角由0变至 $ \pi $。故在w平面上i的对应图形为：以原点为心，4为半径，在u轴上方的半圆周。

(2) 倾角  $ \theta = \frac{\pi}{3} $ 的直线在 w 平面上对应的图形为射线  $ \varphi = \frac{2\pi}{3} $.

（3）因  $ w = z^{2} = x^{2} - y^{2} + 2xyi $，故

 $$ u=x^{2}-y^{2}, $$

<!-- page: 49 -->

所以 z 平面上的双曲线  $ x^{2}-y^{2}=4 $ 在 w 平面上的像为直线 u=4.

### 2. 复变函数的极限与连续性

定义 1.16 设函数  $ w = f(z) $ 于点集 E 上有定义,  $ z_{0} $ 为 E 的聚点. 如存在一复数  $ w_{0} $, 使对任给的  $ \varepsilon > 0 $, 有  $ \delta > 0 $, 只要  $ 0 < |z - z_{0}| < \delta $,  $ z \in E $, 就有

 $$ |f(z)-w_{0}|<\varepsilon, $$ 

则称函数 $ f(z) $沿E于 $ z_{0} $有极限 $ \omega_{0} $，并记为

 $$ \begin{array}{l}\lim\limits_{z\to z_{0}}f(z)=\varpi_{0}.\ \\ \scriptstyle z\in E\end{array} $$ 

我们可以这样来理解极限概念的几何意义: 当变点 z 进入  $ z_{0} $ 的充分小的  $ \delta $ 去心邻域时, 它们的像点就落入  $ w_{0} $ 的一个给定的  $ \varepsilon $ - 邻域内 (图 1.19).

<div style="text-align: center;"><img src="images/p0049_img_in_image_box_574_3176_3905_4356.jpg" alt="图 1.19" width="74%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.19</div> </div>


由于复变函数极限的定义与数学分析中一元实变函数的极限定义相似,我们可以仿照证明而有下述结论:

（1）若极限存在，必然惟一；

(2) 若  $ f(z) $、 $ g(z) $ 沿点集 E 在点  $ z_{0} $ 有极限，则其和、差、积、商（在商的情形，要求分母的极限不等于零）沿点集 E 在点  $ z_{0} $ 仍然有极限，并且其极限值等于  $ f(z) $、 $ g(z) $ 在点  $ z_{0} $ 的极限值的和、差、

<!-- page: 50 -->

积、商.

注 极限  $ \lim_{f(z)\to z_0} f(z) $ 与 z 趋于  $ z_0 $ 的方式无关。通俗地说，就是指

 $ z \to z_0 $

 $ z \in E $

在 E 上，z 要沿着从四面八方通向  $ z_0 $ 的任何路径趋于  $ z_0 $。对比数学分析中一元实变函数  $ f(x) $ 的极限  $ \lim_{x \to x_0} f(x) $， $ x \to x_0 $ 指在 x 轴上 x 只沿  $ x_0 $ 的左右两个方向，我们这里对复变函数极限存在的要求，显然苛刻得多。这正是复变分析与实变分析不同的根源。

下述定理给出了复变函数极限与其实部和虚部极限的关系：

定理 1.2 设函数  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 于点集 E 上有定义,  $ z_{0} = x_{0} + \mathrm{i}y_{0} $ 为 E 的聚点, 则

 $$ \lim\limits_{\substack{z\to z_{0}\\ z\in E}}f(z)=\eta=a+\mathrm{i}b $$ 

的充要条件是

 $$ \lim\limits_{\substack{(x,y)\to(x_{0},y_{0})\\ (x,y)\in E}}u\left(x,y\right)=a,\lim\limits_{\substack{(x,y)\to(x_{0},y_{0})\\ (x,y)\in E}}v\left(x,y\right)=b. $$ 

证 因为

 $$ f(z)-\eta=u(x,y)-a+\mathrm{i}\left[v(x,y)-b\right], $$ 

由不等式(1.1)得

$$  \begin{array}{l}\left|u(x,y)-a\right|\leqslant\left|f(z)-\eta\right|,\\ \left|v(x,y)-b\right|\leqslant\left|f(z)-\eta\right|,\end{array}   \tag*{(1.21)}$$

及

$$  |f(z)-\eta|\leqslant|u(x,y)-a|+|v(x,y)-b|.   \tag*{(1.22)}$$

根据极限的定义,由(1.21)可得必要性部分的证明,由(1.22)可得充分性部分的证明.

另外，复变函数的极限论在复分析中诱导出复变函数的连续性、可微性（第二章）、可积性（第三章）及复级数的收敛性（第四章）.

下面引入复变函数连续性的概念.

<!-- page: 51 -->

定义 1.17 设函数  $ w = f(z) $ 于点集 E 上有定义,  $ z_{0} $ 为 E 的聚点, 且  $ z_{0} \in E $. 若

 $$ \begin{array}{l}\lim\limits_{z\to z_{0}}\limits_{z\in E}f(z)=f(z_{0}),\end{array} $$ 

即对任给的  $ \varepsilon>0 $，有  $ \delta>0 $，只要  $ \left|z-z_{0}\right|<\delta, z\in E $，就有

 $$ |f(z)-f(z_{0})|<\varepsilon, $$ 

则称  $ f(z) $ 沿 E 于  $ z_{0} $ 连续.

这里，复变函数连续性的定义与数学分析中一元实变函数连续性的定义相似，我们可以仿照证明而有下述结论：

(1) 如  $ f(z) $、 $ g(z) $ 沿点集 E 于点  $ z_{0} $ 连续，则其和、差、积、商（在商的情形，要求分母在  $ z_{0} $ 不为零）沿点集 E 于点  $ z_{0} $ 连续.

(2) 如函数  $ \eta = f(z) $ 沿点集 E 于点  $ z_{0} $ 连续，且  $ f(E) \subseteq G $，函数  $ w = g(\eta) $ 沿点集 G 于点  $ \eta_{0} = f(z_{0}) $ 连续，则复合函数  $ w = g[f(z)] = F(z) $ 沿点集 E 于点  $ z_{0} $ 连续.

定理 1.3 设函数  $ f(z) = u(x, y) + iv(x, y) $ 于点集 E 上有定义,  $ z_{0} \in E $, 则  $ f(z) $ 沿 E 在点  $ z_{0} = x_{0} + iy_{0} $ 连续的充要条件是: 二元实变函数  $ u(x, y) $、 $ v(x, y) $ 沿 E 于点  $ (x_{0}, y_{0}) $ 连续.

证 由于连续性是借助于极限概念来定义的. 只要注意到定理1.2中的a就是这里的 $ u(x_{0},y_{0}),b $就是这里的 $ v'(x_{0},y_{0}) $，就可以得到证明.

注 为了简单起见，今后在说到极限、连续时，凡上下文明确，均不必提到“沿什么集”的话，而极限符号也可以省写为  $ \lim $ 。

 $$ z\to z_{0} $$ 

例 1.26 设

 $$ f(z)=\frac{1}{2\mathrm{i}}\left(\frac{z}{z}-\frac{\overline{z}}{z}\right)(z\neq0), $$ 

试证  $ f(z) $ 在原点无极限，从而在原点不连续.

证 令变点  $ z = r (\cos \theta + i \sin \theta) $，则

<!-- page: 52 -->

$$ \begin{align*}f(z)&=\frac{1}{2i}\cdot\frac{z^2-\overline{z^2}}{z\overline{z}}=\frac{1}{2i}\cdot\frac{(z+\overline{z})(z-\overline{z})}{r^2}\\&=\frac{1}{2i r^2}\cdot2r\cos\theta\cdot2r i\sin\theta\\&=\sin2\theta,\end{align*} $$ 

从而

 $$ \lim_{z\to0}f(z)=0\quad\left( 沿正实轴 \theta=0\right), $$ 

 $$ \lim_{z\to0}f(z)=1\quad\left( 沿第一象限的平分角线 \theta=\frac{\pi}{4}\right), $$ 

故  $ f(z) $ 在原点无确定的极限,从而在原点不连续.

注上述例子说明: 当 z 依某一特定方式趋于  $ z_{0} $ 时, 函数虽有极限存在, 但不足以说明它在该点有极限存在. 只有当函数  $ f(z) $ 在一点  $ z_{0} $ 的极限存在的条件下, 才能使 z 依某种特定的方程式趋于  $ z_{0} $ 简单地求得此极限.

在对  $ z \rightarrow z_{0} $ 的这种要求上，单复变函数的极限与二元实函数的极限相似。事实上，因  $ z \rightarrow z_{0} $ 与  $ (x, y) \rightarrow (x_{0}, y_{0}) $，从复数的实数对形式看，二者是一样的。

定义 1.18 如函数  $ f(z) $ 在点集 E 上各点均连续，则称  $ f(z) $ 在 E 上连续.

特别情形 （1）若 E 为实轴上的线段  $ [\alpha, \beta] $，则连续曲线 (1.16) 就是  $ [\alpha, \beta] $ 上的连续函数  $ z = z(t) $.

(2) 若 E 为闭域  $ \overline{D} $，则其上每一点均为其聚点，故对在  $ \overline{D} $ 上有定义的函数，均可考查连续性，不过对于边界上的点  $ z_{0}, z \rightarrow z_{0} $ 只能沿  $ \overline{D} $ 上的点 z 来取.

易知,借助于连续变换  $ w = f(z) $, z 平面上的一条连续曲线也被变成 w 平面上的一条连续曲线.

例 1.27 设  $ \lim_{z \to z_0} f(z) = \eta $，则函数  $ f(z) $ 在点  $ z_0 $ 的某一去心邻域内是有界的.

<!-- page: 53 -->

证 因

 $$ \operatorname*{l i m}_{z\to z_{0}}f(z)=\eta, $$ 

则对任给的  $ \varepsilon > 0 $，有  $ \delta > 0 $，只要  $ 0 < |z - z_{0}| < \delta $，就有

 $$ |f(z)-\eta|<\varepsilon, $$ 

更有

 $$ |f(z)|-|\eta|<\varepsilon, $$ 

于是

 $$ |f(z)|<|\eta|+\varepsilon, $$ 

所以，在点  $ z_{0} $ 的去心邻域  $ N_{\delta}(z_{0}) - \{z_{0}\} $ 内  $ f(z) $ 是有界的.

例 1.28 设函数  $ f(z) $ 在点  $ z_{0} $ 连续，且  $ f(z_{0}) \neq 0 $，则  $ f(z) $ 在点  $ z_{0} $ 的某一邻域内恒不为零.

证 因  $ f(z) $ 在点  $ z_{0} $ 连续，则对任给的  $ \varepsilon>0 $，有  $ \delta>0 $，只要  $ \left|z-z_{0}\right|<\delta $，就有

 $$ |f(z)-f(z_{0})|<\varepsilon. $$ 

特别,取  $ \varepsilon=\frac{|f(z_{0})|}{2}>0 $,则由上面的不等式得

 $ \left|f(z)\right|>\left|f(z_{0})\right|-\varepsilon=\left|f(z_{0})\right|-\frac{\left|f(z_{0})\right|}{2}=\frac{\left|f(z_{0})\right|}{2}>0, $

因此， $ f(z) $在点 $ z_{0} $的 $ \delta $邻域 $ N_{\delta}(z_{0}) $内就恒不为零.

上面两例的结果以后常会用到.

下列三个定理常用.数学分析里已证过.

定理 1.4 [波尔查诺(Bolzano) - 魏尔斯特拉斯定理] 每一个有界无穷点集，至少有一个聚点.

定理 1.5 （闭集套定理） 设无穷闭集列  $ \{\overline{F}_{n}\} $，至少一个为有界且  $ \overline{F}_{n} \supseteq \overline{F}_{n+1} $， $ \lim_{n \to \infty} d(\overline{F}_{n}) = 0 $， $ (d(\overline{F}_{n}) $ 是  $ \overline{F}_{n} $ 的直径)，则必有惟一的一点  $ z_{0} \in \overline{F}_{n} $ ( $ n = 1, 2, \cdots $)。

定理 1.6 [海涅－波莱尔(Heine－Borel)覆盖定理] 设有界闭集 E 的每一点 z 都是圆  $ K_{z} $ 的圆心，则这些圆  $ \{K_{z}\} $ 中必有有限个圆把 E 盖住，换句话说，E 的每一点至少属于这有限个圆中的一个.

<!-- page: 54 -->

我们在数学分析中知道，在闭区间上的连续函数有三个重要性质：有界性、达到最大值与最小值的性质及一致连续性。对于复变连续函数，也有与此平行的性质。

定理 1.7 在有界闭集 E 上连续的函数  $ f(z) $，具有下列三个性质：

(1) 在 E 上  $ f(z) $ 有界. 即有常数 M > 0, 使

 $$ |f(z)|\leqslant M\quad(z\in E); $$ 

(2)  $ \left|f(z)\right| $ 在 E 上有最大值与最小值. 即在 E 上有两点  $ z_{1} $ 和  $ z_{2} $ 使

 $$ |f(z)|\leqslant|f(z_{1})|,|f(z)|\geqslant|f(z_{2})|\quad(z\in E); $$ 

(3)  $ f(z) $ 在 E 上一致连续，即任给  $ \varepsilon>0 $，有  $ \delta>0 $，使对 E 上满足  $ \left|z_{1}-z_{2}\right|<\delta $ 的任意两点  $ z_{1} $ 及  $ z_{2} $，均有

 $$ |f(z_{1})-f(z_{2})|<\varepsilon. $$ 

证 由定理 1.3 可知,二元实值函数

 $$ |f(z)|=\sqrt{u^{2}(x,y)+v^{2}(x,y)} $$ 

在有界闭集 E 上连续，由数学分析中二元连续函数的性质，即知(1)、(2)为真.

参照不等式(1.22)可以看出， $ f(z) $的一致连续性，可由 u(x, y) 及  $ v(x, y) $ 的一致连续性推出.

思考题 本定理对于区域 D 不一定成立. 建议读者在单位圆  $ |z|<1 $ 内考虑函数

 $$ f(z)=\frac{1}{1-z}, $$ 

看看本定理的结论(1)是否为真.

#### §4. 复球面与无穷远点

1. 复球面 复数还有一种几何表示法，它是借用地图图学

<!-- page: 55 -->

中将地球投影到平面上的测地投影法，建立复平面与球面上的点的对应，着重说明引入无穷远点的合理性.

取一个在原点 O 与 z 平面相切的球面，通过点 O 作一垂直于 z 平面的直线与球面交于点 N，N 称为北极，O 称为南极（图 1.20）。现在用直线段将 N 与 z 平面上一点 z 相连，此线段交球面于一点 P(z)，这样就建立起球面上的点（不包括北极点 N）与复平面上的点间的一一对应。

<div style="text-align: center;"><img src="images/p0055_img_in_image_box_1358_1969_3098_3332.jpg" alt="图 1.20" width="38%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.20</div> </div>


考虑 z 平面上一个以原点为中心的圆周 C，在球面上对应的也是一个圆周  $ \Gamma $ (即是纬线). 当圆周 C 的半径越大时，圆周  $ \Gamma $ 就越趋于北极 N. 因此，北极 N 可以看成是与 z 平面上的一个模为无穷大的假想点相对应，这个假想点称为无穷远点，并记为  $ \infty $. 复平面加上点  $ \infty $ 后称为扩充复平面，常记作  $ C_{\infty}, C_{\infty} = C + \{\infty\} $. 与它对应的就是整个球面，称为复球面. 简单说来，扩充复平面的一个几何模型就是复球面.

关于新“数”$\infty$（读作无穷）还需作如下几点规定：

(1) 运算  $ \infty \pm \infty, 0 \cdot \infty, \frac{\infty}{\infty}, \frac{0}{0} $ 无意义；

(2)  $ a \neq \infty $ 时， $ \frac{\infty}{a} = \infty, \frac{a}{\infty} = 0 $.

<!-- page: 56 -->

$$ \infty\pm a=a\pm\infty=\infty； $$ 

(3)  $ b \neq 0 $ (但可为  $ \infty $) 时,  $ \infty \cdot b = b \cdot \infty = \infty $,  $ \frac{b}{0} = \infty $;

（4） $ \infty $的实部、虚部及辐角都无意义， $ \left|\infty\right|=+\infty $。

(5) 复平面上每一条直线都通过点  $ \infty $，同时，没有一个半平面包含点  $ \infty $。并注意，直线不是简单闭曲线。

### 2. 扩充复平面上的几个概念

（1）扩充复平面上，无穷远点的邻域（对照定义1.1）应理解为以原点为心的某圆周的外部，即 $ \uwave{\text{∞的 $ \varepsilon $ - 邻域}} $  $ N_{\varepsilon} $（∞）是指合于条件 $ |z|>\frac{1}{\varepsilon} $的点集，它正好对应着复球面上以北极点N为心的一个球盖。 $ \infty $的去心 $ \varepsilon $邻域是指 $ \frac{1}{\varepsilon}<|z|<+\infty $，它正好对应着去掉北极点N的一个球盖。对照定义1.2及定义1.3，在扩充复平面上，聚点、内点和边界点等概念均可以推广到点 $ \infty $。于是，复平面以 $ \infty $为其唯一的边界点；扩充复平面以 $ \infty $为内点，且它是惟一的无边界的区域。

任一简单闭曲线 C，将扩充 z 平面分为两个不相连接的区域，一个是有界区域  $ I(C) $，另一个是无界区域  $ E(C) $，它们都以 C 为边界（若尔当定理）.

(2) 单连通区域的概念也可以推广到扩充复平面上的区域。对照定义1.11, 我们有定义: 设 D 为扩充复平面上的区域, 若在 D 内无论怎样画简单闭曲线, 其内部或外部(包含无穷远点)仍全含于 D, 则称 D 为单连通区域.

注意 在扩充复平面上，一个圆周的外部（这里把 $ \infty $算作这个区域的内点）就是一个单连通区域。所以，一个无界区域，考虑它是否单连通，首先要考虑是在通常的复平面上还是在扩充复平面上讲的（在扩充复平面上时，还要问 $ \infty $是否算在这个区域内）。

注 如∞在无界区域的边界上,也就是区域的边界曲线延伸到∞,则不论在通常复平面上还是在扩充复平面上,区域是否为单

<!-- page: 57 -->

连通必定是一致的. 例 1.18 的半平面及例 1.20 的带形区域就总是单连通的.

（3）在扩充复平面上，点 $ \infty $可以包含在函数的定义域中，函数值也可以取到 $ \infty $。因此，函数的极限与连续性的概念可以有所推广。在关系式

 $$ \lim_{z\to z_{0}}f(z)=f(z_{0}) $$ 

中，如果  $ z_{0} $ 及  $ f(z_{0}) $ 之一或者它们同时取  $ \infty $，就称  $ f(z) $ 在点  $ z_{0} $ 为广义连续的，极限就称为广义极限。在这种广义的意义下，极限和连续性的  $ \varepsilon - \delta $ 说法要相应修改。

例如，在  $ z_{0}=\infty, f(\infty)\neq\infty $ 时， $ f(z) $ 在  $ z_{0}=\infty $ 连续的  $ \varepsilon-\delta $ 说法应该修改为：

任给  $ \varepsilon>0 $，存在  $ \delta>0 $，只要  $ \left|z\right|>\frac{1}{\delta} $ 时就有

 $$ |f(z)-f(\infty)|<\varepsilon. $$ 

例 1.29 函数  $ f(z)=\frac{1}{z}(f(0)=\infty,f(\infty)=0) $ 在扩充 z 平面上广义连续.

证 因为  $ \frac{1}{z} $ 在  $ z \neq 0 $ 及  $ z \neq \infty $ 时，作为两个连续函数的商是连续的。而在 z = 0 及 z =  $ \infty $ 的连续性可以根据下式得出

 $$ \begin{array}{l}\lim\limits_{z\to\infty}f(z)=0\pm f(\infty),\\\lim\limits_{z\to0}f(z)=\infty=f(0).\end{array} $$ 

注 以后涉及到扩充复平面时，一定强调“扩充”二字，凡是没有强调的地方，均指通常的复平面；以后提到区域及其连通性时，如不加说明，都将限于通常复平面上来考虑；以后提到极限、连续时，如不加说明，均按通常意义去理解。

<!-- page: 58 -->

## 第一章习题

## (一)

1 设  $ z = \frac{1 - \sqrt{3}i}{2} $，求  $ \left| z \right| $ 及  $ \arg z $.

答： $ \left|z\right|=1,\mathrm{Arg}z=-\frac{\pi}{3}+2k\pi,k=0,\pm1,\cdots $

2 设  $ z_{1}=\frac{1+i}{\sqrt{2}} $,  $ z_{2}=\sqrt{3}-i $，试用指数形式表  $ z_{1}z_{2} $ 及  $ \frac{z_{1}}{z_{2}} $

答： $ z_{1}z_{2}=2\mathrm{e}^{\frac{\pi}{12}i},\frac{z_{1}}{z_{2}}=\frac{1}{2}\mathrm{e}^{\frac{5\pi}{12}i} $

3 解二项方程  $ z^{4}+a^{4}=0 $ （ $ a>0 $）.

答： $ \frac{a}{\sqrt{2}}(\pm1+\mathrm{i}),\frac{a}{\sqrt{2}}(\pm1-\mathrm{i}) $.

4 证明  $ \left|z_{1}+z_{2}\right|^{2}+\left|z_{1}-z_{2}\right|^{2}=2\left(\left|z_{1}\right|^{2}+\left|z_{2}\right|^{2}\right) $，并说明其几何意义.

提示 利用公式  $ \left|z\right|^{2}=z\bar{z} $.

5 设  $ z_{1} $、 $ z_{2} $、 $ z_{3} $ 三点适合条件：

 $$ z_{1}+z_{2}+z_{3}=0\  及 \left|z_{1}\right|=\left|z_{2}\right|=\left|z_{3}\right|=1. $$ 

试证明  $ z_{1} $、 $ z_{2} $、 $ z_{3} $ 是一个内接于单位圆周  $ |z|=1 $ 的正三角形的顶点.

6 下列关系表示的点 z 的轨迹的图形是什么？它是不是区域？

(1)  $ \left|z-z_{1}\right|=\left|z-z_{2}\right|,\left(z_{1}\neq z_{2}\right) $;

(2)  $ |z| \leqslant |z - 4| $;

(3) $ \left|\frac{z-1}{z+1}\right|<1; $

(4)  $ 0 < \arg(z - 1) < \frac{\pi}{4} $ 且  $ 2 \leq \mathrm{Re} z \leq 3 $;

(5) $ |z|>2 $ 且  $ |z-3|>1 $;

(6) Im z > 1 且 |z| < 2;

(7)  $ |z| < 2 $ 且  $ 0 < \arg z < \frac{\pi}{4} $;

<!-- page: 59 -->

(8) $ \left|z-\frac{\mathrm{i}}{2}\right|>\frac{1}{2} $且 $ \left|z-\frac{3\mathrm{i}}{2}\right|>\frac{1}{2} $.

7 证明: z 平面上的直线方程可以写成  $ az + \bar{a}z = c $.

(a 是非零复常数, c 是实常数)

8 证明: z 平面上的圆周可以写成

 $$ A z\bar{z}+\beta\bar{z}+\bar{\beta}z+C=0. $$ 

其中 A、C 为实数， $ A \neq 0 $， $ \beta $ 为复数，且  $ \left|\beta\right|^{2} > AC $.

9 试证:复平面上三点  $ a + bi, 0, \frac{1}{-a + bi} $ 共直线.

10 求下列方程 (t 是实参数) 给出的曲线：

(1)  $  z = (1 + i)t  $;

(2)  $ z = a \cos t + i b \sin t $;

(3)  $ z = t + \frac{i}{t} $;

(4)  $ z = t^{2} + \frac{i}{t^{2}} $

答: (1) 直线 y = x; (2) 椭圆周  $ \frac{x^{2}}{a^{2}} + \frac{y^{2}}{b^{2}} = 1 $;

(3) 双曲线  $ y = \frac{1}{x} $;

（4）双曲线  $ y=\frac{1}{x} $ 在 I 象限的一支.

11 函数  $ w = \frac{1}{z} $ 将 z 平面上的下列曲线变成 w 平面上的什么曲线  $ (z = x + iy, w = u + iv) $?

(1)  $ x^{2} + y^{2} = 4 $; (2) y = x;

(3) x = 1; (4)  $ (x - 1)^{2} + y^{2} = 1 $.

答: (1)  $ u^{2} + v^{2} = \frac{1}{4} $; (2) v = -u;

(3)  $ \left(u - \frac{1}{2}\right)^2 + v^2 = \frac{1}{4} $; (4)  $ u = \frac{1}{2} $.

12 试证：

(1) 多项式  $ p(z) = a_{0} z^{n} + a_{1} z^{n-1} + \cdots + a_{n} (a_{0} \neq 0) $ 在 z 平面上连续；

（2）有理分式函数

<!-- page: 60 -->

$$ f(z)=\frac{a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n}}{b_{0}z^{m}+b_{1}z^{m-1}+\cdots+b_{m}} $$ 

 $ (a_{0}\neq0,b_{0}\neq0) $在z平面上除使分母为零的点外都连续.

13 试证:  $ \arg z(-\pi < \arg z \leq \pi) $ 在负实轴上 (包括原点) 不连续, 除此而外在 z 平面上处处连续.

注 若  $ 0 \leq \arg z < 2\pi $，则  $ \arg z $ 在正实轴（包括原点）上不连续，在  $ z' $ 平面上其他点处处连续.

14 命函数  $ f(z)=\left\{\begin{aligned}&\frac{xy}{x^{2}+y^{2}},& 若 z\neq0,\\&0,& 若 z=0,\end{aligned}\right. $

试证:  $ f(z) $ 在原点不连续.

15 试证：函数  $ f(z)=\bar{z} $ 在 z 平面上处处连续.

16 试问函数  $ f(z)=\frac{1}{1-z} $ 在单位圆  $ \left|z\right|<1 $ 内是否连续？是否一致连续？

答: 连续但非一致连续.

17 一个复数列  $ z_{n}=x_{n}+iy_{n} $ ( $ n=1,2,\cdots $) 以  $ z_{0}=x_{0}+iy_{0} $ 为极限的定义为：任给  $ \varepsilon>0 $，存在一个正整数 N=N( $ \varepsilon $)，使当 n>N 时，恒有

 $$ \mid z_{n}-z_{0}\mid<\varepsilon, $$ 

试证:复数列 $ \{z_{n}\} $以 $ z_{0}=x_{0}+iy_{0} $为极限的充要条件为实数列 $ \{x_{n}\} $及 $ \{y_{n}\} $分别以 $ x_{0} $及 $ y_{0} $为极限.(这是一个定理.)

提示 一方面从  $ \left|x_{n}-x_{0}\right|\leqslant\left|z_{n}-z_{0}\right| $ 及  $ \left|y_{n}-y_{0}\right|\leqslant\left|z_{n}-z_{0}\right| $ 推出条件的必要性；另一方面，从  $ \left|z_{n}-z_{0}\right|\leqslant\left|x_{n}-x_{0}\right|+\left|y_{n}-y_{0}\right| $ 推出条件的充分性.

注 本题的定理有如下的三角表示:复数列  $ z_{n}=r_{n}(\cos\theta_{n}+i\sin\theta_{n})(n=1,2,\cdots) $ 以  $ z_{0}=r_{0}(\cos\theta_{0}+i\sin\theta_{0})(z_{0}\neq0,z_{0}\neq\infty) $ 为极限的充要条件是实数列  $ \{r_{n}\} $ 及  $ \{\theta_{n}\} $ 分别以  $ r_{0} $ 及  $ \theta_{0} $ 为极限（必要性证明只要适当选择  $ \theta_{n} $ 及  $ \theta_{0} $ 的值）.

18 一个复数列  $ z_{n}=x_{n}+\mathrm{i}y_{n}(n=1,2,\cdots) $ 有极限的充要条件（即柯西准则）是：任给  $ \varepsilon>0 $，存在正整数 N=N( $ \varepsilon $)，使当 n>N 时，恒有

 $$ |z_{n+p}-z_{n}|<\varepsilon\quad(p=1,2,\cdots). $$ 

提示 利用上题、不等式(1.1)及实数情形的柯西准则.

<!-- page: 61 -->

19 试证: 任何有界的复数列必有一个收敛的子数列.

20 如果复数列  $ \{z_{n}\} $ 合于  $ \lim z_{n}=z_{0}\neq\infty $，试证

 $$ \lim_{n\to+\infty}\frac{z_{1}+z_{2}+\cdots+z_{n}}{n}=z_{0} $$ 

当  $ z_{0}=\infty $ 时，结论是否正确？

## (二)

### 1 将复数

 $$ \frac{(\cos5\varphi+\mathrm{i}\sin5\varphi)^{2}}{(\cos3\varphi-\mathrm{i}\sin3\varphi)^{3}} $$ 

化为指数形式和三角形式.(答: $ e^{19\varphi i} $)

2 如果  $ z = e^{it} $，试证：

 $$ z^{n}+\frac{1}{z^{n}}=2\cos\ n t\;; $$ 

 $$ z^{n}-\frac{1}{z^{n}}=2\mathrm{i}\ \sin\ n t $$ 

其中 n 为正整数.

3 设  $ x_{n} + \mathrm{i}y_{n} = (1 - \mathrm{i}\sqrt{3})^{n} $ ( $ x_{n}, y_{n} $ 为实数; n 为正整数).

试证： $ x_{n}y_{n-1}-x_{n-1}y_{n}=4^{n-1}\cdot\sqrt{3} $

4 设  $ z = x + iy $，试证：

 $$ \frac{\left|x\right|+\left|y\right|}{\sqrt{2}}\leqslant\left|z\right|\leqslant\left|x\right|+\left|y\right|. $$ 

5 设  $ z_{1} $ 及  $ z_{2} $ 是两个复数，试证：

 $$ \mid z_{1}-z_{2}\mid\geqslant\mid\mid z_{1}\mid-\mid z_{2}\mid\mid. $$ 

6 设  $ |z| = 1 $，试证：

 $$ \left|\frac{az+b}{\overline{b}z+\overline{a}}\right|=1. $$ 

7 已知正方形  $ z_{1} z_{2} z_{3} z_{4} $ 的相对顶点  $ z_{1}(0,-1) $ 和  $ z_{3}(2,5) $，求顶点  $ z_{2} $ 和  $ z_{4} $ 的坐标.

答: 如图 1.21,  $ z_{2}(4,1) $,  $ z_{4}(-2,3) $.

8 试证：以  $ z_{1}, z_{2}, z_{3} $ 为顶点的三角

<div style="text-align: center;"><img src="images/p0061_img_in_image_box_2450_4354_3968_5783.jpg" alt="图 1.21" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.21</div> </div>

<!-- page: 62 -->

形和以  $ w_{1}, w_{2}, w_{3} $ 为顶点的三角形同向相似的充要条件为

 $$ \left|\begin{array}{l l l}{z_{1}}&{w_{1}}&{1}\\ {z_{2}}&{w_{2}}&{1}\\ {z_{3}}&{w_{3}}&{1}\end{array}\right|=0. $$ 

9 试证: 四个相异点  $ z_{1}, z_{2}, z_{3}, z_{4} $ 共圆周或共直线的充要条件是

 $ \frac{z_{1}-z_{4}}{z_{1}-z_{2}}:\frac{z_{3}-z_{4}}{z_{3}-z_{2}} $为实数（如图1.22）.

<div style="text-align: center;"><img src="images/p0062_img_in_image_box_519_1867_2140_3001.jpg" alt="图 1.22" width="36%" /></div>


<div style="text-align: center;"><img src="images/p0062_img_in_image_box_2309_1830_3925_2972.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 1.22</div> </div>


10 试证:两向量  $ \overrightarrow{Oz_{1}}(z_{1}=x_{1}+iy_{1}) $ 与  $ \overrightarrow{Oz_{2}}(z_{2}=x_{2}+iy_{2}) $ 互相垂直的充要条件是

 $$ \boldsymbol{z}_{1}\;\overline{{\boldsymbol{z}}}_{2}+\overline{{\boldsymbol{z}}}_{1}\;\boldsymbol{z}_{2}=0. $$ 

11 试证：方程

 $$ \left|\frac{z-z_{1}}{z-z_{2}}\right|=k(0<k\neq1,z_{1}\neq z_{2}) $$ 

表示 z 平面上一个圆周，其圆心为  $ z_{0} $，半径为  $ \rho $，且

 $$ z_{0}=\frac{z_{1}-k^{2}z_{2}}{1-k^{2}},\rho=\frac{k\mid z_{1}-z_{2}\mid}{\mid1-k^{2}\mid}. $$ 

 $ ^{*} $12 试证

 $$ \mathrm{R e}z{>}0\leftrightarrow\left|\frac{1-z}{1+z}\right|<1, $$ 

并能从几何意义上来读本题.

<!-- page: 63 -->

## 第二章 解析函数

这一章，研究复变函数的微分法.

解析函数是复变函数论研究的主要对象，它是一类具有某种特性的可微函数。我们首先引入判断函数可微和解析的主要条件——柯西-黎曼方程；其次，把我们在实数域上熟知的初等函数推广到复数域上来，并研究其性质。

#### §1. 解析函数的概念与柯西－黎曼方程

1. 复变函数的导数与微分 复变函数的导数定义, 形式上和数学分析中一元函数的导数定义一致. 因此, 微分学中几乎所有的求导基本公式, 都可不加更改地推广到复变函数上来.

定义 2.1 设函数  $ w = f(z) $ 在点  $ z_{0} $ 的邻域内或包含  $ z_{0} $ 的区域 D 内有定义, 考虑比值

 $$ \frac{\Delta w}{\Delta z}=\frac{f(z)-f(z_{0})}{z-z_{0}}=\frac{f(z_{0}+\Delta z)-f(z_{0})}{\Delta z}\quad(\Delta z\neq0), $$ 

如果当 z 按任意方式趋于  $ z_{0} $ 时，即当  $ \Delta z $ 按任意方式趋于零时，比值  $ \Delta w / \Delta z $ 的极限都存在，且其值有限，则称此极限为函数  $ f(z) $ 在点  $ z_{0} $ 的导数，并记为  $ f'(z_{0}) $，即

$$  f^{\prime}(z_{0})=\operatorname*{l i m}_{\Delta z\to0}\frac{\Delta w}{\Delta z}=\operatorname*{l i m}_{z\to z_{0}}\frac{f(z)-f(z_{0})}{z-z_{0}},   \tag*{(2.1)}$$

<!-- page: 64 -->

这时称函数  $ f(z) $ 于点  $ z_{0} $ 可导.

式(2.1)的极限存在要求与  $ \Delta z $ 趋于零的方式无关，对于函数的这一限制，要比对于实变量 x 的实值函数  $ y = \varphi(x) $ 的类似限制严得多。事实上，实变函数导数存在性的要求意味着：当点  $ x_{0} + \Delta x $ 由左  $ (\Delta x < 0) $ 及右  $ (\Delta x > 0) $ 两个方向趋于  $ x_{0} $ 时，比值  $ \Delta y / \Delta x $ 的极限都存在且相等。而复变函数导数存在性的要求意味着：当点  $ z_{0} + \Delta z $ 沿连接点  $ z_{0} $ 的任意路径趋于点  $ z_{0} $ 时，比值  $ \Delta w / \Delta z $ 的极限都存在，并且这些极限都相等。

和导数的情形一样,复变函数的微分定义,形式上与实变函数的微分定义一致.

设函数  $ w = f(z) $ 在点 z 可导. 于是

 $$ \lim_{\Delta z\to0}\frac{\Delta w}{\Delta z}=f^{\prime}(z), $$ 

即是

 $$ \frac{\Delta w}{\Delta z}=f^{\prime}(z)+\eta,\operatorname*{l i m}_{\Delta z\to0}\eta=0, $$ 

 $$ \Delta w=f^{\prime}(z)\Delta z+\varepsilon, $$ 

其中 $ \left|\varepsilon\right|=\left|\eta\cdot\Delta z\right| $为比 $ \left|\Delta z\right| $高阶的无穷小.

称  $ f'(z)\Delta z $ 为 w = f(z) 在点 z 的微分. 记为 dw 或 df(z), 此时也称 f(z) 在点 z 可微. 即

$$  \mathrm{d}w=f^{\prime}(z)\Delta z.   \tag*{(2.2)}$$

特别，当  $ f(z)=z $ 时， $ \mathrm{d}z=\Delta z $。于是式(2.2)变为

 $$ \mathrm{d}w=f^{\prime}(z)\mathrm{d}z, $$ 

即

 $$ f^{\prime}(z)=\frac{\mathrm{d}w}{\mathrm{d}z}. $$ 

由此可见： $ f(z) $在点z可导与 $ f(z) $在点z可微是等价的.

函数  $ f(z) $ 在点 z 可微，显然  $ f(z) $ 在点 z 连续。但  $ f(z) $ 在点 z 连续却不一定在点 z 可微。并且在复变函数中，处处连续又处处

<!-- page: 65 -->

不可微的函数几乎随手可得，比如

 $$ f(z)=\bar{z},Re z,Im z 及 \mid z\mid $$ 

等等.而在实变函数中,要造一个这种函数就不是容易的事.

例 2.1 函数  $ f(z)=\bar{z} $ 在 z 平面上处处不可微.

证 由第一章习题(一)15 题知此函数在 z 平面上处处连续.

但

 $$ \frac{\Delta f}{\Delta z}=\frac{\overline{z+\Delta z}-\overline{z}}{\Delta z}=\frac{\overline{z}+\overline{\Delta z}-\overline{z}}{\Delta z}=\frac{\overline{\Delta z}}{\Delta z}, $$ 

当  $ \Delta z \rightarrow 0 $ 时，上式极限不存在。因为让  $ \Delta z $ 取实数而趋于零时，其极限为 1； $ \Delta z $ 取纯虚数而趋于零时，其极限为 -1。

例 2.2 试证: 函数  $ f(z) = z^{n} $ (n 为正整数) 在 z 平面上处处可微, 且  $ \frac{\mathrm{d}}{\mathrm{d}z}z^{n} = nz^{n-1} $.

证 设 z 是随意固定的点, 我们有

 $$ \begin{aligned}&\lim_{\Delta z\to0}\frac{\left(z+\Delta z\right)^{n}-z^{n}}{\Delta z}\\=&\lim_{\Delta z\to0}\left[nz^{n-1}+\frac{n(n-1)}{2}z^{n-2}\Delta z+\cdots+(\Delta z)^{n-1}\right]\\=&nz^{n-1}.\end{aligned} $$ 

如函数  $ f(z) $ 在区域 D 内处处可微，则称  $ f(z) $ 在区域  $ D $ 内可微.

### 2. 解析函数及其简单性质

定义 2.2 如果函数  $ w = f(z) $ 在区域 D 内可微，则称  $ f(z) $ 为区域 D 内的解析函数，或称  $ f(z) $ 在区域 D 内解析.

解析函数这一重要概念，是与相伴区域密切联系的。以后，我们说函数  $ f(z) $ 在某点解析，其意义是指  $ f(z) $ 在该点的某一邻域内解析；说函数  $ f(z) $ 在闭域  $ \overline{D} $ 上解析，其意义是指  $ f(z) $ 在包含  $ \overline{D} $ 的某区域内解析。

区域 D 内的解析函数也称为 D 内的全纯函数或正则函数.

容易看出，函数  $ f(z) $ 在区域 D 内解析与函数  $ f(z) $ 在区域 D

<!-- page: 66 -->

内处处解析的说法是等价的.

定义 2.3 若函数  $ f(z) $ 在点  $ z_{0} $ 不解析，但在  $ z_{0} $ 的任一邻域内总有  $ f(z) $ 的解析点，则称  $ z_{0} $ 为函数  $ f(z) $ 的奇点.

例如，w=1/z 在 z 平面上以 z=0 为奇点.

通常泛称的解析函数是容许有奇点的，但更主要的是，它在复平面上总有解析点。所以它不包含像 $ \bar{z} $这种处处不解析的函数。解析函数是复变函数研究的主要对象，它具有很好的性质。例如，由函数在一点解析（注意，只是在该点的邻域内可微！）就可推出其各阶导数也在该点解析（本书第三章定理3.14），并且就可以展成幂级数（本书第四章定理4.14）。这在一元实变函数是绝对不可能的。因为一元实变函数在一个区间上的导数存在，甚至不可能保证其导数连续。

把数学分析中有关求导法则推广到复变函数，就有：

（1）如函数  $ f_{1}(z) $、 $ f_{2}(z) $ 在区域 D 内解析，则其和、差、积、商（在商的情形，要求分母在 D 内不为零）在 D 内解析，并且

 $$ \begin{align*}&\left[f_{1}(z)\pm f_{2}(z)\right]^{\prime}=f_{1}^{\prime}(z)\pm f_{2}^{\prime}(z),\\&\left[f_{1}(z)f_{2}(z)\right]^{\prime}=f_{1}^{\prime}(z)f_{2}(z)+f_{1}(z)f_{2}^{\prime}(z),\\&\left[\frac{f_{1}(z)}{f_{2}(z)}\right]^{\prime}=\frac{f_{1}^{\prime}(z)f_{2}(z)-f_{1}(z)f_{2}^{\prime}(z)}{\left[f_{2}(z)\right]^{2}}\quad(f_{2}(z)\neq0).\end{align*} $$ 

(2) (复合函数的求导法则) 设函数  $ \xi = f(z) $ 在区域 D 内解析，函数  $ w = g(\xi) $ 在区域 G 内解析。若对于 D 内每一点 z，函数  $ f(z) $ 的值  $ \xi $ 均属于 G，则  $ w = g[f(z)] $ 在 D 内解析，且

 $$ \frac{\mathrm{d}g\left[f(z)\right]}{\mathrm{d}z}=\frac{\mathrm{d}g(\xi)}{\mathrm{d}\xi}\cdot\frac{\mathrm{d}f(z)}{\mathrm{d}z}. $$ 

例 2.3 设多项式  $ P(z) = a_{0} z^{n} + a_{1} z^{n-1} + \cdots + a_{n} (a_{0} \neq 0) $，由例 2.2 及上述求导法则(1)知， $ P(z) $ 在 z 平面上解析，且

 $$ P^{\prime}(z)=n a_{0}z^{n-1}+\left(n-1\right)a_{1}z^{n-2}+\cdots+2a_{n-2}z+a_{n-1}. $$ 

##### 例 2.4 设有理分式函数

<!-- page: 67 -->

$$ \frac{P(z)}{Q(z)}=\frac{a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n}}{b_{0}z^{m}+b_{1}z^{m-1}+\cdots+b_{m}}\quad(a_{0}\neq0,b_{0}\neq0), $$ 

由前例及上述求导法则(1)知,此函数在 z 平面上除使分母 Q(z)=0 的各点外解析,而使 Q(z)=0 的各点就是此有理分式函数的奇点.

例 2.5 设函数  $ f(z) = (3z^{2} - 4z + 5)^{11} $，则由例 2.2 及上述复合函数的求导法则，有

 $$ \begin{aligned}f^{\prime}(z)&=11(3z^{2}-4z+5)^{10}\cdot\frac{\mathrm{d}}{\mathrm{d}z}(3z^{2}-4z^{\prime}+5)\\&=11(3z^{2}-4z+5)^{10}(6z-4)\\&=22(3z-2)(3z^{2}-4z+5)^{10}.\end{aligned} $$ 

对于实变复值函数  $ z(t)=x(t)+iy(t) $ ( $ t\in[\alpha,\beta] $)，其求导法则可直接由定义 2.1 得到，即

 $$ z^{\prime}(t)=x^{\prime}(t)+\mathrm{i}y^{\prime}(t)\quad(t\in[\alpha,\beta]). $$ 

3. 柯西 - 黎曼方程（简称 C. - R. 方程） 假设

 $$ \boldsymbol{w}=\boldsymbol{f}(\boldsymbol{z})=\boldsymbol{u}(\boldsymbol{x},\boldsymbol{y})+\mathrm{i}\boldsymbol{v}(\boldsymbol{x},\boldsymbol{y}) $$ 

是复变函数  $ z = x + iy $ 的一个定义在区域 D 内的函数. 当二元实函数  $ u(x, y) $ 及  $ v(x, y) $ 给定时, 此函数也就完全确定. 一般说来, 如果函数  $ u(x, y) $ 与  $ v(x, y) $ 互相独立, 即使函数  $ u(x, y) $ 及  $ v(x, y) $ 对 x 与 y 所有偏导数都存在, 函数  $ f(z) $ 通常仍是不可微的. 例如,  $ w = \bar{z} = x - iy $ 处处连续, 并且 u = x, v = -y 对 x 和 y 的一切偏导数都存在且连续, 但由例 2.1 知,  $ w = \bar{z} $ 却是一个处处不可微的函数.

因此，如果函数  $ f(z) $ 是可微的，它的实部 u(x, y) 与虚部 v(x, y) 应当不是互相独立的，而必须适合一定的条件，下面我们就来探讨这种条件.

若  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $ 在一点 z=x+iy 可微，而且设

$$  \lim_{\Delta z\to0}\frac{f(z+\Delta z)-f(z)}{\Delta z}=f^{\prime}(z),   \tag*{(2.3)}$$

<!-- page: 68 -->

又设  $ \Delta z = \Delta x + i\Delta y $,  $ f(z + \Delta z) - f(z) = \Delta u + i\Delta v $, 其中

 $$ \begin{aligned}\Delta u&=u\left(x+\Delta x,y+\Delta y\right)-u\left(x,y\right),\\\Delta v&=v\left(x+\Delta x,y+\Delta y\right)-v\left(x,y\right),\end{aligned} $$ 

(2.3) 变为

$$  \lim_{\Delta x\to0\atop\Delta y\to0}\frac{\Delta u+\mathrm{i}\Delta v}{\Delta x+\mathrm{i}\Delta y}=f^{\prime}(z).   \tag*{(2.4)}$$

因为  $ \Delta z = \Delta x + i\Delta y $ 无论按什么方式趋于零时，(2.4)总是成立的。先设  $ \Delta y = 0, \Delta x \to 0 $，即变点  $ z + \Delta z $ 沿平行于实轴的方向趋于

点z（图2.1），此时(2.4)成为

 $$ \lim_{\Delta x\to0}\frac{\Delta u}{\Delta x}+\mathrm{i}\lim_{\Delta x\to0}\frac{\Delta v}{\Delta x}=f^{\prime}(z), $$ 

于是知 $ \frac{\partial u}{\partial x},\frac{\partial v}{\partial x} $必然存在，且有

<div style="text-align: center;"><img src="images/p0068_img_in_image_box_2539_2252_3960_3471.jpg" alt="图2.1" width="31%" /></div>


 $$ \begin{align*}\frac{\partial u}{\partial x}+i\frac{\partial v}{\partial x}&=f'(z)\\&=\lim_{\substack{\Delta y=0\\ \Delta x\to0}}\frac{\Delta w}{\Delta z}\\&=\lim_{y=y_0\atop x\to x_0}\frac{f(z)-f(z_0)}{z-z_0}.\end{align*} $$ 

<div style="text-align: center;"><div style="text-align: center;">图2.1</div> </div>


同样，设  $ \Delta x = 0, \Delta y \to 0 $，即变点  $ z + \Delta z $ 沿平行于虚轴的方向趋于点 z（图 2.1），此时（2.4）成为

 $$ -\mathrm{~i~}\operatorname*{l i m}_{\Delta y\to0}\frac{\Delta u}{\Delta y}+\operatorname*{l i m}_{\Delta y\to0}\frac{\Delta v}{\Delta y}=f^{\prime}\left(z\right), $$ 

故知 $ \frac{\partial u}{\partial y}, \frac{\partial v}{\partial y} $亦必存在，且有

 $$ \begin{aligned}-\mathrm{i}\frac{\partial u}{\partial y}+\frac{\partial v}{\partial y}&=f^{\prime}(z)\\&=\lim_{\substack{\Delta x=0\\ \Delta y\to0}}\frac{\Delta w}{\Delta z}\end{aligned} $$

<!-- page: 69 -->

$$  =\operatorname*{l i m}_{\stackrel{x=x_{0}}{y\to y_{0}}}\frac{f(z)-f(z_{0})}{z-z_{0}}.   \tag*{(2.6)}$$

比较(2.5)及(2.6)得出

$$  \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\frac{\partial u}{\partial y}=-\frac{\partial v}{\partial x},   \tag*{(C.-R.)}$$

这是关于 u 及 v 的偏微分方程组，称为柯西－黎曼方程（简记为 C.-R.）.

注 灵活应用(2.5)及(2.6)这两个公式, 计算  $ f(z) $ 的实部  $ u(x, y) $ 及虚部  $ v(x, y) $ 在点  $ (x_{0}, y_{0}) $ 的偏导数, 是比较方便的.

总结以上探讨，即得下述定理：

定理 2.1(可微的必要条件) 设函数

 $$ f(z)=u(x,y)+\mathrm{i}v(x,y) $$ 

在区域 D 内有定义，且在 D 内一点  $ z = x + iy $ 可微，则必有

（1）偏导数  $ u_{x} $、 $ u_{y} $、 $ v_{x} $、 $ v_{y} $ 在点  $ (x,y) $ 存在；

(2)  $ u(x,y) $、 $ v(x,y) $ 在点  $ (x,y) $ 满足 C. -R. 方程.

由下例可见定理中的条件不是充分的：

例 2.6 函数  $ f(z)=\sqrt{|xy|} $ 在 z=0 满足定理 2.1 中的条件，但在 z=0 不可微.

证 因为  $ u(x,y)=\sqrt{|xy|} $,  $ v(x,y)\equiv0 $,

 $$ u_{x}\left(0,0\right)=\lim_{\Delta x\to0}\frac{u\left(\Delta x,0\right)-u\left(0,0\right)}{\Delta x}=0=v_{y}\left(0,0\right), $$ 

 $$ u_{y}\left(0,0\right)=\lim_{\Delta y\rightarrow0}\frac{u\left(0,\Delta y\right)-u\left(0,0\right)}{\Delta y}=0=-\;v_{x}\left(0,0\right), $$ 

但是

 $$ \frac{f(\Delta z)-f(0)}{\Delta z}=\frac{\sqrt{|\Delta x\Delta y|}}{\Delta x+i\Delta y} $$ 

在  $ \Delta z \rightarrow 0 $ 时无极限. 这只要让  $ \Delta z = \Delta x + i\Delta y $ 沿射线  $ \Delta y = k\Delta x $ ( $ \Delta x > 0 $) 随  $ \Delta x \rightarrow 0 $ 而趋于零, 即知上述比值是一个与 k 有关的值

<!-- page: 70 -->

$$ \frac{\sqrt{\vert k\vert}}{1+k i}. $$ 

我们把定理 2.1 的条件适当加强，就得到

定理 2.2 （可微的充要条件） 设函数  $ f(z) = u(x, y) + iv(x, y) $ 在区域 D 内有定义，则  $ f(z) $ 在 D 内一点  $ z = x + iy $ 可微的充要条件是

（1）二元函数  $ u(x,y) $、 $ v(x,y) $ 在点  $ (x,y) $ 可微；

(2)  $ u(x, y) $、 $ v(x, y) $ 在点  $ (x, y) $ 满足 C. -R. 方程.

上述条件满足时， $ f(z) $ 在点 z = x + iy 的导数可以表示为下列形式之一：

$$  \begin{aligned}f^{\prime}(z)&=\frac{\partial u}{\partial x}+\mathrm{i}\frac{\partial v}{\partial x}=\frac{\partial v}{\partial y}-\mathrm{i}\frac{\partial u}{\partial y}\\&=\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}=\frac{\partial v}{\partial y}+\mathrm{i}\frac{\partial v}{\partial x}.\end{aligned}   \tag*{(2.7)}$$

证 必要性 设  $ f(z) $ 在 D 内一点 z 可微，则

$$  \Delta f(z)=f^{\prime}(z)\Delta z+\eta\Delta z,   \tag*{(2.8)}$$

其中  $ \eta $ 是随  $ \Delta z \rightarrow 0 $ 而趋于零的复数. 若命

 $$ f^{\prime}\left(z\right)=\alpha+\mathrm{i}\beta,\Delta z=\Delta x+\mathrm{i}\Delta y,\Delta f(z)=\Delta u+\mathrm{i}\Delta v, $$ 

则(2.8)可写成

 $$ \Delta u+\mathrm{i}\Delta v=\alpha\Delta x-\beta\Delta y+\mathrm{i}\left(\beta\Delta x+\alpha\Delta y\right)+\eta_{1}+\mathrm{i}\eta_{2}, $$ 

这里  $ \eta_{1} = \mathrm{Re}(\eta \cdot \Delta z) $， $ \eta_{2} = \mathrm{Im}(\eta \cdot \Delta z) $ 是  $ \left|\Delta z\right| = \sqrt{(\Delta x)^{2} + (\Delta y)^{2}} $ 的高阶无穷小.

比较上式两端的实、虚部，即得

 $$ \begin{aligned}\Delta u&=\alpha\Delta x-\beta\Delta y+\eta_{1},\\\Delta v&=\beta\Delta x+\alpha\Delta y+\eta_{2},\end{aligned} $$ 

由数学分析中二元函数的微分定义即知， $ u(x,y) $ 与  $ v(x,y) $ 在点  $ (x,y) $ 可微，且

 $$ u_{x}=\alpha=v_{y},u_{y}=-\beta=-\upsilon_{x}.\eqno(\mathrm{C.}-\mathrm{R.}) $$ 

充分性 由  $ u(x,y) $ 及  $ v(x,y) $ 的可微性即知，在点  $ (x,y) $ 有

<!-- page: 71 -->

$$ \Delta u=u_{x}\Delta x+u_{y}\Delta y+\eta_{1}, $$ 

 $$ \Delta v=v_{x}\Delta x+v_{y}\Delta y+\eta_{2}, $$ 

其中  $ \eta_{1} $ 及  $ \eta_{2} $ 是  $ \sqrt{(\Delta x)^{2}+(\Delta y)^{2}} $ 的高阶无穷小.

再由 C.-R. 方程, 可设

 $$ \alpha=u_{x}=v_{y},u_{y}=-v_{x}=-\beta, $$ 

于是就有

 $$ \begin{aligned}\Delta f&=\Delta u+\mathrm{i}\Delta v=\alpha\Delta x-\beta\Delta y+\eta_{1}+\mathrm{i}\left(\beta\Delta x+\alpha\Delta y+\eta_{2}\right)\\&=\left(\alpha+\mathrm{i}\beta\right)\left(\Delta x+\mathrm{i}\Delta y\right)+\eta_{1}+\mathrm{i}\eta_{2},\end{aligned} $$ 

或

 $$ \frac{\Delta f}{\Delta z}=\alpha+\mathrm{i}\beta+\eta. $$ 

其中  $ \eta=\frac{\eta_{1}+i\eta_{2}}{\Delta x+i\Delta y} $ 随  $ \Delta z\rightarrow0 $ 而趋于零. 因为

 $$ |\eta|\leqslant\frac{|\eta_{1}|}{\sqrt{(\Delta x)^{2}+(\Delta y)^{2}}}+\frac{|\eta_{2}|}{\sqrt{(\Delta x)^{2}+(\Delta y)^{2}}}, $$ 

所以

 $$ \lim_{\Delta z\to0}\frac{\Delta f}{\Delta z}=\alpha+\mathrm{i}\beta, $$ 

即是说

 $$ \begin{align*}f^{\prime}\left(z\right)&=\alpha+\mathrm{i}\beta=u_{x}+\mathrm{i}v_{x}=v_{y}-\mathrm{i}u_{y}\\&=u_{x}-\mathrm{i}u_{y}=v_{y}+\mathrm{i}v_{x}.\end{align*} $$ 

由数学分析知道,二元函数的可微性可以通过偏导数的连续性看出来,于是我们有

推论 2.3 （可微的充分条件） 设函数  $ f(z) = u(x, y) + iv(x, y) $ 在区域 D 内有定义，则  $ f(z) $ 在 D 内一点  $ z = x + iy $ 可微的充分条件是

（1） $ u_{x} $、 $ u_{y} $、 $ v_{x} $、 $ v_{y} $ 在点  $ (x,y) $ 处连续；

(2)  $ u(x,y) $、 $ v(x,y) $ 在点  $ (x,y) $ 处满足 C.-R. 方程.

由定义 2.2 及定理 2.2, 我们得到一个刻画函数在区域内解析的定理.

定理 2.4 函数  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 在区域 D 内解析的充要条件是：

<!-- page: 72 -->

（1）二元函数  $ u(x,y) $、 $ v(x,y) $ 在区域 D 内可微；

(2)  $ u(x,y) $、 $ v(x,y) $ 在 D 内满足 C. -R. 方程.

由定义 2.2 及推论 2.3, 我们有

定理 2.5 函数  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 在区域 D 内解析的充分条件是

（1） $ u_{x} $、 $ u_{y} $、 $ v_{x} $、 $ v_{y} $ 在D内连续；

(2)  $ u(x,y) $、 $ v(x,y) $ 在 D 内满足 C. -R. 方程.

并且  $ f'(z) $ 可由公式 (2.7) 给出.

从以上几个定理，我们可以看出：C. - R. 方程是判断复变函数在一点可微或在一区域内解析的主要条件，在哪一点不满足它，函数在那一点就不可微；在哪个区域内不满足它，函数在那个区域内就不解析。定理2.4或定理2.5既提供了判别函数解析性的方法，又指出了求导数的公式(2.7)。而用它求导数，可避免计算极限(2.1)所带来的困难。

例 2.7 讨论函数  $ f(z) = |z|^{2} $ 的解析性.

解 因  $ u(x,y)=x^{2}+y^{2} $， $ v(x,y)\equiv0 $，故

 $$ u_{x}=2x,u_{y}=2y,v_{x}=v_{y}=0. $$ 

这四个偏导数在 z 平面上处处连续，但只在 z=0 处满足 C. -R.

方程. 故函数  $ f(z) $ 只在 z=0 可微，从而，此函数在 z 平面上处处不解析. 并且  $ f'(0) = (u_{x} + i v_{x}) \mid_{(0,0)} = 0 $.

例 2.8 讨论函数  $ f(z) = x^{2} - iy $ 的可微性和解析性.

解 因  $ u(x,y)=x^{2} $,  $ v(x,y)=-y $, 故

 $$ u_{x}=2x,u_{y}=0,v_{x}=0,v_{y}=-1, $$ 

所以

 $$ u_{y}=0=-\;v_{x}. $$ 

要  $ 2x = u_{x} = v_{y} = -1 $，必须  $ x = -\frac{1}{2} $。故仅在直线  $ x = -\frac{1}{2} $ 上，C.

- R. 方程成立，且偏导数连续。从而仅在直线  $ x = -\frac{1}{2} $ 上  $ f(z) $ 可

微，但在 z 平面上， $ f(z) $ 却处处不解析。并且

<!-- page: 73 -->

$$ \begin{aligned}f^{\prime}(z)\bigg|_{x=-\frac{1}{2}}&=(u_{x}+\mathrm{i}v_{x})\bigg|_{x=-\frac{1}{2}}\\&=(2x+\mathrm{i}\cdot0)\bigg|_{x=-\frac{1}{2}}=-1.\end{aligned} $$ 

注上述两例,由于函数  $ f(z) $ 只有一个孤立点或只在一条直线上可微,各点都未形成由可微点构成的圆邻域,故  $ f(z) $ 在其上都不解析,从而在 z 平面上处处不解析.

例 2.9 试证函数  $ f(z) = \mathrm{e}^{x}\left(\cos y + \mathrm{i}\sin y\right) $ 在 z 平面上解析，且  $ f'(z) = f(z) $.

证 因  $ u(x,y)=\mathrm{e}^{x}\cos y $,  $ v(x,y)=\mathrm{e}^{x}\sin y $, 而

 $$ u_{x}=\mathrm{e}^{x}\cos y,u_{y}=-\mathrm{e}^{x}\sin y, $$ 

 $$ v_{x}=\mathrm{e}^{x}\sin y,v_{y}=\mathrm{e}^{x}\cos y $$ 

在 z 平面上处处连续，且适合 C. -R. 方程. 由定理 2.5 即知  $ f(z) $ 在 z 平面上解析，并且

 $$ f^{\prime}(z)=u_{x}+\mathrm{i}v_{x}=\mathrm{e}^{x}\cos y+\mathrm{i}\mathrm{e}^{x}\sin y=f(z). $$ 

* 例 2.10 若函数  $ f(z) = u(x, y) + iv(x, y) $ 在区域  $ D' $ 内解析，且  $ f'(z) \neq 0 (z \in D) $，则

 $$ u\left(x,y\right)=c_{1.},v\left(x,y\right)=c_{2} $$ 

( $ c_{1},c_{2} $为常数)是D内两组正交曲线族.

证 因  $ f'(z) = u_{x} + \mathrm{i} v_{x} \neq 0 (z \in D) $，故在点  $ (x, y) $， $ u_{x} $ 与  $ v_{x} $ 必不全为零.

（1）设在点 $ (x,y) $， $ u_{x}\neq0 $ 且  $ v_{x}\neq0 $，则曲线  $ u(x,y)=c_{1} $ 的斜率由

 $$ 0=\mathrm{d}u=u_{x}\mathrm{d}x+u_{y}\mathrm{d}y $$ 

求得为

 $$ k_{u}=-\frac{u_{x}}{u_{y}}; $$ 

同理，求得曲线  $ v(x,y)=c_{2} $ 的斜率为

<!-- page: 74 -->

$$ k_{v}=-\frac{v_{x}}{v_{y}}, $$ 

故在点 $ (x,y) $,

 $$ k_{u}\cdot k_{v}=\frac{u_{x}}{u_{y}}\cdot\frac{v_{x}}{v_{y}}\frac{(\mathrm{C.}-\mathrm{R.})}{}\frac{v_{y}}{-v_{x}}\cdot\frac{v_{x}}{v_{y}}=-1. $$ 

所以曲线  $ u(x,y)=c_{1} $ 及  $ v(x,y)=c_{2} $ 在点  $ (x,y) $ 正交.

（2）设在点 $ (x,y) $，

 $$ u_{x}\neq0\  且 \ v_{x}=0, $$ 

或

 $$ u_{x}=0\  且 \ v_{x}\neq0. $$ 

此时，过交点的两条切线，必然一条为水平切线，另一条为铅直线，它们仍然在交点处正交.

最后，我们还要指出：当  $ z_{0}=x_{0}+\mathrm{i}y_{0}\in D,f^{\prime}(z_{0})\neq0 $ 时，则两条曲线：

 $$ u\left(x,y\right)=u\left(x_{0},y_{0}\right),v\left(x,y\right)=v\left(x_{0},y_{0}\right) $$ 

必在 $ (x_{0},y_{0}) $处正交.

思考题 （1）复变函数的可微性与解析性有什么异同？

（2）判断函数的解析性有哪些方法？

#### §2. 初等解析函数

例 2.3 及例 2.4 已经指出了多项式及有理分式函数的解析性. 这一节和下一节将进一步叙述复变数的初等函数, 这些函数是数学分析中通常的初等函数在复数域中的自然推广. 经过推广之后的初等函数, 往往会获得一些新的性质. 例如, 复指数函数  $ e^{z} $ 是有周期的, 复三角函数  $ \sin z $ 及  $ \cos z $ 已不再是有界的, 等等.

另外，这一节主要讨论复初等单值函数的解析性，这可从它们各自在一定区域内的可微性来判定.

1. 指数函数 由例 2.9, 我们知道  $ f(z) = \mathrm{e}^{x} (\cos y + \sin y) $

<!-- page: 75 -->

在 z 平面上解析，且  $ f'(z) = f(z) $. 进一步，还易验证

 $$ f(z_{1}+z_{2})=f(z_{1})f(z_{2}). $$ 

因此，我们有理由给出下面定义.

定义 2.4 对于任何复数  $ z = x + iy $，我们用关系式

$$  \mathrm{e}^{z}=\mathrm{e}^{x+\mathrm{i}y}=\mathrm{e}^{x}\left(\cos y+\mathrm{i}\sin y\right)   \tag*{(2.9)}$$

来规定指数函数  $ e^{z} $

对于复指数函数  $ e^{z} $，我们指出它具有如下的性质：

(1) 对于实数 z = x (y = 0) 来说, 我们的定义与通常实指数函数的定义是一致的.

(2)  $ \left|e^{x}\right|=e^{x}>0,\arg e^{z}=y $; 在 z 平面上  $ e^{z}\neq0 $.

（3） $ e^{z} $ 在 z 平面上解析，且  $ (e^{z})^{\prime}=e^{z} $

（4）加法定理成立，即  $ e^{z_{1}+z_{2}}=e^{z_{1}}e^{z_{2}} $

(5)  $ e^{z} $ 是以  $ 2\pi i $ 为基本周期的周期函数 (注(1)).

因对任一整数 k,  $ \mathrm{e}^{z+2k\pi i} = \mathrm{e}^{x} $,

这里  $ \mathrm{e}^{2k\pi i} = 1 $.

（6）极限  $ \lim_{x \to \infty} e^{x^{2}} $ 不存在，即  $ e^{\infty} $ 无意义.

因当 z 沿实轴趋于  $ +\infty $ 时,  $ e^{z} \to \infty $; 当 z 沿实轴趋于  $ -\infty $ 时,  $ e^{z} \to 0 $.

注 (1) 如一函数  $ f(z) $ 当 z 增加一个定值  $ \omega $ 时其值不变，即  $ f(z + \omega) = f(z) $，则称  $ f(z) $ 为周期函数， $ \omega $ 称为  $ f(z) $ 的周期。如  $ f(z) $ 的所有周期都是某一周期  $ \omega $ 的整倍数，则称  $ \omega $ 为  $ f(z) $ 的基本周期。

(2) (2.9) 式中，当 z 的实部 x=0 时，就得到欧拉公式

 $$ \mathrm{e}^{\mathrm{i}y}=\cos y+\mathrm{i}\sin y, $$ 

所以(2.9)是欧拉公式的推广.

（3）因  $ e^{z}e^{-z}=e^{0}=1 $ ，从而

 $$ \mathrm{e}^{-z}=\frac{1}{\mathrm{e}^{z}};\frac{\mathrm{e}^{z_{1}}}{\mathrm{e}^{z_{2}}}=\mathrm{e}^{z_{1}-z_{2}}. $$ 

（4） $ e^{z} $ 仅仅是一个记号，其意义如定义 2.4，它与 e = 2.718…

<!-- page: 76 -->

的乘方不同,没有幂的意义.有时将复指数函数 $ e^{z} $写成 $ \exp z $,表示区别.

（5）虽然在 z 平面上， $ e^{z}=e^{z+2k\pi i} $（k 为整数），但

 $$ \left(\mathrm{e}^{z}\right)^{\prime}=\mathrm{e}^{z}\neq0, $$ 

即不满足罗尔(Rolle)定理，故数学分析中的微分中值定理不能直接推广到复平面上来. 不过，洛必达(L'Hospital)法则在复平面上却是成立的(见本章习题2).

 $$ (6)\mathrm{e}^{z_{1}}=\mathrm{e}^{z_{2}}\Longleftrightarrow\mathrm{z}_{1}=\mathrm{z}_{2}+2k\pi\mathrm{i}(k=0,\pm1,\cdots). $$ 

*例 2.11 对任意的复数 z，若  $ \mathrm{e}^{z+\omega} = \mathrm{e}^{z} $，则必有

 $$ \omega=2k\pi i(k 为整数 )． $$ 

证 由假设, 对 z=0, $ \omega=a+ib $, 就有

 $$ \mathrm{e}^{\omega}=\mathrm{e}^{0}=1,\mathrm{e}^{a}\left(\cos b+\mathrm{i}\sin b\right)=1, $$ 

于是

 $$ \mathrm{e}^{a}=1,\cos b+\mathrm{i}\sin b=1, $$ 

 $$ a=0,\cos b=1,\sin b=0, $$ 

 $ a=0, b=2k\pi $ (k为整数)，

 $$ \omega=a+i b=2k\pi i(k 为整数 ). $$ 

2. 三角函数与双曲函数 由(2.9)，当 x=0 时推得

 $$ \mathrm{e}^{iy}=\cos y+\mathrm{i}\sin y, $$ 

 $$ \mathrm{e}^{-\mathrm{i}y}=\cos y-\mathrm{i}\sin y. $$ 

这里左端表示右端那个确定的复数，从而得到

 $$ \sin y=\frac{\mathrm{e}^{\mathrm{i}y}-\mathrm{e}^{-\mathrm{i}y}}{2\mathrm{i}},\cos y=\frac{\mathrm{e}^{\mathrm{i}y}+\mathrm{e}^{-\mathrm{i}y}}{2} $$ 

对于任意的实数 y 成立. 这两个公式中的 y 代以任意复数 z 后，由(2.9)，右端有意义，而左端尚无意义，因而我们给出如下定义.

定义 2.5 规定

 $$ \sin z=\frac{\mathrm{e}^{iz}-\mathrm{e}^{-iz}}{2i},\cos z=\frac{\mathrm{e}^{iz}+\mathrm{e}^{-iz}}{2}, $$ 

并分别称为 z 的正弦函数和余弦函数.

这样定义的正弦函数和余弦函数具有如下性质：

<!-- page: 77 -->

（1）对于 z 为实数 y 来说，我们的定义与通常正弦函数及余弦函数的定义是一致的.

（2）在 z 平面上是解析的，且

 $$ \left(\sin z\right)^{\prime}=\cos z,\left(\cos z\right)^{\prime}=-\sin z. $$ 

因为

 $$ (\sin z)^{\prime}=\frac{1}{2\mathrm{i}}(\mathrm{e}^{\mathrm{i}z}-\mathrm{e}^{-\mathrm{i}z})^{\prime}=\frac{1}{2}(\mathrm{e}^{\mathrm{i}z}+\mathrm{e}^{-\mathrm{i}z})=\cos z. $$ 

同理可证另一个.

(3)  $ \sin z $ 是奇函数,  $ \cos z $ 是偶函数, 并遵从通常的三角恒等式:

 $$ \sin^{2}z+\cos^{2}z=1, $$ 

 $$ \sin(z_{1}+z_{2})=\sin z_{1}\cdot\cos z_{2}+\cos z_{1}\cdot\sin z_{2}, $$ 

 $$ \cos(z_{1}+z_{2})=\cos z_{1}\cdot\cos z_{2}-\sin z_{1}\cdot\sin z_{2}, $$ 

等等.例如

 $$ \begin{align*}\sin(z_1+z_2)&=\frac{e^{i(z_1+z_2)}-e^{-i(z_1+z_2)}}{2i}\\&=\frac{e^{iz_1}e^{iz_2}-e^{-iz_1}e^{-iz_2}}{2i}\\&=\frac{e^{iz_1}-e^{-iz_1}}{2i}\cdot\frac{e^{iz_2}+e^{-iz_2}}{2}\\&\quad+\frac{e^{iz_1}+e^{-iz_1}}{2}\cdot\frac{e^{iz_2}-e^{-iz_2}}{2i}\\&=\sin z_1\cdot\cos z_2+\cos z_1\cdot\sin z_2.\end{align*} $$ 

（4） $ \sin z $ 及  $ \cos z $ 是以  $ 2\pi $ 为周期的周期函数.

因由定义 2.5，

 $$ \begin{align*}\cos(z+2\pi)&=\frac{e^{i(z+2\pi)}+e^{-i(z+2\pi)}}{2}\\&=\frac{e^{iz}e^{2\pi i}+e^{-iz}e^{-2\pi i}}{2}\\&=\frac{e^{iz}+e^{-iz}}{2}=\cos z.\end{align*} $$

<!-- page: 78 -->

同理可证另一个.

(5)  $ \sin z $ 的零点（即  $ \sin z = 0 $ 的根）为

 $$ z=n\pi\quad(n=0,\pm1,\cdots). $$ 

 $ \cos z $ 的零点为

 $$ z=\left(n+\frac{1}{2}\right)\pi\quad(n=0,\pm1,\cdots). $$ 

事实上，因为方程  $ \sin z = 0 $ 可以写成  $ e^{2iz} = 1 $。如令  $ z = \alpha + i\beta $，即可写成  $ e^{-2\beta}e^{2ia} = 1 = e^{2n\pi i} $ 故

 $$ \mathrm{e}^{-2\beta}=1,2\alpha=2n\pi\quad(n=0,\pm1,\cdots), $$ 

即

 $$ \beta=0,\alpha=n\pi\quad(n=0,\pm1,\cdots). $$ 

所以  $ z = n\pi $ （ $ n = 0, \pm 1, \cdots $）是  $ \sin z $ 的零点.

同理可推得  $ \cos z $ 的零点.

（6）在复数域内不能再断言

 $$ \left|\sin z\right|\leqslant1,\left|\cos z\right|\leqslant1. $$ 

例如，取  $ z = \mathrm{i} y (y > 0) $，则

 $$ \cos(\mathrm{i}y)=\frac{\mathrm{e}^{\mathrm{i}(\mathrm{i}y)}+\mathrm{e}^{-\mathrm{i}(\mathrm{i}y)}}{2}=\frac{\mathrm{e}^{-y}+\mathrm{e}^{y}}{2}>\frac{\mathrm{e}^{y}}{2} $$ 

只要 y 充分大, $ \cos i y $ 就可大于任一预先给定的正数.

例 2.12 求  $ \sin(1+2i) $ 的值.

解

 $$ \begin{aligned}\sin(1+2i)&=\frac{e^{i(1+2i)}-e^{-i(1+2i)}}{2i}=\frac{e^{-2+i}-e^{2-i}}{2i}\\&=\frac{e^{-2}(\cos1+i\sin1)-e^{2}(\cos1-i\sin1)}{2i}\\&=\frac{e^{2}+e^{-2}}{2}\sin1+i\frac{e^{2}-e^{-2}}{2}\cos1\\&=cosh2\sin1+i\sinh2\cos1.\end{aligned} $$ 

例 2.13 对任意的复数 z，若  $ \sin(z + \omega) = \sin z $，则必有

 $$ \omega=2k\pi\quad(k 为整数 ). $$ 

证 由假设,有  $ \sin(z+\omega)-\sin z=0 $,因而

 $$ \sin\frac{\omega}{2}\cos\left(z+\frac{\omega}{2}\right)=0, $$

<!-- page: 79 -->

效必

 $$ \omega=2k\pi\quad(k 为整数 ). $$ 

定义 2.6 规定

 $$ \tan z=\frac{\sin z}{\cos z},\cot z=\frac{\cos z}{\sin z}, $$ 

 $$ \sec z=\frac{1}{\cos z},\csc z=\frac{1}{\sin z}, $$ 

分别称为 z 的正切函数、余切函数、正割函数及余割函数.

这四个函数都在 z 平面上使分母不为零的点处解析，且

 $$ (\tan z)^{\prime}=\sec^{2}z,(\cot z)^{\prime}=-\csc^{2}z $$ 

 $$ (\sec z)^{\prime}=\sec z\cdot\tan z,(\csc z)^{\prime}=-\csc z\cdot\cot z. $$ 

正切函数和余切函数的周期为  $ \pi $，正割函数及余割函数的周期为  $ 2\pi $，例如，就函数  $ \tan z $ 来说，它在  $ z \neq \left(n + \frac{1}{2}\right)\pi - (n = 0, \pm 1, \cdots) $ 的各点处解析，且有  $ \tan(z + \pi) = \tan z $。因为

 $$ \tan(z+\pi)=\frac{\sin(z+\pi)}{\cos(z+\pi)}=\frac{-\sin z}{-\cos z}=\frac{\sin z}{\cos z}=\tan z. $$ 

*例 2.14 对任意的复数 z，若  $ \tan(z + \omega) = \tan z $，则必有

 $$ \omega=k\pi\quad(k 为整数 ). $$ 

证 由定义 2.6 及定义 2.5 知

 $$ \tan z=\frac{\sin z}{\cos z}=\frac{\mathrm{e}^{2\mathrm{i}x}-1}{\mathrm{i}\left(\mathrm{e}^{2\mathrm{i}x}+1\right)}, $$ 

由此可见， $ \tan(z+\omega)=\tan z $ 等价于  $ \mathrm{e}^{2\mathrm{i}(z+\omega)}=\mathrm{e}^{2\mathrm{i}z} $. 故必有

 $$ \mathrm{e}^{2\mathrm{i}\omega}=1. $$ 

所以

 $$ \omega=k\pi\quad(k 为整数 ). $$ 

定义 2.7 规定

 $$ \sinh z=\frac{\mathrm{e}^{z}-\mathrm{e}^{-z}}{2},\cosh z=\frac{\mathrm{e}^{z}+\mathrm{e}^{-z}}{2}, $$ 

 $$ \tanh z=\frac{\sinh z}{\cosh z},\coth z=\frac{1}{\tanh z}, $$ 

 $$ \operatorname{sech} z=\frac{1}{\cosh z},\operatorname{csch} z=\frac{1}{\sinh z}, $$

<!-- page: 80 -->

并分别称为 z 的双曲正弦函数、双曲余弦函数、双曲正切函数、双

曲余切函数、双曲正割函数及双曲余割函数.

显然，它们都是解析函数，各有其解析区域，且都是相应的实双曲函数在复数域内的推广.

由于  $ e^{z} $ 及  $ e^{-z} $ 皆以  $ 2\pi i $ 为基本周期。故双曲正弦及双曲余弦函数也以  $ 2\pi i $ 为基本周期。

关于三角函数与双曲函数的有些性质以及它们之间的关系，我们已列入本章习题.

注 （1）由定义 2.5 可知，对任何复数 z，有

 $$ \mathrm{e}^{\mathrm{i}z}=\cos z+\mathrm{i}\sin z, $$ 

这是欧拉公式在复数域内的推广.

（2）定义 2.5、定义 2.6 及定义 2.7 本身就反映了复三角函数与复指数函数的关系以及复双曲函数与复指数函数的关系.换言之,无论是复三角函数还是复双曲函数,都是由复指数函数表示的.

本节所提到的初等函数都是周期函数，在下一节，我们可以证明它们的反函数都是多值函数：

#### §3. 初等多值函数

在复数域中对于多值函数的研究具有特殊的重要意义. 因为只有在这样的研究中才能看出函数多值性的本质. 本节的一个内容是介绍幂函数与根式函数、指数函数与对数函数的映射性质; 主要内容是采用限制辐角或割破平面的方法, 来分出根式函数与对数函数的单值解析分支; 最后, 对反三角函数及一般幂函数只作初步介绍.

为了下面讨论的需要,我们先给出如下定义.

定义 2.8 设函数  $ f(z) $ 在区域 D 内有定义，且对 D 内任意不同的两点  $ z_{1} $ 及  $ z_{2} $，都有  $ f(z_{1}) \neq f(z_{2}) $，则称函数  $ f(z) $ 在 D 内是单叶的。并且称区域 D 为  $ f(z) $ 的单叶性区域。

<!-- page: 81 -->

显然，区域 D 到区域 G 的单叶满变换  $ w = f(z) $ 就是 D 到 G 的一一变换.

### 1. 根式函数

定义 2.9 我们规定根式函数  $ w = \sqrt[n]{z} $ 为幂函数  $ z = w^{n} $ 的反函数 (n 是大于 1 的整数).

##### （1）幂函数的变换（映射）性质及其单叶性区域

$$  z=w^{n}   \tag*{(2.10)}$$

在 w 平面上单值解析，它把扩充 w 平面变成扩充 z 平面，且 z = 0， $ \infty $ 分别对应于 w = 0， $ \infty $ 。可是由

 $$ \begin{aligned}\mathcal{w}=&\sqrt[n]{z}=\sqrt[n]{|z|}e^{i\frac{\arg z+2k\pi}{n}}\\&(k=0,1,\cdots,n-1)\end{aligned} $$ 

知道，每一个不为零或 $ \infty $的z，在w平面上有n个原像，且此n个点分布在以原点为中心的正n角形的顶点上.于是，函数(2.10)的反函数 $ w=\sqrt[n]{z} $在z平面上就是n值的.

如果置  $ z = re^{\mathrm{i}\theta} $， $ w = \rho e^{\mathrm{i}\varphi} $，则(2.10)成为

$$  r=\rho^{n},\theta=n\varphi.   \tag*{(2.11)}$$

由(2.11)知道，变换(2.10)把从原点出发的射线  $ \varphi = \varphi_{0} $ 变成从原点出发的射线  $ \theta = n\varphi_{0} $，并把圆周  $ \rho = \rho_{0} $ 变成圆周  $ r = \rho_{0}^{n} $ (图2.2).

<div style="text-align: center;"><img src="images/p0081_img_in_image_box_511_4295_3941_5793.jpg" alt="图2.2" width="76%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.2</div> </div>

<!-- page: 82 -->

当 w 平面上的动射线从射线  $ \varphi = 0 $ 扫动到射线  $ \varphi = \varphi_{0} $ 时，在变换  $ z = w^{n} $ 下的像，就在 z 平面上从射线  $ \theta = 0 $ 扫动到射线  $ \theta = n\varphi_{0} $。从而，w 平面上的角形  $ 0 < \varphi < \varphi_{0} $ 就被变成 z 平面上的角形  $ 0 < \theta < n\varphi_{0} $（图 2.2）。

特别，变换(2.10)把  $ w_{i} $ 平面上的角形  $ -\frac{\pi}{n} < \varphi < \frac{\pi}{n} $ 变成 z 平面除去原点及负实轴的区域(图 2.3).

<div style="text-align: center;"><img src="images/p0082_img_in_image_box_426_1930_4024_3033.jpg" alt="图2.3" width="80%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.3</div> </div>


一般,变换(2.10)把张度为 $ \frac{2\pi}{n} $的 $ n $个角形

$$  \begin{aligned}T_{k}:\left(\frac{2k\pi}{n}-\frac{\pi}{n}\right)&<\varphi<\left(\frac{2k\pi}{n}+\frac{\pi}{n}\right)\ $ k&=0,1,\cdots,n-1)\end{aligned}   \tag*{(2.12)}$$

都变成 z 平面除去原点及负实轴的区域. 图 2.3 是 k=0 的情形. 图 2.4 是 n=3 的情形, 这时  $ T_{k}(k=0,1,2) $ 都变成 z 平面除去原点及负实轴的区域.

显然(2.12)是函数(2.10)的单叶性区域的 $ \uwave{\text{一种分法}} $.因由(2.11),我们知道区域T是(2.10)的单叶性区域的充要条件是:对于T内任一点 $ w_{1} $,满足下面等式的点 $ w_{2} $,

 $$ \begin{aligned}\mid\boldsymbol{w}_{2}\mid&=\mid\boldsymbol{w}_{1}\mid,\arg\boldsymbol{w}_{2}=\arg\boldsymbol{w}_{1}+\frac{2k\pi}{n}\\&\quad(k=1,2,\cdots,n-1)\end{aligned} $$

<!-- page: 83 -->

<div style="text-align: center;"><img src="images/p0083_img_in_image_box_746_566_3716_1850.jpg" alt="图2.4" width="66%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.4</div> </div>


不属于 T. (2.12) 的这些角形互不相交而填满（都加上同一端边界）w 平面（图 2.4）.

总之，幂函数  $ w = z^{n} $ （ $ n $ 是大于 1 的整数）的单叶性区域，是顶点在原点 z = 0，张度不超过  $ \frac{2\pi}{n} $ 的角形区域.

(2) 分出  $ \omega = \sqrt[n]{z} $ 的单值解析分支 当  $ z = r e^{i\theta} $ 时，函数

 $$ \begin{array}{r}{\varpi=\sqrt[n]{z}=\sqrt[n]{r}\mathrm{e}^{\mathrm{i}\frac{\theta+2k\pi}{n}},(k=0,1,\cdots,n-1)}\end{array} $$ 

出现多值性的原因是由于 z 确定后，其辐角并不唯一确定（可以相差  $ 2\pi $ 的整数倍）。今在 z 平面上从原点 O 到点  $ \infty $ 任意引一条射线（或一条无界简单曲线 $ ^{①} $），将 z 平面割破，割破了的 z 平面构成一个以此割线为边界的区域，记为 G（同时我们就用 G 表示包含在割破了的 z 平面内的某一子区域）。在 G 内随意指定一点  $ z_{0} $，并指定  $ z_{0} $ 的一个辐角值，则在 G 内任意的点 z，皆可根据  $ z_{0} $ 的辐角，依连续变化而惟一确定 z 的辐角。

假定从原点起割破负实轴，C 是 G 内过点  $ z_{0} $ 的一条简单闭曲线，即 C 不穿过负实轴，它的内部不包含原点 z=0，则当变点 z

<!-- page: 84 -->

从  $ z_{0} $ 起绕 C 一周时，z 的像点  $ \boldsymbol{w}_{k} = (\sqrt[n]{z})_{k} $ 各画出一条闭曲线  $ \Gamma_{k} $ （包含在角形  $ T_{k} $ 内）而各回到它原来的位置  $ \boldsymbol{w}_{k}^{(0)} $，因为这时  $ \arg z $ 回到其起始的值  $ \arg z_{0} $ （如图 2.5，它是 n = 3 的情形）.

<div style="text-align: center;"><img src="images/p0084_img_in_image_box_588_1231_3854_2750.jpg" alt="图2.5" width="73%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.5</div> </div>


因此，在区域 G 内可以得到

$$  \begin{align*}\varpi_{k}=(\sqrt[n]{z})_{k}&=\sqrt[n]{r(z)}\mathrm{e}^{\mathrm{i}\frac{\theta(z)+2k\pi}{n}},(z\in G)\ $ k&=0,1,2,\cdots,n-1)\end{align*}   \tag*{(2.13)}$$

它们也可记成

$$  \begin{aligned}\omega=&\sqrt[n]{z}\left(\sqrt[n]{1}=\mathrm{e}^{\mathrm{i}\frac{2k\pi}{n}}\right),(z\in G)\\&(k=0,1,\cdots,n-1)\end{aligned}   \tag*{(2.13)  ^{\prime} }$$

(2.13)或(2.13)′称为 $ \sqrt[n]{z} $的n个单值连续分支函数.当k取0,1, $ \cdots $,n-1中的固定值时,它就是 $ \sqrt[n]{z} $的第k个分支函数

下面,我们根据列入本章习题第9题的那个定理,来验证这个单值连续分支函数都是解析函数,并有

$$  \begin{aligned}\frac{\mathrm{d}}{\mathrm{d}z}(\sqrt[n]{z})_{k}&=\frac{1}{n}\frac{(\sqrt[n]{z})_{k}}{z},(z\in G)\ $ k&=0,1,\cdots,n-1)\end{aligned}   \tag*{(2.14)}$$

例如，对  $ \omega_{k} = (\sqrt[n]{z})_{k} $ 这一单值连续分支函数，其实部及虚部

<!-- page: 85 -->

$$ u\left(r,\theta\right)=\sqrt[n]{r}\cos\frac{\theta+2k\pi}{n},v\left(r,\theta\right)=\sqrt[n]{r}\sin\frac{\theta+2k\pi}{n} $$ 

在 G 内皆为 r, $ \theta $ 的可微函数，并且

 $$ u_{r}=\frac{1}{n}r^{\frac{1}{n}-1}\cos\frac{\theta+2k\pi}{n},u_{\theta}=-\frac{1}{n}r^{\frac{1}{n}}\sin\frac{\theta+2k\pi}{n}, $$ 

 $$ v_{r}=\frac{1}{n}r^{\frac{1}{n}-1}\sin\frac{\theta+2k\pi}{n},v_{\theta}=\frac{1}{n}r^{\frac{1}{n}}\cos\frac{\theta+2k\pi}{n}, $$ 

在 G 内满足极坐标的 C.-R. 方程：

 $$ u_{r}=\frac{1}{r}v_{\theta}\mathrm{,}v_{r}=-\frac{1}{r}u_{\theta}\mathrm{,} $$ 

故  $ \omega_{k} = (\sqrt[n]{z})_{k} $ 在 G 内解析，且

 $$ \begin{align*}\frac{\mathrm{d}}{\mathrm{d}z}(\sqrt[n]{z})_{k}&=\frac{r}{z}(u_{r}+\mathrm{i}v_{r})\\&=\frac{r}{z}\left(\frac{1}{n}r^{\frac{1}{n}-1}\cos\frac{\theta+2k\pi}{n}+\mathrm{i}\frac{1}{n}r^{\frac{1}{n}-1}\sin\frac{\theta+2k\pi}{n}\right)\\&=\frac{1}{n}\frac{1}{z}r^{\frac{1}{n}}\left(\cos\frac{\theta+2k\pi}{n}+\mathrm{i}\sin\frac{\theta+2k\pi}{n}\right)\\&=\frac{1}{n}\frac{(\sqrt[n]{z})_{k}}{z}(k=0,1,\cdots,n-1).\end{align*} $$ 

(3)  $ \omega = \sqrt[n]{z} $ 的支点及支割线 我们再分析一下，如果不像上述办法割破 z 平面，则变点 z 就可以沿一条简单闭曲线  $ \widetilde{C} $ (如图 2.5) 变  $ z_{0} $ 是  $ \widetilde{C} $ 上某一个点， $ \widetilde{C} $ 包含原点 z = 0 在其内部。这时， $ \widetilde{C} $ 穿过负实轴。于是，当变点 z 从  $ z_{0} $ 出发，循正 (负) 方向绕  $ \widetilde{C} $ 一周后， $ z_{0} $ 的辐角已经增 (减) 了  $ 2\pi $，z 的像点  $ \omega_{k} = (\sqrt[n]{z})_{k} $ 就不可能回到它们的原来位置  $ \omega_{k}^{(0)} $ ( $ \omega_{0}^{(0)} = \omega_{0} $)，而是沿如图 2.5 中虚线路径，从一支变到另一支：

 $$ \begin{aligned}{\mathcal{W}_{0}=\mathcal{W}_{0}^{(0)}}&{{}\xrightarrow{}\mathcal{W}_{1}^{(0)}\xrightarrow{}\mathcal{W}_{2}^{(0)}\xrightarrow{}\mathcal{W}_{3}^{(0)}\xrightarrow{}\cdots\xrightarrow{}\mathcal{W}_{n-1}^{(0)}\xrightarrow{}\mathcal{W}_{0}}\\ {\quad}&{{}(\leftarrow)\quad(\leftarrow)\quad(\leftarrow)\quad(\leftarrow)\cdots(\leftarrow)\quad(\leftarrow)}\\ \end{aligned} $$ 

这样一来，在包含或包围着原点 z=0 的区域 D 内，我们不可能把  $ w=\sqrt[n]{z} $ 分成 n 个独立的单值解析分支。而现在，这些分支好像在原

<!-- page: 86 -->

点 z=0 连接起来，抖不散了.

原点 z=0——在此点的充分小邻域内，作一个包围此点的圆周  $ \Gamma $，当变点 z 从  $ \Gamma $ 上一点出发，绕  $ \Gamma $ 连续变动一周而回到其出发点时， $ \sqrt[n]{z} $ 从其一支变到另外一支——我们称它为  $ \sqrt[n]{z} $ 的支点.

 $ z=\infty $ 也具有 z=0 所具有的类似性质，也称为 $ \sqrt[n]{z} $ 的支点。因为 z 沿顺时针方向绕以原点 z=0 为心，半径为充分大的圆周  $ \Gamma $ （此圆周可以看作是在点  $ \infty $ 的邻域内，并包围着  $ \infty $ 的一个圆周）一周时， $ \sqrt[n]{z} $ 也从其一支变到另外一支。

一般地，具有这种性质的点，使得当变点 z 绕这点一整周时，多值函数从其一支变到另一支，也就是说，当变点回转至原来的位置时，函数值与原来的值相异，则称此点为此多值函数的支点.

 $ \sqrt[n]{z} $ 除在 z=0 及 z= $ \infty $ 具有上述性质外，其他任何点皆不具此性质。因此， $ \sqrt[n]{z} $ 仅以 z=0 及 z= $ \infty $ 为支点。

用来割破 z 平面，借以分出  $ \sqrt[n]{z} $ 的单值解析分支的割线，称为  $ \sqrt[n]{z} $ 的支割线。一般地说，支割线可以区分为两岸。当支割线接近于平行 x 轴的方向，就分成上岸与下岸；当支割线接近平行于 y 轴的方向，就分成左岸与右岸。每一单值分支在支割线的两岸取得不同的值。

对应于支割线的不同作法，分支也就不同。因为这时各分支的定义域 G 随支割线改变而改变，其值域  $ T_{k}(k=0,1,\cdots,n-1) $ 当然也要随支割线改变而改变。但无论怎样，各分支的总体仍然是  $ \sqrt[n]{z} $，因为改变后的  $ T_{k}(k=0,1,\cdots,n-1) $ 仍然互不相交而填满（都加上同一端边界）w 平面。

特别情形,是取负实轴为支割线而得出的 n 个不同的分支,其中有一支在正实轴上取正实值的,称为 $ \sqrt[n]{z} $的主值支,它可以表为:

$$  \left(\sqrt[n]{z}\right)_{0}=\sqrt[n]{r}\mathrm{e}^{\frac{\mathrm{i}\theta}{n}},\quad(-\pi<\theta<\pi).   \tag*{(2.15)}$$

<!-- page: 87 -->

顺便指出：每一单值分支在支割线上是不连续的。就拿以负实轴为支割线的主值支(2.15)来说，当 z 从负实轴上方趋于点 z = -x (x > 0)，与从负实轴下方趋于此点时，分别有极限  $ \sqrt[n]{x} e^{\frac{i\pi}{n}} $ 及  $ \sqrt[n]{xe^{-\frac{i\pi}{n}}} $。不过，函数  $ w = \sqrt[n]{z} $ 的每一单值连续分支，可以扩充成为直到负实轴（除去原点 z = 0）的上岸（或下岸）连续的函数。扩充的函数值称为上述单值连续分支在负实轴的上岸（或下岸）所取的值。

也就是说，如  $ z = z_{0} $ 在支割线负实轴的上岸，而每个在 G:  $ -\pi < \theta(z) < \pi $ 内的单值解析分支  $ (\sqrt[n]{z})_{k} $ 是可以扩充成单边连续到负实轴上岸的。这时，就可以在上岸上计算其值。

值得注意的是：√z除了表多值函数的总体外，在一般书中，也常用它同时表某一特定单值分支。这时，一定要从上上下文去看它究竟是表示什么区域上的哪一分支。比如，当我们将√z的第k支(√z)仍用√z表示时，公式(2.14)就可写成

$$  \frac{\mathrm{d}}{\mathrm{d}z}\sqrt[n]{z}=\frac{1}{n}\cdot\frac{\sqrt[n]{z}}{z}=\frac{1}{n}z^{\frac{1}{n}-1},   \tag*{(2.14)  ^{\prime} }$$

这时，(2.14)′中的 $ \sqrt[n]{z} $及 $ z^{\frac{1}{n}} $就不能看成多值函数的总体，而应看成同一个特定单值解析分支.

还要强调一下，对于定义域 G 而言，如 G 不包含（或不包围）原点（或点 $ \infty $）时，则 $ \sqrt[n]{z} $在 G 内已能分出单值解析分支（如图 2.6

<div style="text-align: center;"><img src="images/p0087_img_in_image_box_734_4601_3678_5804.jpg" alt="图2.6" width="65%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.6</div> </div>

<!-- page: 88 -->

所示各区域 G)，否则(如图 2.7 所示各区域 G)就要从原点至点  $ \infty $ 引割线将 G 割开，才能分出单值解析分支.

<div style="text-align: center;"><img src="images/p0088_img_in_image_box_949_967_3539_2241.jpg" alt="图2.7" width="57%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.7</div> </div>


前面讨论的一切结论,经过适当的变数代换,就可以转移到多少更一般类型的函数:

 $$ w=\sqrt[n]{z-a}, $$ 

它只以 z = a 及  $ z = \infty $ 为支点，以从  $ z = a $ 出发并伸向无穷的广义简单曲线为支割线。且在沿支割线割开的 z 平面上任一区域内，能分出 n 个单值解析分支。

例 2.15 设  $ \omega = \sqrt[3]{z} $ 确定在从原点 z = 0 起沿负实轴割破了的 z 平面上，并且  $ \omega(i) = -i $. 试求  $ \omega(-i) $ 之值.

解 设  $ z = re^{\mathrm{i}\theta} $，则

 $$ \omega_{k}=\sqrt[3]{r(z)}\mathrm{e}^{\mathrm{i}\frac{\theta(z)+2k\pi}{3}},k=0,1,2 $$ 

这里

 $ z \in G: -\pi < \theta < \pi $. 且必  $ r(z) = |z| > 0 $.

(因为在单有限支点的情形,沿 z 平面的负实轴割破,与限制 z 的辐角  $ \arg z = \theta(z) $ 的变化范围  $ -\pi < \theta(z) < \pi $ 是一致的.)

（1）由已给条件定 k:

 $$ z=\mathrm{i}\in G\mathrm{ 时 },r(\mathrm{i})=1,\theta(\mathrm{i})=\frac{\pi}{2}. $$

<!-- page: 89 -->

要  $ -\mathrm{i} = \mathrm{e}^{\mathrm{i}\frac{\pi}{2} + 2k\pi} = \mathrm{e}^{\mathrm{i}\frac{\pi}{6} + 4k\pi} $，必 k = 2。

或直接由 -i 的辐角  $ \arg(-i)=\frac{3}{2}\pi $，合于  $ \pi<arg(-i)<\frac{5\pi}{3} $ 看出  $ -i\in T_{2} $（如图 2.8），因而 k=2。

(2) 求  $ w_2(-i)(-i \in G) $:

因  $ r(-i)=1, \theta(-i)=-\frac{\pi}{2} $，故

 $$ \begin{array}{r}{\mathcal{w}_{2}\left(-\mathrm{~i~}\right)=\mathrm{e}^{\mathrm{i}\frac{1}{3}\left(-\frac{\pi}{2}+4\pi\right)}=\mathrm{e}^{\frac{7}{6}\pi\mathrm{i}}=-\mathrm{e}^{\frac{\pi}{6}\mathrm{i}}.}\end{array} $$ 

（3）各支的图像（如图 2.8）：

 $$ G:-\pi<\theta(z)<\pi\longrightarrow T_1:\frac{\pi}{3}<\arg w_1(z)<\pi;T_2:\pi<\arg w_2(z)<\frac{5\pi}{3}. $$ 

<div style="text-align: center;"><img src="images/p0089_img_in_image_box_460_3510_4007_4784.jpg" alt="图2.8" width="79%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.8</div> </div>


2. 对数函数

(1) 复对数的定义

定义 2.10 我们规定对数函数是指数函数的反函数.即若

$$  \mathrm{e}^{w}=z\quad(z\neq0,\infty)   \tag*{(2.16)}$$

则复数 w 称为复数 z 的对数, 记为  $ w = \mathrm{Ln} z $.

<!-- page: 90 -->

令  $ z = re^{\mathrm{i}\theta} $, w = u + iv, 则 (2.16) 就是

因而

 $$ \begin{array}{c}{\mathrm{e}^{u+\mathrm{i}v}=r\mathrm{e}^{\mathrm{i}\theta}}\\ {\mathrm{u}=\ln r,v=\theta+2k\pi}\\ {\mathrm{(~k=0,~\pm1,\cdots~)}}\end{array} $$ 

故方程(2.16)的全部根是

或

$$  \begin{aligned}\ln z&=\ln r+\mathrm{i}(\theta+2k\pi),(k=0,\pm1,\cdots)\\\ln z&=\ln|z|+\mathrm{i}\arg z\\&=\ln|z|+\mathrm{i}(\arg z+2k\pi).(k=0,\pm1,\cdots)\end{aligned}   \tag*{(2.18)}$$

（当 k 取确定值时， $ \ln z $ 的对应值记为 $ (\ln z)_{k} $）

且

$$  \ln z=\ln z+2k\pi\mathrm{i}(k=0,\pm,\cdots)   \tag*{(2.19)}$$

这就说明了一个复数  $ z(z \neq 0, \infty) $ 的对数仍是复数，它的实部是 z 的模的通常实自然对数，它的虚部是 z 的辐角的一般值，即虚部可以取无穷多个值，任二相异值之差为  $ 2\pi $ 的一个整数倍。也就是说， $ w = \mathrm{Ln} z $ 是 z 的无穷多值函数。

式(2.19)的  $ \ln z = \ln |z| + \mathrm{iarg} z $ 表示  $ \mathrm{Ln} z $ 的某一个特定值，其中  $ \arg z $ 表示  $ \mathrm{Arg} z $ 的一个特定值。当限定  $ \arg z $ 取主值时，即  $ -\pi < \arg z \leq \pi $ 时， $ \ln z $ 称为  $ \mathrm{Ln} z $ 的主值（或主值支）。于是

主值

$$  \begin{aligned}\ln z&=\ln|z|+\mathrm{i}\arg z,\ $ -\pi&<\arg z\leqslant\pi)\end{aligned}   \tag*{(2.20)}$$

例 2.16 设 a>0，则

 $$ \mathrm{L n}a=\ln a+2k\pi\mathrm{i},(k=0,\pm1,\cdots) $$ 

其主值就是通常的实对数  $ \ln a $.

 $$ \mathrm{L n}(-a)=\ln a+(2k+1)\pi\mathrm{i}(k=0,\pm1,\cdots); $$ 

 $$ \ln(-\alpha)=\ln a+\pi\mathrm{i}; $$ 

特别

 $$ \ln(-1)=\ln1+\pi\mathrm{i}=\pi\mathrm{i}; $$ 

 $$ \mathrm{L n}(-1)=(2k+1)\pi\mathrm{i}(k=0,\pm1,\cdots). $$ 

此例说明:复对数是实对数在复数域内的推广;在实数域内“负数无对数”的说法,在复数域内是不成立的.但可修改成“负数

<!-- page: 91 -->

无实对数，且正实数的复对数也是无穷多值的。”

例 2.17

 $$ \ln i=\ln|\mathrm{i}|+\frac{\pi}{2}\mathrm{i}=\frac{\pi}{2}\mathrm{i}; $$ 

 $$ \begin{aligned}\mathrm{Ln i}=\frac{\pi}{2}\mathrm{i}+2k\pi\mathrm{i}=\left(\frac{1+4k}{2}\right)\pi\mathrm{i}\\ (k=0,\pm1,\cdots)\end{aligned} $$ 

例 2.18

 $$ \begin{array}{c}{\mathrm{L n}(3+4\mathrm{i})=\ln5+\mathrm{i}\mathrm{a r c}\tan\frac{4}{3}+2k\pi\mathrm{i}.}\\ {(k=0,\pm1,\cdots)}\end{array} $$ 

（2）对数函数的基本性质

$$  \begin{array}{r}{\mathrm{L n}(z_{1}z_{2})=\mathrm{L n}z_{1}+\mathrm{L n}z_{2},}\\ {\mathrm{L n}\frac{z_{1}}{z_{2}}=\mathrm{L n}z_{1}-\mathrm{L n}z_{2}.}\end{array}\Biggl\{(z_{1},z_{2}\neq0,\infty)}   \tag*{(2.21)}$$

可以像在实数域中一样证明它们在复数域中成立.例如证明前一个.根据指数函数的加法定理,由恒等式

 $$ \mathrm{e}^{\mathrm{Ln}z_{1}}=z_{1} 和 \mathrm{e}^{\mathrm{Ln}z_{2}}=z_{2}, $$ 

即可推出恒等式

 $$ \mathrm{e}^{\mathrm{L n}z_{1}+\mathrm{L n}z_{2}}=\mathcal{Z}_{1}\mathcal{Z}_{2}; $$ 

另一方面，因

 $$ \begin{array}{c}{\mathrm{e}^{\mathrm{L n}\left(z_{1}z_{2}\right)}=\mathcal{Z}_{1}\mathcal{Z}_{2},}\\ {\mathrm{e}^{\mathrm{L n}\left(z_{1}z_{2}\right)}=\mathrm{e}^{\mathrm{L n}z_{1}+\mathrm{L n}z_{2}}.}\end{array} $$ 

故

于是得证.

思考题 参照我们对公式(1.12)及(1.12)′所作的说明，试对公式(2.21)作出类似的说明.

当求等式

 $$ \mathrm{e}^{z_{1}}=\mathrm{e}^{z_{2}} $$ 

的对数时，结果可以写成

 $$ z_{1}=z_{2}+2k\pi\mathrm{i}. $$ 

加上  $ 2k\pi $ 是必要的，因为指数函数具有虚周期  $ 2\pi i $.

<!-- page: 92 -->

##### （3）指数函数  $ z = e^{w} $ 的变换性质及其单叶性区域

令  $ z = re^{\mathrm{i}\theta} $, w = u + iv, 则 (2.16) 成为

 $$ r=e^{u},\theta=v. $$ 

由此知道，变换(2.16):

 $$ z=\mathrm{e}^{w},(z\neq0,\infty) $$ 

把直线  $ v = v_{0} $ 变成从原点出发的射线  $ \theta = v_{0} $，把线段“u = u_{0} 且  $ -\pi < v \leq \pi $”变成圆周  $ r = e^{u_{0}} $ (图 2.9).

<div style="text-align: center;"><img src="images/p0092_img_in_image_box_433_1947_4046_3328.jpg" alt="图2.9" width="80%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.9</div> </div>


当 w 平面上的动直线从直线 v = 0 扫动到直线  $ v = v_{0} $ 时，在变换  $ z = e^{w} $ 下的像，就在 z 平面上从射线  $ \theta = 0 $ 扫动到射线  $ \theta = v_{0} $. 从而 w 平面上的带形  $ 0 < v < v_{0} $ 就被变成 z 平面上的角形  $ 0 < \theta < v_{0} $ (图 2.9).

特别,变换  $ z = e^{w} $ 把 w 平面上的带形  $ -\pi < v < \pi $ 变成 z 平面上除去原点及负实轴的区域.

一般，变换(2.16)把宽为  $ 2\pi $ 的带形

$$  B_{k}:(2k-1)\pi<v<(2k+1)\pi,(k=0,\pm1,\cdots)   \tag*{(2.22)}$$

都变成 z 平面上除去原点及负实轴的区域(图 2.10).

显然(2.22)是函数(2.16)的单叶性区域的 $ \uwave{\text{一种分法}} $. 因而(2.17)我们知道, 区域 B 是(2.16)的单叶性区域的充要条件为: 对于

<!-- page: 93 -->

B 内任一点  $ w_{1}=u_{1}+\mathrm{i}v_{1} $，满足条件

 $$ u_{2}=u_{1},v_{2}=v_{1}+2k\pi\quad(k 为非零整数 ) $$ 

的点  $ w_{2}=u_{2}+iv_{2} $ 不属于 B.

(2.22)的这些带形互不相交而填满(都加上同一端边界) $ \omega $ 平面(图 2.10).

<div style="text-align: center;"><img src="images/p0093_img_in_image_box_393_1567_4016_3227.jpg" alt="图2.10" width="81%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.10</div> </div>


总之, 指数函数  $ w = e^{z} $ 的单叶性区域, 是 z 平面上平行于实轴, 宽不超过  $ 2\pi $ 的带形区域.

(4) 分出  $ w = \mathrm{Ln} z $ 的单值解析分支 参照图 2.11 作类似于对函数  $ \omega = \sqrt[n]{z} $ 的讨论. 在 z 平面上从原点 z = 0 起割破负实轴的区域 G 内, 可以得到 w =  $ \mathrm{Ln} z $ 的无穷多个不同的单值连续分支函数

$$  \begin{align*}\boldsymbol{w}_{k}=(\ln z)_{k}=\ln r(z)+\mathrm{i}\big[\theta(z)+2k\pi\big].\ $ z\in G,k=0,\pm1,\cdots)\end{align*}   \tag*{(2.23)}$$

它们也可记成

$$  \begin{aligned}\omega=\ln z\left(\ln1=i2k\pi\right),(z\in G)\ $ k=0,\pm1,\cdots)\end{aligned}   \tag*{· (2.23)  ^{\prime} }$$

仍可根据列入本章习题9的那个定理，验证(2.23)皆在G内解

<!-- page: 94 -->

析，且有

 $$ \frac{\mathrm{d}}{\mathrm{d}z}(\ln z)_{k}=\frac{1}{z}\quad(z\in G,k=0,\pm1,\cdots). $$ 

当不割破 z 平面时，参照图 2.11 作类似于对  $ \omega = \sqrt[n]{z} $ 的讨论，即知 w = Ln z 仍只以 z = 0 及 z =  $ \infty $ 为支点，仍以连接 z = 0 及 z =  $ \infty $ 的广义简单曲线（特别是负实轴）为支割线.

<div style="text-align: center;"><img src="images/p0094_img_in_image_box_666_1721_3834_3386.jpg" alt="图2.11" width="70%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.11</div> </div>


同理，易知  $ \mathrm{Ln}(z-a) $ 只以 z=a 及 z= $ \infty $ 为支点，以联结 z=a 及 z= $ \infty $ 的任一射线或广义简单曲线为支割线；在沿支割线割开了的 z 平面上任一区域 G 内， $ \mathrm{Ln}(z-a) $ 的每一分支是单值解析的.

### 3. 一般幂函数与一般指数函数

定义 2.11  $ w = z^{a} = e^{a\mathrm{Ln}z} (z \neq 0, \infty; a $ 为复常数) 称为 z 的一般幂函数.

此定义是实数域中等式

 $$ x^{\alpha}=\mathrm{e}^{\alpha\ln x}\quad(x>0,\alpha 为实数 ) $$ 

在复数域中的推广. 不难验证, 当  $ \alpha $ 取整数  $ n \geqslant 1 $ 或取分数  $ \frac{1}{n} $ (n 为大于 1 的整数) 时, 它就是我们已经定义过的幂函数  $ z^{n} $ 及根式

<!-- page: 95 -->

函数 $ \sqrt[n]{z} $.

设 $ (\ln z)_{0} $表示 $ \mathrm{Ln}z $中的任意一个确定的值.则

 $$ \begin{aligned}\boldsymbol{z}^{\alpha}&=\mathrm{e}^{\alpha\operatorname{Ln}z}=\mathrm{e}^{\alpha\left[\left(\ln z\right)_{0}+2k\pi\mathrm{i}\right]}\\&=\mathcal{w}_{0}\mathrm{e}^{2k\pi\mathrm{i}\alpha},\left(k=0,\pm1,\cdots\right)\end{aligned} $$ 

其中  $ w_{0} = e^{a(\ln z)}_{0} $ 表  $ z^{a} $ 所有的值中的一个.

现在我们来讨论  $ \alpha $ 的如下三种特殊情形：

(1)  $ \alpha $ 是一整数 n. 此时

 $$ \mathrm{e}^{2k\pi\mathrm{i}\alpha}=\mathrm{e}^{2(k n)\pi\mathrm{i}}=1, $$ 

故  $ z^{a} $ 这时是 z 的单值函数.

(2)  $ \alpha $ 是一有理数  $ \frac{q}{p} $ (既约分数). 这时

 $$ \mathrm{e}^{2k\pi\mathrm{i}\alpha}=\mathrm{e}^{2k\pi\mathrm{i}\frac{q}{p}}, $$ 

只能取 p 个不同的值，即当 k=0,1,2,\cdots,p-1 时的对应值.于是

 $$ z^{\frac{q}{p}}=\mathcal{w}_{0}\mathrm{e}^{2k\pi\mathrm{i}\frac{q}{p}},k=0,1,2,\cdots,p-1. $$ 

(3)  $ \alpha $ 是一无理数或虚数 这时, 式子  $ \mathrm{e}^{2k\pi i a} $ 的所有的值各不相同,  $ z^{\alpha} $ 就是无限多值的.

总之，由于  $ \mathrm{Ln}z $ 的多值性， $ z^{a} $ 一般也是多值的（仅当 a 为整数时例外）。将  $ z^{a} $ 分成单值解析分支的方法与  $ \mathrm{Ln}z $ 同，且  $ z^{a} $ 仍只以 z=0 及 z= $ \infty $ 为支点。当从原点起沿负实轴割破 z 平面后，对  $ z^{a} $ 的每一分支（仍以  $ z^{a} $ 表示之）有

 $$ \begin{array}{c}\frac{\mathrm{d}}{\mathrm{d}z}z^{\alpha}=\frac{\mathrm{d}}{\mathrm{d}z}\mathrm{e}^{\alpha\ln z}=\mathrm{e}^{\alpha\ln z}\cdot\frac{\alpha}{z}\\ \\ =z^{\alpha}\cdot\frac{\alpha}{z}=\alpha z^{\alpha-1},\end{array} $$ 

当 $ \alpha $取分数 $ \frac{1}{n} $（ $ n $为大于1的整数）时，它就是（2.14）'。

定义 2.12  $ \because w = a^{z} = e^{z\mathrm{Ln}a} (a \neq 0, \infty $ , 为一复常数) 称为一般指数函数.

它是无穷多个独立的，在 z 平面上单值解析的函数. 当  $ \alpha = e $，

<!-- page: 96 -->

Ln e 取主值时,便得到通常的单值的指数函数  $ e^{z} $.

本段说的这两种函数都可看作复合函数，它们的性质可由其他函数的性质推导出来。

例 2.19 求  $ i^{i} $.

解

 $$ \begin{align*}\mathrm{i}^{\mathrm{i}}=\mathrm{e}^{\mathrm{i}\mathrm{Ln}\mathrm{i}}&=\mathrm{e}^{\mathrm{i}\left(\frac{\pi}{2}\mathrm{i}+2k\pi\mathrm{i}\right)}=\mathrm{e}^{-\frac{\pi}{2}-2k\pi},\ $ k&=0,\pm1,\cdots)\end{align*} $$ 

且  $ \mathrm{i}^{i} $ 的主值为  $ \mathrm{e}^{-\frac{\pi}{2}} $

例 2.20 求  $ 2^{1+i} $

解

 $$ \begin{aligned}2^{1+i}&=e^{(1+i)\ln2}\\&=e^{(1+i)(\ln2+2k\pi i)}\\&=e^{(\ln2-2k\pi)+i(\ln2+2k\pi)}\\&=e^{(\ln2-2k\pi)}(\cos\ln2+i\sin\ln2),\\&\quad(k=0,\pm1,\cdots)\end{aligned} $$ 

且  $ 2^{1+i} $ 的主值为  $ \mathrm{e}^{\ln2}\left(\cos\ln2+i\sin\ln2\right) $.

### 4. 具有多个有限支点的情形

前面我们讨论了根式函数  $ \omega = \sqrt[n]{z} $ 与对数函数  $ \omega = \ln z $，它们的支点都是一个有限支点 z = 0 和无穷远点 z = ∞。其支割线可以是从 0 到 ∞ 的一条射线（如包含原点的负实轴），这与限制变点的辐角范围（如  $ -\pi < \arg z < \pi $）是一致的。从而，在 z 平面上以此割线为边界的区域 G 内，它们都能分出单值解析分支。

但对具有多个有限支点的多值函数,我们就不便采取限制辐角范围的办法,而是首先求出该函数的一切支点,然后适当联结支点以割破z平面.于是,在z平面上以此割线为边界的区域G内就能分出该函数的单值解析分支.因为,在G内变点z不能穿过支割线,也就不能单独绕任一个支点转一整周,函数就不可能在G内同一点取不同的值了.

##### （1）讨论函数

<!-- page: 97 -->

$$  w=f(z)=\sqrt[n]{P(z)}   \tag*{(2.24)}$$

的支点，其中  $ P(z) $ 是任意的 N 次多项式，

 $$ P\left(z\right)=A\left(z-a_{1}\right)^{a_{1}}\cdots\left(z-a_{m}\right)^{a_{m}} $$ 

 $ a_{1},a_{2},\cdots,a_{m} $ 是  $ P(z) $ 的一切相异零点  $ \alpha_{1},\alpha_{2},\cdots,\alpha_{m} $ 分别是它们的重数，合于

 $$ \alpha_{1}+\alpha_{2}+\cdots+\alpha_{m}=N. $$ 

##### 我们先来看

##### 例 2.21 考查下列二函数有哪些支点：

 $$ (a)f(z)=\sqrt{z(1-z)};(b)f(z)=\sqrt[3]{z(1-z)} $$ 

##### 解

(a) 当 z 沿内部包含 0(但不包含 1) 的简单闭曲线  $ C_{0} $ 正方向绕行一周时，z 的辐角得到增量  $ 2\pi $ (即  $ \Delta_{C_{0}}\arg z = 2\pi $), 1-z 的辐角并未改变 (即  $ \Delta_{C_{0}}\arg(1 - z) = \Delta_{C_{0}}\arg(z - 1) = 0 $), 结果  $ f(z) = \sqrt{z(1 - z)} $ 的辐角获得增量  $ \pi $, 即

 $$ \begin{aligned}\Delta_{C_{0}}\arg f(z)&=\frac{1}{2}\left[\Delta_{C_{0}}\arg z+\Delta_{C_{0}}\arg(1-z)\right]\\&=\frac{1}{2}\left[2\pi+0\right]=\pi.\end{aligned} $$ 

故  $ f(z) $ 的终值较初值增加了一个因子  $ e^{i\pi} = -1 $，发生了变化，可见  $ 0 $ 是  $ f(z) = \sqrt{z(1 - z)} $ 的支点。同样的讨论，可见 1 也是其支点。

任何异于 0、1 的有限点都不可能是  $ f(z) $ 的支点. 事实上, 对于这样的点  $ \zeta $, 可以取一条包含  $ \zeta $ 但不包含点 0、1 的简单闭曲线  $ \tilde{C} $, 而

 $$ \begin{aligned}\Delta_{\tilde{c}}\arg f(z)&=\frac{1}{2}\left[\Delta_{\tilde{c}}\arg z+\Delta_{\tilde{c}}\arg(1-z)\right]\\&=\frac{1}{2}\left[0+0\right]=0,\end{aligned} $$

<!-- page: 98 -->

即  $ f(z) $ 的终值与初值比较,未发生改变.

如果简单闭曲线 C 同时包含 0、1 两点（如图 2.12），点 z 沿 C 的正向绕行一周后，

<div style="text-align: center;"><img src="images/p0098_img_in_image_box_863_1145_3564_3749.jpg" alt="图2.12" width="60%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.12</div> </div>


 $$ \begin{align*}\Delta_{C}\arg f(z)&=\frac{1}{2}\left[\Delta_{C}\arg z+\Delta_{C}\arg(1-z)\right]\\&=\frac{1}{2}\left[\Delta_{C}\arg z+\Delta_{C}\arg(z-1)\right]\\&=\frac{1}{2}\left[2\pi+2\pi\right]=2\pi.\end{align*} $$ 

结果是  $ f(z) $ 原来的值乘以  $ e^{2\pi i}=1 $，并不改变其值。由此可见， $ \infty $ 不是  $ f(z) $ 的支点。

(b)  $ f(z) $ 可能的支点是 0,1, $ \infty $. 如图 2.12, 由于

 $$ \Delta_{c_{0}}\arg f(z)=\frac{1}{3}\left[\Delta_{c_{0}}\arg z+\Delta_{c_{0}}\arg(1-z)\right] $$

<!-- page: 99 -->

$$ =\frac{1}{3}\left[2\pi+0\right]=\frac{2\pi}{3}, $$ 

 $$ \begin{aligned}\Delta_{c_{_{1}}}\arg f(z)&=\frac{1}{3}\left[\Delta_{c_{_{1}}}\arg z+\Delta_{c_{_{1}}}\arg(1-z)\right]\\&=\frac{1}{3}\left[0+2\pi\right]=\frac{2\pi}{3},\end{aligned} $$ 

 $$ \begin{aligned}\Delta_{C}\arg f(z)&=\frac{1}{3}\left[\Delta_{C}\arg z+\Delta_{C}\arg(1-z)\right]\\&=\frac{1}{3}\left[2\pi+2\pi\right]=\frac{4\pi}{3},\end{aligned} $$ 

结果  $ f(z) $ 的值均较原值发生了变化. 故 0、1、 $ \infty $ 都是  $ f(z) $ 的支点，且此外别无支点.

对式(2.24)函数作类似地讨论，我们就能得到下列结论：

(a) (2.24)可能的支点是  $ a_{1}, a_{2}, \cdots, a_{m} $ 和  $ \infty $;

(b) 当且仅当 n 不能整除  $ \alpha_{i} $ 时,  $ \alpha_{i} $ 是  $ \sqrt[n]{P(z)} $ 的支点;

(c) 当且仅当 n 不能整除 N 时,  $ \infty $ 是  $ \sqrt[n]{P(z)} $ 的支点;

(d) 如果 n 能整除  $ \alpha_{1}, \alpha_{2}, \cdots, \alpha_{m} $ 中若干个之和，则  $ a_{1}, a_{2}, \cdots, a_{m} $ 中对应的那几个就可以联结成割线抱成团，即变点 z 沿只包含它们在其内部的简单闭曲线转一整周后，函数值不变。这种抱成的团可能不止一个。其余不入团的点  $ a_{i} $ 则与点  $ \infty $ 联结成一条割线。

例如，对

 $$ \begin{array}{r}{\varpi=\sqrt{z\left(z-1\right)\left(z-2\right)\left(z-3\right)\left(z-4\right)},}\end{array} $$ 

就可将0与1,2与3分别用直线联结成割线，抱成两个团，再把余下的4与点 $ \infty $联结成一条割线.

又如对

 $$ \begin{array}{r}{\varpi=\sqrt[3]{z\left(z-1\right)\left(z-2\right)\left(z-3\right)\left(z-4\right)},}\end{array} $$ 

就可将 0,1,2 用直线联结成一条割线，抱成一个团，再把余下的 3,4 与点 $ \infty $联结成一条割线.

<!-- page: 100 -->

(2) 由已给单值解析分支  $ f(z) $ 的初值  $ f(z_{1}) $，计算终值  $ f(z_{2}) $

借助每一单值解析分支  $ f(z) $ 的连续性，先计算当 z 从  $ z_{1} $ 沿曲线 C（不穿过支割线）到终点  $ z_{2} $ 时， $ f(z) $ 的辐角的连续改变量  $ \Delta_{c} $arg  $ f(z) $，再计算终值

 $$ \begin{aligned}f(z_{2})&=\mid f(z_{2})\mid\mathrm{e}^{\mathrm{iarg}f(z_{2})}\\&=\mid f(z_{2})\mid\mathrm{e}^{\mathrm{i}\left[\arg f(z_{2})-\arg f(z_{1})+\arg f(z_{1})\right]}\\&f(z_{2})=\mid f(z_{2})\mid\mathrm{e}^{\mathrm{i}\Delta_{C}\arg f(z)}\bullet\mathrm{e}^{\mathrm{iarg}f(z_{1})}\end{aligned} $$ 

即

其中  $ \Delta_{C}\arg f(z) $ 与  $ \arg f(z_{1}) $ 的取值无关,  $ \arg f(z_{1}) $ 可以相差  $ 2\pi $ 的整倍数.

当初值  $ f(z_{1}) $ 取定时，(2.25) 就是终点（或动点） $ z_{2} $ 的单值函数，故 (2.25) 就是此单值解析分支的表达式。

例 2.22 试证  $ f(z) = \sqrt[3]{z(1-z)} $ 在将 z 平面适当割开后能分出三个单值解析分支. 并求出在点 z = 2 取负值的那个分支在 z = i 的值.

解 （1）由上例,我们已经知道  $ f(z) $ 的支点是 0,1, $ \infty $.

将 z 平面沿正实轴从 0 到 1 割开，再沿负虚轴割开（如图 2.13）。这样就保证了变点 z 不会单绕 0 或 1 转一周，也不会同绕 0 及 1（即绕点  $ \infty $）转一周了。在这样割开后的 z 平面 G 上， $ f(z)=\sqrt[3]{z(1-z)} $ 就能分出三个单值解析分支。

（2）解法一 设  $ z = r_{1} e^{i\theta_{1}} $

 $$ 1-z=r_{2}\mathrm{e}^{\mathrm{i}\theta_{2}}, $$ 

则

 $$ \begin{aligned}f_{k}\left(z\right)&=\sqrt[3]{r_{1}\left(z\right)r_{2}\left(z\right)}\mathrm{e}^{\mathrm{i}\frac{\theta_{1}\left(z\right)+\theta_{2}\left(z\right)+2k\pi}{3}}\\&\quad\left(z\in G,k=0,1,2\right)\end{aligned} $$ 

当 z=2 时， $ \theta_{1}=0,\theta_{2}=\pi,r_{1}=2,r_{2}=1 $

 $$ f_{k}\left(2\right)=\sqrt[3]{2}\mathrm{e}^{\mathrm{i}\frac{\left(2k+1\right)\pi}{3}},k=0,1,2 $$

<!-- page: 101 -->

当且仅当 k=1 时， $ f_{k}(2) $ 取负值.

故所取分支为

 $$ f_{1}(z)=\sqrt[3]{r_{1}(z)r_{2}(z)}\mathrm{e}^{\mathrm{i}\frac{\theta_{1}(z)+\theta_{2}(z)+2\pi}{3}} $$ 

因此

 $$ \begin{align*}f_{1}\left(\mathrm{i}\right)&=\sqrt[3]{\left|\mathrm{i}\right|\left|1-\mathrm{i}\right|}\mathrm{e}^{\frac{1}{3}\left(\frac{\pi}{2}+\frac{7\pi}{4}+2\pi\right)\mathrm{i}}\\&=\left(\sqrt{2}\right)^{\frac{1}{3}}\mathrm{e}^{\left(\pi+\frac{5\pi}{12}\right)\mathrm{i}}\\&=-\sqrt[6]{2}\mathrm{e}^{\frac{5}{12}\pi\mathrm{i}}.\end{align*} $$ 

<div style="text-align: center;"><img src="images/p0101_img_in_image_box_2896_550_4009_1822.jpg" alt="图2.13" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.13</div> </div>


解法二 如图 2.13.

 $$ \Delta_{C}\arg z=\frac{\pi}{2},\Delta_{C}\arg(1-z)=\frac{3\pi}{4}, $$ 

于是

 $$ \begin{aligned}\Delta_{C}\arg f(z)&=\frac{1}{3}\left[\Delta_{C}\arg z+\Delta_{C}\arg(1-z)\right]\\&=\frac{1}{3}\left(\frac{\pi}{2}+\frac{3\pi}{4}\right)=\frac{5\pi}{12}.\end{aligned} $$ 

而由题设,我们可以认为  $ \arg f(2)=\pi $ (允许相差  $ 2\pi $ 的整数倍).再由公式(2.25)得

 $$ f(\mathrm{i})=\sqrt[3]{|\mathrm{i}||1-\mathrm{i}|}\mathrm{e}^{\mathrm{i}\pi}\mathrm{e}^{\mathrm{i}\frac{5\pi}{12}}=-\sqrt[6]{2}\mathrm{e}^{\frac{5\pi}{12}\mathrm{i}}. $$ 

可见，用解法二（即用公式(2.25)）计算此单值解析分支的终值是较简捷的.

（3）关于对数函数的已给单值解析分支  $ \ln f(z) $，我们可以借助下面的公式来计算它的终值：

 $$ \begin{aligned}\ln f(z_{2})&=\ln|f(z_{2})|+\mathrm{i}\arg f(z_{2})\\&=\ln|f(z_{2})|+\mathrm{i}[\arg f(z_{2})-\arg f(z_{1})\\&\quad+\arg f(z_{1})]\end{aligned} $$ 

即

$$  \ln f(z_{2})=\ln\mid f(z_{2})\mid+\mathrm{i}\Delta_{C}\mathrm{a r g}f(z)+\mathrm{i}\mathrm{a r g}f(z_{1})   \tag*{(2.26)}$$

其中  $ C $ 是一条联结起点  $ z_{1} $ 和终点  $ z_{2} $ 且不穿过支割线的简单曲线； $ \arg f(z_{1}) $ 表示符合条件那一支在起点  $ z_{1} $ 之值

<!-- page: 102 -->

$$ \ln f(z_{1})=\ln|f(z_{1})|+\mathrm{iarg}f(z_{1}) $$ 

的虚部，是一个确定的值.

(2.26)就是此单值解析分支的表达式(当视  $ z_{2} $ 为 G 内的动点时).

例 2.23 试证  $ \mathrm{Ln}(1-z^{2}) $ 在割去“从 -1 到 i 的直线段”，“从 i 到 1 的直线段”与射线“x=0 且  $ y \geqslant 1 $”的 z 平面内能分出单值解析分支。并求 z=0 时等于零的那一支在 z=2 的值。

解 (1)  $ \mathrm{Ln}(1-z^{2}) $ 的支点为  $ z=\pm1 $ 及  $ \infty $.

 $$ \ln(1-z^{2})=\ln(1-z)+\ln(1+z), $$ 

当变点 z 单绕 -1 或 +1 一周时,  $ \ln(1 - z^{2}) $ 的值就改变  $ 2\pi i $ (沿正向) 或  $ -2\pi i $ (沿负向), 即  $ \ln(1 - z^{2}) $ 从一支变成另一支; 当变点 z 同绕 -1 及 +1 一周时,  $ \ln(1 - z^{2}) $ 共改变  $ 4\pi i $ (沿正向) 或  $ -4\pi i $ (沿负向), 即  $ \ln(1 - z^{2}) $ 也从一支变成另一支.

将 z 平面沿题中要求割破后(图 2.14)，变点 z 既不能单纯 -1 或 +1 转一周，也不能同绕 -1 及 +1 转一周。于是，在这样割破了的 z 平面上任一区域 G 内， $ \mathrm{Ln}(1 - z^{2}) $ 就能分出无穷多个单值解析分支。

<div style="text-align: center;"><img src="images/p0102_img_in_image_box_1334_4020_3096_5360.jpg" alt="图2.14" width="39%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.14</div> </div>


（2）当 z 从 z=0 沿 G 内一条简单曲线 C 变动到 z=2 时，由

<!-- page: 103 -->

图 2.14，

 $$ \begin{align*}\Delta_{C}\arg(1-z^{2})&=\Delta_{C}\arg(1+z)(1-z)\\&=\Delta_{C}\arg(1+z)+\Delta_{C}\arg(1-z)\\&=\Delta_{C}\arg\left[-(1+z)\right]+\Delta_{C}\arg(1-z)\\&=0+\pi=\pi.\end{align*} $$ 

已知此指定分支在 z=0 的值为 0，从而此初值的虚部为零，故由公式(2.26)可知该分支在 z=2 的值为

 $$ \ln|1-z^{2}|_{z=2}+\pi\mathrm{i}=\ln3+\pi\mathrm{i}. $$ 

注 解这类问题(如以上三个例题)的要点,就是作图观察,当动点z沿路线C(C在G内,且不穿过支割线)从起点 $ z_{1} $到终点 $ z_{2} $时,各因子辐角的连续改变量: $ \Delta_{C} $arg z, $ \Delta_{C} $arg(1-z), $ \cdots $,即观察向量z,1-z, $ \cdots $,的辐角的连续改变量.由此即可计算 $ \Delta_{C} $arg f(z),并可利用公式(2.25)或(2.26).

5. 反三角函数与反双曲函数 正如我们在定义 2.5、定义 2.6 及定义 2.7 中所看到的，三角函数和双曲函数都可以非常简单的用指数函数表示；因为对数函数是指数函数的反函数，所以反三角函数和反双曲函数都可以用对数函数非常简单地表示。

（1）我们先从反正切函数开始. 记号

 $$ \varpi=\operatorname{A r c t a n}z. $$ 

指的是方程

 $$ \tan\ w=z $$ 

的解的总体.我们将此方程改写成

 $$ \frac{1}{\mathrm{i}}\cdot\frac{\mathrm{e}^{\mathrm{i}w}-\mathrm{e}^{-\mathrm{i}w}}{\mathrm{e}^{\mathrm{i}w}+\mathrm{e}^{-\mathrm{i}w}}=z, $$ 

还可改写成

 $$ \mathrm{e}^{2\mathrm{i}w}=\frac{1+\mathrm{i}z}{1-\mathrm{i}z}, $$ 

由此即得

 $$ 2\mathrm{i}w=\mathrm{L n}\frac{1+\mathrm{i}z}{1-\mathrm{i}z}, $$

<!-- page: 104 -->

最后即得

$$  \mathrm{A r c t a n}z=\frac{1}{2\mathrm{i}}\mathrm{L n}\frac{1+\mathrm{i}z}{1-\mathrm{i}z}.   \tag*{(2.27)}$$

同理,由关系  $ \omega = \mathrm{Arcsin} z $ 或由和它等价的关系

 $$ \sin w=z, $$ 

我们即得

 $$ z=\frac{\mathrm{e}^{\mathrm{i}w}-\mathrm{e}^{-\mathrm{i}w}}{2\mathrm{i}}. $$ 

由此得：

 $$ \mathrm{e}^{2i w}-2\mathrm{i}z\mathrm{e}^{\mathrm{i}w}-1=0. $$ 

将此等式看作  $ e^{i\omega} $ 的二次方程，即得

 $$ \begin{aligned}\mathrm{e}^{\mathrm{i}w}&=\mathrm{i}z+\sqrt{1-z^{2}}.\\\mathrm{i}w&=\mathrm{Ln}(\mathrm{i}z+\sqrt{1-z^{2}}).\\\mathrm{w}&=\frac{1}{\mathrm{i}}\mathrm{Ln}(\mathrm{i}z+\sqrt{1-z^{2}}).\end{aligned} $$ 

我们得到了反正弦函数恒等式

$$  \mathrm{A r c s i n}z=\frac{1}{\mathrm{i}}\mathrm{L n}(\mathrm{i}z+\sqrt{1-z^{2}}).   \tag*{(2.28)}$$

同理，对于反余弦函数，我们容易得出：

$$  \mathrm{A r c c o s}z=\frac{1}{\mathrm{i}}\mathrm{L n}(z+\mathrm{i}\sqrt{1-z^{2}}).   \tag*{(2.29)}$$

公式(2.27)、(2.28)和(2.29)都是无穷多值的,因为对数是无穷多值的;此外,不应忽视公式(2.28)和(2.29)中的根式是二值的.

（2）我们现在来讨论双曲函数的反函数.

例如，由等式

 $$ z=\cosh w 或 z=\frac{e^{w}+e^{-w}}{2} $$ 

我们即得(关于  $ w $ 解出方程)和它等价的等式

 $$ \begin{aligned}w&=\mathrm{Ln}(z+\sqrt{z^{2}-1}).\\ \mathrm{Arcosh}z&=\mathrm{Ln}(z+\sqrt{z^{2}-1}).\end{aligned} $$ 

于是

<!-- page: 105 -->

同理，可得

$$  \operatorname{A r s i n h}z=\operatorname{L n}(z+\sqrt{z^{2}+1}),   \tag*{(2.31)}$$

和

$$  \mathrm{A}\operatorname{t a n h}z=\frac{1}{2}\mathrm{L n}\frac{1+z}{1-z}.   \tag*{(2.32)}$$

公式(2.30)、(2.31)和(2.32)都是无穷多值的，且公式(2.30)和(2.31)中的根式是二值的.

所有这些函数分成单值解析分支的方法，与前面所用的讨论方法是类似的，也要先讨论它们的支点，只是较复杂些也较困难些。所有这些分支都在适当割破平面后的区域内单值解析。

当然，也可把它们视为复合函数来化简处理。这里，我们只要求掌握反三角函数的计值方法。

例 2.24 求 Arcsin 2.

解 由公式(2.28)

 $$ \begin{array}{l}\operatorname{Arcsin}2=-\mathrm{i}\operatorname{Ln}(2\mathrm{i}\pm\sqrt{3}\mathrm{i})\\ =-\mathrm{i}\operatorname{Ln}\left[(2\pm\sqrt{3})\mathrm{i}\right]\\ =-\mathrm{i}\left[\ln(2\pm\sqrt{3})+\frac{\pi}{2}\mathrm{i}+2k\pi\right]\\ =\frac{\pi}{2}-\mathrm{i}\ln(2\pm\sqrt{3})+2k\pi\\ =\left(\frac{1}{2}+2k\right)\pi-\mathrm{i}\ln(2\pm\sqrt{3}).\\ (k=0,\pm1,\pm2,\cdots)\end{array} $$ 

例 2.25 求  $ \mathrm{Arctan}(2i) $.

解 由公式(2.27)

 $$ \begin{array}{c}\operatorname{Arctan}(2\mathrm{i})=-\frac{\mathrm{i}}{2}\mathrm{Ln}\left(-\frac{1}{3}\right)\\ =-\frac{\mathrm{i}}{2}\left(\ln\frac{1}{3}+\pi\mathrm{i}+2k\pi\mathrm{i}\right)\\ =\frac{\pi}{2}+\mathrm{i}\frac{\ln3}{2}+k\pi\end{array} $$

<!-- page: 106 -->

$$ \begin{aligned}&=\left(\frac{1}{2}+k\right)\pi+\mathrm{i}\frac{\ln3}{2}.\\&\quad(k=0,\pm1,\pm2,\cdots)\end{aligned} $$ 

## 第二章 习题

## (一)

1 设连续曲线  $ C: z = z(t), t \in [\alpha, \beta] $，有

 $$ z^{\prime}(t_{0})\neq0\quad(t_{0}\in[\alpha,\beta]), $$ 

则(试证)曲线 C 在点  $ z(t_{0}) $ 有切线.

2 洛必达(L'Hospital)法则 若  $ f(z) $ 及  $ g(z) $ 在点  $ z_{0} $ 解析，且

 $$ f(z_{0})=g(z_{0})=0,g^{\prime}(z_{0})\neq0, $$ 

则（试证）

 $$ \lim_{z\to z_{0}}\frac{f(z)}{g(z)}=\frac{f^{\prime}(z_{0})}{g^{\prime}(z_{0})}. $$ 

3 设  $ f(z)=\left\{\begin{aligned}\frac{x^{3}-y^{3}+i(x^{3}+y^{3})}{x^{2}+y^{2}},&z\neq0,\\0,&z=0,\end{aligned}\right. $

试证  $ f(z) $ 在原点满足 C.-R. 方程,但却不可微.

4 试证下列函数在 z 平面上任何点都不解析：

(1)  $ |z| $; (2)  $ x + y $; (3) Re z; (4)  $ \frac{1}{\overline{z}} $

5 试判断下列函数的可微性和解析性：

(1)  $ f(z) = xy^{2} + \mathrm{i}x^{2}y $;

(2)  $ f(z) = x^{2} + \mathrm{i} y^{2} $;

(3)  $ f(z) = 2x^{3} + 3\mathrm{i}y^{3} $;

(4)  $ f(z) = x^{3} - 3xy^{2} + \mathrm{i}(3x^{2}y - y^{3}) $.

答: (1) 只在原点 z = 0 可微;

（2）只在直线 y=x 上可微；

（3）只在 $ \sqrt{2}x\pm\sqrt{3}y=0 $上可微；

<!-- page: 107 -->

（4）处处可微.

6 若函数  $ f(z) $ 在区域 D 内解析，且满足下列条件之一，试证  $ f(z) $ 在 D 内必为常数.

(1) 在 D 内  $ f'(z)=0 $;

(2) $ \overline{f(z)} $在D内解析；

(3) $ |f(z)| $在D内为常数；

(4)  $ \mathrm{Re} f(z) $ 或  $ \mathrm{Im} f(z) $ 在 D 内为常数.

7 如果  $ f(z) $ 在区域 D 内解析，试证  $ \mathrm{i}\overline{f(z)} $ 在区域 D 内也解析.

8 试证下列函数在 z 平面上解析，并分别求出其导函数.

(1)  $ f(z) = x^{3} + 3x^{2}y\mathrm{i} - 3xy^{2} - y^{3}\mathrm{i} $;

(3)  $ f(z) = \sin x \cdot \cosh y + \mathrm{i} \cos x \cdot \sinh y; $

(4)  $ f(z) = \cos x \cdot \cosh y - i \sin x \cdot \sinh y $.

答: (1)  $ f'(z) = 3z^{2} $;

(2)  $ f'(z) = (z + 1)e^z $;

(3)  $ f'(z) = \cos x \cdot \cosh y - i \sin x \cdot \sinh y $;

(4)  $ f'(z) = -(\sin x \cdot \cosh y + \mathrm{i} \cos x \cdot \sinh y) $.

### 9 试证下面的定理：

设  $ f(z)=u(r,\theta)+\mathrm{i}v(r,\theta) $,  $ z=r\mathrm{e}^{\mathrm{i}\theta} $,

若  $ u(r,\theta) $,  $ v(r,\theta) $ 在点  $ (r,\theta) $ 是可微的，且满足极坐标的 C.-R. 方程：

 $$ \frac{\partial u}{\partial r}=\frac{1}{r}\frac{\partial v}{\partial\theta},\quad\frac{\partial v}{\partial r}=-\frac{1}{r}\frac{\partial u}{\partial\theta}(r>0), $$ 

则  $ f(z) $ 在点 z 是可微的，并且

 $$ \begin{align*}f^{\prime}\left(z\right)&=\left(\cos\theta-\mathrm{i}\sin\theta\right)\left(\frac{\partial u}{\partial r}+\mathrm{i}\frac{\partial v}{\partial r}\right)\\&=\frac{r}{z}\left(\frac{\partial u}{\partial r}+\mathrm{i}\frac{\partial v}{\partial r}\right).\end{align*} $$ 

注 这里要适当割破 z 平面(如沿负实轴割破), 否则  $ \theta(z) $ 就不是单值的.

10 设  $ z = x + iy $，试求

(1)  $ \left|e^{i-2z}\right| $; (2)  $ \left|e^{z^2}\right| $; (3)  $ \mathrm{Re}(e^{\frac{1}{z}}) $

答: (1)  $ e^{-2x} $; (2)  $ e^{x^{2}-y^{2}} $;

<!-- page: 108 -->

(3)

 $$ \mathrm{e}^{\frac{x}{2}+y^{2}}\cos\frac{y}{x^{2}+y^{2}}. $$ 

11 试证

(1)  $ \overline{e^{z}} = e^{\overline{z}} $; (2)  $ \overline{\sin z} = \sin \overline{z} $;

(3)  $ \overline{\cos z} = \cos \overline{z} $.

12 试证: 对任意的复数 z 及整数 m,

 $$ \left(\mathrm{e}^{z}\right)^{m}=\mathrm{e}^{mz}. $$ 

13 试求下面各式之值：

(1)  $ \mathrm{e}^{3+\mathrm{i}};\left(2\right)\cos\left(1-\mathrm{i}\right). $

14 试验证：

(1)

 $$ \lim_{z\to0}\frac{\sin z}{z}=1; $$ 

 $$ \lim_{z\to0}\frac{\mathrm{e}^{z}-1}{z}=1 $$ 

(3)

 $$ \lim_{z\to0}\frac{z^{-}z\cos z}{z^{-}\sin z}=3. $$ 

15 设 a、b 为复常数， $ b \neq 0 $，试证

$$  \begin{array}{l}\cos a+\cos(a+b)+\cdots+\cos(a+nb)\\ =\frac{\sin\frac{n+1}{2}b}{\sin\frac{b}{2}}\cos\left(a+\frac{nb}{2}\right);\end{array}   \tag*{(2.33)}$$

及

$$  \begin{aligned}&\sin a+\sin(a+b)+\cdots+\sin(a+nb)\\=&\frac{\sin\frac{n+1}{2}b}{\sin\frac{b}{2}}\sin\left(a+\frac{nb}{2}\right).\end{aligned}   \tag*{(2.34)}$$

注 分别证明（2.33）和（2.34）。由于 a 和 b 是复数，不能从  $ (2.33) + i \cdot (2.34) $ 着手化简后，再比较“实、虚”部。

16 试证：

 $$ (1)\sin(\mathrm{i}z)=\mathrm{i}\sinh z;\qquad(2)\cos(\mathrm{i}z)=\cosh z; $$ 

 $$ (3)\sinh(\mathrm{i}z)=\mathrm{i}\sin z;\qquad(4)\cosh(\mathrm{i}z)=\cos z; $$ 

 $$ (5)\tan(\mathrm{i}z)=\mathrm{i}\mathrm{t a n h}z;\qquad(6)\operatorname{t a n h}(\mathrm{i}z)=\mathrm{i}\mathrm{t a n z}. $$ 

17 试证：

 $$ (1)\ \cosh^{2}z-\sinh^{2}z=1;\quad(2)\ \operatorname{sech}^{2}z+\tanh^{2}z=1; $$ 

 $$ (3)\ \cosh(z_{1}+z_{2})=\cosh z_{1}\cosh z_{2}+\sinh z_{1}\sinh z_{2} $$

<!-- page: 109 -->

18 若  $ z = x + iy $，试证：

(1) $\sin z = \sin x \cdot \cosh y + \mathrm{i} \cos x \cdot \sinh y$;

(2)  $ \cos z = \cos x \cdot \cosh y - i \sin x \cdot \sinh y $;

(3)  $ \left|\sin z\right|^{2}=\sin^{2}x+\sinh^{2}y; $

(4)  $ \left|\cos z\right|^{2}=\cos^{2}x+\sinh^{2}y $

19 试证 $ (\sinh z)' = \cosh z; (\cosh z)' = \sinh z $.

20 试解方程：

(1)  $ \mathrm{e}^{z}=1+\sqrt{3}\mathrm{i}; $ (2)  $ \ln z=\frac{\pi\mathrm{i};}{2}; $

(3)  $ 1 + e^{z} = 0 $; (4)  $ \cos z + \sin z = 0 $;

 $ ^{*} $ (5)  $ \tan z = 1 + 2i $.

答: (1)  $ z = \ln 2 + i \left( \frac{\pi}{3} + 2k\pi \right) $,  $ (k = 0, \pm 1, \cdots) $;

(2) z = i; (3)  $ (2k + 1)\pi i $, (k 为整数);

(4)  $ -\frac{\pi}{4} + k\pi $, (k 为整数).

(5)  $ z = \frac{1}{2} \left[ (2k + 1)\pi - \arctan \frac{1}{2} \right] + \frac{i}{4} \ln 5 $,

 $ (k = 0, \pm 1, \cdots) $

21 设  $ z = re^{i\theta} $，试证

 $$ \mathrm{R e}\bigl[\ln(z-1)\bigr]=\frac{1}{2}\ln(1+r^{2}-2r\cos\theta). $$ 

22 设  $ \omega = \sqrt[3]{z} $ 确定在从原点 z = 0 起沿正实轴割破了的 z 平面上，并且  $ \omega(i) = -i $，试求  $ \omega(-i) $ 之值.

答： $ w(-i)=\frac{1}{2}(\sqrt{3}-i)=e^{-\frac{\pi}{6}i} $

23 设  $ \omega = \sqrt[3]{z} $ 确定在从原点 z = 0 起沿负实轴割破了的 z 平面上，并且  $ w(-2) = -\sqrt[3]{2} $ (这是边界上岸点对应的函数值)，试求  $ w(i) $ 之值.

答： $ w(i) = e^{\frac{5}{6}\pi i} $

24 试求  $ (1 + i)^{i} $ 及  $ 3^{i} $ 之值.

答： $ (1 + \mathrm{i})^{\mathrm{i}} = \mathrm{e}^{\mathrm{i}\ln\sqrt{2}} \mathrm{e}^{-}\left(\frac{\pi}{4} + 2k\pi\right) $， $ (k = 0, \pm 1, \cdots) $；

 $$ 3^{\mathrm{i}}=\mathrm{e}^{1\ln3}\cdot\mathrm{e}^{-2k\pi},(k=0,\pm1,\cdots). $$ 

25 已知  $ f(z) = \sqrt{z^{4} + 1} $ 在 Ox 轴上 A 点  $ (OA = R > 1) $ 的初值为

<!-- page: 110 -->

$ \sqrt{R^{4}+1} $，令 z 由 A 起沿正向在以原点为中心的圆周上走  $ \frac{1}{4} $ 圆周而至 Oy 轴的 B 点，问  $ f(z) $ 在 B 点的终值为何？

 $$ :-\sqrt{R^{4}+1}.\quad( 提示 : 作代换 \omega=z^{4}) $$ 

注 作了提示中的代换后,即可将原具有四个有限支点的繁难情形简化为具有单有限支点的情形.

26 试证: 在将 z 平面适当割开后, 函数

 $$ f(z)=\sqrt[3]{(1-z)z^{2}} $$ 

能分出三个单值解析分支. 并求出在点 z=2 取负值的那个分支在 z=i 的值.

答： $ -\sqrt[6]{2}e^{\frac{7}{12}\pi i} $

## (二)

1 设函数  $ f(z)=\frac{z}{1-z^{2}} $，试证

 $$ \mathrm{R e}\bigg[z\frac{f^{\prime}(z)}{f(z)}\bigg]>0,(|z|<1). $$ 

注 这里  $ f(z)=\frac{z}{1-z^{2}} $ 是单位圆  $ \left|z\right|<1 $ 内的单叶解析星像函数.

2 设  $ f(z)=\frac{z}{1-z} $，试证

 $$ \mathrm{R e}\bigg[1+z\frac{f^{\prime\prime}(\bar{z})}{f^{\prime}(z)}\bigg]>0,(|z|<1). $$ 

注 这里  $ f(z)=\frac{z}{1-z} $ 是单位圆  $ \left|z\right|<1 $ 内的单叶解析凸像函数.

3 若函数  $ f(z) $ 在上半 z 平面内解析，试证函数  $ \overline{f(\bar{z})} $ 在下半 z 平面内解析.

 $ ^{*} $4 （形式导数）(1) 设二元实变函数  $ u(x,y) $ 有偏导数. 此函数可以写成  $ z = x + iy $ 及  $ \bar{z} $ 的函数

 $$ u=u\left(\frac{z+\bar{z}}{2},\frac{z-\bar{z}}{2\mathrm{i}}\right). $$ 

试证(形式地)

 $$ \frac{\partial u}{\partial z}=\frac{1}{2}\left(\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}\right),\frac{\partial u}{\partial\overline{z}}=\frac{1}{2}\left(\frac{\partial u}{\partial x}+\mathrm{i}\frac{\partial u}{\partial y}\right). $$

<!-- page: 111 -->

（2）设复变函数  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $，且  $ u(x,y) $ 和  $ v(x,y) $ 都有偏导数.

试证(形式地):对于  $ f(z) $,柯西-黎曼方程可以写成

 $$ \begin{array}{r}{\frac{\partial f}{\partial\overline{{z}}}=\frac{\partial u}{\partial\overline{{z}}}+\mathrm{i}\frac{\partial v}{\partial\overline{{\dot{z}}}}=0.}\end{array} $$ 

（由此可见，解析函数是以条件 $ \frac{\partial f}{\partial \overline{z}}=0 $为其特征的.因此，我们不妨说，一个解析函数与 $ \overline{z} $无关，而是z的函数.）

5 试证:  $ |\operatorname{Im} z| \leqslant |\sin z| \leqslant e^{|\operatorname{Im} z|} $.

6 若  $ |z| \leq R $，试证

 $$ |\sin z|\leqslant\cosh R,|\cos z|\leqslant\cosh R. $$ 

7 证明函数  $ f(z)=z^{2}+2z+3 $ 在单位圆  $ \left|z\right|<1 $ 内是单叶的.

提示 对圆内的任二相异点  $ z_{1}, z_{2} $，证明

 $$ \left|\frac{f(z_{1})-f(z_{2})}{z_{1}-z_{2}}\right|>0. $$ 

8 试证多值函数  $ f(z)=\sqrt[4]{(1-z)^{3}(1+z)} $ 在割去线段  $ [-1,1] $ 的 z 平

面上可以分出四个单值解析分支.求函数在割线上岸取正值的那个分支在点 $ z=\pm i $的值.

答： $ f(i)=\sqrt{2}e^{-\frac{\pi}{8}i},f(-i)=\sqrt{2}e^{\frac{5\pi}{8}i} $

9 已知  $ f(z)=\sqrt{(1-z)(1+z^{2})} $ 在 z=0 的值为 1. 令 z 描绘路线 OPA（如图 2.15）. 点 A 为 2，试求  $ f(z) $ 在点 A 的值.

<div style="text-align: center;"><img src="images/p0111_img_in_image_box_2588_3573_4005_4951.jpg" alt="图2.15" width="31%" /></div>


答： $ f(2) = -\sqrt{5}i $.

<div style="text-align: center;"><div style="text-align: center;">图2.15</div> </div>


10 试证  $ f(z)=\sqrt{z(1-z)} $ 在割去线段  $ 0 \leq \mathrm{Re} z \leq 1 $ 的 z 平面上能分出两个单值

解析分支.并求出在支割线  $ 0 \leq \mathrm{Re} z \leq 1 $ 上岸取正值时的那一支在 z = -1 的值,以及它的第二阶导数在 z = -1 的值.

答： $ f(-1)=\sqrt{2}\mathrm{i},f''(-1)=-\frac{\sqrt{2}}{16}\mathrm{i} $

<!-- page: 112 -->

## 第三章 复变函数的积分

‖◆‖‖◆‖‖◆‖‖‖◆‖‖‖◆‖‖

复变函数的积分(简称复积分)是研究解析函数的一个重要工具.解析函数的许多重要性性质要利用复积分来证明.例如,要证明“解析函数的导函数连续”及“解析函数的各阶导数存在”这些表面上看来只与微分学有关的命题,一般均要使用复积分.

本章要建立的柯西积分定理及柯西积分公式尤其重要，它们是复变函数论的基本定理和基本公式，以后各章都直接地或间接地和它们有关联。

‖◆‖‖◆‖‖◆‖‖‖‖

#### §1. 复积分的概念及其简单性质

1. 复变函数积分的定义为为了叙述简便而又不妨碍实际应用，今后我们所提到的曲线（除特别声明外），一律是指光滑的或逐段光滑的，因而也是可求长的。曲线通常还要规定其方向，在开口弧的情形，这只要指出其始点与终点就行了。

逐段光滑的简单闭曲线简称周线。周线自然也是可求长的。对于周线，我们在第一章若尔当定理之后实际上已经规定过它的方向。“反时针”方向为正；“顺时针”方向为负。

定义 3.1 设有向曲线 C:

 $$ z=z\left(t\right),\left(a\leqslant t\leqslant\beta\right) $$ 

以 $ a=z(\alpha) $为起点， $ b=z(\beta) $为终点， $ f(z) $沿C有定义.顺着C

<!-- page: 113 -->

<div style="text-align: center;"><img src="images/p0113_img_in_image_box_1379_559_3073_1802.jpg" alt="图3.1" width="37%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.1</div> </div>


从a到b的方向在C上取分点：

 $$ a=z_{0},z_{1},\cdots,z_{n-1},z_{n}=b $$ 

把曲线 C 分成若干个弧段（图 3.1）. 在从  $ z_{k-1} $ 到  $ z_{k}(k=1,2,\cdots,n) $ 的每一弧段上任取一点  $ \zeta_{k} $. 作成和数

 $$ S_{n}=\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}, $$ 

其中  $ \Delta z_{k}=z_{k}-z_{k-1} $. 当分点无限增多，而这些弧段长度的最大值趋于零时，如果和数  $ S_{n} $ 的极限存在且等于 J，则称  $ f(z) $ 沿  $ C(从 a $ 到 b) 可积，而称 J 为  $ f(z) $ 沿 C (从 a 到 b) 的积分，并以记号  $ \int_{C}f(z)dz $ 表示：

 $$ J=\int_{c}\dot{f}(z)\mathrm{d}z. $$ 

C 称为积分路径.  $ \int_{C} f(z) dz $ 表示沿 C 的正方向的积分,  $ \int_{C^{-}} f(z) dz $ 表示沿 C 的负方向的积分.

如果 J 存在，我们一般不能把 J 写成  $ \int_{a}^{b} f(z) dz $ 的形式，因为 J 的值不仅和 a, b 有关，而且和积分路径 C 有关.

显然， $ f(z) $ 沿曲线 C 可积的必要条件为  $ f(z) $ 沿 C 有界.另

<!-- page: 114 -->

一方面，我们有

定理 3.1 若函数  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 沿曲线 C 连续，则  $ f(z) $ 沿 C 可积，且

$$  \int_{C}f(z)\mathrm{d}z=\int_{C}u\mathrm{d}\bar{x}-v\mathrm{d}y+\mathrm{i}\int_{C}v\mathrm{d}x+u\mathrm{d}y.   \tag*{(3.1)}$$

证 设  $ z_{k}=x_{k}+\mathrm{i}y_{k}, x_{k}-x_{k-1}=\Delta x_{k}, y_{k}-y_{k-1}=\Delta y_{k} $

 $$ \zeta_{k}=\xi_{k}+\mathrm{i}\eta_{k},u(\xi_{k},\eta_{k})=u_{k},v(\xi_{k},\eta_{k})=v_{k}, $$ 

我们便得到：

 $$ \begin{align*}S_{n}&=\sum_{k=1}^{n}f(\zeta_{k})(z_{k}-z_{k-1})\\&=\sum_{k=1}^{n}(u_{k}+i v_{k})(\Delta x_{k}+i\Delta y_{k})\end{align*} $$ 

上式右端的两个和数是对应的两个曲线积分的积分和数. 在定理的条件下, 必有  $ u(x, y) $ 及  $ v(x, y) $ 沿 C 连续, 于是这两个曲线积分都是存在的. 因此, 积分  $ \int_{C} f(z) dz $ 存在, 且有公式 (3.1).

公式(3.1)说明,复变函数积分的计算问题,可以化为其实、虚部两个二元实函数曲线积分的计算问题.

注 公式(3.1)可以在形式上看成函数  $ f(z) = u + iv $ 与微分  $ \mathrm{d}z = \mathrm{d}x + \mathrm{d}iy $ 相乘后所得到的. 这样看, 便于记忆.

例 3.1 命 C 表连接点 a 及 b 的任一曲线，试证

(1)  $ \int_{C} dz = b - a $; (2)  $ \int_{C} z dz = \frac{1}{2}(b^{2} - a^{2}) $.

证 (1) 因  $ f(z)=1, S_{n}=\sum_{k=1}^{n}(z_{k}-z_{k-1})=b-a $，故

 $ \lim_{\substack{n\to\infty\\ \max|\Delta z_k|\to0}} $

 $ S_n = b - a $，即  $ \int_{C} dz = b - a $.

<!-- page: 115 -->

(2) 因  $ f(z)=z $，选  $ \zeta_{k}=z_{k-1} $，则得

 $$ \begin{array}{r}{\sum_{1}=\displaystyle\sum_{k=1}^{n}z_{k-1}\left(\mathscr{Z}_{k}-\mathscr{Z}_{k-1}\right),}\end{array} $$ 

但我们又可选  $ \zeta_{k}=z_{k} $，则得

 $$ \begin{array}{r}{\sum_{2}=\displaystyle\sum_{k=1}^{n}z_{k}\left(z_{k}-z_{k-1}\right),}\end{array} $$ 

由定理 3.1, 可知积分  $ \int_{C} z \, dz $ 存在, 因而  $ S_{n} $ 的极限存在, 且应与  $ \sum_{1}  $ 及  $ \sum_{2} $ 的极限相等, 从而应与  $ \frac{1}{2} (\sum_{1} + \sum_{2}) $ 的极限相等. 令

 $$ \frac{1}{2}\left(\sum_{1}+\sum_{2}\right)=\frac{1}{2}\sum_{k=1}^{n}\left(z_{k}^{2}-z_{k-1}^{2}\right)=\frac{1}{2}(b^{2}-a^{2}), $$ 

所以

 $$ \int_{c}z\mathrm{d}z=\frac{1}{2}(b^{2}-a^{2}). $$ 

注 当 C 为闭曲线时， $ \int_{C} dz = 0 $， $ \int_{C} z dz = 0 $.

2. 复变函数积分的计算问题 设有光滑曲线 C:

 $$ z=z\left(t\right)=x\left(t\right)+\mathrm{i}y\left(t\right)\quad\left(a\leqslant t\leqslant\beta\right) $$ 

这就表示  $ z'(t) $ 在  $ [\alpha,\beta] $ 上连续且有不为零的导数  $ z'(t)=x'(t)+iy'(t) $. 又设  $ f(z) $ 沿 C 连续. 令

 $$ \begin{aligned}f[\boldsymbol{z}(t)]&=u[\boldsymbol{x}(t),\boldsymbol{y}(t)]+\mathrm{i}v[\boldsymbol{x}(t),\boldsymbol{y}(t)]\\&=\boldsymbol{u}(t)+\mathrm{i}v(t),\end{aligned} $$ 

由公式(3.1)我们有

 $$ \begin{align*}\int_{C}f(z)\mathrm{d}z&=\int_{C}u\mathrm{d}x-v\mathrm{d}y+i\int_{C}u\mathrm{d}y+v\mathrm{d}x\\&=\int_{a}^{\beta}\left[u(t)x^{\prime}(t)-v(t)y^{\prime}(t)\right]\mathrm{d}t\\&\quad+i\int_{a}^{\beta}\left[u(t)y^{\prime}(t)+v(t)x^{\prime}(t)\right]\mathrm{d}t,\end{align*} $$

<!-- page: 116 -->

即

$$  \int_{C}f(z)\mathrm{d}z=\int_{a}^{\beta}f[z(t)]z^{\prime}(t)\mathrm{d}t,   \tag*{(3.2)}$$

或

$$  \begin{align*}\int_{C}f(z)\mathrm{d}z&=\int_{a}^{\beta}\mathrm{Re}\{f[z(t)]z^{\prime}(t)\}\mathrm{d}t\\&\quad+\mathrm{i}\int_{a}^{\beta}\mathrm{Im}\{f[z(t)]z^{\prime}(t)\}\mathrm{d}t.\end{align*}   \tag*{(3.3)}$$

用公式(3.2)或(3.3)计算复变函数的积分,是从积分路径 C 的参数方程着手的,称为参数方程法.(3.2)或(3.3)称为复积分的变量代换公式.

例 3.2 （一个重要的常用的积分）

 $$ \int_{c}\frac{\mathrm{d}z}{\left(z-a\right)^{n}}=\left\{\begin{aligned}&2\pi i,\left(n=1\right)\\ &0,\left(n\neq1\right) 的整数 \end{aligned}\right. $$ 

这里 C 表示以 a 为心,  $ \rho $ 为半径的圆周. (注意: 积分值与  $ a, \rho $ 均无关, a 可为 0).

证 C 的参数方程为:  $ z - a = \rho e^{i\theta}, 0 \leq \theta \leq 2\pi $. 故

 $$ \int_{C}\frac{\mathrm{d}z}{z-a}\frac{(3.2)}{\overbrace{0}^{2\pi}}\int_{0}^{2\pi}\frac{\mathrm{i}\rho\mathrm{e}^{\mathrm{i}\theta}\mathrm{d}\theta}{\rho\mathrm{e}^{\mathrm{i}\theta}}=\mathrm{i}\int_{0}^{2\pi}\mathrm{d}\theta=2\pi\mathrm{i}; $$ 

当 n 为整数且  $ n \neq 1 $ 时

 $$ \begin{align*}\int_{C}\frac{\mathrm{d}z}{(z-a)^{n}}&\xrightarrow{(3.2)}\int_{0}^{2\pi}\frac{\mathrm{i}\rho\mathrm{e}^{\mathrm{i}\theta}\mathrm{d}\theta}{\rho^{n}\mathrm{e}^{\mathrm{i}n\theta}}=\frac{\mathrm{i}}{\rho^{n-1}}\int_{0}^{2\pi}\mathrm{e}^{-\mathrm{i}(n-1)\theta}\mathrm{d}\theta\\&=\frac{\mathrm{i}}{\rho^{n-1}}\left[\int_{0}^{2\pi}\cos(n-1)\theta\mathrm{d}\theta-\mathrm{i}\int_{0}^{2\pi}\sin(n-1)\theta\mathrm{d}\theta\right]\\&=0.\end{align*} $$ 

3. 复变函数积分的基本性质 设函数  $ f(z) $,  $ g(z) $ 沿曲线 C 连续, 则有下列与数学分析中的曲线积分相类似的性质:

(1)  $ \int_{C}af(z)\mathrm{d}z=a\int_{C}f(z)\mathrm{d}z $, a 是复常数；

(2)

 $$ \int_{C}\left[f(z)+g(z)\right]\mathrm{d}z=\int_{C}f(z)\mathrm{d}z+\int_{C}g(z)\mathrm{d}z; $$ 

(3)  $ \int_{C} f(z) dz = \int_{C_{1}} f(z) dz + \int_{C_{2}} f(z) dz $，其中 C 由曲线

<!-- page: 117 -->

$ C_{1} $ 和  $ C_{2} $ 衔接而成；

(4)

 $$ \int_{c^{-}}f(z)\mathrm{d}z=-\int_{c}f(z)\mathrm{d}z. $$ 

（5）

 $$ \left|\int_{C}f(z)\mathrm{d}z\right|\leqslant\int_{C}\left|f(z)\right|\left|\mathrm{d}z\right|=\int_{C}\left|f(z)\right|\mathrm{d}s. $$ 

这里  $ \left| dz \right| $ 表示弧长的微分，即

 $$ \left|\mathrm{d}z\right|=\sqrt{\left(\mathrm{d}x\right)^{2}+\left(\mathrm{d}y\right)^{2}}=\mathrm{d}s. $$ 

要得到(5)式，只要把下列不等式取极限 $ ^{①} $:

 $$ \big|\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}\big|\leqslant\sum_{k=1}^{n}\mid f(\zeta_{k})\mid\mid\Delta z_{k}\mid\leqslant\sum_{k=1}^{n}\mid f(\zeta_{k})\mid\Delta s_{k}. $$ 

定理 3.2 (积分估值) 若沿曲线 C，函数  $ f(z) $ 连续，且有正数 M 使  $ \left|f(z)\right| \leq M $，L 为 C 之长，则

 $$ \left|\int_{c}f(z)\mathrm{d}z\right|\leqslant M L. $$ 

证 由不等式

 $$ \left|\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}\right|\leqslant M\sum_{k=1}^{n}\left|\Delta z_{k}\right|\leqslant M L, $$ 

取极限即得证.

例 3.3 试证  $ \left|\int_{C}\frac{\mathrm{d}z}{z^{2}}\right|\leq2 $.

积分路径 C 是连接 i 和  $ 2+i $ 的直线段.

证 C 的参数方程为

 $$ z=\left(1-t\right)\mathrm{i}+t\left(2+\mathrm{i}\right)\quad\left(0\leqslant t\leqslant1\right), $$ 

 $$ z=2t+\mathrm{i}\quad(0\leqslant t\leqslant1), $$ 

即

沿  $ C, \frac{1}{z^{2}} $ 连续，且

 $$ \left|\frac{1}{z^{2}}\right|=\frac{1}{\left|z\right|^{2}}=\frac{1}{4t^{2}+1}\leqslant1. $$

<!-- page: 118 -->

而 C 之长为 2. 故由定理 3.2,  $ \left|\int_{C}\frac{dz}{z^{2}}\right|\leq2 $.

例 3.4 试证

 $$ \left|\int_{|z|=r}\frac{\mathrm{d}z}{(z-a)(z+a)}\right|<\frac{2\pi r}{|r^{2}-|a|^{2}|}\quad(r>0,|a|\neq r). $$ 

证 若 a=0，则  $ \int_{|z|=r}\frac{\mathrm{d}z}{z^{2}}=0 $（例 3.2），不等式成立；若  $ a\neq0 $，则由复积分的基本性质（5），

 $$ \begin{align*}\left|\int_{|z|=r}\frac{\mathrm{d}z}{(z-a)(z+a)}\right|&\leq\int_{|z|=r}\frac{|\mathrm{d}z|}{|z^2-a^2|}\\<\int_{|z|=r}\frac{|\mathrm{d}z|}{|r^2-|a|^2|}&=\frac{2\pi r}{|r^2-|a|^2|}.\end{align*} $$ 

注 数学分析中实变函数的积分中值定理,不能直接推广到复积分上来.因由

 $$ \int_{0}^{2\pi}\mathrm{e}^{\mathrm{i}\theta}\mathrm{d}\theta=\int_{0}^{2\pi}\cos\theta\mathrm{d}\theta+\mathrm{i}\int_{0}^{2\pi}\sin\theta\mathrm{d}\theta=0, $$ 

而  $ \mathrm{e}^{\mathrm{i}\theta}(2\pi-0)\neq0 $，即可看出.

例 3.5 计算积分

 $$ \int_{c}\mathrm{R e}z\mathrm{d}z, $$ 

其中积分路径 C(图 3.2) 为：

（1）连接由点 O 到点  $ 1+i $ 的直线段；

<div style="text-align: center;"><img src="images/p0118_img_in_image_box_2493_3448_3989_4533.jpg" alt="Image" width="33%" /></div>


（2）连接由点 O 到点 1 的直线 图 3.2 段，以及连接由点 1 到点  $ 1+i $ 的直线段所组成的折线.

解 （1）连接 O 及  $ 1+i $ 的直线段的参数方程为：

 $$ z=\left(1+\mathrm{i}\right)t\quad\left(0\leqslant t\leqslant1\right), $$ 

故

 $$ \begin{align*}\int_{C}\operatorname{Re}z\mathrm{d}z&=\int_{0}^{1}\left\{\operatorname{Re}[(1+\mathrm{i})t]\right\}(1+\mathrm{i})\mathrm{d}t\\&=(1+\mathrm{i})\int_{0}^{1}t\mathrm{d}t=\frac{1+\mathrm{i}}{2}.\end{align*} $$

<!-- page: 119 -->

（2）连接 O 与 1 的直线段的参数方程为：

 $$ z=t\quad(0\leqslant t\leqslant1), $$ 

连接点1与 $ 1+i $的直线段的参数方程为：

 $$ z=\left(1-t\right)+\left(1+\mathrm{i}\right)t\quad\left(0\leqslant t\leqslant1\right), $$ 

即

 $$ z=1+i t\quad\left(0\leqslant t\leqslant1\right), $$ 

故

 $$ \begin{aligned}\int_{C}\operatorname{Re}z\mathrm{d}z&=\int_{0}^{1}\operatorname{Re}t\mathrm{d}t+\int_{0}^{1}\left[\operatorname{Re}(1+\mathrm{i}t)\right]\mathrm{i}\mathrm{d}t\\&=\int_{0}^{1}t\mathrm{d}t+\mathrm{i}\int_{0}^{1}\mathrm{d}t=\frac{1}{2}+\mathrm{i}.\end{aligned} $$ 

由此例可以看出，积分路径不同，积分结果可以不同。

#### §2. 柯西积分定理

1. 柯西积分定理 从上一节所举的例题来看,例 3.1(2)的被积函数  $ f(z)=z $ 在单连通区域 z 平面上处处解析,它沿连接起点 a 及终点 b 的任何路径 C 的积分值都相同,即积分与路径无关,或者说沿 z 平面上任何闭曲线的积分为零;例 3.2 的被积函数

 $$ f(z)=\frac{1}{z-a} $$ 

只以 z=a 为奇点，即在“z 平面除去一点 a”的非单连通区域内处处解析，但是积分

 $$ \int_{c}\frac{\mathrm{d}z}{z-a}=2\pi\mathrm{i}\neq0, $$ 

其中 C 表圆周  $ |z - a| = \rho > 0 $，即在此区域内积分与路径有关；例 3.5 的被积函数  $ f(z) = \mathrm{Re} \cdot z $。在单连通区域 z 平面上处处不解析（第二章习题4（3）），而积分与连接起点 O 及终点  $ 1 + i $ 的路径 C 有关，即沿 z 平面上任何闭曲线的积分，其值不恒为零。

由此可见，复积分的值与路径无关的条件，或沿区域内任何闭曲线积分值为零的条件，可能与被积函数的解析性及解析区域的单连通性有关。

<!-- page: 120 -->

1825 年柯西给出了如下的定理，肯定地回答了上述问题，它是研究复变函数的钥匙，常称为柯西积分定理.

定理 3.3 设函数  $ f(z) $ 在 z 平面上的单连通区域 D 内解析，C 为 D 内任一条周线，则

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

要证明这个定理是比较困难的.

1851年，黎曼在附加假设“ $ f'(z) $在D内连续”的条件下，得到一个如下的简单证明.

黎曼证明 令  $ z = x + iy $,  $ f(z) = u(x, y) + iv(x, y) $; 由公式(3.1),

 $$ \int_{C}f(z)\mathrm{d}z=\int_{C}\dot{u}\mathrm{d}x-v\mathrm{d}y+\mathrm{i}\int_{C}v\mathrm{d}x+u\mathrm{d}y, $$ 

而  $ f'(z) $ 在 D 内连续，导致  $ u_{x}, u_{y}, v_{x}, v_{y} $ 在 D 内连续，并适合 C. -R. 方程：

 $$ u_{x}=v_{y},u_{y}=-v_{x}. $$ 

由格林定理，

 $$ \int_{c}u\mathrm{d}x-v\mathrm{d}y=0,\int_{c}v\mathrm{d}x+u\mathrm{d}y=0, $$ 

故得

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

柯西将复变函数  $ f(z) $ 作为复变数 z 的一元函数来研究. 他定义解析函数为  $ f'(z) $ 在区域 D 内存在并连续. 1900 年古莎 (Goursat) 发表上述定理的新的证明方法, 无须将  $ f(z) $ 分为实部与虚部: 更重要的是免去了  $ f'(z) $ 为连续的假设. 因此,  $ f'(z) $ 的连续性假设不仅在柯西积分定理中可以省略, 同时对解析函数的定义也像我们现在这样定义 (定义 2.2), 只须  $ f'(z) $ 在区域 D 存在, 不必假设  $ f'(z) $ 连续.

柯西积分定理的古莎证明比较长，我们将它放在下一段单独证明.现在先由柯西积分定理，可以得到

<!-- page: 121 -->

定理 3.4 设函数  $ f(z) $ 在 z 平面上的单连通区域 D 内解析，C 为 D 内任一闭曲线（不必是简单的），则

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

证 因为  $ \mathring{C} $ 总可以看成区域 D 内有限多条周线衔接而成(如图 3.3). 再由复积分的基本性质(3)及柯西积分定理 3.3, 即可得证.

<div style="text-align: center;"><img src="images/p0121_img_in_image_box_951_1862_3491_3136.jpg" alt="图3.3" width="56%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.3</div> </div>


推论 3.5 设函数  $ f(z) $ 在 z 平面上的单连通区域  $ D_{1} $ 内解析，则  $ f(z) $ 在 D 内积分与路径无关。即对 D 内任意两点  $ z_{0} $ 与  $ z_{1} $，积分

 $$ \int_{z_{0}}^{z_{1}}f(z)\mathrm{d}z $$ 

之值,不依赖于 D 内连接起点  $ z_{0} $ 与终点  $ z_{1} $ 的曲线.

证 设  $ C_{1} $ 与  $ C_{2} $ 是 D 内连接起点  $ z_{0} $ 与终点  $ z_{1} $ 的任意两条曲线（如图 3.4）. 则正方向曲线  $ C_{1} $ 与负方向曲线  $ C_{2}^{-} $就衔接成 D 内的一条闭曲线 C. 于是，由定理 3.4 与复积分的基本性质（3）有

 $$ 0=\int_{c}f(z)\mathrm{d}z=\int_{c_{1}}f(z)\mathrm{d}z+\int_{c_{2}^{-}}f(z)\mathrm{d}z, $$ 

因而

<!-- page: 122 -->

$$ \int_{c_{1}}f(z)\mathrm{d}z=\int_{c_{2}}f(z)\mathrm{d}z. $$ 

<div style="text-align: center;"><img src="images/p0122_img_in_image_box_792_974_3648_2168.jpg" alt="图3.4" width="63%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.4</div> </div>


### 2. 柯西积分定理的古莎证明

第一步: C 为 D 内任一个三角形  $ \triangle $.

假设

 $$ \left|\int_{\triangle}f(z)\mathrm{d}z\right|=M. $$ 

我们来证明

 $$ M=0. $$ 

二等分给定三角形 $ \triangle $的每一边，两两连接这些分点， $ \triangle $就被分成了四个全等的三角形，它们的周界是 $ \triangle_{1} $， $ \triangle_{2} $， $ \triangle_{3} $， $ \triangle_{4} $（如图3.5）。显然有

<div style="text-align: center;"><img src="images/p0122_img_in_image_box_1441_4303_3009_5509.jpg" alt="图3.5" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.5</div> </div>

<!-- page: 123 -->

$$  \begin{align*}\int_{\Delta}f(z)\mathrm{d}z&=\int_{\Delta_{1}}f(z)\mathrm{d}z+\int_{\Delta_{2}}f(z)\mathrm{d}z+\int_{\Delta_{3}}f(z)\mathrm{d}z\\&\quad+\int_{\Delta_{4}}f(z)\mathrm{d}z.\end{align*}   \tag*{(3.4)}$$

因为在这里沿每一条连接分点的线段的积分从彼此正好相反的方向取了两次，刚好互相抵消。由于  $ \left|\int_{\Delta} f(z) \, \mathrm{d}z\right| = M $，根据(3.4)，周界  $ \triangle_{k}(k=1,2,3,4) $ 中至少有一个使沿着它所取积分的模不小于  $ \frac{M}{4} $。比如说，假定这个周界是  $ \triangle^{(1)} = \triangle_{1} $。

 $$ \left|\int_{\triangle^{(1)}}f(z)\mathrm{d}z\right|\geqslant\frac{M}{4}. $$ 

对于这个三角形周界 $ \triangle^{(1)} $，和前面一样，我们把它分成四个全等三角形。于是，在以 $ \triangle^{(1)} $为周界的三角形内的四个三角形中我们又可以找到一个三角形，记它的周界为 $ \triangle^{(2)} $，使

 $$ \left|\int_{\triangle^{(2)}}f(z)\mathrm{d}z\right|\geqslant\frac{M}{4^{2}}. $$ 

很明显，这个作法可以无限制的作下去，于是我们得到具有周界： $ \triangle=\triangle^{(0)},\triangle^{(1)},\triangle^{(2)},\triangle^{(3)},\cdots,\triangle^{(n)},\cdots $的三角形序列，其中一个包含后面的一个而且有下列不等式：

$$  \left|\int_{\triangle}^{(n)}f(z)\mathrm{d}z\right|\geqslant\frac{M}{4^{n}},(n=0,1,2,\cdots).   \tag*{(3.5)}$$

用 U 表示周界△的长度，于是周界△ $ ^{(1)} $，△ $ ^{(2)} $，⋯，△ $ ^{(n)} $，⋯相应的长度就是：

 $$ \frac{U}{2},\frac{U}{2^{2}},\cdots,\frac{U}{2^{n}},\cdots. $$ 

我们来估计  $ \int_{\Delta(n)} f(z) dz $ 的模. 由于序列中每一个三角形都包含在它后面的全部三角形，而且它们周界的长度随 n 的无限增大而趋向于零（根据定义 1.11）. 所以根据极限理论的基本原则（即闭集套定理 1.5——这里是三角形套），惟一存在一个点  $ z_{0} $ 属于这个

<!-- page: 124 -->

序列中所有的三角形. 这个点  $ z_{0} $ 在区域 D 内，而函数  $ f(z) $ 在 D 内又是解析的，因此在点  $ z_{0} $ 函数  $ f(z) $ 有一个有限导数. 从而，对于任一个无论怎样小的  $ \varepsilon > 0 $，都有一个正数  $ \delta = \delta(\varepsilon) $ 存在，使当  $ 0 < |z - z_{0}| < \delta $ 时，有

 $$ \left|\frac{f(z)-f(z_{0})}{z-z_{0}}-f^{\prime}(z_{0})\right|<\varepsilon. $$ 

把上不等式两端乘以  $ |z - z_{0}| $，即得

$$  |f(z)-f(z_{0})-f^{\prime}(z_{0})(z-z_{0})|<\varepsilon|z-z_{0}|.   \tag*{(3.6)}$$

对于以  $ z_{0} $ 为中心、以  $ \delta $ 为半径的圆内的点  $ z(\neq z_{0}) $，(3.6)成立；另一方面，从一个充分大的 n 开始，三角形  $ \triangle^{(n)} $ 都在上述圆内。因此，可以用 (3.6) 式来估计  $ \int_{\triangle^{(n)}} f(z) dz $ 的模。由于  $ \int_{\triangle^{(n)}} dz = 0 $， $ \int_{\triangle^{(n)}} zdz = 0 $ (见例 3.1 注)，所以

$$  \int_{\triangle^{(n)}}f(z)\mathrm{d}z=\int_{\triangle^{(n)}}\left[f(z)-f(z_{0})-f^{\prime}(z_{0})(z-z_{0})\right]\mathrm{d}z.   \tag*{(3.7)}$$

但由(3.6)式,当 z 位于三角形周界  $ \triangle^{(n)} $ 上时,

 $$ |f(z)-f(z_{0})-f^{\prime}(z_{0})(z-z_{0})|<\varepsilon|z-z_{0}|<\frac{\varepsilon U}{2^{n}}, $$ 

其中第二个不等式，是因为三角形周界 $ \triangle^{(n)} $上任一点z，到此三角形上一点 $ z_{0} $的距离小于 $ \frac{U}{2^{n}} $，故由(3.7)式得

$$  \left|\int_{\triangle}^{(n)}f(z)\mathrm{d}z\right|<\varepsilon\cdot\frac{U}{2^{n}}\cdot\frac{U}{2^{n}}=\varepsilon\cdot\frac{U^{2}}{4^{n}}.   \tag*{(3.8)}$$

比较(3.5)和(3.8)可得

 $$ \begin{array}{l}\varepsilon\cdot\frac{U^{2}}{4^{n}}>\frac{M}{4^{n}}.\\M<\varepsilon\cdot U^{2}.\end{array} $$ 

即

但  $ \varepsilon $ 是一个可以任意小的正数，而  $ M \neq 0 $，故

<!-- page: 125 -->

$$ M=0. $$ 

第二步: C 为 D 内任一条简单闭环线 P.

用对角线把以 P 为周界的多角形分成有限多个三角形，如图 3.6(P 为凸多角形)、图 3.7(P 为非凸多角形).

<div style="text-align: center;"><img src="images/p0125_img_in_image_box_821_1497_1801_2622.jpg" alt="图3.6" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.6</div> </div>


<div style="text-align: center;"><img src="images/p0125_img_in_image_box_2652_1425_3601_2642.jpg" alt="图3.7" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.7</div> </div>


因为这时沿每一条对角线，积分从彼此正好相反的方向取了两次，刚好互相抵消。于是，由第一步的结果得

 $$ \int_{P}f(z)\mathrm{d}z=0. $$ 

<div style="text-align: center;"><img src="images/p0125_img_in_image_box_1581_3717_2892_5224.jpg" alt="图3.8" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.8</div> </div>


第三步：C 为 D 内任一条周线.

（1）对于任一无论怎样小的  $ \varepsilon>0 $，都存在一条内接于 C 并完全在 D 内的简单闭环线 P（如图 3.8），使得

<!-- page: 126 -->

$$  \left|\int_{C}f(z)\mathrm{d}z-\int_{P}f(z)\mathrm{d}z\right|<\varepsilon.   \tag*{(3.9)}$$

换句话说，积分  $ \int_{C} f(z) dz $ 的值，可以用沿着在区域 D 内内接于 C 的简单闭环线 P 所取积分的值来逼近任何精确的程度.

为了证明这个事实，我们考虑区域 D 内的一个闭子域  $ \overline{G} $，使曲线 C 整个位于 G 内。设 G 的边界与 C 间的最小距离为  $ \rho $。易知  $ \rho > 0 $（见后面注）。于是以 C 上任意点为心， $ \rho $ 为半径的圆，均全含于  $ \overline{G} $ 内。从而，C 上任意两点只要距离小于  $ \rho $，它们的联结线段必全在  $ \overline{G} $ 内。

根据假设，函数  $ f(z) $ 在  $ \overline{G} $ 上连续，因而在  $ \overline{G} $ 上一致连续，故对于任一无论怎样小的  $ \varepsilon > 0 $，都存在一个正数  $ \delta_{1} = \delta_{1}(\varepsilon) $，使得当  $ z^{\prime}, z^{\prime\prime} $ 在  $ \overline{G} $ 上且适合  $ |z^{\prime} - z^{\prime\prime}| < \delta_{1} $ 时，不等式

 $$ f(z^{\prime})-f(z^{\prime \prime})<\frac{\varepsilon}{2l} $$ 

成立，这里 l 为 C 之长.

显然，可以在 C 上依积分正向取 n 个点  $ z_{0}, z_{1}, z_{2}, \cdots, z_{n-1} $ 分 C 为 n 段弧  $ \sigma_{1}, \sigma_{2}, \cdots, \sigma_{n} $，使

 $$ \max_{1\leqslant j\leqslant n}(\sigma_{j} 之长 )<\delta\leqslant\min(\delta_{1},\rho) $$ 

于是以  $ z_{0}, z_{1}, \cdots, z_{n-1} $ 为顶的简单多边形 P 全含于  $ \overline{G} $ 内（因而全含于 D 内）。P 的边  $ r_{1}, r_{2}, \cdots, r_{n} $ 分别是  $ \sigma_{1}, \sigma_{2}, \cdots, \sigma_{n} $ 所对的弦，故有

 $$ \begin{array}{r l}&{\left|\displaystyle\int_{C}f(z)d z-\displaystyle\int_{P}f(z)d z\right|}\\ {=}&{\left|\displaystyle\sum_{j=1}^{n}\int_{\sigma_{j}}^{f(z)}f(z)d z-\displaystyle\sum_{j=1}^{n}\int_{r_{j}}^{f(z)}f(z)d z\right|}\\ {\leqslant}&{\displaystyle\sum_{j=1}^{n}\left|\displaystyle\int_{\sigma_{j}}^{f(z)}f(z)d z-\displaystyle\int_{r_{j}}^{f(z)}f(z)d z\right|.}\end{array} $$ 

因由例 3.1(1)，有

<!-- page: 127 -->

$$ \frac{1}{10} $$ 

即得

 $$ \begin{array}{r l}&{\int\displaylimits_{\sigma_{j}}f(z_{j})\mathrm{d}z=f(z_{j})(z_{j}-z_{j-1})=\int\displaylimits_{r_{j}}f(z_{j})\mathrm{d}z,}\\ &{\quad}\\ &{\left|\int\displaylimits_{\sigma_{j}}f(z)\mathrm{d}z-\int\displaylimits_{r_{j}}f(z)\mathrm{d}z\right|}\\ &{\leqslant\left|\int\displaylimits_{\sigma_{j}}\left[f(z)-f(z_{j})\right]\mathrm{d}z\right|+\left|\int\displaylimits_{r_{j}}\left[f(z)-f(z_{j})\right]\mathrm{d}z\right|}\\ &{\leqslant\underset{z\in\sigma_{j}}{\operatorname*{s u p}}|f(z)-f(z_{j})|(\sigma\mathrm{~之~长~})}\\ &{\quad+\underset{z\in r_{j}}{\operatorname*{s u p}}|f(z)-f(z_{j})|\cdot(r_{j}\mathrm{~之~长~}),}\end{array} $$ 

但是弧  $ \sigma_{j} $ 与弦  $ r_{j} $ 上任意两点的距离小于  $ \delta $，所以

 $$ \operatorname*{s u p}_{z\in\sigma_{j}}\left|f(z)-f(z_{j})\right|<\frac{\epsilon}{2l},\operatorname*{s u p}_{z\in\tau_{j}}\left|f(z)-f(z_{j})\right|<\frac{\epsilon}{2l}, $$ 

从而

 $$ \begin{aligned}&\left|\int_{o_{j}}f(z)dz-\int_{r_{j}}f(z)dz\right|\\ &<\frac{\varepsilon}{2l}\cdot(\sigma_{j} 之长 +r_{j} 之长 )<\frac{\varepsilon}{l}(\sigma_{j} 之长 ),\\ \end{aligned} $$ 

所以

 $$ \left|\int_{C}f(z)\mathrm{d}z-\int_{P}f(z)\mathrm{d}z\right|<\frac{\varepsilon}{l}\cdot l=\varepsilon. $$ 

（2）由第二步结果，对于(1)段中作出的 P，有

 $$ \begin{aligned}\int_{P}f(z)\mathrm{d}z&=0,\\\left|\int_{c}f(z)\mathrm{d}z\right|&<\varepsilon.\end{aligned} $$ 

故(3.9)成为

由于  $ \varepsilon $ 可以任意小，故必  $ \int_{C} f(z) dz = 0 $。至此柯西积分定理已经得到证明。

注 设 E 和 F 是平面上两个点集，下确界  $ \inf\{|z_{1}-z_{2}|\} $  $ |z_{1}\in E,z_{2}\in F\} $ 称为点集 E 和 F 的距离，记为  $ \rho(E,F) $，可以证明，当 E 和 F 是不相交的闭集，E 有界时， $ \rho(E,F)>0 $。

<!-- page: 128 -->

3. 不定积分 柯西积分定理 3.3 已经回答了积分与路径无关的问题. 这就是说, 如果在单连通区域 D 内函数  $ f(z) $ 解析, 则沿 D 内任一曲线 L 的积分  $ \int_{L} f(\zeta) d\zeta $ 只与其起点和终点有关. 因此当起点  $ z_{0} $ 固定时, 这积分就在 D 内定义了一个变上限 z 的单值函数, 我们把它记成变上限积分

$$  \boldsymbol{F}(z)=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta.\left(\begin{aligned}& 定点 z_{0}\in D\\ & 动点 z\in D\end{aligned}\right)   \tag*{(3.10)}$$

定理3.6. 设函数  $ f(z) $ 在单连通区域 D 内解析，则由 (3.10) 定义的函数  $ F(z) $ 在 D 内解析，且  $ F'(z) = f(z) $.

证 我们只要对 D 内任一点 z 证明  $ F'(z) = f(z) $ 就行了. 以 z 为心作一个含于 D 内的小圆，在小圆内取动点  $ z + \Delta z $. 考虑  $ (\Delta z \neq 0) $

 $$ \frac{F(z+\Delta z)-F(z)}{\Delta z}=\frac{1}{\Delta z}\left[\int_{z_{0}}^{z+\Delta z}f(\zeta)\mathrm{d}\zeta-\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta\right] $$ 

在  $ \Delta z \rightarrow 0 $ 时的极限.

由于积分与路径无关， $ \int_{z_{0}}^{z+\Delta z} f(\zeta) \, d\zeta $ 的积分路径，可以考虑为由  $ z_{0} $ 到 z，再从 z 沿直线段到  $ z+\Delta z $。而由  $ z_{0} $ 到 z 的积分路径取得和  $ \int_{z_{0}}^{z} f(\zeta) \, d\zeta $ 的积分路径相同（图 3.9）。于是就有

<div style="text-align: center;"><img src="images/p0128_img_in_image_box_2959_3546_4022_4949.jpg" alt="图3.9" width="23%" /></div>


 $$ \frac{F(z+\Delta z)-F(z)}{\Delta z}=\frac{1}{\Delta z}\int_{z}^{z+\Delta z}f(\zeta)\mathrm{d}\zeta, $$ 

<div style="text-align: center;"><div style="text-align: center;">图3.9</div> </div>


注意到  $ f(z) $ 是与积分变量  $ \zeta $ 无关的定值, 所以由例 3.1(1) 又有

 $$ \frac{1}{\Delta z}\int_{z}^{z+\Delta z}f(z)\mathrm{d}\zeta=f(z), $$ 

由以上两式即得

<!-- page: 129 -->

$$ \frac{F(z+\Delta z)-F(z)}{\Delta z}-f(z)=\frac{1}{\Delta z}\int_{z}^{z+\Delta z}[f(\zeta)-f(z)]\mathrm{d}\zeta. $$ 

根据  $ f(z) $ 在 D 内的连续性，对于任给的  $ \varepsilon > 0 $，只要开始取的那个小圆足够小，则小圆内一切点  $ \zeta $ 均符合条件

 $$ |f(\zeta)-f(z)|<\varepsilon, $$ 

这样一来，由定理 3.2

 $$ \begin{align*}\left|\frac{F(z+\Delta z)-F(z)}{\Delta z}-f(z)\right|&=\left|\frac{1}{\Delta z}\int_{z}^{z+\Delta z}[f(\zeta)-f(z)]\mathrm{d}\zeta\right|\\&\leq\epsilon\frac{|\Delta z|}{|\Delta z|}=\epsilon,\end{align*} $$ 

即是说

 $$ \lim_{\Delta z\to0}\frac{F(z+\Delta z)-F(z)}{\Delta z}=f(z). $$ 

也就是

 $$ F^{\prime}(z)=f(z)\quad(z\in D). $$ 

分析以上的证明，我们实际上已经证明了一个更一般的定理：

定理 3.7 设(1)函数  $ f(z) $ 在单连通区域 D 内连续；

(2)  $ \int f(\zeta) \, \mathrm{d}\zeta $ 沿区域 D 内任一周线的积分值为零（从而，积分与路径无关），则函数

 $$ F(z)=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta\quad(z_{0} 为 D 内一定点 ) $$ 

在 D 内解析，且  $ F'(z) = f(z) $ ( $ z \in D $).

与数学分析相仿，我们有

定义 3.2 在区域 D 内，如果函数  $ f(z) $ 连续，则称符合条件

 $$ \Phi^{\prime}(z)=f(z)\quad(z\in D) $$ 

的函数  $ \Phi(z) $ 为  $ f(z) $ 的一个不定积分或原函数（显然  $ \Phi(z) $ 必在 D 内解析）.

在定理 3.6 或定理 3.7 的条件下，函数(3.10)就是  $ f(z) $ 的一个原函数。下面我们来证明  $ f(z) $ 的任何一个原函数  $ \Phi(z) $ 都呈形式：

<!-- page: 130 -->

$$  \Phi(z)=F(z)+C=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta+C,   \tag*{(3.11)}$$

其中 C 为一常数. 事实上, 我们有

 $$ [\Phi(z)-F(z)]^{\prime}=f(z)-f(z)=0\quad(z\in D), $$ 

由第二章习题(一)6(1)即知

 $$ \Phi\left(z\right)-F\left(z\right)=C, 即 \Phi\left(z\right)=F\left(z\right)+C. $$ 

在公式(3.11)中令  $ z = z_{0} $，得到  $ C = \Phi(z_{0}) $。于是有与数学分析中积分基本定理（牛顿－莱布尼茨公式）类似的如下定理。

定理 3.8 在定理 3.6 或定理 3.7 的条件下，如果  $ \Phi(z) $ 为  $ f(z) $ 在单连通区域 D 内的任意一个原函数，则

$$  \int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta=\Phi(z)-\Phi(z_{0})\quad(z、z_{0}\in D).   \tag*{(3.12)}$$

例3.6 在单连通区域  $ D: -\pi < \arg z < \pi $ 内，函数  $ \ln z $ 是  $ f(z) = \frac{1}{z} $ 的一个原函数，而  $ f(z) = \frac{1}{z} $ 在 D 内解析，故由定理 3.8 有

 $$ \int_{1}^{z}\frac{\mathrm{d}\zeta}{\zeta}=\ln z-\ln1=\ln z\quad(z\notin D). $$ 

下面两段我们介绍柯西积分定理的再推广.

4. 柯西积分定理的推广 首先,我们来证明柯西积分定理

3.3与下面的定理是等价的.

定理3.3' 设 C 是一条周线，D 为 C 之内部，函数  $ f(z) $ 在闭域  $ \overline{D} = D + C $ 上解析，则  $ \int_{C} f(z) dz = 0 $.

证 （1）由定理 3.3 推证定理 3.3'

由定理3.3的假设，函数 $ f(z) $必在z平面上一含D的单连通区域G内解析，于是由定理3.3就有 $ \int_{D}f(z)dz=0 $.

（2）由定理3.3 $ ^{′} $推证定理3.3

由定理 3.3 的假设：“函数  $ f(z) $ 在单连通区域 D 内解析，C

<!-- page: 131 -->

为D内任一条周线”，今设G为C之内部，则 $ f(z) $必在闭域 $ \overline{G}=G+C $上解析.于是由定理3.3'就有

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

下面的定理要比定理3.3'更一般,它是从一个方面推广了的 $ \uwave{\text{柯西积分定理}} $.

定理 3.9 设 C 是一条周线，D 为 C 之内部，函数  $ f(z) $ 在 D 内解析，在  $ \overline{D} = D + C $ 上连续（也可以说“连续到  $ C $”），则

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

因  $ f(z) $ 沿 C 连续，故积分  $ \int_{C} f(z) dz $ 存在。在 C 的内部作周线  $ C_{n} $ 逼近于 C，由定理 3.3 知  $ \int_{C_{n}} f(z) dz = 0 $。我们希望取极限而得出所要的结论。这种想法提供了证明本定理的一个线索，但严格的证明①②都比较麻烦，故这里从略不证。

例 3.7 计算下列积分：

(1)

 $$ \int_{|z|=r}\ln(1+z)\mathrm{d}z\quad(0<r<1) $$ 

(2)

 $$ \int_{c}\frac{1}{z^{2}}\mathrm{d}z, $$ 

其中 C 为右半圆周:  $ \left|z\right|=3 $, Re  $ z\geqslant0 $, 起点为 -3i, 终点为 3i;

(3)  $ \int_{|z-1|=1}\sqrt{z}\,dz $，其中 $ \sqrt{z} $取 $ \sqrt{1}=-1 $那一支.

解 （1）因为  $ \ln(1+z) $ 的支点为 -1,  $ \infty $, 所以它在闭圆

<!-- page: 132 -->

$ |z| \leqslant r (0 < r < 1) $上单值解析. 于是由柯西积分定理 3.9.

 $$ \int_{|z|=r}\ln(1+z)\mathrm{d}z=0. $$ 

（2）因为 $ \frac{1}{z^{2}} $在 $ \mathrm{Re} z \geqslant 0, z \neq 0 $上解析，

故

 $$ \int_{C}\frac{1}{z^{2}}\mathrm{d}z=\frac{1}{-2+1}z^{-2+1}\bigg|_{-3\mathrm{i}}^{3\mathrm{i}}=\frac{2\mathrm{i}}{3}. $$ 

（3）因为 $ \sqrt{z} $的支点为0, $ \infty $，其单值分支在圆 $ \left|z-1\right|<1 $内解析，并连续到边界 $ \left|z-1\right|=1 $，所以由柯西积分定理3.9，

 $$ \int_{|z-1|=1}\sqrt{z}\mathrm{d}z=0. $$ 

### 5. 柯西积分定理推广到复周线的情形

下面我们从另一个方面再推广柯西积分定理，即将柯西积分定理从以一条(单)周线为边界的有界单连通区域，推广到以多条周线组成的“复周线”为边界的有界多连通区域.

定义 3.3 考虑  $ n+1 $ 条周线  $ C_{0}, C_{1}, \cdots, C_{n} $，其中  $ C_{1}, C_{2}, \cdots, C_{n} $ 中每一条都在其余各条的外部，而它们又全都在  $ C_{0} $ 的内部。在  $ C_{0} $ 的内部同时又在  $ C_{1}, C_{2}, \cdots, C_{n} $ 外部的点集构成一个有界的  $ n+1 $ 连通区域 D，以  $ C_{0}, C_{1}, C_{2}, \cdots, C_{n} $ 为它的边界。在这种情况下，我们称区域 D 的边界是一条复周线

 $$ \boldsymbol{C}=\boldsymbol{C}_{0}+\boldsymbol{C}_{1}^{-}+\boldsymbol{C}_{2}^{-}+\cdots+\boldsymbol{C}_{n}^{-}\mathrm{,} $$ 

它包括取正方向的  $ C_{0} $，以及取负方向的  $ C_{1} $， $ C_{2} $， $ \cdots $， $ C_{n} $。换句话说，假如观察者沿复周线 C 的正方向绕行时，区域 D 的点总在它的左手边（图 3.10 是 n=2 的情形）。

定理 3.10 设 D 是由复周线

 $$ \boldsymbol{C}=\boldsymbol{C}_{0}+\boldsymbol{C}_{1}^{-}+\boldsymbol{C}_{2}^{-}+\cdots+\boldsymbol{C}_{n}^{-} $$ 

所围成的有界  $ n+1 $ 连通区域，函数  $ f(z) $ 在 D 内解析，在  $ \overline{D}=D+C $ 上连续，则

 $$ \int_{c}f(z)\mathrm{d}z=0, $$

<!-- page: 133 -->

<div style="text-align: center;"><img src="images/p0133_img_in_image_box_696_600_3751_2090.jpg" alt="图 3.10" width="68%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.10</div> </div>


或写成

$$  \begin{aligned}\int_{C_{0}}f(z)\mathrm{d}z+\int_{C_{1}^{-}}f(z)\mathrm{d}z+&\cdots+\int_{C_{n}^{-}}f(z)\mathrm{d}z\\ =&0,\end{aligned}   \tag*{(3.13)}$$

或写成  $ \int_{C_{0}} f(z)dz=\int_{C_{1}} f(z)dz+\cdots+\int_{C_{n}} f(z)dz. $

（沿外边界积分等于沿内边界积分之和。）

注 定理 3.10 中的复周线换成单周线（一条）就是定理 3.9. 所以定理 3.10 是定理 3.9 的推广.

证 取  $ n+1 $ 条互不相交且全在 D 内（端点除外）的光滑弧  $ L_{0}, L_{1}, L_{2}, \cdots, L_{n} $ 作为割线. 用它们顺次地与  $ C_{0}, C_{1}, C_{2}, \cdots, C_{n} $ 连接. 设想将 D 沿割线割破, 于是 D 就被分成两个单连通区域 (图 3.10 是 n=2 的情形), 其边界各是一条周线, 分别记为  $ \Gamma_{1} $ 和  $ \Gamma_{2} $. 而由定理 3.9, 我们有

 $$ \int_{\Gamma_{1}}f(z)\mathrm{d}z=0,\int_{\Gamma_{2}}f(z)\mathrm{d}z=0, $$ 

将这两个等式相加，并注意到沿着  $ L_{0}, L_{1}, \cdots, L_{n} $ 的积分，各从相反的两个方向取了一次，在相加的过程中互相抵消。于是，由复积分的基本性质(3)就得到

<!-- page: 134 -->

$$ \int_{c}f(z)\mathrm{d}z=0. $$ 

从而有(3.13)和(3.14).

例 3.8 设 a 为周线 C 内部一点，则

 $$ \int_{c}\frac{\mathrm{d}z}{\left(z-a\right)^{n}}=\left\{\begin{aligned}&2\pi\mathrm{i}&\left(n=1\right),\\ &0&\left(n\neq1,\mathrm{ 且 }\right.\end{aligned}\right. $$ 

证 以 a 为圆心画圆周  $ C^{\prime} $，使  $ C^{\prime} $ 全含于 C 的内部，则由 (3.14)

 $$ \int_{C}\frac{\mathrm{d}z}{\left(z-a\right)^{n}}=\int_{C^{\prime}}\frac{\mathrm{d}z}{\left(z-a\right)^{n}}, $$ 

再由例 3.2 即得要证明的结论.

注 例 3.8 是例 3.2 更普遍的形式.

 $ ^{*} $例 3.9 （多连通区域内的不定积分或变上限积分）试证

 $$ \int_{1}^{z}\frac{\mathrm{d}\zeta}{\zeta}=\mathrm{L n}z\quad(z\in G:z\neq0,\infty). $$ 

其中积分路径是不过原点，且连接点  $ z_{0}=1 $ 和点 z 的任意逐段光滑曲线.

证 G 是二连通区域. 考虑这样两条路径的积分值, 其中一条 L 沿正方向或负方向绕原点若干周; 另一条 l 则不绕原点 (不穿过负实轴). 如图 3.11, 由例 3.6 及例 3.8 可得

 $$ \begin{aligned}\int_{L}\frac{d\zeta}{\zeta}&=\int_{ABCbDA}\frac{d\zeta}{\zeta}+\int_{ADaCEA}\frac{d\zeta}{\zeta}+\int_{AEF}\frac{d\zeta}{\zeta}\\&=2\int_{\gamma}\frac{d\zeta}{\zeta}+\int_{l}\frac{d\zeta}{\zeta}.\end{aligned} $$ 

一般，

 $$ \begin{array}{c}\displaystyle\int_{L}\frac{\mathrm{d}\zeta}{\zeta}=\displaystyle\int_{l}\frac{\mathrm{d}\zeta}{\zeta}+n\displaystyle\int_{r}\frac{\mathrm{d}\zeta}{\zeta}\\ \\ =\ln z+2n\pi i\\ \\ (n=0,\pm1,\cdots)\\ \\ =\mathrm{Ln}\ z.\end{array} $$ 

<div style="text-align: center;"><img src="images/p0134_img_in_image_box_2776_4735_4018_5894.jpg" alt="图3.11" width="27%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.11</div> </div>

<!-- page: 135 -->

因此，所给变上限 z 的函数

 $$ \dot{F}(z)=\int_{1}^{z}\frac{\mathrm{d}\zeta}{\zeta} $$ 

是对数函数  $ \mathrm{Ln}z $ 的一个积分表达式，在原点处的支点是被积函数惟一的奇点.

注 多连通区域 G 内的变上限积分一般表示多值解析函数，比如上面例 3:9，但也有表示单值解析函数的。比如，我们来考查变上限积分

$$  \int_{1}^{z}\frac{1}{\zeta^{2}}\mathrm{d}\zeta,   \tag*{  (*) }$$

这里  $ z \in G $:  $ z \neq 0, \infty, G $ 是二连通区域，积分路径 L 是不过原点，且联结点  $ z_{0} = 1 $ 和点 z 的任意逐段光滑曲线.

1) 当 L 不围绕原点 z = 0，被积函数  $ \frac{1}{z^{2}} $ 在包含 L 但不包含 z = 0 的一个单连通子区域 D 内单值解析，从而由定理 3.8

 $$ \int_{1}^{z}\frac{1}{\zeta^{2}}\mathrm{d}\zeta=-\left.\frac{1}{\zeta}\right|_{1}^{z}=-\frac{1}{z}+1\quad(z\in D). $$ 

2) 设  $ \gamma $ 是在 G 内的一条周线，原点在  $ \gamma $ 的内部，则当 z 沿  $ \gamma $ 的正向绕行一周时，积分 ( $ * $) 有增量

 $$ \int_{y}\frac{1}{\zeta^{2}}\mathrm{d}\zeta=0\quad( 例 3.8). $$ 

3）由1)和2)的结果，并参看图3.11，可见

 $$ \int_{1}^{z}\frac{1}{\zeta^{2}}\mathrm{d}\zeta=-\frac{1}{z}+1\quad(z\in G), $$ 

这就是 z 的单值解析函数.

#### §3. 柯西积分公式及其推论

1. 柯西积分公式 我们利用柯西积分定理(复周线形式)导出一个用边界值表示解析函数内部值的积分公式.

<!-- page: 136 -->

定理 3.11 设区域 D 的边界是周线 (或复周线) C，函数  $ f(z) $ 在 D 内解析，在  $ \overline{D} = D + C $ 上连续，则有

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\quad(z\in D).   \tag*{(3.15)}$$

这就是柯西积分公式. 它是解析函数的积分表达式, 因而是今后我们研究解析函数各种局部性质的重要工具.

证 任意固定  $ z \in D $,  $ F(\zeta) = \frac{f(\zeta)}{\zeta - z} $ 作为  $ \zeta $ 的函数在 D 内除点  $ z $ 外均解析. 今以点 z 为心, 充分小的  $ \rho > 0 $ 为半径作圆周  $ \gamma_{\rho} $, 使  $ \gamma_{\rho} $ 及其内部均含于 D (图 3.12). 对于复周线  $ \Gamma = C + \gamma_{\rho}^{-} $及函数  $ F(\zeta) $, 应用定理 3.10 的 (3.13) 式, 得

<div style="text-align: center;"><img src="images/p0136_img_in_image_box_2656_1281_4031_2932.jpg" alt="图 3.12" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.12</div> </div>


 $$ \int_{C}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=\int_{\gamma_{0}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta. $$ 

（这一步的重要性，在于将复杂路径 C 代以简单路径  $ \gamma_{\rho} $）上式表示右端与  $ \gamma_{\rho} $ 的半径  $ \rho $ 无关，因此我们只须证明

$$  \lim_{\rho\to0}\int_{\gamma}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=2\pi\mathrm{i}f(z),   \tag*{(3.16)}$$

则柯西积分公式(3.15)就算证明了.

注意到  $ f(z) $ 与积分变量  $ \zeta $ 无关，而  $ 2\pi i = \int_{\gamma} \frac{d\zeta}{\zeta - z} $（见例 3.2），于是有

$$  \begin{align*}\left|\int_{\gamma_{\rho}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta-2\pi\mathrm{i}f(z)_{z}\right|&=\left|\int_{\gamma_{\rho}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta-f(z)\int_{\gamma_{\rho}}\frac{\mathrm{d}\zeta}{\zeta-z}\right|\\&=\left|\int_{\gamma_{\rho}}\frac{f(\zeta)-f(z)}{\zeta-z}\mathrm{d}\zeta\right|.\tag{3.}\end{align*}   \tag*{(3.17)}$$

根据  $ f(\zeta) $ 的连续性，对任给的  $ \varepsilon > 0 $，存在  $ \delta > 0 $，只要  $ \left|\zeta - z\right| $

<!-- page: 137 -->

$ \rho<\delta $，就有

 $$ \mid f(\zeta)-f(z)\mid<\frac{\varepsilon}{2\pi}\quad(\zeta\in\gamma_{\rho}), $$ 

由定理 3.2 知 (3.17) 不超过  $ \frac{\varepsilon}{2\pi\rho} \cdot 2\pi\rho = \varepsilon $，于是证明了 (3.16). 定理得证.

定义 3.4 在定理 3.11 的条件下，

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta,(z\notin\mathbb{C}) $$ 

称为柯西积分.

思考题 在定理 3.11 的条件下，如果  $ z \notin \overline{D} $，则柯西积分  $ \frac{1}{2\pi i} \int_{c} \frac{f(\zeta)}{\zeta - z} \, \mathrm{d}\zeta $ 之值如何？

柯西积分公式(3.15)可以改写成

$$  \int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=2\pi\mathrm{i}f(z)\quad(z\in D),   \tag*{(3.15)'}$$

借此公式可以计算某些周线积分（指路径是周线的积分）.

例 3.10 设 C 为圆周  $ \left|\zeta\right|=2 $，则按(3.15).

 $$ \begin{array}{r}{\int_{c}\frac{\zeta}{(9-\zeta^{2})(\zeta+i)}\mathrm{d}\zeta=\displaystyle\int_{c}\frac{\frac{\zeta}{9-\zeta^{2}}}{\zeta-(-i)}\mathrm{d}\zeta}\\ {=2\pi i\cdot\frac{\zeta}{9-\zeta^{2}}\bigg|_{\zeta=-i}=\frac{\pi}{5}.}\end{array} $$ 

注意到  $ f(\zeta)=\frac{\zeta}{9-\zeta^{2}} $ 在闭圆  $ |\zeta|\leq2 $ 上解析，定理 3.11 的条件满足，故公式 (3.15) 它可以应用，因而上面的计算是正确的.

注 在(3.15)及(3.15) $ ^{\prime} $中， $ \zeta = z $ 是被积函数

 $$ F(\zeta)=\frac{f(\zeta)}{\zeta-z} $$ 

在 C 内部的惟一奇点，如果给定的积分被积函数  $ F(\zeta) $ 在 C 内部有两个以上奇点，就不能直接应用柯西积分公式

<!-- page: 138 -->

定理 3.11 的特殊情形,有如下的解析函数平均值定理. 在下一章,我们将应用它来证明解析函数的最大模原理.

定理 3.12 如果函数  $ f(z) $ 在圆  $ \left|\zeta - z_{0}\right| < R $ 内解析，在闭圆  $ \left|\zeta - z_{0}\right| \leq R $ 上连续，则

 $$ f(z_{0})=\frac{1}{2\pi}\int_{0}^{2\pi}f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi, $$ 

即  $ f(z) $ 在圆心  $ z_{0} $ 的值等于它在圆周上的值的算术平均数.

证 设 C 表圆周  $ \left|\zeta - z_{0}\right| = R $ (如图 3.13), 则

 $$ \zeta-z_{0}=R\mathrm{e}^{\mathrm{i}\varphi},\quad0\leqslant\varphi\leqslant2\pi, $$ 

<div style="text-align: center;"><img src="images/p0138_img_in_image_box_2646_1741_4018_2926.jpg" alt="图 3.13" width="30%" /></div>


或

 $$ \zeta=z_{0}+R\mathrm{e}^{\mathrm{i}\varphi}, $$ 

由此

<div style="text-align: center;"><div style="text-align: center;">图 3.13</div> </div>


 $$ \mathrm{d}\boldsymbol{\zeta}=\mathrm{i}R\mathrm{e}^{\mathrm{i}\varphi}\mathrm{d}\varphi, $$ 

根据柯西积分公式(3.15)

 $$ \begin{align*}f(z_{0})&=\frac{1}{2\pi i}\int_{c}\frac{f(\zeta)}{\zeta-z_{0}}\mathrm{d}\zeta\\&=\frac{1}{2\pi i}\int_{0}^{2\pi}\frac{f(z_{0}+Re^{i\varphi})\mathrm{i}Re^{i\varphi}\mathrm{d}\varphi}{Re^{i\varphi}}\\&=\frac{1}{2\pi}\int_{0}^{2\pi}f(z_{0}+Re^{i\varphi})\mathrm{d}\varphi.\end{align*} $$ 

例 3.11 设函数  $ f(z) $ 在闭圆  $ \left|z\right| \leqslant R $ 上解析. 如果存在 a > 0, 使当  $ \left|z\right| = R $ 时

 $$ \begin{aligned}&|f(z)|>a,\\&|f(0)|<a,\end{aligned} $$ 

而且

试证：在圆  $ \left|z\right|<R $ 内  $ f(z) $ 至少有一个零点.

证 反证法，设  $ f(z) $ 在  $ |z|<R $ 内无零点，而由题设  $ f(z) $ 在  $ |z|=R $ 上也无零点。于是

 $$ F(z)=\frac{1}{f(z)} $$

<!-- page: 139 -->

在闭圆  $ \left|z\right| \leqslant R $ 上解析. 由解析函数的平均值定理,

 $$ \begin{array}{r}{F(0)=\frac{1}{2\pi}\int_{0}^{2\pi}F(R\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi,}\end{array} $$ 

又由题设

 $$ \left|F(0)\right|=\frac{1}{\left|f(0)\right|}>\frac{1}{a}, $$ 

 $$ |F(R\mathrm{e}^{\mathrm{i}\varphi})|=\frac{1}{|f(R\mathrm{e}^{\mathrm{i}\varphi})|}<\frac{1}{a}, $$ 

从而

 $$ \begin{aligned}\frac{1}{a}<|F(0)|_{.}=&\left|\frac{1}{2\pi}\int_{0}^{2\pi}F(R\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi\right|\leqslant\frac{1}{a}\cdot\frac{1}{2\pi}\cdot2\pi\\ =&\frac{1}{a}.\end{aligned} $$ 

矛盾. 故在圆  $ \left|z\right|<R $ 内  $ f(z) $ 至少有一个零点.

2. 解析函数无穷可微性 我们将柯西积分公式(3.15)形式地在积分号下对 z 求导后得

$$  f^{\prime}(z)=\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta\quad(z\in D),   \tag*{(3.18)}$$

这样继续一次又可得

 $$ f^{\prime\prime}(z)=\frac{2!}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{(\zeta-z)^{3}}\mathrm{d}\zeta\quad(z\in D), $$ 

我们将对这些公式的正确性加以证明.

定理 3.13 在定理 3.11 的条件下，函数  $ f(z) $ 在区域 D 内有各阶导数，并且有

$$  \begin{align*}f^{(n)}(z)=\frac{n!}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{(\zeta-z)^{n+1}}\mathrm{d}\zeta\quad(z\in D).\ $ n=1,2,\cdots)\tag{1}\end{align*}   \tag*{(3.19)}$$

这是一个用解析函数  $ f(z) $ 的边界值表示其各阶导函数内部值的积分公式.

证 首先对 n=1 的情形来证明，即要证公式(3.18)成立.按照(3.15)，有 $ (\Delta z \neq 0) $

 $$ \frac{f(z+\Delta z)\div f(z)}{\Delta z}=\frac{1}{\Delta z}\left[\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{\zeta-z-\Delta z}\mathrm{d}\zeta-\right. $$

<!-- page: 140 -->

$$ \begin{array}{l}\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\\ =-\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)}\mathrm{d}\zeta.\end{array} $$ 

我们要证明下面的差数

$$  \begin{align*}\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)\mathrm{d}\zeta}{(\zeta-z-\Delta z)(\zeta-z)}-\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)\mathrm{d}\zeta}{(\zeta-z)^{2}}\\=\left|\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{\Delta z f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)^{2}}\mathrm{d}\zeta\right|\end{align*}   \tag*{(3.20)}$$

在  $ \left|\Delta z\right| $ 充分小时不超过任给的正数  $ \varepsilon $.

设沿周线  $ C, |f(\zeta)| \leq M $。设 d 表示 z 与 C 上点  $ \zeta $ 间的最短距离。于是，当  $ \zeta \in C $ 时， $ |\zeta - z| \geq d > 0 $（参看定理 3.3 注）。

先设  $ \left|\Delta z\right| < \frac{d}{2} $，于是（图 3.14） $ \left|\zeta - z - \Delta z\right| \geqslant \left|\zeta - z\right| - \left|\Delta z\right| > \frac{d}{2} $，这样一来，差数 (3.20) 不超过

 $$ \frac{|\Delta z|}{2\pi}\cdot\frac{M l}{\frac{d}{2}\cdot d^{2}}, $$ 

其中 l 为 C 之长度. 为使上式不超过任给正数  $ \varepsilon $, 只要取

 $$ |\Delta z|<\delta=\min\left(\frac{d}{2},\frac{\pi d^{3}\varepsilon}{M l}\right). $$ 

<div style="text-align: center;"><img src="images/p0140_img_in_image_box_2724_3158_4033_4622.jpg" alt="图 3.14" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.14</div> </div>


于是(3.18)就证明了.

要完成定理的证明，只要应用数学

归纳法.设  $ n=k $ 时公式(3.19)成立;证明  $ n \neq k+1 $ 时,(3.19)也成立.这就是要证明下面这个式子

 $$ \begin{align*}\frac{f^{(k)}\left(z+\Delta z\right)-f^{(k)}\left(z\right)}{\Delta z}&=\frac{1}{\Delta z}\left[\frac{k!}{2\pi i}\int_{c}\frac{f(\zeta)d\zeta}{(\zeta-z-\Delta z)^{k+1}}\right.\\&\quad\left.-\frac{k!}{2\pi i}\int_{c}\frac{f(\zeta)d\zeta}{(\zeta-z)^{k+1}}\right].\end{align*} $$

<!-- page: 141 -->

在  $ \Delta z \rightarrow 0 $ 时，以

 $$ \frac{(k+1)!}{2\pi i}\int_{c}\frac{f(\zeta)}{(\zeta-z)^{k+2}}\mathrm{d}\zeta $$ 

为极限.方法和证明 n=1 的情形类似,不过稍微复杂些,就不重复了.

公式(3.19)可改写成

$$  \int_{c}\frac{f(\zeta)}{(\zeta-z)^{n+1}}\mathrm{d}\zeta=\frac{2\pi\mathrm{i}}{n!}f^{(n)}(z)\quad(z\in D,n=1,2,\cdots).   \tag*{(3.19)'}$$

注 （1）应用(3.19)可以计算一些周线积分；

(2) 在(3.19)及(3.19)′中， $ \zeta = z $ 是被积函数  $ F(\zeta) $ 在 C 内部的惟一奇点，如果  $ F(\zeta) $ 在 C 内部有两个以上的奇点，就不能直接应用它们.

例 3.12 计算积分

 $$ \int_{c}\frac{\cos z}{(z-\mathrm{i})^{3}}\mathrm{d}z, $$ 

其中 C 是绕 i 一周的周线.

解 因为  $ \cos z $ 在 z 平面上解析，应用公式 (3.19) 于  $ f(z) = \cos z $，我们得

 $$ \int_{c}\frac{\cos z}{(z-i)^{3}}\mathrm{d}z=\frac{2\pi i}{2!}(\cos z)^{\prime \prime}\bigg|_{z=i}=-\pi\mathrm{i}\cos i=-\pi\frac{\mathrm{e}^{-1}+\mathrm{e}}{2}\mathrm{i}. $$ 

应用上述定理，我们得出解析函数的无穷可微性：

定理 3.14 设函数  $ f(z) $ 在 z 平面上的区域 D 内解析，则  $ f(z) $ 在 D 内具有各阶导数，并且它们也在 D 内解析.

证 设  $ z_{0} $ 为 D 内任一点，将定理 3.13 应用于以  $ z_{0} $ 为心的充分小的圆（只要这个闭圆全含于 D 内），即知  $ f(z) $ 在此圆内有各阶导数。特别说来， $ f(z) $ 在点  $ z_{0} $ 有各阶导数。由于  $ z_{0} $ 的任意性，所以  $ f(z) $ 在 D 内有各阶导数。

这样，由函数在区域 D 内解析（注意：仅只假设其导数在 D

<!-- page: 142 -->

内存在!), 就推出了其各阶导数在 D 内存在且连续. 而数学分析中区间上的可微函数, 在此区间上不一定有二阶导数, 更谈不上有高阶导数了.

借助解析函数的无穷可微性,我们现在来把判断函数  $ f(z) $ 在区域 D 内解析的一个充分条件——定理 2.5,补充证明成刻画解析函数的第二个等价定理:

定理 3.15 函数  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 在区域 D 内解析的充要条件是

（1） $ u_{x}, u_{y}, v_{x}^{'} $,  $ v_{y} $ 在 D 内连续；

(2)  $ u(x,y) $,  $ v(x,y) $ 在 D 内满足 C. -R. 方程.

##### 证 充分性 即定理 2.5.

必要性 条件(2)的必要性已由定理2.1得出. 现在, 由于解析函数  $ f(z) $ 的无穷可微性,  $ f'(z) $ 必在 D 内连续, 因而  $ u_{x}, u_{y}, v_{x}, v_{y} $ 必在 D 内连续.

3. 柯西不等式与刘维尔(Liouville)定理 利用定理 3.13 可以得出一个很有用的导数的估计式：

柯西不等式 设函数  $ f(z) $ 在区域 D 内解析, a 为 D 内一点, 以 a 为心作圆周  $ \gamma: |\zeta - a| = R $, 只要  $ \gamma $ 及其内部 K 均含于 D, 则有

 $$ \mid f^{(n)}(a)\mid\leqslant\frac{n!}{R^{n}}M(R), $$ 

其中  $ M(R) = \max_{|z - a| = R} |f(z)| $, n = 1, 2,  $ \cdots $.

证 应用定理 3.13 于  $ \overline{K} $ 上，则有

 $$ \begin{aligned}\left|f^{(n)}(a)\right|&=\left|\frac{n!}{2\pi\mathrm{i}}\int_{\gamma}\frac{f(\zeta)}{\left(\zeta-a\right)^{n+1}}\mathrm{d}\zeta\right|\leqslant\frac{n!}{2\pi}\cdot\frac{M(R)}{R^{n+1}}\cdot2\pi R\\&=\frac{n!}{R^{n}}\frac{M(R)}{}\end{aligned} $$ 

注 柯西不等式是对解析函数各阶导数模的估计式，说明解析函数在解析点 a 的各阶导数的估计与它的解析区域的大小密

<!-- page: 143 -->

切相关.

在整个复平面上解析的函数称为整函数.例如多项式, $ e^{z} $,  $ \cos z $及 $ \sin z $都是整函数.常数当然也是整函数.应用柯西不等式,可得一个关于整函数的定理:

刘维尔定理 有界整函数  $ f(z) $ 必为常数.

证 设  $ \left|f(z)\right| $ 的上界为 M，则在柯西不等式中，对无论什么样的 R，均有  $ M(R) \leq M $。于是命 n = 1 有

 $$ |f^{\prime}(a)|\leqslant\frac{M}{R}, $$ 

上式对一切 R 均成立，让  $ R \to +\infty $，即知  $ f'(a) = 0 $。而 a 是 z 平面上任一点，故  $ f(z) $ 在 z 平面上的导数为零。由第二章习题（一）6(1)知  $ f(z) $ 必为常数。

注 这是一个非局部性命题，也是模有界定理，其逆也真，即：常数是有界整函数；此定理的逆否定理为：非常数的整函数必无界；关于刘维尔定理，我们以后还要论及。

应用刘维尔定理可以很简洁地证明：

代数学基本定理 在 z 平面上，n 次多项式

 $$ p(z)=a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n}\quad(a_{0}\neq0) $$ 

至少有一个零点.

证 反证法，设  $ p(z) $ 在 z 平面上无零点。由于  $ p(z) $ 在 z 平面上是解析的， $ \frac{1}{p(z)} $ 在 z 平面上也必解析。

下面我们证明 $ \frac{1}{p(z)} $在z平面上有界.由于

 $$ \begin{aligned}&\lim_{z\to\infty}p\left(z\right)=\lim_{z\to\infty}z^{n}\left(a_{0}+\frac{a_{1}}{z}+\cdots+\frac{a_{n}}{z^{n}}\right)=\infty,\\&\lim_{z\to\infty}\frac{1}{p\left(z\right)}=0,\end{aligned} $$ 

故存在充分大的正数 R，使当  $ \left|z\right|>R $ 时， $ \left|\frac{1}{p(z)}\right|<1 $.

<!-- page: 144 -->

又因 $ \frac{1}{p(z)} $在闭圆 $ \left|z\right|\leq R $上连续，故可设

 $$ \left|\frac{1}{p(z)}\right|\leqslant M( 正常数 ), $$ 

从而，在 z 平面上

 $$ \left|\frac{1}{p(z)}\right|<M+1, $$ 

于是， $ \frac{1}{p(z)} $ 在 z 平面上是解析且有界的. 由刘维尔定理， $ \frac{1}{p(z)} $ 必为常数，即  $ p(z) $ 必为常数. 这与定理的假设矛盾. 故定理得证.

注 代数学基本定理,用纯粹代数的方法是不容易证明的,这是因为数学知识还不够的缘故,由此可见,数学知识积累在解决问题中的重要性.

4. 摩勒拉(Morera)定理 我们现在来证明柯西积分定理(定理3.3)的逆定理,称为摩勒拉定理.

定理 3.16 若函数  $ f(z) $ 在单连通区域 D 内连续，且对 D 内的任一周线 C，有

 $$ \int_{c}f(z)\mathrm{d}z=0, $$ 

则  $ f(z) $ 在 D 内解析.

证 在假设条件下，根据定理 3.7 即知

 $$ F(z)=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta\quad(z_{0}\in D) $$ 

在 D 内解析，且  $ F'(z) = f(z) $ ( $ z \in D $). 但解析函数  $ F(z) $ 的导函数  $ F'(z) $ 还是解析的。即是说  $ f(z) $ 在 D 内解析。

下面我们着重指出刻画解析函数的第三个等价定理.

定理 3.17 函数  $ f(z) $ 在区域 G 内解析的充要条件是：

（1） $ f(z) $在G内连续；

（2）对任一周线 C，只要 C 及其内部全含于 G 内，就有

 $$ \int_{c}f(z)\mathrm{d}z=0. $$

<!-- page: 145 -->

证 必要性可由柯西积分定理 3.3 导出.至于充分性,我们在 G 内任一点  $ z_{0} $ 的一个邻域 K:  $ |\zeta - z_{0}| < \rho $ 内来应用定理 3.16,只要  $ \rho $ 充分小,就知道  $ f(z) $ 在圆 K 内解析.特别说来,在  $ z_{0} $ 解析,因为  $ z_{0} $ 可在 G 内任意取,故  $ f(z) $ 在 G 内解析.

例 3.13 如果函数  $ f(z) $ 为一整函数，且有使

 $$ \mathrm{Re}f(z)<M $$ 

的实数 M 存在，试证  $ f(z) $ 为常数.

证 令  $ F(z) = \mathrm{e}^{f(z)} $，则  $ F(z) $ 为整函数。又在 z 平面上

 $$ \mid F(z)\mid=\mathrm{e}^{\mathrm{R e}f(z)}<\mathrm{e}^{M}, $$ 

故有界，由刘维尔定理可见  $ F(z) $ 是常数。因此  $ f(z) $ 也是常数。

例 3.14 设  $ f(z) $ 是整函数, n 为正整数, 试证当

 $$ \lim_{z\to\infty}\frac{f(z)}{z^{n}}=0 $$ 

时， $ f(z) $至多是 n-1 次多项式.

证 由第二章习题(一)6(1)及定理3.8,只须证得对任何的  $ z, f^{(n)}(z)=0 $.

由

 $$ \lim_{z\to\infty}\frac{f(z)}{z^{n}}=0 $$ 

可知，对任给的  $ \varepsilon > 0 $，存在 R > 0，只要  $ \left| z \right| > R $ 时就有

 $$ |f(z)|<\varepsilon|z|^{n}. $$ 

在 z 平面上任取一点 z. 再取以 z 为心, 以 r 为半径的圆周 C, 使圆周  $ C_{1} = \{z \mid |z| = R\} $ 全含于其内部. 于是有  $ r > |z| $. 这时对于  $ \zeta \in C $, 必  $ |\zeta| > R $, 因而

 $$ |f(\zeta)|<\varepsilon|\zeta|^{n}\leqslant\varepsilon(|z|+r)^{n}. $$ 

由柯西不等式可得

 $$ \begin{align*}|f^{(n)}(z)|&\leqslant\frac{n!}{r^n}\varepsilon(|z|+r)^n\\&=n!\varepsilon\left(1+\frac{|z|}{r}\right)^n\leqslant n!2^n\varepsilon.\end{align*} $$

<!-- page: 146 -->

因为  $ \varepsilon>0 $ 是任意的，所以

 $$ f^{\left(n\right)}\left(z\right)=0. $$ 

故  $ f(z) $ 至多是 n-1 次多项式.

#####  $ ^{*} $5. 柯西型积分

定义 3.4 设 C 为任一条简单逐段光滑曲线（不必闭合）， $ f(\zeta) $ 是在 C 上有定义的可积函数，则具有如下形式的积分：

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\quad(z\notin C) $$ 

称为柯西型积分.

显然柯西积分为柯西型积分的特例，但柯西型积分就不一定为柯西积分.

例如（1）

 $$ \frac{1}{2\pi i}\int_{|\zeta|=1}\frac{\overline{\zeta}}{\zeta-z}\mathrm{d}\zeta,(\mid z\mid\neq1); $$ 

(2)

 $$ \frac{1}{2\pi i}\int_{|\zeta|=1}\frac{\frac{1}{\zeta}}{\zeta-z}\mathrm{d}\zeta,(\mid z\mid\neq1); $$ 

(3)

 $$ \frac{1}{2\pi\mathrm{i}}\int_{-1}^{+1}\frac{\mathrm{d}x}{x-z},(z\in[-1,1]). $$ 

（显然(1)可变形为(2);(2)、(3)的计算留给读者).这三个积分都是柯西型积分而非柯西积分.

类似定理 3.13 的证明,我们可以得到类似定理 3.13 的结果.

定理 3.13' 若函数  $ f(\zeta) $ 沿简单逐段光滑曲线 C（不必闭合）连续，则由柯西型积分

 $$ F(z)=\frac{1}{2\pi i}\int_{c}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta,(z\notin C) $$ 

所定义的函数  $ F(z) $，在 z 平面上 C 外任一区域 D 内解析，且

 $$ \begin{align*}F^{(n)}(z)&=\frac{n!}{2\pi\mathrm{i}}\int_{c}\frac{f(\zeta)}{(\zeta-\overrightarrow{z})^{n+1}}\mathrm{d}\zeta,\ $ z&\in D,n=1,2,\cdots).\end{align*} $$ 

证明留给读者.

<!-- page: 147 -->

#### §4. 解析函数与调和函数的关系

在前一节,我们已经证明了,在区域内解析的函数具有任何阶的导数.因此,在区域内它的实部u与虚部v都有二阶连续导数.现在我们来研究应该如何选择u与v才能使函数 $ u+iv $在区域内解析.

设  $ f(z)=u+i v $ 在区域 D 内解析，则由 C.-R. 方程

 $$ \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\quad\frac{\partial u}{\partial y}=-\frac{\partial v}{\partial x}, $$ 

得

 $$ \frac{\partial^{2}u}{\partial x^{2}}=\frac{\partial^{2}v}{\partial x\partial y},\quad\frac{\partial^{2}u}{\partial y^{2}}=-\frac{\partial^{2}v}{\partial y\partial x}, $$ 

因 $ \frac{\partial^{2}v}{\partial x\partial y} $与 $ \frac{\partial^{2}v}{\partial y\partial x} $在D内连续，它们必定相等，故在D内有

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0, $$ 

同理，在 D 内有

 $$ \frac{\partial^{2}v}{\partial x^{2}}+\frac{\partial^{2}v}{\partial y^{2}}=0, $$ 

即 u 及 v 在 D 内满足拉普拉斯 (Laplace) 方程：

 $$ \Delta u=0,\quad\Delta v=0. $$ 

这里  $ \Delta\equiv\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}} $ 是一种运算记号，称为拉普拉斯算子.

定义 3.5 如果二元实函数  $ H(x, y) $ 在区域 D 内有二阶连续偏导数，且满足拉普拉斯方程  $ \Delta H = 0 $，则称  $ H(x, y) $ 为区域 D 内的调和函数.

调和函数常出现在诸如流体力学、电学、磁学等实际问题中.

定义 3.6 在区域 D 内满足 C. -R. 方程

 $$ \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\quad\frac{\partial u}{\partial y}=-\frac{\partial v}{\partial x} $$ 

的两个调和函数 u, v 中, v 称为 u 在区域 D 内的共轭调和函数.

<!-- page: 148 -->

由上面的讨论，我们已经证明了：

定理 3.18 若  $ f(z) = u(x, y) + \mathrm{i}v(x, y) $ 在区域 D 内解析，则在区域 D 内  $ v(x, y) $ 必为  $ u(x, y) $ 的共轭调和函数.

现在接着上面的讨论.反过来,如果 u,v 是任意选取的在区域 D 内的两个调和函数,则  $ u+iv $ 在 D 内就不一定解析.

要想  $ u + iv $ 在区域 D 内解析, u 及 v 还必须满足 C. -R. 方程. 即 v 必须是 u 的共轭调和函数. 由此, 如已知一个解析函数的实部  $ u(x, y) $ (或虚部  $ v(x, y) $) 就可以求出它的虚部  $ v(x, y) $ (或实部  $ u(x, y) $).

假设 D 是一个单连通区域,  $ u(x, y) $ 是区域 D 内的调和函数, 则  $ u(x, y) $ 在 D 内有二阶连续偏导数, 且

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0. $$ 

即  $ -\frac{\partial u}{\partial y}, \frac{\partial u}{\partial x} $ 在 D 内具有一阶连续偏导数，且

 $$ \frac{\partial}{\partial y}\left(-\frac{\partial u}{\partial y}\right)=\frac{\partial}{\partial x}\left(\frac{\partial u}{\partial x}\right). $$ 

由数学分析的定理, 知道  $ -\frac{\partial u}{\partial y}dx + \frac{\partial u}{\partial x}dy $ 是全微分,

命

$$  -\frac{\partial u}{\partial y}\mathrm{d}x+\frac{\partial u}{\partial x}\mathrm{d}y=\mathrm{d}v\left(x,y\right),   \tag*{(3.21)}$$

则

$$  v(x,y)=\int_{(x_{0},y_{0})}^{(x,y)}-\frac{\partial u}{\partial y}\mathrm{d}x+\frac{\partial u}{\partial x}\mathrm{d}y+C,   \tag*{(3.22)}$$

其中 $ (x_{0},y_{0}) $是D内的定点， $ (x,y) $是D内的动点，C是一个任意常数，积分与路径无关.

将(3.22)式分别对 x, y 求偏导数，得

 $$ \frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y},\quad\frac{\partial v}{\partial y}=\frac{\partial u}{\partial x}, $$ 

这就是 C. -R. 方程. 由定理 3.15 知  $ u + i v $ 在 D 内解析. 故得

定理 3.19 设  $ u(x, y) $ 是在单连通区域 D 内的调和函数，则

<!-- page: 149 -->

存在由(3.22)式所确定的函数  $ v(x,y) $，使  $ u + iv = f(z) $ 是 D 内的解析函数.

注（1）如单连通区域 D 包含原点，则（3.22）式中的  $ (x_{0}, y_{0}) $ 显然可取成原点  $ (0,0) $；如 D 非单连通区域，则积分 (3.22) 可能规定一个多值函数.

（2）公式(3.22)不必强记，可以先如下去推(3.21):由

 $$ \mathrm{d}v(x,y)=v_{x}\mathrm{d}x+v_{y}\mathrm{d}y\xlongequal{C.-R.-}u_{y}\mathrm{d}x+u_{x}\mathrm{d}y, $$ 

然后两端积分之.

（3）类似地，

 $$ \mathrm{d}u\left(x,y\right)=u_{x}\mathrm{d}x+u_{y}\mathrm{d}y\xlongequal{C.-R.}v_{y}\mathrm{d}x-v_{x}\mathrm{d}y, $$ 

然后两端积分，有

$$  u\left(x,y\right)=\int_{\left(x_{0},y_{0}\right)}^{(x,y)}v_{y}\mathrm{d}x-v_{x}\mathrm{d}y+C.   \tag*{(3.22)  ^{\prime} }$$

思考题（1）“v 是 u 的共轭调和函数”，其中 u, v 是否可以交换顺序？

(2) 如果 v 是 u 的共轭调和函数, 那么 v 的共轭调和函数是什么?

注 （1）刻画解析函数的又一等价定理.

 $$ f(z)=u(x,y)+iv(x,y) 在区域 D 内解析 $$ 

定理3.18

 $ \Longleftrightarrow $ 在区域 D 内  $ v(x,y) $ 是  $ u(x,y) $ 的共轭调和函数.

定理3.19

(2) 由于任一个二元调和函数都可作为一个解析函数  $ f(z) $ 的实部  $ u(x, y) $ (或虚部  $ v(x, y) $), 而虚部  $ v(x, y) $ (或实部  $ u(x, y) $) 可由 C. - R. 方程确定. 于是由于解析函数  $ f(z) = u + iv $ 的任意阶导数仍然是解析的, 可知, 任一个二元调和函数的任意阶偏导数也是调和函数.

例 3.15 验证  $ u(x, y) = x^{3} - 3xy^{2} $ 是 z 平面上的调和函数，并求以  $ u(x, y) $ 为实部的解析函数  $ f(z) $，使合  $ f(0) = i $.

<!-- page: 150 -->

解 因在 z 平面上任一点

 $$ u_{x}=3x^{2}-3y^{2},u_{y}=-6x y, $$ 

 $$ u_{xx}=6x,u_{yy}=-6x. $$ 

故  $ u(x,y) $ 在 z 平面上为调和函数.

解法一

 $$ \begin{aligned}&\text{(d)}v=v_{x}\mathrm{d}x+v_{y}\mathrm{d}y\xlongequal{C.-R.-}u_{y}\mathrm{d}x+u_{x}\mathrm{d}y)\\&\xrightarrow{}\boldsymbol{v}(x,y)\frac{(3.22)}{ 记 }=\int_{(0,0)}^{(x,0)}6xy\mathrm{d}x+(3x^{2}-3y^{2})\mathrm{d}y\\&\quad+\int_{(x,0)}^{(x,y)}6xy\mathrm{d}x+(3x^{2}-3y^{2})\mathrm{d}y+C\\&\quad=\int_{0}^{y}(3x^{2}-3y^{2})\mathrm{d}y+C\\&\quad=3x^{2}y-y^{3}+C,\end{aligned} $$ 

故

 $$ \begin{aligned}f(z)&=u+\mathrm{i}v=x^{3}-3xy^{2}+\mathrm{i}(3x^{2}y-y^{3}+C)\\&=(x+\mathrm{i}y)^{3}+\mathrm{i}C=z^{3}+\mathrm{i}C.\end{aligned} $$ 

要合  $ f(0)=\mathrm{i} $，必 C=1，故  $ f(z)=z^{3}+\mathrm{i} $.

解法二 先由 C.-R. 方程中的一个得

 $$ v_{y}=u_{x}=3x^{2}-3y^{2}, $$ 

 $$ \left(\mathrm{d}v=v_{x}\mathrm{d}x+v_{y}\mathrm{d}y\xlongequal{C.-R.-}u_{y}\mathrm{d}x+u_{x}\mathrm{d}y\right) $$ 

 $$ \Rightarrow v=\int u_{x}\mathrm{d}y+\varphi(x) $$ 

故

 $$ v=3x^{2}y-y^{3}+\varphi(x), $$ 

<div style="text-align: center;"><img src="images/p0150_img_in_image_box_1454_4594_2948_5751.jpg" alt="图 3.15" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.15</div> </div>

<!-- page: 151 -->

再由 C.-R. 方程中的另一个得

 $$ v_{x}=6x y+\varphi^{\prime}(x)=-u_{y}=6\dot{x}y, $$ 

故

 $$ \varphi^{\prime}(x)=0,\quad 即 \quad\varphi(x)=C, $$ 

因此

 $$ v\left(x,y\right)=3x^{2}y-y^{3}+C. $$ 

（下同解法一）

注 这两个方法都可以根据公式前括号内的形式推导进行，

不必强记公式. 两个方法的共同点是都要引用 C. - R. 方程.

例 3.16 验证  $ v(x, y) = \arctan \frac{y}{x}(x > 0) $ 在右半 z 平面内是调和函数，并求以此为虚部的解析函数  $ f(z) $.

解

 $$ v_{x}=\frac{-\frac{y}{x^{2}}}{1+\frac{y}{x^{2}}}=-\frac{y}{x^{2}+y^{2}}\quad(x>0), $$ 

 $$ v_{y}=\frac{\frac{1}{x}}{1+\frac{y^{2}}{x^{2}}}=\frac{x}{x^{2}+y^{2}}\quad(x>0), $$ 

 $$ v_{xx}=\frac{2xy}{\left(x^{2}+y^{2}\right)^{2}},v_{yy}=\frac{-2xy}{\left(x^{2}+y^{2}\right)^{2}}\quad\left(x>0\right), $$ 

于是

 $$ v_{x x}+v_{y y}=0\quad\left(x>0\right), $$ 

故在右半 z 平面内， $ v(x,y) $ 是调和函数.

 $$ \begin{align*}u\left(x,y\right)&=\int u_{x}\mathrm{d}x+\psi\left(y\right)\frac{\mathrm{C.}-\mathrm{R.}}{\mathrm{C.}} \int v_{y}\mathrm{d}x+\psi\left(y\right)\\&=\int\frac{x}{x^{2}+y^{2}}\mathrm{d}x+\psi\left(y\right)=\frac{1}{2}\ln\left(x^{2}+y^{2}\right)+\psi\left(y\right),\end{align*} $$ 

两端对 y 求导

 $$ \frac{1}{2}\cdot\frac{2y}{x^{2}+y^{2}}+\psi^{\prime}(y)=u_{y}\frac{C.-R.}{x^{2}+y^{2}}, $$ 

所以  $ \psi'(y)=0 $，从而  $ \psi(y)=C $（任意常数），

 $$ u\left(x,y\right)=\frac{1}{2}\ln\left(x^{2}+y^{2}\right)+C, $$

<!-- page: 152 -->

故

 $$ \begin{aligned}f(z)&=\frac{1}{2}\ln(x^{2}+y^{2})+C+\mathrm{i}\arctan\frac{y}{x}(x>0)\\&=\ln|z|+\mathrm{i}\arg z+C\\&=\ln z+C,\end{aligned} $$ 

它在右半 z 平面内单值解析.

注 由于解析函数与调和函数的密切联系，人们自然会想到利用这种联系，可以由解析函数的已知性质去推出调和函数的某些性质.不过调和函数尚有它本身的重要性，且对它们的研究又常常不能用复变函数的方法加以简化.因此，有必要对它作专门的研究.我们将在第九章作适当介绍.

#### §5. 平面向量场——解析函数的应用（一）

本节我们要讨论平行于一个平面的定常向量场。这就是说：第一，这个向量场中的向量是与时间无关的；第二，这个向量场中的向量都平行于某一个平面  $ S_{0} $，并且在垂直于  $ S_{0} $ 的任何一条直线上所有的点处，这个场中的向量（就大小与方向来说）都是相等的。显然，在所有的平行于  $ S_{0} $ 的平面内，这个向量场的情形都完全同样。因此，这个向量场可以由位于平面  $ S_{0} $ 内的向量所构成的一个平面向量场完全表示出来。这时，说到平面向量场  $ S_{0} $ 的一个点  $ z_{0} $，我们在心中便要记起在那个平行于平面的向量场中的一条无限直线，它通过所说的那个点  $ z_{0} $ 而垂直于平面  $ S_{0} $；说到  $ S_{0} $ 内的一条曲线 C，则是意味着一个以 C 为基线的柱面；说到  $ S_{0} $ 的一个区域 D，则是意味着以 D 为底面的一个柱体。

我们把平面  $ S_{0} $ 取作 z 平面. 于是向量场中每个向量便可以用复数来表示.

由于解析函数的发展是与流体力学密切联系的,因此,在下面

讲平面向量场与解析函数的关系时,我们常采用流体力学中的术

<!-- page: 153 -->

语. 尽管所讲的那些内容, 都是可以关系着各种不同物理特性的向量场的(如在第五章 §5 所提到的平面电场).

现在我们把江面上水的流动(例 1.1.1)作些补充，并把问题深入一步，从中就可看出解析函数是怎样应用于流体力学的.

我们不限于水的流动，广泛一点说是流体的流动。假设流体是质量均匀的，并且具有不可压缩性，即是说密度不因流体所处的位置以及受到的压力而改变。我们就假设密度为1。流体的形式是 $ \uwave{\text{定常的}} $(即与时间无关) $ \uwave{\text{平面流动}} $。所谓平面流动是指流体在垂直于某一固定平面的直线上各点均有相同的流动情况(图3.16)。流体层的厚度可以不考虑，或者认为是一个单位长。

<div style="text-align: center;"><img src="images/p0153_img_in_image_box_526_2738_2052_4143.jpg" alt="图 3.16" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.16</div> </div>


<div style="text-align: center;"><img src="images/p0153_img_in_image_box_2439_2619_3779_4156.jpg" alt="图 3.17" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 3.17</div> </div>


1. 流量与环量 设流体在 z 平面上某一区域 D 内流动， $ v(z)=p+qi $ 是在点  $ z\in D $ 处的流速，其中  $ p=p(x,y) $，q=q(x,y) 分别为  $ v(z) $ 的水平及垂直分速，并且假设它们都是连续的.

今考查流体在单位时间内流过以 A 为起点，B 为终点的有向曲线  $ \gamma $ (图 3.17) 一侧的流量 (实际上是流体层的质量). 为此取弧元 ds, n 为其单位法向量，它指向曲线  $ \gamma $ 的右边 (顺着 A 到 B 的方向看). 显然，在单位时间内流过 ds 的流最为  $ v_{n} $ ds ( $ v_{n} $ 是 v 在 n

<!-- page: 154 -->

上的投影)，再乘上流体层的厚度以及流体的密度(取厚度为一个单位长，密度为1).因此，这个流量的值就是

 $$ v_{n}\mathrm{d}s $$ 

这里 ds 为切向量  $ \mathrm{d}z = \mathrm{d}x + \mathrm{id}y $ 之长. 当 v 与 n 夹角为锐角时, 流量  $ v_{n} $ ds 为正; 夹角为钝角时为负.

令

 $$ \tau=\frac{\mathrm{d}x}{\mathrm{d}s}+\mathrm{i}\frac{\mathrm{d}y}{\mathrm{d}s} $$ 

是顺  $ \gamma $ 正向的单位切向量. 故 n 恰好可由  $ \tau $ 旋转  $ -\frac{\pi}{2} $ 得到, 即

 $$ \boldsymbol{n}=\mathrm{e}^{-\frac{\pi}{2}\mathrm{i}}\boldsymbol{\tau}=-\mathrm{i}\boldsymbol{\tau}=\frac{\mathrm{d}y}{\mathrm{d}s}-\mathrm{i}\frac{\mathrm{d}x}{\mathrm{d}s}. $$ 

于是即得v在n上的投影为

 $$ \begin{array}{r}{\boldsymbol{v}_{n}=\boldsymbol{v}\cdot\boldsymbol{n}=p\frac{\mathrm{d}y}{\mathrm{d}s}-q\frac{\mathrm{d}x}{\mathrm{d}s}.}\end{array} $$ 

以  $ N_{\gamma} $ 表示单位时间内流过  $ \gamma $ 的流量，则

 $$ N_{r}=\int_{r}\left(\not{p}\frac{\mathrm{d}y}{\mathrm{d}s}-q\frac{\mathrm{d}x}{\mathrm{d}s}\right)\mathrm{d}s=\int_{r}-q\mathrm{d}x+\not{p}\mathrm{d}y. $$ 

在流体力学中，还有一个重要的概念，即流速的环量。它定义为：流速在曲线  $ \gamma $ 上的切线分速，沿着该曲线的积分，以  $ \Gamma_{y} $ 表示。于是

 $$ \Gamma_{\gamma}=\int_{\gamma}\bigg(p\ \frac{\mathrm{d}x}{\mathrm{d}s}+q\ \frac{\mathrm{d}y}{\mathrm{d}s}\bigg)\mathrm{d}s=\int_{\gamma}p\mathrm{d}x+q\mathrm{d}y. $$ 

现在我们可以借助于复积分来表示环量和流量.为此,我们以i乘 $ N_{\gamma} $,再与 $ \Gamma_{\gamma} $相加即得环流量

 $$ \begin{align*}\Gamma_{r}+\mathrm{i}N_{r}&=\int_{r}p\mathrm{d}x+q\mathrm{d}y+\mathrm{i}\int_{r}-q\mathrm{d}x+p\mathrm{d}y\\&=\int_{r}\left(p-q\mathrm{i}\right)\left(\mathrm{d}x+\mathrm{i}\mathrm{d}y\right),\end{align*} $$ 

即

 $$ \Gamma_{\gamma}+\mathrm{i}N_{\gamma}=\int_{\gamma}\overline{{\boldsymbol{v}(z)}}\mathrm{d}z. $$

<!-- page: 155 -->

我们称  $ \overline{v(z)} $ 为复速度.

2. 无源、漏的无旋流动 我们可以假设在流动过程中没有流体自 D 内任何一处涌出或者漏掉。用术语来说，即 D 内无源、漏。即使有源、漏，为了研究方便，我们也可以把 D 适当缩小使源、漏从研究的区域中排除。这样一来，在 D 内任作一周线 C，只要其内部均含于 D，由于不可压缩性，则经过 C 而流进 C 内的流量，恰好等于经过 C 而流出的流量，即  $ N_{C} = 0 $。并且，在源点邻域内  $ N_{C} > 0 $；在漏点邻域内  $ N_{C} < 0 $（图 3.18）。

<div style="text-align: center;"><img src="images/p0155_img_in_image_box_758_2172_3677_3482.jpg" alt="图3.18" width="65%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.18</div> </div>


在流体力学中,对于无旋流动的研究是很重要的.这里它可以定义为  $ \Gamma_{C}=0 $, 只要 C 及其内部均含于 D.

这样,如果流体在 D 内作无源、漏的无旋流动,其充要条件为

 $$ \int_{c}\overline{v(z)}\mathrm{d}z=0, $$ 

只要 C 及其内部均含于 D.

按照定理 3.17, 即知无源、漏的无旋流动特征是  $ \overline{v}(z) $ 在该流动区域 D 内解析.

3. 复势设在区域 D 内有一无源、漏的无旋流动，从以上的讨论，即知其对应的复速度为解析函数  $ \overline{v(z)} $。我们称函数  $ f(z) $ 为对应于此流动的复势，如果  $ f(z) $ 在 D 内处处合乎条件

<!-- page: 156 -->

$$ f^{\prime}(z)=\overline{v(z)}. $$ 

对于无源、漏的无旋流动，复势总是存在的；如果略去常数不计，它还是惟一的. 这是因为  $ \overline{v(z)} $ 解析，由下式确定的

 $$ \ddot{f}(z)=\int_{z_{0}}^{z}\overline{v(z)}\mathrm{d}z $$ 

就是复势，其中  $ z, z_{0} $ 属于 D. 当 D 为单连通时， $ f(z) $ 为单值解析函数. 当 D 为多连通时， $ f(z) $ 可能为多值解析函数. 但它在 D 内任何一个单连通子区域内均能分出单值解析分支.

今设

 $$ f(z)=\varphi(x,y)+\mathrm{i}\psi(x,y) $$ 

为某一流动的复势. 我们称  $ \varphi(x, y) $ 为所述流动的势函数, 称  $ \varphi(x, y) = k(k $ 为实常数 $ ) $ 为势线; 称  $ \psi(x, y) $ 为所述流动的流函数, 称  $ \psi(x, y) = k(k $ 为实常数 $ ) $ 为流线.

因

 $$ \varphi_{x}+\mathrm{i}\psi_{x}=f^{\prime}\left(z\right)=\overline{v\left(z\right)}=p-\mathrm{i}q, $$ 

所以

 $$ \begin{array}{r l}{p=\varphi_{x}=\psi_{y}\mathrm{,}}&{{}q=-\psi_{x}=\varphi_{y}\mathrm{.}\quad\mathrm{~(C.~-R.)}}\end{array} $$ 

又因流线上点  $ z(x, y) $ 的速度方向与该点的切线方向一致, 即流线的微分方程为

 $$ \begin{aligned}\frac{\mathrm{d}x}{p}&=\frac{\mathrm{d}y}{q},\\\psi_{x}\mathrm{d}x&+\psi_{y}\mathrm{d}y=0.\end{aligned} $$ 

即

而  $ \psi(x,y) $ 为调和函数，我们有  $ \psi_{yx} = \psi_{xy} $，于是

 $$ \mathrm{d}\psi(x,y)=0, $$ 

所以  $ \psi(x,y)=k $ 就是流线方程的积分曲线.

流线与势线在流速不为零的点处互相正交(根据例 2.10).

我们用复势来刻画流动比用复速度方便.因为由复势求复速度只用到求导数,反之则要用积分.另一方面,由复势容易求流线和势线,这样就可以了解流动的概况.

例 3.17 考查复势为  $ f(z)=az $ 的流动情况.

<!-- page: 157 -->

解 设 a > 0，则势函数和流函数分别为：

 $$ \varphi\left(x,y\right)=ax,\quad\psi\left(x,y\right)=ay, $$ 

故势线是  $ x = C_{1} $; 流线是  $ y = C_{2} $ ( $ C_{1}, C_{2} $ 均为实常数). 这种流动称为均匀常流 (图 3.19).

当 a 为复数时，情况相仿，势线和流线也是直线，只是方向有了改变。这时的速度为  $ \bar{a} $。

<div style="text-align: center;"><img src="images/p0157_img_in_image_box_651_1811_3820_3193.jpg" alt="图3.19" width="71%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.19</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 3.20</div> </div>


例 3.18 设复势为  $ f(z) = z^{2} $，试确定其流线、势线和速度.

解 势函数和流函数分别为

 $$ \varphi(x,y)=x^{2}-y^{2}, $$ 

 $$ \psi(x,y)=2xy, $$ 

故势线及流线是互相正交的两族等轴双曲线（图 3.20）.

在点 z 处的速度  $ v(z)=\overline{f'(z)}=2\overline{z} $.

## 第三章 习题

(一)

1 计算积分  $ \int_{C}(x-y+ix^{2})dz $，积分路径 C 是连接由 0 到  $ 1+i $ 的直线段.

<!-- page: 158 -->

答： $ -\frac{1}{3}(1-i) $

2 计算积分  $ \int_{-1}^{1}|z| $ dz，积分路径是(1)直线段；(2)上半单位圆周；(3)下半单位圆周.

答:(1) $ ^{1} $; (2)2; (3)2.

### 3 利用积分估值，证明

(1)  $ \left|\int_{C}(x^{2}+iy^{2})dz\right|\leq2 $, 其中 C 是连接 -i 到 i 的直线段;

(2)  $ \left|\int_{C}(x^{2}+iy^{2})dz\right|\leq\pi $, 其中 C 是连接 -i 到 i 的右半圆周.

4 不用计算，验证下列积分之值为零，其中 C 均为单位圆周  $ \left|z\right|=1 $

(1)  $ \int_{c}\frac{dz}{\cos z} $; (2)  $ \int_{c}\frac{dz}{z^{2}+2z+2} $;

(3)  $ \int_{c}\frac{e^{z}dz}{z^{2}+5z+6} $; (4)  $ \int_{c}z\cos z^{2}dz $.

5 计算: (1)  $ \int_{-2}^{-2+i}(z+2)^2 dz $; (2)  $ \int_0^{\pi+2i}\cos\frac{z}{2} dz $.

答: (1)  $ -\frac{\mathrm{i}}{3} $ (2) 2  $ \cosh 1 $.

6 求积分

 $$ \int_{0}^{2\pi a}\left(2z^{2}+8z+1\right)\mathrm{d}z $$ 

之值,其中积分路径是连接0到 $ 2\pi a $的摆线:

 $$ x=a\left(\theta-\sin\theta\right),y=a\left(1-\cos\theta\right). $$ 

7 （分部积分法）设函数  $ f(z) $,  $ g(z) $ 在单连通区域 D 内解析,  $ \alpha $、 $ \beta $ 是 D 内两点, 试证

 $$ \int_{a}^{\beta}f(z)g^{\prime}(z)\mathrm{d}z=\left[f(z)g(z)\right]_{a}^{\beta}-\int_{a}^{\beta}g(z)f^{\prime}(z)\mathrm{d}z. $$ 

8 由积分 $ \int_{c}\frac{\mathrm{d}z}{z+2} $之值证明

 $$ \int_{0}^{\pi}\frac{1+2\cos\theta}{5+4\cos\theta}\mathrm{d}\theta=0, $$ 

其中 C 取单位圆周  $ |z|=1 $.

9 计算(C: |z| = 2)

<!-- page: 159 -->

(1)  $ \int_{C}\frac{2z^{2}-z+1}{z-1}dz $; (2)  $ \int_{C}\frac{2z^{2}-z+1}{(z-1)^{2}}dz $.

答: (1)  $ 4\pi i $; (2)  $ 6\pi i $.

10 计算积分：

 $$ \int_{c_{j}}\frac{\sin\frac{\pi}{4}z}{z^{2}-1}\mathrm{d}z,\quad(j=1,2,3) $$ 

(1)  $ C_{1}:|z+1|=\frac{1}{2} $; (2)  $ C_{2}:|z-1|=\frac{1}{2} $; (3)  $ C_{3}:|z|=2 $.

答: (1)  $ \frac{\sqrt{2}}{2}\pi\mathrm{i} $; (2)  $ \frac{\sqrt{2}}{2}\pi\mathrm{i} $; (3)  $ \sqrt{2}\pi\mathrm{i} $.

11 求积分

 $$ \int_{C}\frac{\mathrm{e}^{z}}{z}\mathrm{d}z\left(C\colon|z|=1\right), $$ 

从而证明

 $$ \int_{0}^{\pi}\mathrm{e}^{\cos\theta}\cos(\sin\theta)\mathrm{d}\theta=\pi. $$ 

12 设 C 表圆周  $ x^{2} + y^{2} = 3 $,  $ f(z) = \int_{C} \frac{3\zeta^{2} + 7\zeta + 1}{\zeta - z} \, \mathrm{d}\zeta $, 求  $ f'(1 + i) $.

提示 令  $ \varphi(\zeta)=3\zeta^{2}+7\zeta+1 $.

答:  $ 2\pi(-6+13i) $.

13 设  $ C: z = z(t) (a \leq t \leq \beta) $ 为区域 D 内的光滑曲线， $ f(z) $ 于区域 D 内单叶解析且  $ f'(z) \neq 0 $ ①， $ w = f(z) $ 将 C 映成曲线  $ \Gamma $，求证  $ \Gamma $ 亦为光滑曲线.

提示 光滑曲线 C 的特点是: C 是若尔当曲线且  $ z'(t) \neq 0 $ 连续于  $ \alpha \leq t \leq \beta $. 现要证  $ \Gamma: w = f[z(t)] $ 亦具有类似的性质.

14 同前题的假设,证明积分换元公式

 $$ \int_{\varGamma}\Phi(\mathbf{\nabla}w)\mathrm{d}\mathbf{\nabla}w=\int_{C}\Phi\big[\mathbf{\nabla}f(z)\big]\mathbf{\nabla}f^{\prime}(z)\mathrm{d}z. $$ 

其中  $ \Phi(w) $ 沿  $ \Gamma $ 连续.

15 设函数  $ f(z) $ 在 z 平面上解析，且  $ \left|f(z)\right| $ 恒大于一个正的常数，试证  $ f(z) $ 必为常数.

16 分别由下列条件求解析函数  $ f(z)=u+iv $.

<!-- page: 160 -->

(1)

 $$ u=x^{2}+x y-y^{2} $$ 

 $$ f(\mathrm{i})=-1+\mathrm{i}; $$ 

(2)  $ u = e^{x} $ ( $ x \cos y - y \sin y $),  $ f(0) = 0 $;

(3)  $ v = \frac{y}{x^{2} + y^{2}} $, \quad f(2) = 0.

答: (1)  $ f(z) = \left(1 - \frac{\mathrm{i}}{2}\right)z^{2} + \frac{\mathrm{i}}{2} $; (2)  $ f(z) = z\mathrm{e}^{z} $;

(3)  $ f(z)=\frac{1}{2}-\frac{1}{z} $.

17 设函数  $ f(z) $ 在区域 D 内解析,试证

 $$ \left(\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}\right)\mid f(z)\mid^{2}=4\mid f^{\prime}(z)\mid^{2}. $$ 

18 设函数  $ f(z) $ 在区域 D 内解析，且  $ f'(z) \neq 0 $，试证  $ \ln |f'(z)| $ 为区域 D 内的调和函数.

19 设流体流动的水平及垂直分速为  $ ky, kx $ ( $ k > 0 $ 为常数)，试求复势并画出势线及流线.

答: 复势  $ f(z) = -\frac{k i}{2} z^{2} $.

20 某流动的复势为  $ f(z)=\frac{1}{z^{2}-1} $，试分别求出沿圆周

(1)  $ C_{1}:|z-1|=\frac{1}{2} $; (2)  $ C_{2}:|z+1|=\frac{1}{2} $;

(3)  $ C_{3}: |z| = 3 $,

的流量及环量.

答:(1) 0,0; (2) 0,0; (3) 0;0.

## (二)

1 设函数  $ f(z) $ 在  $ 0<|z|<1 $ 内解析，且沿任何圆周  $ C: |z|=r, 0<r<1 $ 的积分值为零。问  $ f(z) $ 是否必须在 z=0 处解析？试举例说明之。

2 沿从 1 到 -1 的如下路径求  $ \int_{C}\frac{1}{\sqrt{z}}\mathrm{d}z $.

（1）上半单位圆周；（2）下半单位圆周，其中 $ \sqrt{z} $取主值支.

3 试证

 $$ \left|\int_{c}\frac{z+1}{z-1}\mathrm{d}z\right|\leqslant8\pi, $$

<!-- page: 161 -->

其中 C 为圆周  $ \left|z-1\right|=2 $.

4 设 a, b 为实数,  $ s = \sigma + it (\sigma > 0) $ 时, 试证

 $$ \left|\mathrm{e}^{b s}-\mathrm{e}^{a s}\right|\leqslant\left|s\right|\mid b-a\mid\mathrm{e}^{\max\{a,b\}\cdot\sigma}. $$ 

5 设在区域  $ D = \left\{ z \mid |\arg z| < \frac{\pi}{2} \right\} $ 内的单位圆周  $ |z| = 1 $ 上任取一点 z，用 D 内曲线 C 连接 0 与 z，试证

 $$ \mathrm{R e}\int_{c}\frac{\mathrm{d}z}{1+z^{2}}=\frac{\pi}{4}. $$ 

6 试计算积分

 $$ \int_{c}\left(\mid z\mid-\mathrm{e}^{z}\sin z\right)\mathrm{d}z $$ 

之值，其中 C 为圆周  $ |z|=a>0 $.

7 设(1)  $ f(z) $ 在  $ \mid z\mid \leqslant 1 $ 上连续；(2) 对任意的  $ r (0 < r < 1) $,

 $$ \int_{|z|=r}f(z)\mathrm{d}z=0, $$ 

试证

 $$ \int_{|z|=1}f(z)\mathrm{d}z=0. $$ 

8 设(1)函数  $ f(z) $ 当  $ \left|z - z_{0}\right| > r_{0} > 0 $ 时是连续的；(2)  $ M(r) $ 表  $ \left|f(z)\right| $ 在  $ K_{r}:\left|z - z_{0}\right| = r > r_{0} $ 上的最大值；(3)  $ \lim_{r \to +\infty} rM(r) = 0 $. 试证

 $$ \lim_{r\to+\infty}\int_{K_{r}}f(z)\mathrm{d}z=0. $$ 

##### 提示 应用积分估值定理.

9 证明：

（1）若函数  $ f(z) $ 在点 z=a 的邻域内连续，则

 $$ \lim_{r\to0}\int_{|z-a|=r}\frac{f(z)}{z-a}\mathrm{d}z=2\pi\mathrm{i}f(a); $$ 

(2) 若函数  $ f(z) $ 在原点 z=0 的邻域内连续，则

 $$ \operatorname*{l i m}_{r\to0}\int_{0}^{2\pi}f(r\mathrm{e}^{\mathrm{i}\theta})\mathrm{d}\theta=2\pi f(0). $$ 

10 设函数  $ f(z) $ 在  $ \left|z\right| < 1 $ 内解析，在闭圆  $ \left|z\right| \leq 1 $ 上连续，且  $ f(0) = 1 $，求积分

 $$ \frac{1}{2\pi\mathrm{i}}\int_{|z|=1}\left[2\pm\left(z+\frac{1}{z}\right)\right]f(z)\frac{\mathrm{d}z}{z} $$ 

之值.

<!-- page: 162 -->

答:  $ 2 \pm f'(0) $.

11 若函数  $ f(z) $ 在区域 D 内解析，C 为 D 内以 a, b 为端点的直线段。试证：存在数  $ \lambda, |\lambda| \leq 1 $，与  $ \xi \in C $ 使得

 $$ f(b)-f(a)=\lambda(b-a)f^{\prime}(\xi). $$ 

12 如果在  $ \left|z\right|<1 $ 内函数  $ f(z) $ 解析，且

 $$ \mid f(z)\mid\leqslant\frac{1}{1-\mid z\mid}. $$ 

试证：

 $$ \begin{aligned}\mid f^{(n)}(0)\mid\leqslant(n+1)!\quad\left(1+\frac{1}{n}\right)^{n}&<\mathrm{e}(n+1)!\ ,\ $ n=1,2,\cdots).\end{aligned} $$ 

提示 可取积分路径为圆周  $ C: |z| = \frac{n}{n+1} $，然后应用柯西高阶导数公式.

13 设在  $ \left|z\right|\leqslant1 $ 上函数  $ f(z) $ 解析，且  $ \left|f(z)\right|\leqslant1 $

试证：

 $ \left|f'(0)\right|\leqslant1 $

注 很清楚,由  $ f(z)=z $ 知,这是可能的最好界.

14 设  $ f(z) $ 为非常数的整函数，又设 R, M 为任意正数。试证：满足  $ \left|z\right| > R $ 且  $ \left|f(z)\right| > M $ 的 z 必存在。

提示 用反证法，并应用刘维尔定理.

15 已知  $ u + v = (x - y)(x^{2} + 4xy + y^{2}) - 2(x + y) $，试确定解析函数  $ f(z) = u + iv $.

答： $ f(z)=z^{3}-2z+k $ （k为任意常数）.

16 设(1)区域 D 是有界区域，其边界是周线或复周线 C；(2)函数  $ f_{1}(z) $ 及  $ f_{2}(z) $ 在 D 内解析，在闭域  $ \overline{D} = D + C $ 上连续；(3) 沿 C,  $ f_{1}(z) = f_{2}(z) $，试证：在整个闭域  $ \overline{D} $ 上， $ f_{1}(z) \equiv f_{2}(z) $.

<!-- page: 163 -->

## 第四章 解析函数的幂级数表示法

级数也是研究解析函数的一个重要工具.把解析函数表为级数不仅有理论上的意义,而且也有实用的意义.例如,利用级数可以计算函数的近似值;在许多带有应用性质的问题中(如解微分方程等)也常常用到级数.

本章将讨论把解析函数表示为幂级数的问题，对于某些和数学分析中平行的结论，往往只叙述而不加证明。

‖◇‖‖◇

#### § 1. 复级数的基本性质

### 1. 复数项级数

定义 4.1 对于复数项的无穷级数

$$  \sum_{n=1}^{\infty}\alpha_{n}=\alpha_{1}+\alpha_{2}+\cdots+\alpha_{n}+\cdots,   \tag*{(4.1)}$$

命  $ s_{n}=\alpha_{1}+\alpha_{2}+\cdots+\alpha_{n} $ （ $ \uwave{\text{部分和}} $）. 若复数列  $ s_{n} $ （n=1,2,\cdots）以有限复数 s 为极限，即若

 $$ \lim_{n\to\infty}s_{n}=s, $$ 

则称复数项无穷级数(4.1)收敛于 s，且称 s 为级数(4.1)的和，写成

<!-- page: 164 -->

$$ s=\sum_{n=1}^{\infty}\alpha_{n}； $$ 

若复数列  $ s_{n} $ (n=1,2, $ \cdots $) 无有限极限，则称级数 (4.1) 为发散.

定理 4.1 设  $ \alpha_{n}=a_{n}+ib_{n}(n=1,2,\cdots) $， $ a_{n} $ 及  $ b_{n} $ 为实数，则复级数 (4.1) 收敛于  $ s=a+ib(a,b $ 为实数) 的充要条件为: 实级数  $ \sum_{n=1}^{\infty}a_{n} $ 及  $ \sum_{n=1}^{\infty}b_{n} $ 分别收敛于 a 及 b.

证 设  $ \dot{s}_{n} = \sum_{k=1}^{n} a_{k}, A_{n} = \sum_{k=1}^{n} a_{k}, B_{n} = \sum_{k=1}^{n} b_{k} $，

则  $ s_{n}=A_{n}+\mathrm{i}B_{n} $  $ (n=1,2,\cdots) $,

由第一章习题(一)17

 $$ \lim_{n\to\infty}s_{n}=a+i b $$ 

的充要条件为：

 $$ \lim_{n\to\infty}A_{n}=a\  及 \lim_{n\to\infty}B_{n}=b. $$ 

例 4.1 考察级数  $ \sum_{n=1}^{\infty}\left(\frac{1}{n}+\frac{i}{2^{n}}\right) $ 的敛散性.

解 因  $ \sum_{n=1}^{\infty}\frac{1}{n} $ 发散，故虽  $ \sum_{n=1}^{\infty}\frac{1}{2^{n}} $ 收敛，我们仍断定原级数发散.

由柯西收敛准则(第一章习题(一)18)立得

定理 4.2 复级数(4.1)收敛的充要条件为: 对任给  $ \varepsilon > 0 $, 存在正整数  $ N(\varepsilon) $, 当 n > N 且 p 为任何正整数时

 $$ \mid\alpha_{n+1}+\alpha_{n+2}+\cdots+\alpha_{n+p}\mid<\varepsilon. $$ 

特别，取 p=1，则必  $ \left|\alpha_{n+1}\right|<\varepsilon $，即收敛级数的通项必趋于零： $ \lim_{n\to\infty}\alpha_{n}=0 $。

显然，收敛级数的各项必是有界的.

若级数(4.1)中略去有限个项,则所得级数与原级数同为收敛或同为发散.

<!-- page: 165 -->

定理 4.3 复级数(4.1)收敛的一个充分条件为级数  $ \sum_{n=1}^{\infty} |\alpha_n| $ 收敛.

证 由于

 $ \left|\alpha_{n+1}+\alpha_{n+2}+\cdots+\alpha_{n+p}\right|\leq\left|\alpha_{n+1}\right|+\left|\alpha_{n+2}\right|+\cdots\left|\alpha_{n+p}\right| $

 $ \infty $

若  $ \sum_{n=1}^{\infty}\left|\alpha_{n}\right| $ 收敛，则由定理 4.2，必  $ \sum_{n=1}^{\infty}\alpha_{n} $ 收敛.

定义 4.2 若级数  $ \sum_{n=1}^{\infty} |\alpha_n| $ 收敛，则原级数  $ \sum_{n=1}^{\infty} \alpha_n $ 称为绝对收敛；非绝对收敛的收敛级数，称为条件收敛.

级数  $ \sum_{n=1}^{\infty} |\alpha_n| $ 的各项既为非负实数，故它是否收敛，可依正项级数的理论判定之.

和实级数一样，我们有

定理 4.4 （1）一个绝对收敛的复级数的各项可以任意重排次序，而不致改变其绝对收敛性，亦不致改变其和.（2）两个绝对收敛的复级数

 $$ s=\alpha_{1}+\alpha_{2}+\cdots+\alpha_{n}+\cdots, $$ 

 $$ s^{\prime}=\alpha^{\prime}{}_{1}+\alpha^{\prime}{}_{2}+\cdots+\alpha^{\prime}{}_{n}+\cdots, $$ 

可按下述对角线方法

 $$ \begin{array}{cccc}\alpha^{\prime}_{1}&\alpha^{\prime}_{2}&\alpha^{\prime}_{3}&...\\\hline\alpha_{1}&\alpha_{1}\alpha^{\prime}_{1}&\alpha_{1}\alpha^{\prime}_{2}&\alpha_{1}\alpha^{\prime}_{3}\\*&\*&\*&\*\\*&\alpha_{2}\alpha^{\prime}_{1}&\alpha_{2}\alpha^{\prime}_{2}&\alpha_{2}\alpha^{\prime}_{3}\\*&\*&\*&\*\\*&\alpha_{3}\alpha^{\prime}_{1}&\alpha_{3}\alpha^{\prime}_{2}&\alpha_{3}\alpha^{\prime}_{3}\\*&\vdots&\vdots&\vdots\end{array} $$ 

得出乘积(柯西积)级数

 $$ \alpha_{1}\alpha^{^{\prime}}{}_{1}+\left(\alpha_{1}\alpha^{^{\prime}}{}_{2}+\alpha_{2}\alpha^{^{\prime}}{}_{1}\right)+\cdots+ $$

<!-- page: 166 -->

$$ \begin{align*}&+\left(\alpha_{1}\alpha^{^{\prime}}_{n}+\alpha_{2}\alpha^{^{\prime}}_{n-1}+\cdots+\alpha_{n}\alpha^{^{\prime}}_{1}\right)+\cdots\\=&\sum_{n=1}^{\infty}\sum_{k=1}^{n}\alpha_{k}\alpha^{^{\prime}}(_{n+1)-k}\end{align*} $$ 

也绝对收敛于  $ s\ddot{s}^{\prime} $.

### 2. 一致收敛的复函数项级数

定义 4.3 设复变函数项级数

$$  f_{1}\left(z\right)+f_{2}\left(z\right)+\cdots+f_{n}\left(z\right)+\cdots   \tag*{(4.2)}$$

的各项均在点集 E 上有定义，且在 E 上存在一个函数  $ f(z) $， $ \uwave{\text{对于 E 上的每一点 z，级数(4.2)均收敛于 f(z)}} $，则称  $ f(z) $ 为级数 (4.2) 的和函数，记为

 $$ f(z)=\sum_{n=1}^{\infty}f_{n}(z). $$ 

用  $ \varepsilon-N $ 的说法来描述这件事就是：

任给  $ \varepsilon>0 $，以及给定的  $ z\in E $，存在正整数 N=N( $ \varepsilon $,z)，使当 n>N 时，有

 $$ |f(z)-s_{n}(z)|<\varepsilon, $$ 

式中  $ s_{n}(z)=\sum_{k=1}^{n}f_{k}(z) $.

上述的正整数  $ N = N(\varepsilon, z) $，一般地说，不仅依赖于  $ \varepsilon $，而且依赖于  $ z \in E $。重要的一种情形是  $ N = N(\varepsilon) $ 不依赖于  $ z \in E $，这就是：

定义 4.4 对于级数 (4.2)，如果在点集 E 上有一个函数  $ f(z) $，使对任意给定的  $ \varepsilon > 0 $，存在正整数 N = N( $ \varepsilon $)，当 n > N 时，对一切的  $ z \in E $ 均有

 $$ |f(z)-s_{n}(z)|<\varepsilon, $$ 

则称级数(4.2)在 E 上一致收敛于  $ f(z) $.

注（1）根据定义 4.4，证明级数(4.2)在点集 E 上一致收敛于  $ f(z) $ 的关键，是找不依赖于 z 的正整数 N，使当 n > N 时， $ |f(z) - s_{n}(z)| < \varepsilon $ 成立。因此，一般是先如下加强不等式  $ |f(z)| $

<!-- page: 167 -->

$ -s_{n}(z)| \leqslant P_{n}(z) \leqslant Q_{n} $，并对 $ \forall \varepsilon > 0 $，由 $ Q_{n} < \varepsilon $找N.

（2）证明不一致收敛的方法，是利用定义 4.4 的否定形式. 即把定义 4.4 逐句以否定语句代替，而成

定义 4.4  $ \sum_{n=1}^{\infty} f_{n}(z) $ 在点集 E 上不一致收敛于  $ f(z) \Leftrightarrow \exists $ 某个  $ \varepsilon_{0} > 0 $，对任何整数 N > 0， $ \exists $ 整数  $ n_{0} > N $ 时，总有某个  $ z_{0} \in E $，使  $ |f(z_{0}) - s_{n_{0}}(z_{0})| \geq \varepsilon_{0} $。

定理4.5（柯西一致收敛准则）级数(4.2)在点集E上一致收敛于某函数的充要条件是：任给 $ \varepsilon>0 $，存在正整数 $ N=N(\varepsilon) $，使当 $ n>N $时，对一切 $ z\in E $，均有

 $$ |f_{n+1}(z)+\cdots+f_{n+p}(z)|<\varepsilon\quad(p=1,2,\cdots). $$ 

定理4.5  $ \sum_{n=1}^{\infty} f_{n}(z) $在点集E上不一致收敛 $ \Leftrightarrow $∃某个 $ \varepsilon_{0} $

>0,对任何正整数N，∃整数 $ n_{0} $，使当 $ n_{0}>N $，总有某个 $ z_{0}\in E $

及某个正整数 $ p_{0} $，有

 $$ \mid f_{n_{0}+1}(z_{0})+f_{n_{0}+2}(z_{0})+\cdots+f_{n_{0}+p_{0}}(z_{0})\mid\geqslant\varepsilon_{0}. $$ 

由这个准则，可得出一致收敛的一个充分条件，即优级数准则：

如果有正数列  $ M_{n} $ (n=1,2, $ \cdots $),使对一切  $ z\in E $,有

 $$ |f_{n}(z)|\leqslant M_{n}(n=1,2,\cdots), $$ 

而且正项级数  $ \sum_{n=1}^{\infty} M_{n} $ 收敛，则复函数项级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 在集 E 上绝对收敛且一致收敛：

这样的正项级数  $ \sum_{n=1}^{\infty} M_{n} $ 称为复函数项级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 的优先级数.

注 优先级数准则是一个被广泛应用的方法.因为它把判别复函数项级数的一致收敛性转化为判别正项级数的收敛性,而实现后者较容易;另外,优先级数准则同时还可以判定绝对收敛性.

<!-- page: 168 -->

例 4.2 级数

 $$ 1+z+z^{2}+\cdots+z^{n}+\cdots $$ 

在闭圆  $ \left|z\right| \leqslant r (r < 1) $ 上一致收敛.

事实上,所述级数有收敛的优级数  $ \sum_{n=0}^{\infty} r^{n} $.

下述两个定理也和数学分析中相应的定理平行.

定理 4.6 设级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 的各项在点集 E 上连续，并且一致收敛于  $ f(z) $，则和函数

 $$ f(z)=\sum_{n=1}^{\infty}f_{n}(z) $$ 

也在 E 上连续.

定理 4.7 设级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 的各项在曲线 C 上连续，并且在 C 上一致收敛于  $ f(z) $，则沿 C 可以逐项积分：

 $$ \int_{C}f(z)\mathrm{d}z=\sum_{n=1}^{\infty}\int_{C}f_{n}(z)\mathrm{d}z $$ 

定义 4.5 设函数  $ f_{n}(z) $ (n=1,2, $ \cdots $) 定义于区域 D 内，若级数 (4.2) 在 D 内任一有界闭集上一致收敛，则称此级数在 D 内内闭一致收敛.

定理 4.8 级数(4.2)在圆  $ K: |z - a| < R $ 内闭一致收敛的充要条件为: 对任意正数  $ \rho $, 只要  $ \rho < R $, 级数(4.2)在闭圆  $ \overline{K}_{\rho}: |z - a| \leq \rho $ 上一致收敛.

证 必要性 因为  $ \overline{K}_{\rho} $ 就是 K 内的有界闭集.

充分性 因为圆 K 内的任意闭集 F，总可以包含在 K 内的某个闭圆  $ K_{\rho} $ 上.

显然，在区域 D 内一致收敛的级数必在 D 内内闭一致收敛，但其逆不真.例如，我们考察几何级数

 $$ 1+z+z^{2}+\cdots+z^{n}+\cdots, $$

<!-- page: 169 -->

当 $ \left|z\right|<1 $时，此级数收敛但不一致收敛.可是，由例4.2知它在单位圆 $ \left|z\right|<1 $内是内闭一致收敛的.

3. 解析函数项级数 在数学分析中, 函数项级数能逐项求导的条件是苛刻的, 然而解析函数项级数求导的条件却比较宽些, 这就是下面的魏尔斯特拉斯定理.

定理 4.9 设(1) 函数  $ f_{n}(z) $ (n=1,2,\cdots) 在区域 D 内解析，(2)  $ \sum_{n=1}^{\infty} f_{n}(z) $ 在 D 内内闭一致收敛于函数  $ f(z) $:

 $$ f(z)=\sum_{n=1}^{\infty}f_{n}(z), $$ 

则 （1）函数  $ f(z) $ 在区域 D 内解析.

(2)

 $$ f^{\left(p\right)}\left(z\right)=\sum_{n=1}^{\infty}f_{n}^{\left(p\right)}\left(z\right)\quad\left(z\in D,p=1,2,\cdots\right). $$ 

证（1）设  $ z_{0} $ 为 D 内任一点，则必有  $ \rho>0 $，使闭圆  $ \overrightarrow{K}:|z-z_{0}|\leq\rho $ 全含于 D 内。若 C 为圆  $ K:|z-z_{0}|<\rho $ 内任一周线，则由柯西积分定理得

 $$ \int_{C}f_{n}(z)\mathrm{d}z=0,n=1,2,\cdots, $$ 

再由假设知级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 在  $ \overline{K} $ 上一致收敛，且  $ f_{n}(z) $ 是连续的，所以由定理4.6知  $ f(z) $ 在  $ \overline{K} $ 上连续，由定理4.7得

 $$ \int_{C}f(z)\mathrm{d}z=\sum_{n=1}^{\infty}\int_{C}f_{n}(z)\mathrm{d}z=0, $$ 

于是，由摩勒拉定理知  $ f(z) $ 在 K 内解析，即  $ f(z) $ 在点  $ z_{0} $ 解析，由于  $ z_{0} $ 的任意性，故  $ f(z) $ 在区域 D 内解析.

(2) 设  $ z_{0} $ 为 D 内任一点，则必有  $ \rho > 0 $，使闭圆  $ \overline{K}: |z - z_{0}| \leq \rho $ 全含于 D 内， $ \overline{K} $ 的边界是圆周  $ \Gamma: |z - z_{0}| = \rho $。故由定理 3.12 有

<!-- page: 170 -->

$$ \begin{array}{r l}&{f^{(p)}\left(z_{0}\right)=\frac{p!}{2\pi\mathrm{i}}\displaystyle\int_{\Gamma}\frac{f(\zeta)}{\left(\zeta-z_{0}\right)^{p+1}}\mathrm{d}\zeta}\\ &{f_{n}^{(p)}\left(z_{0}\right)=\frac{p!}{2\pi\mathrm{i}}\displaystyle\int_{\Gamma}\frac{f_{n}(\zeta)}{\left(\zeta-z_{0}\right)^{p+1}}\mathrm{d}\zeta.}\end{array}\quad(p=1,2,\cdots), $$ 

在  $ \Gamma $ 上由条件(2)知级数

 $$ \frac{f(\zeta)}{(\zeta-z_{0})^{p+1}}=\sum_{n=1}^{\infty}\frac{f_{n}(\zeta)}{(\zeta-z_{0})^{p+1}} $$ 

是一致收敛的.于是由定理4.7得到

 $$ \int_{\Gamma}\frac{f(\zeta)}{\left(\zeta-z_{0}\right)^{p+1}}\mathrm{d}\zeta=\sum_{n=1}^{\infty}\int_{\Gamma}\frac{f_{n}(\zeta)}{\left(\zeta-z_{0}\right)^{p+1}}\mathrm{d}\zeta, $$ 

两端同乘以 $ \frac{p!}{2\pi i} $就得到所要证明的

 $$ f^{\left(p\right)}\left(z_{0}\right)=\sum_{n=1}^{\infty}f_{n}^{\left(p\right)}\left(z_{0}\right)\qquad\left(p=1,2,\cdots\right). $$ 

注（1）这个定理的证明，关键是用了柯西高阶导数公式，它使我们可以根据原来函数项级数的内闭一致收敛性，对级数进行逐项求积分，从而推出逐项求任意阶导数的性质。这是上一章柯西高阶导数公式的应用的一个范例。

（2）这个定理还有第三条结论：

 $$ \sum_{n=1}^{\infty}f_{n}^{\left(p\right)}\left(z\right) 在 D 内内闭一致收敛于 f^{\left(p\right)}\left(z\right) $$ 

 $$ \left(p=1,2,\cdots. 证明从略 \right). $$ 

#### §2. 幂级数

### 1. 幂级数的敛散性 具有

$$  \sum_{n=0}^{\infty}c_{n}\left(z-a\right)^{n}=c_{0}+c_{1}\left(z-a\right)+c_{2}\left(z-a\right)^{2}+\cdots   \tag*{(4.3)}$$

形式的复函数项级数称为幂级数, 其中  $ c_{0}, c_{1}, c_{2}, \cdots $ 和 a 都是复常数. 如果作变换  $ \zeta = z - a $, 则以上幂级数还可以写成如下形式

<!-- page: 171 -->

（把  $ \zeta $ 仍改写为 z）

 $$ \sum_{n=0}^{\infty}c_{n}z^{n}=c_{0}+c_{1}z+c_{2}z^{2}+\cdots. $$ 

幂级数是最简单的解析函数项级数.其收敛范围很规范,是个圆,因而在理论和应用上都很重要.为了搞清它的敛散性,先建立下述定理,通常称为阿贝尔(Abel)定理.

定理 4.10 如果幂级数(4.3)在某点  $ z_{1} (\neq a) $ 收敛，则它必在圆  $ K: |z - a| < |z_{1} - a| $ (即以 a 为心，圆周通过  $ z_{1} $ 的圆) 内绝对收敛且内闭一致收敛.

证 设 z 是所述圆 K 内的任意定点. 因为  $ \sum_{n=0}^{\infty} c_{n}(z_{1}-a)^{n} $ 收敛, 它的各项必然有界, 即有正数 M, 使

 $$ \mid c_{n}(z_{1}-a)^{n}\mid\leqslant M\quad(n=0,1,2,\cdots), $$ 

这样一来，即有

 $$ \mid c_{n}\left(z-a\right)^{n}\mid=\mid c_{n}\left(z_{1}-a\right)^{n}\left(\frac{z-a}{z_{1}-a}\right)^{n}\mid\leqslant M\left|\frac{z-a}{z_{1}-a}\right|^{n}, $$ 

注意到  $ \left|z-a\right|<\left|z_{1}-a\right| $，故级数

 $$ \sum_{n=0}^{\infty}M\left|\frac{z-a}{z_{1}-a}\right|^{n} $$ 

为收敛的等比级数. 因而  $ \sum_{n=0}^{\infty}c_{n}(z-a)^{n} $ 在圆 K 内绝对收敛.

其次，对 K 内任一闭圆  $ \overline{K}_{\rho}: |z-a| \leqslant \rho (0 < \rho < |z_{1}-a|) $ 上的一切点来说，有

 $$ \mid c_{n}\left(z-a\right)^{n}\mid\leqslant M\left|\frac{z-a}{z_{1}-a}\right|^{n}\leqslant M\left(\frac{\rho}{\lceil z_{1}-a\rceil}\right)^{n}, $$ 

故  $ \sum_{n=0}^{\infty}c_{n}(.z-a)^{n} $ 在  $ \overline{K}_{\rho} $ 上有收敛的优级数

 $$ \sum_{n=0}^{\infty}M\left(\frac{\rho}{\lceil z_{1}-a\rceil}\right)^{n}, $$ 

因而它在  $ \overline{K}_{\rho} $ 上绝对且一致收敛. 再由定理 4.8, 此级数必在圆 K

<!-- page: 172 -->

内绝对且内闭一致收敛.

推论 4.11 若幂级数(4.3)在某点  $ z_{2} (\neq a) $ 发散，则它在以 a 为心并通过  $ z_{2} $ 的圆周外部发散.

证 用反证法，证明留给读者.

对于一个形如(4.3)的幂级数,  $ z = a $ 这一点总是收敛的.  $ z \neq a $ 时, 可能有下述三种情况

第一种 任意的  $ z \neq a $，级数  $ \sum_{n=0}^{\infty} c_{n}(z-a)^{n} $ 均发散.

例 4.3 级数

 $$ 1+z+2^{2}z^{2}+\cdots+n^{n}z^{n}+\cdots, $$ 

当  $ z \neq 0 $ 时，通项不趋于零，故发散.

第二种 任意的 z，级数  $ \sum_{n=0}^{\infty} c_{n}(z-a)^{n} $ 均收敛.

例 4.4 级数

 $$ 1+z+\frac{z^{2}}{2^{2}}+\cdots+\frac{z^{n}}{n^{n}}+\cdots, $$ 

对任意固定的 z，从某个 n 开始，以后总有  $ \frac{|z|}{n} < \frac{1}{2} $，于是从此以后，有  $ \left|\frac{z^{n}}{n^{n}}\right| < \left(\frac{1}{2}\right)^{n} $，故所述级数对任意的 z 均收敛.

第三种 存在一点  $ z_{1} \neq a $，使  $ \sum_{n=0}^{\infty} c_{n}(z_{1}-a)^{n} $ 收敛（此时，根据定理4.10的第一部分知，它必在圆周  $ |z-a|=|z_{1}-a| $ 内部绝对收敛），另外又存在一点  $ z_{2} $，使  $ \sum_{n=0}^{\infty} c_{n}(z_{2}-a)^{n} $ 发散。（肯定  $ |z_{2}-a|\geq|z_{1}-a| $；根据推论4.11知，它必在圆周  $ |z-a|=|z_{2}-a| $ 外部发散。）

在这种情况下，可以证明，存在一个有限正数 R，使得

 $ \sum_{n=0}^{\infty}c_{n}(z-a)^{n} $ 在圆周  $ \left|z-a\right|=R $ 内部绝对收敛，在圆周  $ \left|z-a\right| $

<!-- page: 173 -->

= R 的外部发散. R 称为此幂级数的收敛半径; 圆  $ \left|z - a\right| < R $ 和圆周  $ \left|z - a\right| = R $ 分别称为它的收敛圆和收敛圆周. 在第一种情形, 约定 R = 0; 在第二种情形, 约定  $ R = +\infty $, 并也称它们为收敛半径.

一个幂级数在其收敛圆周上的敛散性有如下三种可能: (1) 处处发散; (2) 既有收敛点, 又有发散点; (3) 处处收敛.

2. 收敛半径 R 的求法、柯西 - 阿达马 (Hadamard) 公式.

定理 4.12 如果幂级数  $ \sum_{n=0}^{\infty} c_{n}(z-a)^{n} $ 的系数  $ c_{n} $ 介于

 $ \lim_{n\to\infty}\left|\frac{c_{n+1}}{c_n}\right|=l $，(达朗贝尔(D'Alembert))

或  $ \lim_{n\to\infty}\sqrt[n]{|c_n|}=l $，(柯西)

或  $ \lim_{n\to\infty}\sqrt[n]{|c_n|}=l $，(柯西-阿达马)

则幂级数  $ \sum_{n=0}^{\infty}c_{n}(z-a)^{n} $ 的收敛半径 $ ^{①} $

$$  R=\left\{\begin{aligned}{}&{{}\frac{1}{l},}&{\quad l\neq0,l\neq+\infty;}\\ {}&{{}0,}&{\quad l=+\infty;}\\ {}&{{}+\infty,}&{\quad l=0.}\\ \end{aligned}\right.   \tag*{(4.4)}$$

例 4.5 试求下列各幂级数的收敛半径 R.

(1)

 $$ \sum_{n=1}^{\infty}\frac{z^{n}}{n^{2}} $$ 

解  $ R = \lim_{n \to \infty} \left| \frac{c_n}{c_{n+1}} \right| = \lim_{n \to \infty} \left( \frac{n+1}{n} \right)^2 = 1 $.

(2)  $ \sum_{n=0}^{\infty}\frac{z^{n}}{n!} $.

解 因  $ l=\lim_{n\to\infty}\left|\frac{c_{n+1}}{c_n}\right|=\lim_{n\to\infty}\frac{1}{(n+1)!}= $0,

<!-- page: 174 -->

故  $ R = +\infty $.

(3)  $ \sum_{n=0}^{\infty} n! z^{n} $.

解 因  $ l=\lim_{n\to\infty}\left|\frac{c_{n+1}}{c_n}\right|=\lim_{n\to\infty}\frac{(n+1)!}{n!}=+\infty $,

故

 $$ \boldsymbol{R}=\boldsymbol{0}. $$ 

(4)  $ 1 + z^{2} + z^{4} + z^{9} + \cdots $

解 因当 n 是平方数时  $ c_{n}=1 $，其他情形  $ c_{n}=0 $。因此，相应有  $ \sqrt[n]{|c_{n}|}=1 $ 或 0，于是数列  $ \left\{\sqrt[n]{|c_{n}|}\right\} $ 的聚点是 0 和 1，从而 l=1, R=1。

(5)  $ \sum_{n=0}^{\infty} n! z^{n} $

解 因  $ C_{n}=n!,\lim_{n\to\infty}\sqrt[n]{|c_{n}|}=\infty, $

 $ \therefore\quad R=0. $

### 3. 幂级数和的解析性

定理 4.13 （1）幂级数

$$  f(z)=\sum_{n=0}^{\infty}c_{n}\left(z-a\right)^{n}   \tag*{(4.5)}$$

的和函数  $ f(z) $ 在其收敛圆 K:  $ \left|z - a\right| < R $ ( $ 0 < R \leq +\infty $) 内解析.

（2）在 K 内，幂级数（4.5）可以逐项求导至任意阶，即

$$  \begin{align*}f^{(p)}\left(z\right)&=p!c_{p}+\left(p+1\right)p\cdots2c_{p+1}\left(z-a\right)+\cdots\\&\quad+n\left(n-1\right)\cdots\left(n-p+1\right)c_{n}\left(z-a\right)^{n-p}+\cdots.\\\left(p&=1,2,\cdots\right)\tag{4.}\end{align*}   \tag*{(4.6)}$$

还有，(4.6)与(4.5)的收敛半径 R 相同(本章习题(一)3).

（3）

$$  c_{p}=\frac{f^{(p)}(a)}{p!}\quad(p=0,1,2,\cdots).   \tag*{(4.7)}$$

证 由阿贝尔定理(定理4.10)，幂级数

<!-- page: 175 -->

$$ \sum_{n=0}^{\infty}c_{n}\left(z-a\right)^{n} $$ 

在其收敛圆  $ K: |z - a| < R $ ( $ 0 < R \leq +\infty $) 内内闭一致收敛于  $ f(z) $，而其各项  $ c_{n}(z - a)^{n} $ ( $ n = 0, 1, 2, \cdots $) 又都在 z 平面上解析。故由魏尔斯特拉斯定理（定理 4.9），本定理的 (1)、(2) 部分得证。逐项求 p 阶导数 (p = 1, 2,  $ \cdots $) 后，即得 (4.6)。

在(4.6)中令 z=a，得

 $$ c_{p}=\frac{f^{(p)}(a)}{p!}\qquad(p=1,2,\cdots), $$ 

注意到  $ c_{0}=f(a)=f^{(0)}(a) $，即得(4.7).

注 （1）本定理还有一条结论：级数(4.5)可沿 K 内曲线 C 逐项积分，且其收敛半径与原级数(4.5)的收敛半径 R 相同（本章习题(一)3）.

(2) 所有的幂级数(4.5)至少在中心 a 是收敛的,但收敛半径等于零的幂级数没有什么有益的性质,是平凡情形.

#### §3. 解析函数的泰勒(Taylor)展式

这一节主要研究在圆内解析的函数展开成幂级数的问题.

1. 泰勒定理 由定理4.13(1)我们看到,任意一个具有非零收敛半径的幂级数在其收敛圆内收敛于一个解析函数,这个性质是很重要的.但在解析函数的研究上,幂级数之所以重要,还在于这个性质的逆命题也是成立的,即有

定理 4.14 （泰勒定理）设  $ f(z) $ 在区域 D 内解析,  $ a \in D $, 只要圆 K: |z - a| < R 含于 D, 则  $ f(z) $ 在 K 内能展成幂级数

$$  f(z)=\sum_{n=0}^{\infty}c_{n}(z-a)^{n},   \tag*{(4.8)}$$

其中系数

$$  c_{n}=\frac{1}{2\pi i}\int_{r_{o}}\frac{f(\zeta)}{\left(\zeta-a\right)^{n+1}}\mathrm{d}\zeta=\frac{f^{(n)}(a)}{n!}.   \tag*{(4.9)}$$

（积分形式）

 $$ ( 微分形式 ) $$

<!-- page: 176 -->

$$ (\Gamma_{\rho}:|\zeta-a|=\rho,0<\rho<R;n=0,1,2,\cdots) $$ 

且展式是惟一的.

证 证明的关键是利用柯西积分公式及如下熟知的公式

$$  \frac{1}{1-u}=\sum_{n=0}^{\infty}u^{n}\qquad(\mid u\mid<1).   \tag*{(4.10)}$$

设 z 为 K 内任意取定的点，总有一个圆周  $ \Gamma_{\rho}: |\zeta - a| = \rho (0 < \rho < R) $，使点 z 含在  $ \Gamma_{\rho} $ 的内部（图 4.1 中虚线表  $ \Gamma_{\rho} $）。由柯西积分公式得

<div style="text-align: center;"><img src="images/p0176_img_in_image_box_1448_2164_2963_3598.jpg" alt="图4.1" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图4.1</div> </div>


 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\int_{r_{p}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta. $$ 

我们设法将被积式 $ \frac{f(\zeta)}{\zeta-z} $表为含有z-a的正幂次的级数.为此写

$$  \frac{f(\zeta)}{\zeta-z}=\frac{f(\zeta)}{\zeta-a-(z-a)}=\frac{f(\zeta)}{\zeta-a}\cdot\frac{1}{1-\frac{z-a}{\zeta-a}},   \tag*{(4.11)}$$

当  $ \zeta \in \Gamma_{\rho} $ 时，由于

 $$ \left|\frac{z-a}{\zeta-a}\right|=\frac{\left|z-a\right|}{\rho}<1, $$

<!-- page: 177 -->

应用公式(4.10)，我们有

 $$ \frac{1}{1-\frac{z-a}{\zeta-a}}=\sum_{n=0}^{\infty}\left(\frac{z-a}{\zeta-a}\right)^{n}, $$ 

等号右端的级数在  $ \Gamma_{\rho} $ 上(关于  $ \zeta $) 是一致收敛的. 以  $ \Gamma_{\rho} $ 上的有界函数  $ \frac{f(\zeta)}{\zeta-a} $ 相乘, 仍然得到  $ \Gamma_{\rho} $ 上的一致收敛级数. 于是(4.11)表示为  $ \Gamma_{\rho} $ 上一致收敛级数

 $$ \frac{f(\zeta)}{\zeta-z}=\sum_{n=0}^{\infty}(z-a)^{n}\cdot\frac{f(\zeta)}{(\zeta-a)^{n+1}}, $$ 

将上式沿  $ \Gamma_{\rho} $ 积分，并以  $ \frac{1}{2\pi i} $ 乘所得结果. 根据逐项积分定理，即得

 $$ \begin{align*}f(z)&=\frac{1}{2\pi\mathrm{i}}\int_{r_{\rho}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\\&=\sum_{n=0}^{\infty}(z-a)^{n}\cdot\frac{1}{2\pi\mathrm{i}}\int_{r_{\rho}}\frac{f(\zeta)}{(\zeta-a)^{n+1}}\mathrm{d}\zeta,\end{align*} $$ 

由定理 3.13 知

 $$ \frac{1}{2\pi i}\int_{\Gamma_{\rho}}\frac{f(\zeta)}{\left(\zeta-a\right)^{n+1}}\mathrm{d}\zeta=\frac{f^{(n)}(a)}{n!}, $$ 

最后得出

 $$ f(\overset{,}{z})=\sum_{n=0}^{\infty}c_{n}(z-a)^{n}. $$ 

其中的系数  $ c_{n} $ 由公式(4.9)给出.上面的证明对任意  $ z \in K $ 均成立,故定理的前半部分得证..

下面证明展式是惟一的.

设另有展式

 $$ f(z)=\sum_{n=0}^{\infty}c^{\prime}_{n}(z-a)^{n}(z\in K:|z-a|<R). $$ 

由定理 4.13(3)，即知

 $$ c_{n}^{\prime}=\frac{f^{(n)}(a)}{n!}=c_{n}\quad(n=0,1,2,\cdots), $$

<!-- page: 178 -->

故展式是惟一的.

显然幂级数(4.8)的收敛半径大于或等于 R.

定义 4.6 (4.8) 称为  $ f(z) $ 在点 a 的泰勒展式，(4.9) 称为其泰勒系数，而 (4.8) 等号右边的级数，则称为泰勒级数.

综合定理 4.13(1) 和定理 4.14 可得出刻画解析函数的第四个等价定理：

定理 4.15 函数  $ f(z) $ 在区域 D 内解析的充要条件为:  $ f(z) $ 在 D 内任一点 a 的邻域内可展成 z - a 的幂级数, 即泰勒级数.

由第三章的柯西不等式知，若  $ f(z) $ 在  $ \left|z - a\right| < R $ 内解析，则其泰勒系数  $ c_{n} $ 满足柯西不等式

 $$ \left|c_{n}\right|\leqslant\frac{\max\limits_{\left|z-a\right|=\rho}\left|f(z)\right|}{\rho^{n}}(0<\rho<R,n=0,1,2,\cdots). $$ 

### 2. 幂级数的和函数在其收敛圆周上的状况

泰勒展式(4.8)仅限于 z 在  $ \Gamma_{\rho} $ (图 4.1) 的内部时方能成立，而  $ \Gamma_{\rho} $ 又只需在  $ f(z) $ 的解析区域 D 内就行，其大小并无限制。故展式 (4.8) 在以 a 为心，通过与 a 最接近的  $ f(z) $ 之奇点的圆周内部皆成立。事实上，我们有

定理 4.16 如果幂级数  $ \sum_{n=0}^{\infty} c_{n} (z - a)^{n} $ 的收敛半径 R > 0，且

 $$ f(z)=\sum_{n=0}^{\infty}c_{n}(z-a)^{n}\quad(z\in K;|z-a|<R), $$ 

则  $ f(z) $ 在收敛圆周 C:  $ \left|z - a\right| = R $ 上至少有一奇点，即不可能有这样的函数  $ F(z) $ 存在，它在  $ \left|z - a\right| < R $ 内与  $ f(z) $ 恒等，而在 C 上处处解析.

证 假若这样的  $ F(z) $ 存在，这时 C 上的每一点就都是某圆 O 的中心，而在圆 O 内  $ F(z) $ 是解析的。根据有限覆盖定理，我们就可以在这些圆 O 中选取有限个圆将 C 覆盖了。这有限个圆构成

<!-- page: 179 -->

一个区域 G，用  $ \rho>0 $ 表 C 到 G 的边界的距离（参看第三章定理3.3注）。于是， $ F(z) $ 在较圆 K 大的同心圆  $ K^{\prime}: |z-a|<R+\rho $ 内是解析的。于是  $ F(z) $ 在  $ K^{\prime} $ 中可展开为泰勒级数。但因在  $ |z-a|<R $ 中  $ F(z)\equiv f(z) $，故在 z=a 处它们以及各阶导数有相同的值，因此级数  $ \sum_{n=0}^{\infty}c_{n}(z-a)^{n} $ 也是  $ F(z) $ 的泰勒级数，而它的收敛半径不会小于  $ R+\rho $，这与假设矛盾。

现在,我们立即可得—确定收敛半径 R 的方法:

设  $ f(z) $ 在点 a 解析, b 是  $ f(z) $ 的奇点中距 a 最近的一个奇点, 则  $ \left| b - a \right| = R $ 即为  $ f(z) $ 在点 a 的邻域内的幂级数展式  $ \sum_{n=0}^{\infty} c_{n}(z - a)^{n} $ 的收敛半径.

注（1）纵使幂级数在其收敛圆周上处处收敛，其和函数在收敛圆周上仍然至少有一个奇点.

例如，

 $$ f(z)=\frac{z}{1^2}+\frac{z^2}{2^2}+\frac{z^3}{3^2}+\cdots+\frac{z^n}{n^2}+\cdots, $$ 

由例 4.5(1) 知其收敛半径 R = 1 > 0，而在圆周  $ \left|z\right| = 1 $ 上级数

 $$ \sum_{n=1}^{\infty}\left|\frac{z^{n}}{n^{2}}\right|:=\sum_{n=1}^{\infty}\frac{1}{n^{2}} $$ 

是收敛的，所以原级数  $ \sum_{n=1}^{\infty}\frac{z^{n}}{n^{2}} $ 在收敛圆周  $ \left|z\right|=1 $ 上是处处绝对收敛的；从而  $ \sum_{n=1}^{\infty}\frac{z^{n}}{n^{2}} $ 在闭圆  $ \left|z\right|\leq1 $ 上绝对且一致收敛。但

 $$ f^{\prime}\left(z\right)=1+\frac{z}{2}+\frac{z^{2}}{3}+\cdots+\frac{z^{n-1}}{n}+\cdots\quad\left(\mid z\mid<1\right) $$ 

当 z 沿实轴从单位圆内趋于 1 时， $ f'(z) $ 趋于  $ +\infty $，所以 z=1 是  $ f(z) $ 的一个奇点.

（2）这个定理，一方面建立了幂级数的收敛半径与此幂级数

<!-- page: 180 -->

所代表的函数的性质之间的密切关系；同时，还表明幂级数的理论只有在复数域内才弄得完全明白。

例如，在实数域内便不了解：为什么仅当  $ |x|<1 $ 时有展式

 $$ \frac{1}{1+x^{2}}=1-x^{2}+x^{4}-x^{6}+\cdots, $$ 

而函数 $ \frac{1}{1+x^{2}} $对于独立变数x的所有的值都是确定的，且在全实轴上有任意阶导数.这个现象从复变数的观点来看，就完全可以解释清楚.实际上，函数 $ \frac{1}{1+z^{2}} $在z平面上有两个奇点，即 $ z=\pm i $.故我们所考虑的级数的收敛半径等于1.

思考题（1）读者可以将实变函数中无穷多阶可微函数展开为泰勒级数和复变函数中解析函数展开为泰勒级数，两者的条件作一比较.

（2）试列举在区域 D 内解析的函数的种种等价刻画（包括定义 2.2）.

幂级数在它的收敛圆内绝对收敛.因此两个幂级数在收敛半径较小的那个圆域(两圆心相同)内,不但可作加法、减法,还可作乘法.至于除法,我们将通过乘法及待定系数法来解决.

3. 一些初等函数的泰勒展式 一些初等函数的泰勒展开方法，一般不采取计算泰勒系数(4.9)的直接法；而是，常采取借用一些已知展开式来计算要求展式的间接法。下面给出几个初等函数的泰勒展式，它们的形式与数学分析中大家熟知的形式是一致的。

例 4.6 函数  $ f(z) = e^{z} $ 在 z 平面上解析，它在 z = 0 处的泰勒系数为

 $$ c_{n}=\frac{f^{(n)}(0)}{n!}=\frac{1}{n!}\quad(n=0,1,2,\cdots), $$ 

于是有

 $$ \mathrm{e}^{z}=1+z+\frac{z^{2}}{2!}+\cdots+\frac{z^{n}}{n!}+\cdots\quad(|z|<+\infty). $$

<!-- page: 181 -->

例 4.7 我们利用  $ e^{z} $ 的上述展式求得

 $$ \cos z=\frac{\mathrm{e}^{\mathrm{i}z}+e^{-\mathrm{i}z}}{2}=\frac{1}{2}\sum_{n=0}^{\infty}\frac{(\mathrm{i}z)^{n}}{n!}+\frac{1}{2}\sum_{n=0}^{\infty}\frac{(-\mathrm{i}z)^{n}}{n!}. $$ 

注意到两个级数的奇次方项互相抵消，故得

 $$ \cos z=\sum_{n=0}^{\infty}\frac{(-1)^{n}z^{2n}}{(2n)!}\quad(|z|<+\infty); $$ 

同理又可得

 $$ \sin z=\sum_{n=0}^{\infty}\frac{\left(-1\right)^{n}z^{2n+1}}{\left(2n+1\right)!}\quad\left(\mid z\mid<+\infty\right). $$ 

根据泰勒展式的惟一性,上两个展式分别是  $ \cos z $ 及  $ \sin z $ 在 z 平面上的泰勒展式.

例 4.8 多值函数  $ \mathrm{Ln}(1+z) $ 以  $ z = -1, \infty $ 为支点，将 z 平面沿负实轴从 -1 到  $ \infty $ 割破，在这样得到的区域 G（特别在单位圆  $ |z|<1 $）内， $ \mathrm{Ln}(1+z) $ 可以分出无穷多个单值解析分支。先取主值支  $ f_{0}(z)=(\ln(1+z))_{0} $ 在单位圆内展成 z 的幂级数。为此先计算其泰勒系数。由于

 $$ f_{0}^{\prime}\left(z\right)=\frac{1}{1+z},\cdots,f_{0}^{\left(n\right)}\left(z\right)=\left(-1\right)^{n-1}\frac{\left(n-1\right)!}{\left(1+z\right)^{n}}, $$ 

所以其泰勒系数为

 $$ c_{n}=\frac{f_{0}^{(n)}(0)}{n!}=\frac{(-1)^{n-1}}{n}\quad(n=1,2,\cdots), $$ 

因为  $ f_{0}(z)=(\ln(1+z))_{0} $ 是主值，即在  $ 1+z $ 取正实数时， $ (\ln(1+z))_{0} $ 取实数，于是有  $ f_{0}(0)=0 $。最后得出

$$  \begin{aligned}\left(\ln(1+z)\right)_{0}=z-\frac{z^{2}}{2}+\frac{z^{3}}{3}-\cdots+(-1)^{n-1}\frac{z^{n}}{n}+\cdots,\ $ |z|<1)\end{aligned}   \tag*{(4.12)}$$

所以  $ \mathrm{Ln}(1+z) $ 的各支的展式应该是

 $$ \begin{align*}(\ln(1+z))_{k}&=2k\pi\mathrm{i}+z-\frac{\stackrel{,}{z}{}^{2}}{2}+\frac{z^{3}}{3}+\cdots+(-1)^{n-1}\frac{z^{n}}{n}+\cdots.\\&(\mid z\mid<1;k=0,\pm1,\pm2,\cdots)\end{align*} $$

<!-- page: 182 -->

例 4.9 按一般幂函数的定义

 $$ \left(1+z\right)^{\alpha}=\mathrm{e}^{\alpha\mathrm{Ln}\left(1+z\right)}\quad.(\alpha 为复数 ), $$ 

它的支点也是  $ -1, \infty $，故  $ (1 + z)^{a} $ 在  $ \left|z\right| < 1 $ 内也能分出单值解析分支。取其主值支

 $$ g(z)=(1+z)^{\alpha}=\mathrm{e}^{\alpha[\ln(1+z)]_{0}} $$ 

在 z=0 处展开. 我们先算泰勒系数, 为此令

 $$ g\left(z\right)=\mathrm{e}^{a f_{0}\left(z\right)}\quad\left(f_{0}\left(z\right) 就是上例中的 \left[\ln(1+z)\right]_{0}\right), $$ 

按复合函数求导法则得

 $$ g^{\prime}\left(\mathcal{Z}\right)=\mathrm{e}^{a f_{0}\left(z\right)}\cdot a f_{0}^{\prime}\left(z\right), $$ 

为了方便继续求导，注意到

 $$ \begin{array}{c}{\displaystyle f_{0}^{\prime}\left(z\right)=\frac{1}{1+z}=\frac{1}{\mathrm{e}^{\left[\ln\left(1+z\right)\right]_{0}}}=\frac{1}{\mathrm{e}^{f_{0}\left(z\right)}},}\\ {\displaystyle g^{\prime}\left(z\right)=\alpha\mathrm{e}^{\left(a-1\right)f_{0}\left(z\right)},}\end{array} $$ 

所以

继续求导,每次应用  $ f_{0}^{\prime}(z)=\frac{1}{\mathrm{e}^{f_{0}(z)}} $, 即得

 $$ g^{(n)}(z)=\alpha(\alpha-1)\cdots(\alpha-n+1)\mathrm{e}^{(a-n)f_{0}(z)}, $$ 

我们得出泰勒系数为

 $$ g\left(0\right)=1,\frac{g^{\left(n\right)}\left(0\right)}{n!}=\frac{\alpha\left(\alpha-1\right)\cdots\left(\alpha-n+1\right)}{n!},\\\left(n=1,2,\cdots\right) $$ 

于是得出 $ (1+z)^{a} $ 的主值支的展式为

$$  \begin{align*}(1+z)^{a}&=1+\alpha z+\frac{\alpha(a-1)}{2!}z^{2}+\cdots\\&\quad+\frac{\alpha(a-1)\cdots(a-n+1)}{n!}z^{n}+\cdots.\end{align*}   \tag*{(4.13)}$$

利用一些基本的展式,又可导出其它一些函数的展式.

例 4.10 将  $ \frac{e^{z}}{1-z} $ 在 z=0 展开成幂级数.

解 因  $ \frac{e^{z}}{1-z} $ 在  $ \left|z\right|<1 $ 内解析，故展开后的幂级数在  $ \left|z\right|<1 $

<!-- page: 183 -->

内收敛.已经知道：

 $$ \mathrm{e}^{z}=1+z+\frac{z^{2}}{2!}+\frac{z^{3}}{3!}+\cdots,\quad\left(\mid z\mid<+\infty\right), $$ 

 $$ \frac{1}{1-z}=1+z+z^{2}+z^{3}+\cdots\quad\left(\mid z\mid<1\right), $$ 

在 $ \left|z\right|<1 $时将两式相乘得

 $$ \begin{aligned}\frac{\mathrm{e}^{z}}{1-\overline{z}}&=1+\binom{1+\frac{1}{1!}}{1+\frac{1}{1!}}z+\binom{1+\frac{1}{1!}+\frac{1}{2!}}{1+\frac{1}{1!}}z^{2}\\&\quad+\binom{1+\frac{1}{1!}+\frac{1}{2!}+\frac{1}{3!}}{1+\frac{1}{1!}+\frac{1}{2!}+\frac{1}{3!}}z^{3}+\cdots.\end{aligned} $$ 

相乘的方法，可按定理4.4所指出的对角线方法.

例 4.11 求  $ \sqrt{z+i}\left(\sqrt{i}=\frac{1+i}{\sqrt{2}}\right) $ 的展开式.

解 因  $ \sqrt{z+i} $ 的支点为 -i 及  $ \infty $，故其指定分支在  $ \left|z\right|<1 $ 内单值解析.

 $$ \begin{align*}\sqrt{z+i}&=\sqrt{i}\sqrt{1+\frac{z}{i}}=\sqrt{i}\left(1+\frac{z}{i}\right)^{\frac{1}{2}}\\&=\frac{1+i}{\sqrt{2}}\left[1+\frac{1}{2}\cdot\frac{z}{i}+\frac{\frac{1}{2}\left(\frac{1}{2}-1\right)}{\frac{1}{2}-1\cdot\frac{1}{2}}\left(\frac{z}{i}\right)^{2}+\cdots\right]\\&=\frac{1+i}{\sqrt{2}}\left(1-\frac{i}{2}z+\frac{1}{8}z^{2}+\cdots\right)\quad\because\left(\left|z\right|<1\right),\end{align*} $$ 

其一般表达式为:当 $ |z|<1 $时

 $$ \sqrt{z+\mathrm{i}}=\frac{1+\mathrm{i}}{\sqrt{2}}\left(\underbrace{\mathbf{1}_{.}}_{-\cdot}-\frac{\mathrm{i}}{2}z\right.-\sum_{\substack{\pi=2\\ }}^{\infty}\frac{\mathbf{1}\cdot\mathbf{3}\cdots(2n-3)}{2\cdot4\cdots(2n)}\mathrm{i}^{n}z^{n}\left.\right) $$ 

例 4.12 将  $ e^{z}\cos z $ 及  $ e^{z}\sin z $ 展为 z 的幂级数.

 $$ \begin{array}{l}\mathrm{e}^{z}\left(\cos z+\mathrm{i}\sin z\right)=\mathrm{e}^{z}\mathrm{e}^{\mathrm{i}z},\\=\mathrm{e}^{(1+\mathrm{i})z}=\mathrm{e}^{\sqrt{2}\mathrm{e}^{\frac{\pi}{4}1}z}\\=1+\sqrt{2}\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}z+\sum_{n=2}^{\infty}\frac{\left(\sqrt{2}\right)^{n}\mathrm{e}^{\frac{n\pi}{4}\mathrm{i}}z^{n}}{n!},\end{array} $$

<!-- page: 184 -->

同理

 $$ \begin{array}{l}{\mathrm{e}^{z}\left(\cos z-\mathrm{i}\sin z\right)=\mathrm{e}^{\sqrt{2}\mathrm{e}^{-\frac{\pi}{4}\mathrm{i}}z}}\\ {=1+\sqrt{2}\mathrm{e}^{-\frac{\pi}{4}\mathrm{i}}z+\displaystyle\sum_{n=2}^{\infty}\frac{\left(\sqrt{2}\right)^{n}\mathrm{e}^{-\frac{n\pi}{4}\mathrm{i}}z^{n}}{n!}.}\end{array} $$ 

两式相加除以2得

 $$ \begin{align*}\mathrm{e}^{z}\cos z&=1+\sqrt{2}\cos\frac{\pi}{4}z+\sum_{n=2}^{\infty}\frac{(\sqrt{2})^{n}\cos\frac{n\pi}{4}}{n!}z^{n}\\&=2+\sum_{n=2}^{\infty}\frac{(\sqrt{2})^{n}\cos\frac{n\pi}{4}}{n!}z^{n},|z|<+\infty;\end{align*} $$ 

两式相减除以 2i 得

 $$ \begin{align*}\textrm{e}^{z}\sin^{'}{z}&=\sqrt[3]{2}\sin^{i}\frac{\pi}{4}z+\sum_{n=2}^{\infty}\frac{(\sqrt{2})^{n}\sin\frac{n\pi}{4}}{n!}z^{n}\\&=1+\sum_{n=2}^{\infty}\frac{(\sqrt{2})^{n}\sin\frac{n\pi}{4}}{n!}z^{n},|z|<\bar{+}\infty.\end{align*} $$ 

例 4.13 试将函数

 $$ f(z)=\frac{z}{z+2} $$ 

按 z-1 的幂展开，并指明其收敛范围.

解

 $$ \begin{align*}f(z)&=\frac{z}{z+2}=1-\frac{2}{z+2}=1-\frac{2}{(z-1)+3}\\&=1-\frac{2}{3}\cdot\frac{\cdot\cdot\cdot}{1+\frac{z-1}{3}}=1-\frac{2}{3}\sum_{n=0}^{\infty}\left(\cdot-1\right)^{n}\left(\frac{z-1}{3}\right)^{n}\\&=\frac{1}{3}-\frac{2}{3}\sum_{n=1}^{\infty}\left(-\frac{1}{3}\right)^{n}(z-1)^{n}\left(\mid z-1\mid<3\right).\end{align*} $$ 

*例 4.14 设  $ \frac{1}{1-z-z^{2}}=\sum_{n=0}^{\infty}c_{n}z^{n} $.

（1）证明  $ c_{n}=c_{n-1}+c_{n-2}(n\geqslant2) $;

<!-- page: 185 -->

（2）求出展式的前五项；

（3）指出收敛范围.

解 （1）解法一 利用系数公式(4.9)的积分形式，有

 $$ \begin{align*}c_{n-1}+c_{n-2}&=\frac{1}{2\pi\mathrm{i}}\int_{r_\rho:|\zeta|=\rho}\frac{1}{1-\zeta-\zeta^{2}}\left(\frac{1}{\zeta^{n}}+\frac{1}{\zeta^{n-1}}\right)\mathrm{d}\zeta\\&=\frac{1}{2\pi\mathrm{i}}\int_{r_\rho}\frac{1+\zeta}{\zeta^{n}\left(1-\zeta-\zeta^{2}\right)}\mathrm{d}\zeta\\&=\frac{1}{2\pi\mathrm{i}}\int_{r_\rho}\frac{\zeta+\zeta^{2}}{\frac{1-\zeta-\zeta^{2}}{\zeta^{n+1}}}\mathrm{d}\zeta\\&=\frac{1}{2\pi\mathrm{i}}\int_{r_\rho}\frac{1-\zeta-\zeta^{2}}{\frac{1-\zeta-\zeta^{2}}{\zeta^{n+1}}}\mathrm{d}\zeta\\&-\frac{1}{2\pi\mathrm{i}}\int_{r_\rho}\frac{1}{\zeta^{n+1}}\mathrm{d}\zeta=c_n\quad(n\geqslant2).\end{align*} $$ 

解法二 利用待定系数法，有

 $$ \begin{aligned}1&=\left(1-z-z^{2}\right)\left(c_{0}+c_{1}z+c_{2}z^{2}+\cdots+c_{n-2}z^{n-2}+c_{n-1}z^{n-1}\right.\\&\quad\left.+c_{n}z^{n}+\cdots\right)\\&=c_{0}+c_{1}\left|z+c_{2}\right|\left.z^{2}+\cdots+c_{n}\right|\\&\quad-c_{0}\left|-c_{1}\right|\\&\quad-c_{0}\left|-c_{1}\right|\\&\quad-c_{0}\\&z^{n}+\cdots.\\&\quad\left|z^{n}+c_{n-1}\right|\\&-c_{n-2}\\&-c_{n-2}\end{aligned} $$ 

比较两端同次幂的系数得

 $$ c_{0}=1;c_{1}-c_{0}=0,c_{2}-c_{1}-c_{0}=0,\cdots,c_{n}-c_{n-1}-c_{n-2}=0, $$ 

所以  $ c_{0}=1, c_{1}=c_{0}=1, c_{2}=c_{1}+c_{0}=2, \cdots $

 $$ c_{n}=c_{n-1}+c_{n-2}\qquad(n\geqslant2). $$ 

(2)

 $$ c_{0}=\frac{1}{1-z-z^{2}}\bigg|_{z=0}=1, $$ 

 $$ c_{1}=\left(\frac{1}{1-z-z^{2}}\right)_{z=0}^{\prime}=\frac{1+2z}{(1-z-z^{2})^{2}}\bigg|_{z=0}=1, $$ 

从而由(1)依次得  $ c_{2}=c_{1}+c_{0}=1+1=2 $

<!-- page: 186 -->

$$ c_{3}=c_{2}+c_{1}=2+1=3, $$ 

 $$ c_{4}=c_{3}+c_{2}=3+2=5, $$ 

即  $ \frac{1}{1-z-z^{2}}=1+z+2z^{2}+3z^{3}+5z^{4}+\cdots $.

（3）因由  $ 1-z-z^{2}=0 $ 解得  $ z=\frac{-1\pm\sqrt{5}}{2} $，它们是和函数的两个奇点。故知收敛圆为

 $$ |z|<\frac{\sqrt{5}-1}{2}. $$ 

注 在有关单叶解析函数的文献中，常见把单位圆  $ |z|<1 $ 内解析的函数  $ f(z) $ 规范成展式

 $$ f(z)=z+a_{1}z^{2}+\cdots,|z|<1, $$ 

它合乎标准化条件  $ f(0)=0, f'(0)=1 $，其中  $ a_{1} $ 为复常数.

#### §4. 解析函数零点的孤立性及惟一性定理

在很多实际问题中，往往需要研究使一个函数等于零的点，也就是求根。最简单的情况是：在解常系数线性微分方程时，将这个问题转化为求其特征多项式的根的问题。一个 n 次多项式有 n 个根，而多项式是解析函数，那么一个解析函数有几个根呢？在一般情况下，它可能有无穷多个根。那么这无穷多个可能的根的分布情况如何呢？这个问题是属于值的分布论中的问题。这一节，我们从函数  $ f(z) $ 根的分布情况来研究  $ f(z) \equiv 0 $ 的问题。

### 1. 解析函数零点的孤立性

定义 4.7 设函数  $ f(z) $ 在解析区域 D 内一点 a 的值为零，则称 a 为解析函数  $ f(z) $ 的零点.

如果在  $ \left|z - a\right| < R $ 内，解析函数  $ f(z) $ 不恒为零，我们将  $ f(z) $ 在点 a 展成幂级数，此时，幂级数的系数必不全为零。故必有一正整数  $ m (m \geqslant 1) $，使得

<!-- page: 187 -->

$$ f(a)=f^{\prime}(a)=\cdots=f^{(m-1)}(a)=0, 但 f^{(m)}(a)\neq0 $$ 

合乎上述条件的 m 称为  $ \uwave{\text{零点 a 的阶}} $，a 称为  $ f(z) $ 的 m 阶零点. 特别是当 m=1 时，a 也称为  $ f(z) $ 的单零点.

定理 4.17 不恒为零的解析函数  $ f(z) $ 以 a 为 m 阶零点的充要条件为：

$$  f(z)=(z-a)^{m}\varphi(z),   \tag*{(4.14)}$$

其中  $ \varphi(z) $ 在点 a 的邻域  $ \left|z-a\right|<R $ 内解析，且  $ \varphi(a)\neq0 $.

证 必要性 由假设，

 $$ f(z)=\frac{f^{(m)}(a)}{m!}(z-a)^{m}+\frac{f^{(m+1)}(a)}{(m+1)!}(z-a)^{m+1}+\cdots, $$ 

只要设  $ \varphi(z)=\frac{f^{m}(a)}{m!}+\frac{f^{(m+1)}(a)}{(m+1)!}(z-a)+\cdots, $

就得到(4.14).

充分性 证明留给读者.

(4.14)是具有 m 阶零点 a 的解析函数  $ f(z) $ 的解析表达式.

例 4.15 考察函数

 $$ f(z)=z-\sin z $$ 

在原点 z=0 的性质.

解 显然  $ f(z) $ 在 z=0 解析，且  $ f(0)=0 $.

由

 $$ \begin{aligned}f(z)&=z-\left(z-\frac{z^{3}}{3!}+\frac{z^{5}}{5!}-\cdots\right)\\&=z^{3}\left(\frac{1}{3!}-\frac{z^{2}}{5!}+\cdots\right),\end{aligned} $$ 

或由

 $$ f^{\prime}(z)=1-\cos z,f^{\prime}(0)=1-1=0, $$ 

 $$ f^{\prime\prime}(z)=\sin z,\quad f^{\prime\prime}(0)=0, $$ 

 $$ f^{\prime \prime}(z)\rightrightarrows\cos z,\quad f^{\prime \prime}(0)=1\neq0. $$ 

知 z=0 为  $ f(z)=z-\sin z $ 的三阶零点.

例 4.16 求  $ \sin z - 1 $ 的全部零点，并指出它们的阶.

解  $ \sin z - 1 $ 在 z 平面上解析. 由  $ \sin z - 1 = 0 $ 得

 $$ \mathrm{e}^{\mathrm{i}z}-\mathrm{e}^{-\mathrm{i}z}=2\mathrm{i}, $$

<!-- page: 188 -->

即

 $$ \left(\mathrm{e}^{\mathrm{i}z}-\mathrm{i}\right)^{2}=0,\mathrm{e}^{\mathrm{i}z}=\mathrm{i}, $$ 

故

 $$ z=\frac{\pi}{2}+2k\pi\qquad(k=0,\pm1,\cdots), $$ 

这就是  $ \sin z-1 $ 在 z 平面上的全部零点.

显然

 $$ \left(\sin z-1\right)^{\prime}\left|_{z=\frac{\pi}{2}+2k\pi}\right.=\cos z\left|_{z=\frac{\pi}{2}+2k\pi}\right.=0, $$ 

 $$ \left(\sin z-1\right)^{\prime\prime}\bigg|_{z=\frac{\pi}{2}+2k\pi}=-\left.\sin z\right|_{z=\frac{\pi}{2}+2k\pi}=-1\neq0, $$ 

故

 $$ z=\frac{\pi}{2}+2k\pi\qquad(k=0,\pm1,\pm2,\cdots) $$ 

都是函数  $ \sin z - 1 $ 的二阶零点.

一个实变可微函数的零点不一定是孤立的；例如实变函数

 $$ f(x)=\left\{\begin{aligned}&x^{2}\sin\frac{1}{x},&x\neq0,\\ &0,&x=0\end{aligned}\right. $$ 

在点 x=0 可微，在实轴上其它地方也处处可微，且以 x=0 为一个零点。但  $ x=\pm\frac{1}{n\pi}(n=1,2,3,\cdots) $ 也是它的零点，并以 x=0 为聚点。所以尽管这里函数  $ f(x) $ 不恒为零，而 x=0 却不是一个孤立零点。但在复变函数中，我们有

定理 4.18 如在  $ \left|z - a\right| < R $ 内的解析函数  $ f(z) $ 不恒为零，a 为其零点，则必有 a 的一个邻域，使得  $ f(z) $ 在其中无异于 a 的零点。（简单说来就是：不恒为零的解析函数的零点必是孤立的。）

证 设 a 为  $ f(z) $ 的 m 阶零点，于是，由定理 4.17

 $$ f(z)\neq:(z-a)^{m}\varphi(z), $$ 

其中  $ \varphi(z) $ 在  $ |z-a|<R $ 内解析，且  $ \varphi(a)\neq0 $，从而  $ \varphi(z) $ 在点 a 连续。于是由例 1.28 知存在一邻域  $ |z-a|<r $ 使得  $ \varphi(z) $ 于其中恒不为零。故  $ f(z) $ 在其中无异于 a 的其它零点。

上述定理实际上告诉我们这样的结论：

<!-- page: 189 -->

推论4.19 设(1)函数  $ f(z) $ 在邻域 K: |z - a| < R 内解析;

(2) 在 K 内有  $ f(z) $ 的一列零点  $ \{z_{n}\}(z_{n} \neq a) $ 收敛于 a，则  $ f(z) $ 在 K 内必恒为零.

证 因为  $ f(z) $ 在点 a 连续，且  $ f(z_{n})=0 $，让 n 趋于无穷取极限，即得  $ f(a)=0 $。故 a 是一个非孤立的零点。由定理 4.18 必  $ f(z) $ 在 K 内恒为零。

注 为了便于应用,推论4.19中的条件(2)可代换成更强的条件“ $ f(z) $在K内某一子区域(或某一小段弧)上等于0”.

思考题 试举一例，说明  $ f(z) $ 在某区域 D 内解析且有无穷多个零点，但在 D 内  $ f(z) \neq 0 $；这与推论 4.19 矛盾吗？

2. 惟一性定理 对于一个不加条件限制的复变函数，我们不能从其定义域中某一部分的取值情况来确定其它部分的值。对于连续函数也只能说，相邻两点的函数值相差很小。对于解析函数来说就完全不同了。从下面的（内部）惟一性定理可以看出，解析函数在其定义域中某点邻域内的取值情况完全决定着它在其它部分的值。以前由柯西积分公式，曾经使我们知道，从解析函数在边界 C 上的值可以推得它在 C 的内部的一切值。因之（内部）惟一性定理可以看成柯西积分公式的补充定理，它们都反映解析函数的特性，同是解析函数论中最基本的定理。

定理 4.20 设(1) 函数  $ f_{1}(z) $ 和  $ f_{2}(z) $ 在区域 D 内解析；

(2) D 内有一个  $ \uwave{\text{收敛于  $ a \in D $ 的点列}} $  $ \{z_{n}\}(z_{n} \neq a) $，在其上  $ f_{1}(z) $ 和  $ f_{2}(z) $ 等值，则  $ f_{1}(z) $ 和  $ f_{2}(z) $ 在 D 内恒等.

证. 令  $ f(z)=f_{1}(z)-f_{2}(z) $ 我们只须证明  $ f(z) $ 在  $ D^{'} $ 内恒为零就行了.

由假设知  $ f(z) $ 在 D 内解析，且在 D 内有一列零点  $ \{z_{n}\}(z_{n} \neq a) $ 收敛于  $ a \in D $。如果 D 本身就是以 a 为心的圆，或 D 就是整个 z 平面，则由推论 4.19，即知  $ f(z) \equiv 0 $。定理就证明了。在一般情形下，可用下述所谓圆锥法来证明。

<!-- page: 190 -->

设 b 是 D 内任意固定的点（图 4.2）. 在 D 内可作一折线 L 连

设 $b$ 是 $D$ 内任意固定的点（图 4 接 $a$ 及 $b$，以 $d$ 表示 $L$ 与 $D$ 的边界 $\Gamma$ 间的最短距离（见第三章定理 3.3 注，$d>0$）。在 $L$ 上依次取一串点 $a = a_0, a_1, \cdots, a_{n-1}, a_n = b$，使相邻两点间的距离小于定数 $R$（$0 < R < d$）。显然，由推论 4.19，在圆 $K_0: |z - a_0| < R$ 内 $f(z) \equiv 0$。在圆 $K_1: |z - a_1| < R$ 又重复应用推论 4.19，即知在 $K_1$ 内 $f(z) \equiv 0$。这样继续下去，直到最后一个含有点 $b$ 的圆为止，在该圆内 $f(z) \equiv 0$，特别说来，$f(b) = 0$。因为 $b$ 是 $D$ 内任意的点，故证明了在 $D$ 内 $f(z) \equiv 0$。

推论 4.21 设在区域 D 内解析的函数  $ f_{1}(z) $ 及  $ f_{2}(z) $ 在 D 内的某一子区域（或一小段弧）上相等，则它们必在区域 D 内恒等.

<div style="text-align: center;"><img src="images/p0190_img_in_image_box_2439_756_4036_3631.jpg" alt="图4.2" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图4.2</div> </div>


例 4.17 设(1) 函数  $ f(z) $ 及  $ g(z) $ 在区域 D 内解析；

(2) 在 D 内  $ f(z)\cdot g(z)\equiv0 $,

试证:在 D 内  $ f(z) \equiv 0 $ 或  $ g(z) \equiv 0 $.

证 若有  $ z_{0} \in D $ 使  $ g(z_{0}) \neq 0 $. 因  $ g(z) $ 在点  $ z_{0} $ 连续，故由例 1.28 知，存在  $ z_{0} $ 的邻域  $ K \subsetneq D $，使  $ g(z) $ 在 K 内恒不为零。而由题设

 $$ f(z)\cdot g(z)\equiv0\quad(z\in K\subset D), $$ 

故必

 $$ f(z){\equiv}0\quad(z\in K\subset D). $$ 

由惟一性定理(推论 4.21)  $ f(z) \equiv 0 $,  $ \zeta_{z} \in D $.

推论 4.22 一切在实轴上成立的恒等式（例如， $ \sin^{2}z + \cos^{2}z $

<!-- page: 191 -->

=1, $ \sin 2z=2\sin z\cdot\cos z $ 等等)，在 z 平面上也成立，只要这个恒等式的等号两边在 z 平面上都是解析的.

注（1）推论 4.19 显然包含在定理 4.20 中，因此它们和推论 4.21、4.22 在引用时都称为解析函数的惟一性定理.

（2）惟一性定理揭示了解析函数一个非常深刻的性质，函数在区域 $ D $内的局部值确定了函数在区域 $ D $内整体的值，即局部与整体之间有着十分紧密的内在联系。

例 4.18. 应用惟一性定理，在  $ \left|z\right|<1 $ 内展开  $ \mathrm{Ln}(1+z) $ 的主值支成 z 的幂级数.

解 我们已知  $ \mathrm{Ln}(1+z) $ 的主值支  $ \ln(1+z) $ 在  $ \left|z\right|<1 $ 内解析. 又在数学分析中已知

 $$ \ln(1+x)=\sum_{n=0}^{\infty}\frac{(-1)^{n}x^{n+1}}{n+1},x\in(-1,1), $$ 

而幂级数

 $$ \sum_{n=0}^{\infty}\frac{\left(-1\right)^{n}z^{n+1}}{n+1} $$ 

的收敛半径为 1，即它在  $ \left|z\right|<1 $ 内收敛于一个解析函数  $ g(z) $。但在实轴的线段  $ (-1,1) $ 上

 $$ g\left(z\right)=\ln\left(1+z\right), $$ 

因此根据惟一性定理(推论 4.21)，在圆  $ \left|z\right|<1 $ 内

 $$ g\left(z\right)=\ln\left(1+z\right), $$ 

故得  $ \ln(1+z) $ 在  $ \left|z\right|<1 $ 内的幂级数展式为

 $$ \ln(1+z)=\sum_{n=0}^{\infty}\frac{(-1)^{n}z^{n+1}}{n+1}, $$ 

这与(4.12)一致.

由此例我们看出：应用惟一性定理（特别是推论 4.21 或 4.22），在数学分析中常见的一些初等函数的幂级数展式都可以推广到复数域上来.

3. 最大模原理 下面的定理是解析函数论中最有用的定理之一.

<!-- page: 192 -->

定理4.23(最大模原理) 设函数  $ f(z) $ 在区域 D 内解析，则  $ |f(z)| $ 在 D 内任何点都不能达到最大值，除非在 D 内  $ f(z) $ 恒等于常数.

证 如果用 M 表  $ \left|f(z)\right| $ 在 D 内的最小上界，则必  $ 0 < M < +\infty $。假定在 D 内有一点  $ z_{0} $，函数  $ f(z) $ 的模在  $ z_{0} $ 达到它的最大值，即  $ \left|f(z_{0})\right| = M $。

（1）应用平均值定理(定理3.12)于以 $ z_{0} $为中心，并且连同它的周界一起都全含于区域D内的一个圆 $ \left|z-z_{0}\right|<R $，就得到

 $$ f(z_{0})=\frac{1}{2\pi}\int_{0}^{2\pi}f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi. $$ 

由此推出

$$  \mid f(z_{0})\mid\leqslant\frac{1}{2\pi}\int_{0}^{2\pi}\mid f(z_{0}+R e^{\mathrm{i}\varphi})\mid\mathrm{d}\varphi.   \tag*{(4.15)}$$

由于

 $$ \mid f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mid\leqslant M, 而 \mid f(z_{0})\mid=M, $$ 

从不等式(4.15)就可以看出,对于任何  $ \varphi(0\leq\varphi\leq2\pi) $,

 $$ \mid f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mid=M. $$ 

事实上，如果对于某一个值  $ \varphi = \varphi_{0} $ 有

 $$ |f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi_{0}})|<M, $$ 

那么根据  $ \left|f(z)\right| $ 的连续性，不等式  $ \left|f\left(z_{0}+Re^{i\varphi}\right)\right|<M $ 在某个充分小的区间

 $$ \varphi_{0}-\varepsilon<\varphi<\varphi_{0}+\varepsilon $$ 

内成立. 同时, 在这个区间之外, 总是

 $$ \mid f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mid\leqslant M. $$ 

在这样的情况下，由(4.15)得

 $$ \pmb{M}=\mid f(z_{0})\mid\leqslant\frac{1}{2\pi}\int_{0}^{2\pi}\mid f(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi})\mid\mathrm{d}\varphi<M, $$ 

矛盾.因此,我们已经证明了:在以点 $ z_{0} $为中心的 $ \uwave{\text{每一个}} $充分小的圆周上 $ \left|f(z)\right|=M $.换句话说,在 $ z_{0} $点的足够小的邻域K内(K

<!-- page: 193 -->

及其周界全含于D内)有 $ \left|f(z)\right|=M $.

(2) 由第二章习题(一)6(3)，必  $ f(z) $ 在 K 内为一常数.

（3）由惟一性定理，必  $ f(z) $ 在 D 内为一常数.

推论 4.24 设(1) 函数  $ f(z) $ 在有界区域 D 内解析，在闭域  $ \overline{D} = D + \partial D $ 上连续；

 $$ |f(z)|\leqslant M\quad(z\in\bar{D}), $$ 

(2)

则除  $ f(z) $ 为常数的情形外， $ \left|f(z)\right|<M $ （ $ z\in D $）.

注 (1) 在柯西不等式中的  $ M(R) = \max_{|z - a| = R_{1\ldots}}\left|f(z)\right| $，现在也可以理解为  $ M(R) = \max_{|z - a| \leq p} |f(z)| $.

（2）读者可以应用本书第七章定理 7.1 的保域定理，来作出最大模原理的几何解释.

（3）最大模原理说明了解析函数在区域边界上的最大模可以限制区域内的最大模.这也是解析函数特有的性质.

例 4.19 试用最大模原理证明例 3.11. 即证：“设  $ f(z) $ 在闭圆  $ \left|z\right| \leqslant R $ 上解析，如果存在 a > 0，使当  $ \left|z\right| = R $ 时，

 $$ |f(z)|>a, $$ 

而且

 $$ |f(0)|<a, $$ 

则在圆  $ \left|z\right|<R $ 内， $ f(z) $ 至少有一个零点。”

证 如果在  $ \left|z\right|<R $ 内， $ f(z) $ 无零点。而由题设在  $ \left|z\right|=R $ 上  $ \left|f(z)\right|>a>0 $，且  $ f(z) $ 在  $ \left|z\right|\leq R $ 上解析。故

 $$ \varphi(z)=\frac{1}{f(z)} $$ 

在 $ \left|z\right|\leqslant R $上解析.此时

 $$ |\varphi(0)|=\left|\frac{1}{f(0)}\right|>\frac{1}{a}, $$ 

且在 $ \left|z\right|=R $上，

 $$ |\varphi(z)|=\left|\frac{1}{f(z)}\right|<\frac{1}{a}, $$

<!-- page: 194 -->

于是  $ \varphi(z) $ 必非常数，在  $ \left|z\right|=R $ 上

 $$ |\varphi(z)|<|\varphi(0)|. $$ 

由最大模原理，这就得到矛盾。

## 第四章 习题

<div style="text-align: center;"><img src="images/p0194_img_in_image_box_2080_1769_2362_1995.jpg" alt="Image" width="6%" /></div>


1 判断下列级数的敛、散性.

(1)  $ \sum_{n=1}^{\infty} \frac{\mathrm{i}^{n}}{n}; $

(2)  $ \sum_{n=1}^{\infty} \frac{(3+5\mathrm{i})^{n}}{n!}; $

(3)  $ \sum_{n=1}^{\infty} \left( \frac{1+5\mathrm{i}}{2} \right)^{n} $.

答: (1) 条件收敛; (2) 绝对收敛; (3) 发散.

2 试确定下列幂级数的收敛半径：

(1)  $ \sum_{n=0}^{\infty}\frac{z^{n}}{n} $; (2)  $ \sum_{n=0}^{\infty}\frac{nz^{n}}{2^{n}} $; (3)  $ \sum_{n=1}^{\infty}n^{n}z^{n} $.

答: (1) 1; (2) 2; (3) 0.

3 如果  $ \lim_{n\to\infty}\frac{C_{n+1}}{C_n} $ 存在 ( $ \neq\infty $)，试证下列三个幂级数有相同的收敛半径：

(1)  $ \sum c_{n}z^{n} $ (原级数);

(2)  $ \sum\frac{c_{n}}{n+1}z^{n+1} $ (原级数逐项积分后所成级数);

(3)  $ \sum nc_{n}z^{n-1} $ (原级数逐项求导后所成级数).

4 设  $ \sum_{n=0} c_{n} z^{n} $ 的收敛半径为  $ R (0 < R < +\infty) $，并且在收敛圆周上一点绝对收敛。试证明这个级数对于所有的点  $ z: |z| \leq R $ 为绝对收敛且一致收敛。

5 将下列函数展成 z 的幂级数，并指出展式成立的范围：

(1) $ \frac{1}{az+b}(a,b $为复数,且 $ b\neq0 $);

(2)  $ \int_{0}^{z} e^{z^{2}} \, \mathrm{d}z; $ (3)  $ \int_{0}^{z} \frac{\sin z}{z} \, \mathrm{d}z; $

(4)  $ \sin^{2}z; $ (5)  $ \frac{1}{(1-z)^{2}}. $

<!-- page: 195 -->

答: (1)  $ \sum_{n=0}^{\infty}(-1)^{n}\frac{a^{n}}{b^{n+1}}z^{n},\quad|z|<\left|\frac{b}{a}\right| $;

(2)  $ \sum_{n=0}^{\infty}\frac{z^{2n+1}}{(2n+1)n!},\quad|z|<+\infty; $

 $$ \sum_{n=0}^{\infty}\left(-1\right)^{n}\frac{z^{2n+1}}{\left(2n+1\right)\left(2n+1\right)!},\quad\left|z\right|<+\infty; $$ 

(4)  $ -\frac{1}{2}\sum_{n=1}^{\infty}(-1)^{n}\frac{(2z)^{2n}}{(2n)!},\quad|z|<+\infty; $

（5）提示  $ \frac{1}{(1-z)^{2}}=\left(\frac{1}{1-z}\right)^{\prime} $

6 写出  $ e^{z}\ln(1+z) $ 的幂级数展式至含  $ z^{5} $ 项为止，其中  $ \ln(1+z)\bigg|_{z=0}=0 $，

答： $ z+\frac{z^{2}}{2}+\frac{z^{3}}{3}+\frac{3z^{5}}{40}+\cdots,|z|<1 $

7 将下列函数按 z-1 的幂展开，并指明其收敛范围：

(1)  $ \sin z $; (2)  $ \frac{z-1}{z+1} $;

(3)  $ \frac{z}{z^2 - 2z + 5} $; (4)  $ \sqrt[3]{z}\left(\sqrt[3]{1} = \frac{-1 + \sqrt{3}i}{2}\right) $.

答: (1)  $ \sum_{k=0}^{\infty}\frac{\sin\left(\frac{k\pi}{2}+1\right)}{k!}(z-1)^{k},|z-1|<+\infty; $

(2)  $ -\sum_{n=1}^{\infty}\left(-\frac{1}{2}\right)^{n}(z-1)^{n},|z-1|<2; $

 $$ \begin{align*}\frac{1}{4}\left[\sum_{n=0}^{\infty}\left(-\frac{1}{4}\right)^{n}(z-1)^{2n}+\sum_{n=0}^{\infty}\left(-\frac{1}{4}\right)^{n}(z-1)^{2n+1}\right],\\|z-1|<2;\end{align*} $$ 

(4)  $ \frac{-1+\sqrt{3}i}{2}\sum_{n=0}^{\infty}\left(\frac{n}{3}\right)(z-1)^n,|z-1|<1, $

其中  $ \left(\frac{n}{3}\right)=\frac{\frac{1}{3}\left(\frac{1}{3}-1\right)\cdots\left(\frac{1}{3}-n+1\right)}{n!},\quad(n\geqslant1),\quad\left(\frac{0}{1}{}\right)=1. $

8 指出下列函数在零点 z=0 的阶.

<!-- page: 196 -->

(1)  $ z^{2}(e^{z^{2}}-1) $; (2)  $ 6\sin z^{3}+z^{3}(z^{6}-6) $,

答:(1)4 阶；(2)15 阶.

9 设  $ z_{0} $ 是函数  $ f(z) $ 的 m 阶零点，又是  $ g(z) $ 的 n 阶零点，试问下列函数在  $ z_{n} $ 处具有何种性质？

(1)  $ f(z) + g(z) $; (2)  $ f(z) \cdot g(z) $; (3)  $ \frac{f(z)}{g(z)} $.

10 设  $ z_{0} $ 为解析函数  $ f(z) $ 的至少 n 阶零点，又为解析函数  $ \varphi(z) $ 的 n 阶零点，则（试证）

 $$ \lim_{z\to z_{0}}\frac{f(z)}{\varphi(z)}=\frac{f^{(n)}(z_{0})}{\varphi^{(n)}(z_{0})}(\varphi^{(n)}(z_{0})\neq0). $$ 

注 由解析函数的无穷可微性,本题就构成一般形式的洛必达法则.

11 在原点解析, 而在  $ z = \frac{1}{n} (n = 1, 2, \cdots) $ 处取下列各组值的函数是否存在:

(1) 0,1,0,1,0,1, $ \cdots $

(2)  $ 0, \frac{1}{2}, 0, \frac{1}{4}, 0, \frac{1}{6}, \cdots $

(3) $ \frac{1}{2},\frac{1}{2},\frac{1}{4},\frac{1}{4},\frac{1}{6},\frac{1}{6},\cdots $

(4) $ \frac{1}{2},\frac{2}{3},\frac{3}{4},\frac{4}{5},\frac{5}{6},\cdots $

答:(1) 不存在；(2) 不存在；

（3）不存在；（4）存在, $ \frac{1}{1+z} $.

12 设(1)  $ f(z) $ 在区域 D 内解析；

（2）在某一点  $ z_{0} \in D $ 有

 $$ f^{(n)}\left(z_{0}\right)=0,\quad n=1,2,\cdots $$ 

试证  $ f(z) $ 在 D 内必为常数.

13 （最小模原理）若区域 D 内不恒为常数的解析函数  $ f(z) $，在 D 内的点  $ z_{0} $ 有  $ f(z_{0}) \neq 0 $，则  $ \left|f(z_{0})\right| $ 不可能是  $ \left|f(z)\right| $ 在 D 内的最小值，试证之.

提示 反证法,应用最大模原理.

注 最小模原理的推论：

设(1) 函数  $ f(z) $ 在有界区域 D 内解析，在有界闭域  $ \overline{D} = D + \partial D $ 上连

<!-- page: 197 -->

续；

(2)  $ f(z) \neq 0 (z \in D) $;

（3）存在 m>0，使  $ \left|f(z)\right|\geqslant m(z\in\bar{D}) $，则除  $ f(z) $ 为常数外， $ \left|f(z)\right|>m(z\in D) $.

14 设 D 是周线 C 的内部，函数  $ f(z) $ 在区域 D 内解析，在闭域  $ \overline{D} = D + C $ 上连续，其模  $ |f(z)| $ 在 C 上为常数。试证：若  $ f(z) $ 不恒等于一个常数，则  $ f(z) $ 在 D 内至少有一个零点。

## (二)

1 设级数  $ \sum_{n=1}^{\infty} f_{n}(z) $ 在点集 E 上一致收敛于  $ f(z) $，且在 E 上  $ |g(z)| \leq M(M < +\infty) $，则级数

 $$ \sum_{n=1}^{\infty}g(z)f_{n}(z) $$ 

在 E 上一致收敛于  $ g(z) \cdot f(z) $. 试证之.

2 试证: 在单位圆  $ \left|z\right|<1 $ 内, 级数

 $$ z+\left(z^{2}-z\right)+\cdots+\left(z^{n}-z^{n-1}\right)+\cdots $$ 

收敛于函数  $ f(z) \equiv 0 $，但它并非一致收敛的.

试证

（1）如果  $ \sum_{n=1}^{\infty} v_{n} = \delta $ 绝对收敛，则

 $$ \mid\delta\mid\leqslant\mid v_{1}\mid+\mid v_{2}\mid+\cdots+\mid v_{n}\mid+\cdots. $$ 

(2) 对任一复数 z

 $$ \left|\mathrm{e}^{z}-1\right|\leqslant\mathrm{e}^{\left|z\right|}-1\leqslant\left|z\right|\mathrm{e}^{\left|z\right|}. $$ 

（3）当 0<|z|<1 时

 $$ \frac{1}{4}\mid z\mid<|\mathrm{e}^{z}-1|<\frac{7}{4}\mid z\mid. $$ 

3 设  $ f(z)=\sum_{n=0}^{\infty}a_{n}z^{n}(a_{0}\neq0) $ 的收敛半径 R>0，且

 $$ M=\operatorname*{m a x}_{|z|\leqslant\rho}|f(z)|\quad(\rho<R). $$ 

试证：在圆

 $$ \left|z\right|<\frac{\left|a_{0}\right|}{\left|a_{0}\right|+M^{0}} $$

<!-- page: 198 -->

内  $ f(z) $ 无零点.

提示 由柯西不等式  $ \left|a_{n}\right|\leqslant\frac{M}{\rho^{n}} $，在圆  $ \left|z\right|<\rho $ 内可证  $ \left|f(z)-a_{0}\right|\leqslant M\frac{|z|}{\rho-|z|} $，从而在题设圆内可证  $ \left|f(z)\right|>0 $.

4 设在  $ \left|z\right|<R $ 内解析的函数  $ f(z) $ 有泰勒展式

 $$ f(z)=a_{0}+a_{1}z+a_{2}z^{2}+\cdots+a_{n}z^{n}+\cdots, $$ 

试证：当  $ 0 \leq r < R $ 时

 $$ \frac{1}{2\pi}\int_{0}^{2\pi}\mid f(r\mathrm{e}^{\mathrm{i}\theta})\mid^{2}\mathrm{d}\theta=\sum_{n=0}^{\infty}\mid a_{n}\mid^{2}r^{2n}. $$ 

提示  $ \left|f(z)\right|^{2}=f(z)\cdot\overline{f(z)}. $

5 设  $ f(z) $ 是一个整函数，且假定存在着一个非负整数 n，以及两个正数 R 与 M，使当  $ |z| \geq R $ 时， $ |f(z)| \leq M|z|^n $.

试证明： $ f(z) $ 是一个至多 n 次的多项式或一常数.

提示 估计  $ f(z) $ 积分形式的泰勒系数.

注 当 n=0 时,这就是通常的刘维尔定理,故本题是刘维尔定理的推广.

6 设(1)  $ f(z) $ 在邻域 K:  $ |z - z_0| < R $ 内解析,  $ z_0 $ 是  $ f(z) $ 的 m 阶零点;

(2)  $ z_{1} \neq z_{0}, z_{1} \in K $.

问函数

 $$ F(z)=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta\qquad(z\in K) $$ 

及函数

 $$ \Phi(z)=\int_{z_{1}}^{z}f(\zeta)\mathrm{d}\zeta\qquad(z\in K) $$ 

在点  $ z_{0} $ 的性质如何？（这里积分路径都假定在 K 内。）

7 设(1) 区域 D 含有实轴的一段 L；

(2) 函数  $  u(x, y) + iv(x, y)  $ 及

 $$ u\left(z,0\right)+\mathrm{i}v\left(z,0\right)\quad\left(z=x+\mathrm{i}y\right) $$ 

都在区域 D 内解析. 则(试证)在 D 内

 $$ u\left(x,y\right)+\mathrm{i}v\left(x,y\right)\equiv u\left(z,0\right)+\mathrm{i}v\left(z,0\right). $$

<!-- page: 199 -->

注 应用此题,可将一些符合条件的解析函数

 $$ u(x,y)+\mathrm{i}v(x,y) $$ 

（见第二、三章内的一些例题和习题），化成 z 的一元函数

 $$ {}_{,}\quad{}_{,}\quad{}_{,}\quad{}_{,}\quad u\left({z},0\right)+i v\left({z},0\right) $$ 

（即令 y=0, x=z). 读者不妨自己去验证一下.

8 设(1)函数  $ f(z) $ 在区域 D 内解析  $ f(z) $ 非常数；

(2) C 为 D 内任一条周线，只要  $ \overline{I(C)} $ 全含于 D；

(3) A 为任一复数.

试证： $ f(z)=A $ 在 C 的内部  $ I(C) $ 只有有限个根.

9 问  $ \left|e^{z}\right| $ 在闭圆  $ \left|z-z_{0}\right|\leqslant1 $ 上的何处达到最大？并求出最大值.

10 设函数  $ f(z) $ 在  $ \left|z\right| < R $ 内解析，令

 $$ M(r)=\operatorname*{m a x}_{|z|=r}|f(z)|\qquad(0\leqslant r<R). $$ 

试证： $ M(r) $ 在区间  $ [0, R) $ 上是一个上升函数，且若存在  $ r_{1} $ 及  $ r_{2} $ ( $ 0 \leq r_{1}, r_{2} < R $)，使得  $ M(r_{1}) = M(r_{2}) $，则  $ f(z) \equiv $ 常数.

<!-- page: 200 -->

## 第五章 解析函数的洛朗 (Laurent)展式与孤立奇点

在前一章我们已经看出，用泰勒级数来表示圆形区域内的解析函数是很方便的.但是对于有些特殊函数，如贝塞尔（Bessel）函数，以圆心为奇点，就不能在奇点邻域内表成泰勒级数.为此，本章将建立（挖去奇点a的）圆环 $ r<|z-a|<R(r\geqslant0,R\leqslant+\infty $，当r=0时为去心圆 $ 0<|z-a|<R $)内解析函数的级数表示，并以它为工具去研究解析函数在孤立奇点邻域内的性质.

#### §1. 解析函数的洛朗展式

### 1. 双边幂级数 考虑两个级数

$$  c_{0}+c_{1}(z-a)+c_{2}(z-a)^{2}+\cdots,   \tag*{(5.1)}$$

$$  \frac{c_{-1}}{z^{\prime}-a}+\frac{c_{-2}}{\left(z-a\right)^{2}}+\cdots.   \tag*{(5.2)}$$

前者是幂级数，故它在收敛圆  $ \left|z - a\right| < R $ ( $ 0 < R \leq +\infty $) 内表一解析函数  $ f_{1}(z) $. 对第二个级数作代换

 $$ \zeta=\frac{1}{z-a}, $$ 

则它成为一个幂级数

 $$ c_{-1}\zeta+c_{-2}\zeta^{2}+\cdots. $$

<!-- page: 201 -->

设它的收敛区域为  $ \left|\zeta\right| < \frac{1}{r}\left(0 < \frac{1}{r} \leq +\infty\right) $，换回到原来的变数 z，即知 (5.2) 在  $ \left|z - a\right| > r $ ( $ 0 \leq r < +\infty $) 内表一解析函数  $ f_{2}(z) $.

当且仅当 r < R 时，(5.1)及(5.2)有公共的收敛区域即圆环  $ H: r < |z - a| < R $。这时，我们称级数 (5.1) 与 (5.2) 之和为双边幂级数。可以表为

$$  \sum_{n=-\infty}^{\infty}c_{n}\left(z-a\right)^{n}.   \tag*{(5.3)}$$

由以上讨论及定理 4.10 和定理 4.13 得

定理5.1 设双边幂级数(5.3)的收敛圆环为

 $$ H:r<|z-a|<R(r\geqslant0,R\leqslant+\infty) $$ 

则(1)（5.3）在 H 内绝对收敛且内闭一致收敛于

 $$ f(z)=f_{1}(z)+f_{2}(z). $$ 

(2) 函数  $ f(z) $ 在 H 内解析.

(3) 函数  $ f(z)=\sum_{n=-\infty}^{\infty}c_{n}(z-a)^{n} $

在 H 内可逐项求导 p 次  $ (p=1,2,\cdots) $.

（4）函数  $ f(z) $ 可沿 H 内曲线 C 逐项积分.

注 定理 5.1 对应于定理 4.13.

2. 解析函数的洛朗展式 前面指出了双边幂级数在其收敛圆环内表一解析函数，反过来有

定理 5.2 (洛朗定理) 在圆环  $ H: r < |z - a| < R $ ( $ r \geqslant 0, R \leqslant +\infty $) 内解析的函数  $ f(z) $ 必可展成双边幂级数

$$  f(z)=\sum_{n=-\infty}^{\infty}c_{n}(z-a)^{n},   \tag*{(5.4)}$$

其中

$$  c_{n}=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{n+1}}\mathrm{d}\zeta\quad(n=0,\pm1,\cdots),   \tag*{(5.5)}$$

Γ为圆周 $ \left|\zeta-a\right|=\rho(r<\rho<R) $，并且展式是惟一的（即 $ f(z) $及圆环H惟一地决定了系数 $ c_{n} $）。

<!-- page: 202 -->

注，定理 5.2 对应于定理 4.14（泰勒定理）.

证 设 z 为 H 内任意取定的点, 总可以找到含于 H 内的两个圆周

 $$ \begin{aligned}\Gamma_{1}&:|\zeta-a|=\rho_{1},\\\Gamma_{2}&:|\zeta-a|=\rho_{2},\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0202_img_in_image_box_2877_576_4017_1697.jpg" alt="图 5.1" width="25%" /></div>


使得 z 含在圆环  $ \rho_{1} < |z - a| < \rho_{2} $ 内（图 5.1）.

<div style="text-align: center;"><div style="text-align: center;">图 5.1</div> </div>


因为函数  $ f(z) $ 在闭圆环  $ \rho_{1} \leqslant |z - a| \leqslant \rho_{2} $ 上解析，由柯西积分公式有

 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta-\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{1}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta, $$ 

或写成

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta+\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{1}}\frac{f(\zeta)}{z-\zeta}\mathrm{d}\zeta.   \tag*{(5.6)}$$

我们将上式中的两个积分表为含有 z - a 的(正或负)幂次的级数.

对于第一个积分，只要照抄泰勒定理 4.14 证明中的相应部分，就得

$$  \frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\xi=\sum_{n=0}^{\infty}c_{n}\left(z-a\right)^{n},   \tag*{(5.7)}$$

$$  c_{n}=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{2}}\frac{f(\zeta)}{(\zeta-a)^{n+1}}\mathrm{d}\zeta(n=0,1,2,\cdots).   \tag*{(5.8)}$$

类似地，考虑(5.6)式中的第二个积分

 $$ \frac{1}{2\pi\mathrm{i}}\int_{r_{1}}\frac{f(\zeta)}{z-\zeta}\mathrm{d}\zeta, $$ 

我们有

 $$ \frac{f(\zeta)}{z-\zeta}=\frac{f(\zeta)}{(z-a)-(\zeta-a)}=\frac{f(\zeta)}{z-a}\cdot\frac{1}{1-\frac{\zeta-a}{z-a}}. $$

<!-- page: 203 -->

当  $ \zeta \in \Gamma_{1} $ 时，

 $$ \left|\frac{\zeta-a}{z-a}\right|=\frac{\rho_{1}}{|z-a|}<1, $$ 

于是上式可以展成一致收敛的级数

 $$ \frac{f(\zeta)}{z-\zeta}=\frac{f(\zeta)}{z-a}\sum_{n=1}^{\infty}\left(\frac{\zeta-a}{z-a}\right)^{n-1} $$ 

沿  $ \Gamma_{1} $ 逐项积分，再以  $ \frac{1}{2\pi i} $ 乘两端即得

$$  \frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{1}}\frac{f(\zeta)}{z-\zeta}\mathrm{d}\zeta=\sum_{n=1}^{\infty}\frac{c_{-n}}{(z-a)^{n}},   \tag*{(5.9)}$$

$$  c_{-n}=\frac{1}{2\pi i}\int_{r_{1}}\frac{f(\zeta)}{(\zeta-a)^{-n+1}}\mathrm{d}\zeta(n=1,2,\cdots).   \tag*{(5.10)}$$

由（5.6），（5.7），（5.9）即得

 $$ \begin{align*}f(z)&=\sum_{n=0}^{\infty}c_{n}(z-a)^{n}+\sum_{n=1}^{\infty}\frac{c_{-n}}{(z-a)^{n}}\\&=\sum_{n=-\infty}^{\infty}c_{n}(z-a)^{n}.\end{align*} $$ 

· 回过头来考查系数(5.8)及(5.10)，由复周线的柯西积分定理，对任意圆周  $ \Gamma: |z - a| = \rho (r < \rho < R) $; 有

 $$ \begin{align*}c_{n}=&\frac{1}{2\pi i}\int_{\Gamma_{2}}\frac{f(\zeta)}{(\zeta-a)^{n+1}}\mathrm{d}\zeta\\=&\frac{1}{2\pi i}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{n+1}}\mathrm{d}\zeta(n=0,1,2,\cdots),\end{align*} $$ 

 $$ \begin{align*}c_{-n}&=\frac{1}{2\pi i}\int_{\Gamma_{1}}\frac{f(\zeta)}{(\zeta-a)^{-n+1}}\mathrm{d}\zeta\\&=\frac{1}{2\pi i}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{-n+1}}\mathrm{d}\zeta\quad(n=1,2,\cdots),\end{align*} $$ 

于是系数可统一表成(5.5).

因为系数  $ c_{n} $ 与我们所取的 z 根本无关，故在圆环 H 内(5.4)成立.

<!-- page: 204 -->

最后证明展式的惟一性. 设  $ f(z) $ 在圆环 H 内又可展成下式：

 $$ f(z)=\sum_{n=-\infty}^{\infty}c_{n}^{\prime}(z-\dot{a})^{n}, $$ 

由定理 5.1 知，它在圆周  $ \Gamma: |z-a|=\rho(r<\rho<R) $ 上一致收敛.

乘以沿  $ \Gamma $ 上的有界函数  $ \frac{1}{(z-a)^{m+1}} $，仍然一致收敛，故可逐项积分得  $ \int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{m+1}}\mathrm{d}\zeta=\sum_{n=-\infty}^{\infty}\int_{\Gamma}\left(\zeta-a\right)^{n-m-1}\mathrm{d}\zeta $

由例 3.2 即知等号右端级数中 n=m 那一项积分为  $ 2\pi i $，其余各项为零，于是

 $$ c_{m}^{\prime}=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{m+1}}\mathrm{d}\zeta,(m=0,\pm1,\cdots) $$ 

与(5.5)比较，即知  $ c_{n}^{'}=c_{n}(n=0,\pm1,\cdots) $.

定义 5.1 (5.4) 称为函数  $ f(z) $ 在点 a 的洛朗展式，(5.5) 称为其洛朗系数，而 (5.4) 等号右边的级数则称为洛朗级数.

证明了洛朗展式的惟一性后,我们就可以采用一些常用的更简便的方法去求一些初等函数在指定圆环内的洛朗展开式(如例5.1至例5.5),只有在个别的情况下,才直接采用公式(5.5)求洛朗系数的方法(如例5.6).

3. 洛朗级数与泰勒级数的关系 当已给函数  $ f(z) $ 在点 a 处解析时，中心在 a，半径等于由 a 到函数  $ f(z) $ 的最近奇点的距离的那个圆可以看成圆环的特殊情形，在其中就可作出洛朗级数展开式。根据柯西积分定理，由公式(5.5)可以看出，这个展式的所有系数  $ c_{-n}(n=1,2,\cdots) $ 都等于零。在此情形下，计算洛朗级数的系数公式与泰勒级数的系数公式（积分形式）无异，所以洛朗级数就转化为泰勒级数。因此，泰勒级数是洛朗级数的特殊情形。

例 5.1 函数

 $$ f(z)=\frac{1}{(z-1)(z-2)}. $$ 

在 z 平面上只有两个奇点: z = 1 及 z = 2. 因此 z 平面被分成如下

<!-- page: 205 -->

三个不相交的  $ f(z) $ 的解析区域: (1) 圆  $ \left|z\right|<1 $; (2) 圆环  $ 1<|z|<2 $; (3) 圆环:  $ 2<|z|<+\infty $, 试分别在此三个区域内求  $ f(z) $ 的展式.

解 首先将函数  $ f(z) $ 分解成部分分式

 $$ f(z)=\frac{1}{z-2}-\frac{1}{z-1}. $$ 

（1）在圆  $ \left|z\right|<1 $ 内. 因  $ \left|z\right|<1<2 $，即  $ \left|\frac{z}{2}\right|<1 $，利用公式

（4.10）得

 $$ f(z)=\frac{1}{1-z}-\frac{1}{2\left(1-\frac{z}{2}\right)}=\sum_{n=0}^{\infty}\left(1-\frac{1}{2^{n+1}}\right)z^{n}, $$ 

此即  $ f(z) $ 在圆  $ \left|z\right|<1 $ 内的泰勒展式.

（2）在圆环  $ 1<|z|<2 $ 内，即有  $ \left|\frac{1}{z}\right|<1,\left|\frac{z}{2}\right|<1 $

 $$ \begin{align*}f(z)&=-\frac{1}{2}\cdot\frac{1}{1-\frac{z}{2}}-\frac{1}{z}\cdot\frac{1}{1-\frac{1}{z}}\\&=-\frac{1}{2}\sum_{n=0}^{\infty}\frac{z^n}{2^n}-\frac{1}{z}\sum_{n=1}^{\infty}\frac{1}{z^{n-1}}\\&=-\sum_{n=0}^{\infty}\frac{z^n}{2^{n+1}}-\sum_{n=1}^{\infty}\frac{1}{z^n}.\end{align*} $$ 

（3）在圆环  $ 2<|z|<+\infty $ 内.这时  $ \left|\frac{1}{z}\right|<1,\left|\frac{2}{z}\right|<1 $ 故

 $$ \begin{aligned}f(z)&=\frac{1}{z}\cdot\frac{1}{1-\frac{2}{z}}-\frac{1}{z}\cdot\frac{1}{1-\frac{1}{z}}\\&=\frac{1}{z}\sum_{n=0}^{\infty}\frac{2^{n}}{z^{n}}-\frac{1}{z}\sum_{n=0}^{\infty}\frac{1}{z^{n}}=\sum_{n=2}^{\infty}\frac{2^{n-1}-1}{z^{n}}.\end{aligned} $$ 

4. 解析函数在孤立奇点邻域内的洛朗展式

定义 5.2 如果函数  $ f(z) $ 在点 a 的某一去心邻域  $ K - \{a\} $:  $ 0 < |z - a| < R $ (即除去圆心 a 的某圆) 内解析，点 a 是  $ f(z) $ 的奇

<!-- page: 206 -->

点(见定义 2.3)，则称 a 为  $ f(z) $ 的一个孤立奇点.

注 因函数  $ f(z) $ 在  $ K-\{a\} $ 内是单值的，故也称 a 为  $ f(z) $ 的单值性孤立奇点；如以后遇到  $ f(z) $ 在  $ K-\{a\} $ 内是多值的，则称 a 为  $ f(z) $ 的多值性孤立奇点，即支点（由于在支点的邻域内函数能由一支变到另一支，故函数在支点邻域内缺少单值性。因而它以最简单的方式破坏了函数的解析性。因此支点也是函数的奇点）。以后如无特别声明，提到孤立奇点总指单值性孤立奇点。当然，以后也会遇到非孤立奇点。

如果 a 为函数  $ f(z) $ 的一个孤立奇点，则必存在正数 R，使得  $ f(z) $ 在点 a 的去心邻域  $ K - \{a\} : 0 < |z - a| < R $ 内可展成洛朗级数.

例 5.2 函数  $ f(z)=\frac{1}{(z-1)(z-2)} $ 在 z 平面内只有两个奇点 z=1 及 z=2。试分别求  $ f(z) $ 在此二点去心邻域内（图 5.2）的洛朗展式。

解 （1）在（最大的）去心邻域  $ 0<|z-1|<1 $ 内

 $$ \begin{aligned}f(z)&=\frac{-1}{z-1}+\frac{1}{z-2}\\&=-\frac{1}{z-1}+\frac{1}{(z-1)-1}\\&=-\frac{1}{z-1}-\sum_{n=0}^{\infty}(z-1)^{n};\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0206_img_in_image_box_2731_3715_4003_4368.jpg" alt="图5.2" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.2</div> </div>


（2）在（最大的）去心邻域  $ 0<|z-2|<1 $ 内

 $$ \begin{aligned}f(z)&=\frac{1}{z-2}-\frac{1}{z-2+1}\\&=\frac{1}{z-2}-\sum_{n=0}^{\infty}(-1)^{n}(z-2)^{n}.\end{aligned} $$ 

（3）在(最大的)点 $ \infty $的去心邻域 $ 1<|z-1|<+\infty $（以 $ z=1 $为中心）内，有 $ \left|\frac{1}{z-1}\right|<1 $，从而有

<!-- page: 207 -->

$$ \begin{aligned}f(z)&=-\frac{1}{z-1}+\frac{1}{z-1}\cdot\frac{1}{1-\frac{1}{z-1}}\\&=-\frac{1}{z-1}+\frac{1}{z-1}\sum_{n=0}^{\infty}\left(\frac{1}{z-1}\right)^{n}=\sum_{n=1}^{\infty}\left(\frac{1}{z-1}\right)^{n+1}.\end{aligned} $$ 

（4）在（最大的）点 $ \infty $的去心邻域 $ 1<|z-2|<+\infty $（以 $ z=2 $为中心——见本章第3节末）内有 $ \left|\frac{1}{z-2}\right|<1 $，从而有

 $$ \begin{aligned}f(z)&=\frac{1}{z-2}-\frac{1}{z-2+1}=\frac{1}{z-2}-\frac{1}{z-2}\cdot\frac{1}{1+\frac{1}{z-2}}\\&=\frac{1}{z-2}-\frac{1}{z-2}\sum_{n=0}^{\infty}(-1)^{n}\left(\frac{1}{z-2}\right)^{n}\\&=\sum_{n=1}^{\infty}\left(-\frac{1}{z-2}\right)^{n+1}.\end{aligned} $$ 

例 5.3  $ \frac{\sin z}{z} $ 在 z 平面上只有奇点 z=0，在其去心邻域 0<|z|<+\infty 内有洛朗展式

 $$ \frac{\sin z}{z}=\sum_{n=0}^{\infty}\frac{\left(-1\right)^{n}z^{2n}}{\left(2n+1\right)!}=1-\frac{z^{2}}{3!}+\cdots. $$ 

例 5.4  $ e^{z} + e^{\frac{1}{z}} $ 在 z 平面上只有奇点 z=0，在其去心邻域 0<|z|<+\infty 内有洛朗展式

 $$ \mathrm{e}^{z}+\mathrm{e}^{\frac{1}{z}}=2+\sum_{n=1}^{\infty}\frac{z^{n}}{n!}+\sum_{n=1}^{\infty}\frac{1}{n!}\cdot\frac{1}{z^{n}}. $$ 

由以上各例已可看出，在求一些初等函数的洛朗展式时，一般并不是按照公式(5.5)去计算洛朗系数，主要是利用已知的幂级数展式去求所需要的洛朗展式。下面我们再举两例：

例 5.5  $ \sin \frac{z}{z-1} $ 在 z 平面上只有奇点 z=1，且在去心邻域  $ 0<|z-1|<+\infty $ 内可展成洛朗级数：

解  $ \sin\frac{z}{z-1}=\sin\left(1+\frac{1}{z-1}\right) $

<!-- page: 208 -->

$$ \begin{align*}&=\sin1\cdot\cos\frac{1}{z-1}+\cos1\cdot\sin\frac{1}{z-1}\\&=\sin1\left[1-\frac{1}{2!(z-1)^2}+\cdots\right.\\&\quad\left.+(-1)^n\frac{1}{(2n)!(z-1)^{2n}}+\cdots\right]\\&\quad+\cos1\left[\frac{1}{z-1}-\frac{1}{3!(z-1)^3}+\cdots\right.\\&\quad\left.+(-1)^n\frac{1}{(2n+1)!(z-1)^{2n+1}}+\cdots\right]\\&=\sin1+\frac{\cos1}{z-1}-\frac{\sin1}{2!(z-1)^2}\\&\quad-\frac{\cos1}{3!(z-1)^3}+\cdots+(-1)^n\frac{\sin1}{(2n)!(z-1)^{2n}}\\&\quad+(-1)^n\frac{\cos1}{(2n+1)!(z-1)^{2n+1}}+\cdots.\end{align*} $$ 

例 5.6 试证

 $$ \cosh\left(z+\frac{1}{z}\right)=c_{0}+\sum_{n=1}^{\infty}c_{n}\left(z^{n}+z^{-n}\right), $$ 

其中

 $$ c_{n}=\frac{1}{2\pi}\int_{0}^{2\pi}\cos n\varphi\cdot\cosh(2\cos\varphi)\mathrm{d}\varphi. $$ 

证 因  $ w = z + \frac{1}{z} $ 在 z 平面上只有 z = 0 一个奇点. 而

 $$ \cosh w=\frac{1}{2}(\mathrm{e}^{w}+\mathrm{e}^{-w}) $$ 

在 w 平面上解析，故  $ \cosh\left(z+\frac{1}{z}\right) $ 在 z 平面上也只有一个奇点 z = 0。即它在去心邻域  $ 0 < |z| < +\infty $。内解析。由洛朗定理得

 $$ \begin{array}{c}{\displaystyle\operatorname{c o s h}\left(z+\frac{1}{z}\right)=\sum_{n=-\infty}^{\infty}c_{n}z^{n},}\\ {\displaystyle c_{n}=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma_{\rho}}\frac{\operatorname{c o s h}\left(z+z^{-1}\right)}{z^{n+1}}\mathrm{d}z,}\end{array} $$

<!-- page: 209 -->

$ \Gamma_{\rho} $ 表任意圆周  $ |z|=p>0 $.

取  $ \rho=1 $，则沿圆周  $ \Gamma_{\rho}: z=e^{\mathrm{i}\varphi},0\leqslant\varphi\leqslant2\pi $，有

 $$ \begin{align*}c_{n}&=\frac{1}{2\pi}\int_{0}^{2\pi}\cosh(e^{i\varphi}+e^{-i\varphi})e^{-ni\varphi}d\varphi\\&=\frac{1}{2\pi}\int_{0}^{2\pi}\cosh(2\cos\varphi)\cos n\varphi d\varphi\\&\quad-\frac{i}{2\pi}\int_{0}^{2\pi}\cosh\left(2\cos\varphi\right)\sin n\varphi d\varphi.\end{align*} $$ 

命  $ \varphi=2\pi-\theta $，则可知等号右边第二个积分为零。故

 $$ c_{n}=\frac{1}{2\pi}\int_{0}^{2\pi}\cosh(2\cos\varphi)\cos n\varphi\mathrm{d}\varphi. $$ 

所以

 $$ c_{n}=c_{-n}(n=1,2,\cdots). $$ 

所以

 $$ \operatorname{c o s h}\left(z+\frac{1}{z}\right)=c_{0}+\sum_{n=1}^{\infty}c_{n}\left(z^{n}+z^{-n}\right). $$ 

#### §2. 解析函数的孤立奇点

孤立奇点是解析函数的奇点中最简单、最重要的一种类型。以解析函数的洛朗展式为工具，我们能够在孤立奇点的去心邻域内充分研究一个解析函数的性质。

1. 孤立奇点的三种类型 已经说过, 如 a 为函数  $ f(z) $ 的孤立奇点, 则  $ f(z) $ 在 a 点的某去心邻域  $ K - \{a\} $ 内可以展成洛朗级数

 $$ f(z)=\sum_{n=-\infty}^{\infty}c_{n}(z-a)^{n}. $$ 

我们称非负幂部分  $ \sum_{n=0}^{\infty} c_{n}(z-a)^{n} $ 为  $ f(z) $ 在点 a 的正则部分，而称负幂部分  $ \sum_{n=1}^{\infty} c_{-n}(z-a)^{-n} $ 为  $ f(,z) $ 在点 a 的主要部分. 这是因为实际上非负幂部分表示在点 a 的邻域  $ K: |z-a| < R $ 内

<!-- page: 210 -->

的解析函数,故函数  $ f(z) $ 在点 a 的奇异性质完全体现在洛朗级数的负幂部分上.

定义 5.3 设 a 为函数  $ f(z) $ 的孤立奇点.

(1) 如果  $ f(z) $ 在点 a 的主要部分为零，则称 a 为  $ f(z) $ 的可去奇点（见例 5.3）.

(2) 如果  $ f(z) $ 在点 a 的主要部分为有限多项, 设为

 $$ \frac{c_{-m}}{\left(z-a\right)^{m}}+\frac{c_{-(m-1)}}{\left(z-a\right)^{m-1}}+\cdots+\frac{c_{-1}}{z-a}\left(c_{-m}\neq0\right), $$ 

则称 a 为  $ f(z) $ 的 m 阶极点（见例 5.2）. 一阶极点也称为单极点.

(3) 如果  $ f(z) $ 在点 a 的主要部分有无限多项，则称 a 为  $ f(z) $ 的本质奇点（见例 5.4 及例 5.5）.

以下我们分别讨论三类孤立奇点的特征.

2. 可去奇点 如果 a 为函数  $ f(z) $ 的可去奇点，则有

 $$ f(z)=c_{0}+c_{1}(z-a)+c_{2}(z-a)^{2}+\cdots(0<|z-a|<R). $$ 

上式等号右边表圆  $ K: |z - a| < R $ 内的解析函数. 如果命  $ f(a) = c_{0} $，则  $ f(z) $ 在圆 K 内与一个解析函数重合. 也就是说，我们将  $ f(z) $ 在点 a 的值加以适当定义，则点 a 就是  $ f(z) $ 的解析点. 这就是我们称 a 为  $ f(z) $ 的可去奇点的由来.

例如，当我们约定 $ \frac{\sin z}{z}\bigg|_{z=0}=1 $时, $ \frac{\sin z}{z} $在z=0就解析了.

定理 5.3 如果 a 为函数  $ f(z) $ 的孤立奇点，则下列三条是等价的。因此，它们中的任何一条都是可去奇点的特征。

(1)  $ f(z) $ 在点 a 的主要部分为零；

(2)  $ \lim_{z \to a} f(z) = b (\neq \infty) $;

(3)  $ f(z) $ 在点 a 的某去心邻域内有界.

证 只要证明(1)推出(2);(2)推出(3);(3)推出(1)就行了.

（1）推出（2）：由（1）知

 $$ \begin{align*}f(z)=c_{0}+c_{1}(z-a)+\cdots(0<|z-a|<R),\\\liminf_{z\to a}(z)=c_{0}(\neq,\infty).\end{align*} $$ 

于是

<!-- page: 211 -->

（2）推出（3）：即例 1.27.

(3) 推出(1): 设  $ f(z) $ 在点 a 的某去心邻域  $ K - \{a\} $ 内以 M 为界. 考虑  $ f(z) $ 在点 a 的主要部分

 $$ \frac{c_{-1}}{z-a}+\frac{c_{-2}}{\left(z-a\right)^{2}}+\cdots+\frac{c_{-n}}{\left(z-a\right)^{n}}+\cdots, $$ 

 $$ c_{-n}=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{-n+1}}\mathrm{d}\zeta(n=1,2,3,\cdots), $$ 

而  $ \Gamma $ 为全含于 K 内的圆周  $ \left|\zeta - a\right| = \rho, \rho $ 可以充分小. 于是由

 $$ \begin{align*}\mid c_{-n}\mid&=\left|\frac{1}{2\pi i}\int_{\Gamma}\frac{f(\zeta)}{(\zeta-a)^{-n+1}}\mathrm{d}\zeta\right|\\&\leqslant\frac{1}{2\pi}\cdot\frac{M}{\rho^{-n+1}}2\pi\rho=M\rho^{n}\end{align*} $$ 

即知当 n=1,2, $ \cdots $时， $ c_{-n}=0 $。即是说， $ f(z) $在点 a 的主要部分为零。

3. 施瓦茨(Schwarz)引理 如果函数  $ f(z) $ 在单位圆  $ |z|<1 $ 内解析，并且满足条件

 $$ f(0)=0,\mid f(z)\mid<1(\mid z\mid<1), $$ 

则在单位圆  $ \left|z\right|<1 $ 内恒有

 $$ \begin{aligned}\mid f(z)\mid&\leqslant\mid z\mid,\\ \mid f^{\prime}(0)\mid&\leqslant1.\end{aligned} $$ 

且有

如果上式等号成立，或在圆  $ \left|z\right|<1 $ 内一点  $ z_{0}\neq0 $ 处前一式符号成立，则(当且仅当)

 $$ f(z)=\mathrm{e}^{\mathrm{i}\alpha}z\quad(\mid z\mid<1), $$ 

其中  $ \alpha $ 为一实常数.

证 设

 $$ f(z)=c_{1}z+c_{2}z^{2}+\cdots(\mid z\mid<1). $$ 

令

 $$ \varphi\left(z\right)=\frac{f\left(z\right)}{z}=c_{1}+c_{2}z+\cdots\left(z\neq0\right), $$

<!-- page: 212 -->

定义  $ \varphi(0)=c_{1}=f'(0) $，则  $ \varphi(z) $ 在  $ \left|z\right|<1 $ 内解析.

考虑  $ \varphi(z) $ 在单位圆  $ |z|<1 $ 内任一点  $ z_{0} $ 处的值，如果 r 满足条件  $ |z_{0}|<r<1 $，根据最大模原理，有

 $$ |\varphi(z_{0})|\leqslant\max_{|z|=r}|\varphi(z)|=\max_{|z|=r}\left|\frac{f(z)}{z}\right|\leqslant\frac{1}{r}. $$ 

让  $ r \rightarrow 1 $ 即得

 $$ \mid\varphi(z_{0})\mid\leqslant1. $$ 

于是 $ \left|f^{\prime}(0)\right|=\left|\varphi(0)\right|\leqslant1 $，且当 $ z_{0}\neq0 $时，有

 $$ \begin{aligned}\mid\varphi(z_{0})\mid&=\left|\frac{f(z_{0})}{z_{0}}\right|\leqslant1,\\&\mid f(z_{0})\mid\leqslant\mid z_{0}\mid.\end{aligned} $$ 

即

如果这些关系式中，有一个取等号，这就意味着在单位圆  $ |z| < 1 $ 内的某一点  $ z_{0} $，模数  $ |\varphi(z)| $ 达到最大值，这只有  $ \varphi(z) =  $ 常数  $ e^{i\alpha} $ （ $ \alpha $ 为实数）时才可能，此即  $ f(z) = e^{i\alpha}z $.

从几何上看，施瓦茨引理表明：任一解析变换  $ \omega = f(z) $， $ f(0) = 0 $，当它把单位圆变到一个单位圆内的区域  $ \Delta $ 上去时，圆内任一点  $ z \neq 0 $ 的像都比 z 本身距坐标原点为近。而如果有一个点的像与这个点本身距坐标原点有相同距离的话，则  $ \Delta $ 就与单位圆相同，变换就仅仅是一个旋转（图 5.3）。

<div style="text-align: center;"><img src="images/p0212_img_in_image_box_932_4491_3488_5721.jpg" alt="图5.3" width="57%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.3</div> </div>

<!-- page: 213 -->

$ ^{*} $ 注 施瓦茨引理有如下一个简单改进：

我们保留假设条件不变. 如果原点是函数  $ f(z) $ 的  $ \lambda $ 阶零点，就可以考虑函数  $ \frac{f(z)}{z^{\lambda}} $，与刚才的情形一样，我们由此可以得到

 $$ |f(z)|\leqslant|z|^{\lambda}, $$ 

并且只有当

 $$ f(z)=\mathrm{e}^{\mathrm{i}\alpha}z^{\lambda}\left(\alpha 为实数 \right) $$ 

时，等号才成立.这样，在这个特殊情形之下，函数的模就有了一个比前面公式中更小的界限.

### 4. 极点

定理 5.4 如果函数  $ f(z) $ 以点 a 为孤立奇点，则下列三条是等价的. 因此，它们中的任何一条都是 m 阶极点的特征.

(1)  $ f(z) $ 在点 a 的主要部分为

 $$ \frac{c_{-m}}{\left(z-a\right)^{m}}+\cdots+\frac{c_{-1}}{z-a}\left(c_{-m}\neq0\right); $$ 

(2)  $ f(z) $ 在点 a 的某去心邻域内能表成

$$  f(z)=\frac{\lambda(z)}{(z-a)^{m}},   \tag*{(5.11)}$$

其中  $ \lambda(z) $ 在点 a 邻域内解析，且  $ \lambda(a) \neq 0 $;

(3)  $ g(z)=\frac{1}{f(z)} $ 以点 a 为 m 阶零点 (可去奇点要当作解析点看, 只要令  $ g(a)=0 $).

注 第(3)条表明：

f(z)以点a为m阶极点 $ \Leftrightarrow\frac{1}{f(z)} $以点a为m阶零点.

证 （1）推出(2): 若(1)为真, 则在点 a 的某去心邻域内有

 $$ \begin{aligned}f(z)=\frac{c_{-m}}{\left(z-a\right)^{m}}+\frac{c_{-(m-1)}}{\left(z-a\right)^{m-1}}+\cdots+\frac{c_{-1}}{z-a}\\+c_{0}+c_{1}(z-a)+\cdots\end{aligned} $$

<!-- page: 214 -->

$$ =\frac{c_{-m}+c_{-(m-1)}(z-a)+\cdots}{(z-a)^{m}}=\frac{\lambda(z)}{(z-a)^{m}}, $$ 

其中  $ \lambda(z) $ 显然在点 a 的邻域内解析，且  $ \lambda(a)=c\quad m\neq0 $

(2) 推出(3): 若(2)为真, 则在点 a 的某去心邻域内有

 $$ g(z)=\frac{1}{f(z)}=\frac{(z-a)^{m}}{\lambda(z)}, $$ 

其中 $ \frac{1}{\lambda(z)} $在点a的某邻域内解析，且 $ \frac{1}{\lambda(a)}\neq0 $（由例1.28）。因此，a为 $ g(z) $的可去奇点，作为解析点来看，只要令 $ g(a)=0 $，a就为 $ g(z) $的m阶零点。

（3）推出(1): 如果  $ g(z)=\frac{1}{f(z)} $ 以点 a 为 m 阶零点，则在点 a 的某邻域内

 $$ g\left(z\right)=\left(z-a\right)^{m}\varphi\left(z\right) $$ 

（见(4.14)），其中  $ \varphi(z) $ 在此邻域内解析，且  $ \varphi(a)\neq0 $。这样一来

 $$ f(z)=\frac{1}{(z-a)^{m}}\cdot\frac{1}{\varphi(z)}. $$ 

因 $ \frac{1}{\varphi(z)} $在点a某邻域内解析(由例1.28)，如在此邻域内命

 $$ \frac{1}{\varphi(z)}=c_{-_{m}}+c_{-(m-1)}(z-a)+\cdots $$ 

为其泰勒展式,则  $ f(z) $ 在点 a 的主要部分就是

 $$ \frac{c_{-m}}{\left(z-a\right)^{m}}+\frac{c_{-(m-1)}}{\left(z-a\right)^{m-1}}+\cdots+\frac{c_{-1}}{z-a}\left(c_{-m}=\frac{1}{\varphi(a)}\neq0\right). $$ 

下述定理也能说明极点的特征,其缺点是不能指明极点的阶.

定理 5.5 函数  $ f(z) $ 的孤立奇点 a 为极点的充要条件是

 $$ \operatorname*{l i m}_{z\to a}f(z)=\infty. $$ 

证 函数  $ f(z) $ 以 a 为极点的充要条件是  $ \frac{1}{f(z)} $ 以 a 为零点（上定理之(3)，由此知定理为真.

例 5.7 函数

<!-- page: 215 -->

$$ f(z)=\frac{5z+1}{(z-1)(2z+1)^{2}} $$ 

以 z=1 为一阶极点， $ z=-\frac{1}{2} $ 为二阶极点（由定理 5.4(3)）.

### 5. 本质奇点

定理 5.6 函数  $ f(z) $ 的孤立奇点 a 为本质奇点的充要条件是

 $$ \liminf_{z\to a}(z)\neq\left\{\begin{aligned}&b( 有限数 ),\\ &\infty\end{aligned}\right. 即 \liminf_{z\to a}(z) 不存在 . $$ 

这可由定理 5.3.3 之(2)及定理 5.5 得到证明.

定理 5.7 若 z = a 为函数  $ f(z) $ 之一本质奇点，且在点 a 的充分小去心邻域内不为零，则 z = a 亦必为  $ \frac{1}{f(z)} $ 的本质奇点.

证 命  $ \varphi(z)=\frac{1}{f(z)} $. 由假设, z=a 必为  $ \varphi(z) $ 的孤立奇点.

若 z=a 为  $ \varphi(z) $ 的可去奇点 (解析点), 则 z=a 必为  $ f(z) $ 的可去奇点或极点, 此与假设矛盾; 若 z=a 为  $ \varphi(z) $ 的极点, 则 z=a 必为  $ f(z) $ 的可去奇点 (零点), 亦与假设矛盾. 故 z=a 必为  $ \varphi(z) $ 的本质奇点.

例 5.8 z=0 为  $ e^{\frac{1}{z}} $ 的本质奇点. 因为

 $$ \begin{aligned}\mathrm{e}^{\frac{1}{z}}&=1+\frac{1}{z}+\frac{1}{2!z^{2}}+\cdots+\frac{1}{n!z^{n}}+\cdots.\\&\quad(0<|z|<+\infty)\end{aligned} $$ 

由定理 5.7, 我们可以断定 z=0 亦为  $ e^{-\frac{1}{z}} $ 的本质奇点. 在上式中将 z 改为 -z, 也可看出这一点.

就本书所遇到的奇点情况来看，可以列表如下：

<!-- page: 216 -->

<div style="text-align: center;"><img src="images/p0216_img_in_image_box_983_562_3442_1498.jpg" alt="Image" width="55%" /></div>


### 6. 皮卡(Picard)定理

魏尔斯特拉斯 1876 年给出下面的定理, 描述出解析函数在本质奇点邻域内的特性.

定理 5.8 如果 a 为函数  $ f(z) $ 的本质奇点，则对于任何常数 A，不管它是有限数还是无穷，都有一个收敛于 a 的点列  $ \{z_{n}\} $，使得

 $$ \lim_{z_{n}\to a}f(z_{n})=A. $$ 

换句话说，在本质奇点的无论怎样小的去心邻域内，函数  $ f(z) $ 可以取任意接近于预先给定的任何数值（有限的或无穷的）。

证 (1) 在  $ A = \infty $ 的情形, 定理是正确的. 因为函数  $ f(z) $ 的模在 a 的任何去心邻域内都是无界的. 否则, a 必为  $ f(z) $ 的可去奇点.

##### (2) 现在设  $ A \neq \infty $.

可能有这种情形发生,在点 a 的任意小的去心邻域内有这样一点 z 存在,使  $ f(z)=A $. 在这种情形下,定理已经得证.

因此，我们可以假定，在点 a 的充分小的去心邻域  $ K - \{a\} $ 内  $ f(z) \neq A $。这样，由定理 5.7，函数

 $$ \varphi\left(z\right)=\frac{1}{f\left(z\right)-A} $$ 

在  $ K - \{a\} $ 内解析，且以 a 为本质奇点（因 a 为  $ f(z) $ 的本质奇点）。根据前面（1）段的结果，必定有一个趋向 a 的点列  $ \{z_{n}\} $ 存在，使得

 $$ \lim_{z_{n}\to a}\varphi(z)=\infty. $$

<!-- page: 217 -->

由此推出

 $$ \lim_{z_{n}\to a}f(z_{n})=A. $$ 

思考题 试描述这个魏尔斯特拉斯定理的几何意义.

我们用两个例子来说明这个定理.

例 5.9  $ f(z)=\sin\frac{1}{z} $

这里原点是  $ f(z) $ 的本质奇点。事实上，当  $ z \to 0 $ 时， $ \sin \frac{1}{z} $ 不趋于任何（有限的或无穷的）极限。只要考察 z 取实数值就可以发现这一点。

如果  $ A = \infty $，则可设  $ z_{n} = \frac{i}{n} $，即  $ \frac{1}{z_{n}} = -in $，我们得： $ n \to \infty $ 时  $ \sin \frac{1}{z_{n}} = -i  $ sh  $ n \to \infty $。

现在设  $ A \neq \infty $. 为了得到如魏尔斯特拉斯定理中所说的点列  $ \{z_{n}\} $，我们解方程

 $$ \sin\frac{1}{z}=A, $$ 

得

 $$ \frac{1}{z}=\mathrm{A r c}\sin A=\frac{1}{\mathrm{i}}\mathrm{L n}(\mathrm{i}A+\sqrt{1-A^{2}}). $$ 

于是  $ z_{k}=\frac{i}{\ln(iA+\sqrt{1-A^{2}})+2k\pi i},(k=0,\pm1,\cdots). $

若取

 $$ \mathcal{Z}_{n}=\frac{\mathrm{i}}{\ln(\mathrm{i}A+\sqrt{1-A^{2}})+2n\pi\mathrm{i}}, $$ 

并使 n=1,2, $ \cdots $,我们得到点列  $ \{z_{n}\}\to0 $,并满足条件

 $$ f(z_{n})=A(n=1,2,\cdots). $$ 

因此

 $$ \lim_{n\to\infty}f(z_{n})=A. $$ 

思考题 z=0 是否为  $ \frac{1}{\sin\frac{1}{z}} $ 的本质奇点？

<!-- page: 218 -->

例 5.10  $ f(z)=\mathrm{e}^{\frac{1}{z}} $

这里，原点是  $ f(z) $ 的本质奇点.（见例 5.8）

设  $ A = \infty $，取  $ z_{n} = \frac{1}{n} $，我们有

 $ f(z_{n})=\mathrm{e}^{n}\rightarrow\infty $（当  $ n\rightarrow\infty $ 时）.

就是说，当  $ A = \infty $ 时，点列  $ \left\{\frac{1}{n}\right\} $ 适合魏尔斯特拉斯定理中的论断.

现在设 A = 0，若令  $ z_{n} = -\frac{1}{n} $，我们有

 $ f(z_{n})=\mathrm{e}^{-n}\rightarrow0 $（当  $ n\rightarrow\infty $ 时）.

就是说，定理的论断在此情形也得到证实.

最后，设  $ A \neq 0, A \neq \infty $。这里极易由解方程

 $$ \mathrm{e}^{\frac{1}{x}}=A $$ 

来取相应的点  $ z_{n} $. 我们得

 $$ \frac{1}{z}=\mathrm{Ln}A, $$ 

于是

 $$ z_{k}=\frac{1}{\ln A+2k\pi i},(k=0,\pm1,\cdots). $$ 

若取

 $$ z_{n}=\frac{1}{\ln A+2n\pi\mathrm{i}}(n=1,2,\cdots), $$ 

我们就有收敛于零且满足条件  $ f(z_{n}) = A $ 的点列  $ \{z_{n}\} $. 于是

 $$ \lim_{n\to\infty}f(z_{n})=A. $$ 

在例5.9与例5.10中，我们看到了，除了个别的例外（前例中的 $ A=\infty $，后例中的 $ A=\infty,A=0 $），不但有点列 $ \{z_{n}\} $使满足极限等式

 $$ \lim_{z_{n}\to a}f(z_{n})=\bar{A}, $$ 

而且还有点列 $ \{z_{n}\} $使满足准确等式

<!-- page: 219 -->

$$ f(z_{n})=A(n=1,2,\cdots). $$ 

在一般情况下，也有类似的结果。下列定理是皮卡于 1879 年给出的：

定理 5.9 （皮卡(大)定理） 如果 a 为函数  $ f(z) $ 的本质奇点，则对于每一个  $ A \neq \infty $，除掉可能一个值  $ A = A_{0} $ 外，必有趋于 a 的无限点列  $ \{z_{n}\} $ 使  $ f(z_{n}) = A $ （ $ n = 1, 2, \cdots $）.

必须指出，皮卡定理较之魏尔斯特拉斯定理是更普遍并且更深刻了。但它只是函数值分布理论的早期结果之一。

皮卡证明的方法虽然很短 $ ^{①} $，但却利用了一种称为椭圆模函数的性质这种较高深的数学工具。后人虽有多种浅近的证明 $ ^{②③} $方法，但都非常繁复。本书限于篇幅，不加证明。

从皮卡定理出发，近代在这个方面还有许多深刻的研究，这些都是属于解析函数的值的分布理论范围，这里就不深入讨论了。

#### §3. 解析函数在无穷远点的性质

上一节讨论的是函数的孤立奇点为有限的情形. 由于函数  $ f(z) $ 在点  $ \infty $ 总是无意义的, 所以点  $ \infty $ 总是  $ f(z) $ 的奇点.

定义 5.4 设函数  $ f(z) $ 在无穷远点（去心）邻域

 $$ N-\{\infty\}:+\infty>|z|>r\geqslant0 $$ 

内解析,则称点 $ \infty $为 $ f(z) $的一个孤立奇点.

设点 $ \infty $为 $ f(z) $的孤立奇点，利用变换 $ z'=\frac{1}{z} $，于是

<!-- page: 220 -->

$$  \varphi\left(z^{\prime}\right)=f\left(\frac{1}{z^{\prime}}\right)=f(z)   \tag*{(5.12)}$$

在去心邻域  $ K - \{0\}: 0 < |z'| < \frac{1}{r} $ (如 r = 0 规定  $ \frac{1}{r} = +\infty $) 内解析.  $ z' = 0 $ 就为  $ \varphi(z') $ 之一孤立奇点. 我们还看出：

（1）对应于扩充 z 平面上无穷远点的去心邻域  $ N - \{\infty\} $，有扩充  $ z' $ 平面上原点的去心邻域；

(2) 在对应的点 z 与  $ z' $ 上，函数  $ f(z) $ 与  $ \varphi(z') $ 的值相等；

(3)  $ \lim_{z \to \infty} f(z) = \lim_{z' \to 0} \varphi(z') $，或两个极限都不存在.

从这里,我们很自然地根据  $ \varphi(z^{\prime}) $ 在原点的状态来规定函数  $ f(z) $ 在无穷远点的状态. 即有

定义 5.5 若  $ z' = 0 $ 为  $ \varphi(z') $ 的可去奇点（解析点）、m 阶极点或本质奇点，则我们相应地称  $ z = \infty $ 为  $ f(z) $ 的可去奇点（解析点）、m 阶极点或本质奇点.

注 虽然我们可以定义  $ f(\infty) $，但在无穷远处没有定义差商，因此我们没有定义  $ f(z) $ 在无穷远点处的可微性。但由定义 5.5 可见，所谓  $ f(z) $ 在点  $ \infty $ 解析，就是指点  $ \infty $ 为  $ f(z) $ 的可去奇点，且定义  $ f(\infty) = \lim_{z \to \infty} f(z) $.

设在去心邻域  $ K - \{0\}: 0 < |z'| < \frac{1}{r} $ 内将  $ \varphi(z') $ 展成洛朗级数：

 $$ \varphi(z^{\prime})=\sum_{n=-\infty}^{\infty}c_{n}z^{\prime n}. $$ 

令  $ z' = \frac{1}{z} $，并根据(5.12)，则有

$$  f(z)=\sum_{n=-\infty}^{\infty}b_{n}z^{n},   \tag*{(5.13)}$$

其中  $ b_{n}=c_{-n}(n=0,\pm1,\cdots) $

(5.13)为  $ f(z) $ 在无穷远点去心邻域  $ N - \{\infty\}: 0 \leq r < |z| < $

<!-- page: 221 -->

+\infty 内的洛朗展式. 对应  $ \varphi(z^{\prime}) $ 在  $ z^{\prime}=0 $ 的主要部分, 我们称

 $ \sum_{n=1}^{\infty}b_{n}z^{n} $ 为  $ f(z) $ 在  $ z=\infty $ 的主要部分.

注 我们来观察这样一个特例: 设函数  $ f(z) $ 在  $ \mathbb{C}_{\infty} $ 上只有奇点 z=0 和  $ z=\infty $，则可设

 $$ \begin{aligned}f(z)&=a_{0}+\frac{a_{1}}{z}+\cdots+\frac{a_{n}}{z^{n}}+\cdots+b_{1}z+b_{2}z^{2}+\cdots\\&\quad+b_{n}z^{n}+\cdots(0<|z|<+\infty),\end{aligned} $$ 

这样就把函数  $ f(z) - a_{0} $ 一分为二： $ \sum_{n=1}^{\infty} \frac{a_{n}}{z^{n}} $ 及  $ \sum_{n=1}^{\infty} b_{n} z^{n} $. 在 z=0 的去心邻域  $ 0 < |z| < +\infty $ 内，前者是主部，起主导作用， $ f(z) $ 的性质主要由前者所规定，而后者则是次要的. 但是当  $ |z| $ 逐渐变大，趋向  $ +\infty $ 时，主要和非主要就互相转化. 在  $ z = \infty $ 的去心邻域  $ 0 < |z| < +\infty $ 内，后者是主部，起主导作用，决定  $ f(z) $ 的性质，而前者却变为次要的.

由上述定义及性质(1),(2),(3)等,我们易得

定理 5.3′ （对应于定理 5.3）函数  $ f(z) $ 的孤立奇点  $ z = \infty $ 为可去奇点的充要条件是下列三条中的任何一条成立：

(1)  $ f(z) $ 在  $ z = \infty $ 的主要部分为零；

(2)  $ \lim_{z \to \infty} f(z) = b (\neq \infty) $;

(3)  $ f(z) $ 在  $ z = \infty $ 的某去心邻域  $ N - \{\infty\} $ 内有界.

定理 5.4′ （对应于定理 5.4） 函数  $ f(z) $ 的孤立奇点  $ z = \infty $ 为 m 阶极点的充要条件是下列三条中的任何一条成立：

(1)  $ f(z) $ 在  $ z = \infty $ 的主要部分为

 $$ b_{1}z+b_{2}z^{2}+\cdots+b_{m}z^{m}\left(b_{m}\neq0\right); $$ 

(2)  $ f(z) $ 在  $ z = \infty $ 的某去心邻域  $ N - \{\infty\} $ 内能表成

$$  f(z)=z^{m}\cdot\mu(z),   \tag*{(5.11)^{\prime}}$$

其中  $ \mu(z) $ 在  $ z=\infty $ 的邻域 N 内解析，且  $ \mu(\infty)\neq0 $;

<!-- page: 222 -->

(3)  $ g(z)=\frac{1}{f(z)} $ 以  $ z=\infty $ 为 m 阶零点 (只要令  $ g(\infty)=0 $).

例 5.11 由  $ f(z)=\frac{1}{(z-1)(z-2)} $ 在  $ 2<|z|<+\infty $ 内的洛朗展式（见例 5.1（3）），知它以  $ z=\infty $ 为可去奇点，并且作为解析点来看是二阶零点（只要让  $ f(\infty)=0 $）。

又

 $$ \begin{aligned}g\left(z\right)&=\frac{1}{f\left(z\right)}=\left(z-1\right)\left(z-2\right)\\&=z^{2}\left(1-\frac{1}{z}\right)\left(1-\frac{2}{z}\right),\end{aligned} $$ 

以  $ z = \infty $ 为二阶极点. 这里

 $$ \mu(z)=\left(1-\frac{1}{z}\right)\left(1-\frac{2}{z}\right),\mu(\infty)=1\neq0. $$ 

定理 5.5′ （对应于定理 5.5） 函数  $ f(z) $ 的孤立奇点  $ \infty $ 为极点的充要条件是  $ \lim_{z \to \infty} f(z) = \infty $.

定理 5.6′ （对应于定理 5.6） 函数  $ f(z) $ 的孤立奇点  $ \infty $ 为本质奇点的充要条件是下列两条中的任何一条成立：

(1)  $ f(z) $ 在  $ z = \infty $ 的主要部分有无穷多项正幂不等于零；

(2)  $ \lim_{z \to \infty} f(z) $ 不存在 (即当 z 趋向于  $ \infty $ 时,  $ f(z) $ 不趋向于任何 (有限或无穷) 极限).

注 定理 5.7、5.8 及 5.9 对  $ z = \infty $ 是  $ f(z) $ 的本质奇点也真.

下面我们再举几个其他类型的例子.

例 5.12 将多值解析函数  $ \mathrm{Ln}\frac{z-a}{z-b} $ 的各分支在无穷远点的某去心邻域内展成洛朗级数.

解 无穷远点不是

 $$ \mathrm{Ln}\frac{z-a}{z-b} $$ 

的支点，故能在点 $ \infty $的邻域 $ \left|z\right| > \max\left\{\left|a\right|, \left|b\right|\right\} $内分出单值解析分支.且在此去心邻域内，各支均能展成洛朗级数.现在第k支

<!-- page: 223 -->

$$ \begin{aligned}\ln\frac{z-a}{z-b}&=\ln\frac{1-\frac{a}{z}}{1-\frac{b}{z}}\\&=\ln\left(1-\frac{a}{z}\right)-\ln\left(1-\frac{b}{z}\right)+2k\pi i,\end{aligned} $$ 

其中  $ \ln\left(1-\frac{a}{z}\right) $ 及  $ \ln\left(1-\frac{b}{z}\right) $ 均表主值支. 由(4.12)即得

 $$ \begin{aligned}\ln\frac{z-a}{z-b}&=2k\pi\mathrm{i}-\\&=2k\pi\mathrm{i}+\\&\quad\sum_{n=1}^{\infty}\frac{1}{n}\left(\frac{a}{z}\right)^{n}+\\&\quad\sum_{n=1}^{\infty}\frac{b^{n}-a^{n}}{n}\cdot\frac{1}{z^{n}}(k=0,\pm1,\pm2,\cdots).\end{aligned} $$ 

由此可见， $ z=\infty $实为各单值解析分支的单值性孤立奇点——可去奇点.

例 5.13 在点  $ z = \infty $ 的去心邻域内将函数

 $$ f(z)=\mathrm{e}^{\frac{z}{z+2}} $$ 

展成洛朗级数.

解 令  $ z=\frac{1}{\zeta} $，则得

 $$ f\left(\frac{1}{\zeta}\right)=\mathrm{e}^{\frac{1}{\frac{1}{\zeta}+2}}=\mathrm{e}^{\frac{1}{1+2\zeta}}, $$ 

而点  $ \zeta=0 $ 是此函数的解析点. 将此函数简记为  $ \varphi(\zeta) $, 就得

 $$ \varphi^{\prime}(\zeta)=-\frac{2}{(1+2\zeta)^{2}}\mathrm{e}^{\frac{1}{1+2\zeta}}, $$ 

 $$ \varphi^{\prime\prime}(\zeta)=\mathrm{e}^{\frac{1}{1+2\zeta}}\left[\frac{8}{(1+2\zeta)^{3}}+\frac{4}{(1+2\zeta)^{4}}\right]. $$ 

等等. 于是  $ \varphi(0)=\mathrm{e},\varphi^{\prime}(0)=-2\mathrm{e},\varphi^{\prime\prime}(0)=12\mathrm{e} $ 等等.

由此得

 $$ \varphi\left(\zeta\right)=\mathrm{e}\left(1-2\zeta+6\dot{\zeta}^{2}+\cdots\right). $$ 

所以

 $$ \mathrm{e}^{\frac{z}{z+2}}=\mathrm{e}\left(1-\frac{2}{z}+\frac{6}{z^{2}}+\cdots\right)\quad(2<|z|<+\infty), $$

<!-- page: 224 -->

这里  $ z=\infty $ 是  $ f(z) $ 的可去奇点，如令  $ f(\infty)=e $，则化为解析点.

例 5.14 求出函数  $ \frac{\tan(z-1)}{z-1} $ 的奇点（包括无穷远点），并确定其类别.

解  $ \frac{\tan(z-1)}{z-1}=\frac{\sin(z-1)}{(z-1)\cos(z-1)} $

以 z=1 为可去奇点； $ z_{k}=1+\frac{2k+1}{2}\pi,k=0,\pm1,\cdots $ 为一阶极点；z= $ \infty $ 为这些极点的聚点，是个非孤立奇点.

例 5.15 问函数  $ \sec \frac{1}{z-1} $ 在 z=1 的去心邻域内能否展开为

洛朗级数.

解 因 z=1 为函数

 $$ \sec\frac{1}{z-1}=\frac{1}{\cos\frac{1}{z-1}} $$ 

的非孤立奇点. (注意:  $ \sec \frac{1}{z-1} $ 的奇点除 z=1 外, 还有奇点)

 $$ z_{k}=\frac{1}{\left(k+\frac{1}{2}\right)\pi}+1,k=0,\pm1,\pm2,\cdots $$ 

以 z=1 为聚点. 故此函数在 z=1 的去心邻域内不能展开为洛朗级数.

例 5.16 若函数  $ f(z) $ 在 0<|z-a|<R 内解析，且不恒为零；又若  $ f(z) $ 有一列异于 a 但却以 a 为聚点的零点。试证 a 必为  $ f(z) $ 的本质奇点。

证 z = a 必是  $ f(z) $ 的孤立奇点且不能是可去奇点. 否则  $ f(z) $ 于  $ \left|z - a\right| < R $ 内解析 (令  $ f(a) = 0 $) 且以 a 为非孤立的零点. 由推论 4.2 必有  $ f(z) $ 恒为零, 这与假设矛盾.

其次, z=a 也不能是  $ f(z) $ 的极点. 否则, 对任给 M>0, 有  $ \delta>0 $, 使当  $ 0<|z-a|<\delta $ 时,  $ |f(z)|>M $. 也与假设矛盾.

<!-- page: 225 -->

故 z=a 必为  $ f(z) $ 的本质奇点.

注 在本节最后,我们把第一章§4定义过的无穷远点邻域的概念推广如下,以方便应用:

无穷远点邻域正好对应着以北极点 N 为心的一个球盖，在复平面  $ C_{\infty} $ 上就是任何一个圆周的外部（包含点  $ \infty $）。确切地说， $ N(\infty):r<|z-a| $ 就称为以  $ z=a $ 为中心的  $ z=\infty $ 的邻域（包含点  $ \infty $);  $ N(\infty)-\{\infty\} $:  $ r<|z-a|<+\infty $ 就称为以  $ z=a $ 为中心的  $ z=\infty $ 的去心邻域。

当 a=0 时，这就是第一章 §4 定义过的情形.

设函数  $ f(z) $ 在  $ \mathbb{C}_{\infty} $ 上只有奇点 z = a 和 z =  $ \infty $，则其洛朗展式可设为

 $$ \begin{align*}f(z)&=a_{0}+\frac{a_{1}}{z-a}+\cdots+\frac{a_{n}}{\left(z-a\right)^{n}}+\cdots+b_{1}\left(z-a\right)+b_{2}\left(z-a\right)^{2}+\\&\cdots+b_{n}\left(z-a\right)^{n}+\cdots\left(r<\mid z-a\mid<\right.+\infty).\end{align*} $$ 

#### §4. 整函数与亚纯函数的概念

根据解析函数的孤立奇点特征,便可以区分出两种最简单的解析函数族.

1. 整函数 在第三章我们已经定义过，在整个 z 平面上解析的函数  $ f(z) $ 称为整函数.

设  $ f(z) $ 为一整函数，则  $ f(z) $ 只以 z =  $ \infty $ 为孤立奇点，且可设

$$  f(z)=\sum_{n=0}^{\infty}c_{n}z^{n}\quad(0\leqslant|z|<+\infty).   \tag*{(5.14)}$$

于是显然有

定理 5.10 若  $ f(z) $ 为一整函数，则

(1)  $ z = \infty $ 为  $ f(z) $ 的可去奇点的充要条件为:  $ f(z) = 常数 c_{0} $.

(2)  $ z = \infty $ 为  $ f(z) $ 的 m 阶极点的充要条件为:  $ f(z) $ 是一个 m 次多项式  $ c_{0} + c_{1}z + \cdots + c_{m}z^{m} (c_{m} \neq 0) $.

<!-- page: 226 -->

(3)  $ z = \infty $ 为  $ f(z) $ 的本质奇点的充要条件为: 展式 (5.14) 有无穷多个  $ c_{n} $ 不等于零. (我们称这样的  $ f(z) $ 为超越整函数.)

由此可见，整函数族按惟一奇点  $ z = \infty $ 的不同类型而被分成了三类 $ ^{①} $.

例如, $ e^{z} $, $ \sin z $及 $ \cos z^{-} $都是超越整函数.

### 2. 亚纯函数

定义 5.6 在 z 平面上除极点外无其他类型奇点的单值解析函数称为亚纯函数.

亚纯函数族是较整函数族更一般的函数族.

定理 5.11 一函数  $ f(z) $ 为有理函数的充要条件为:  $ f(z) $ 在扩充 z 平面上除极点外没有其他类型的奇点.

证 必要性 设有理函数

 $$ f(z)=\frac{P(z)}{Q(z)}, $$ 

其中  $ P(z) $ 与  $ Q(z) $ 分别为 z 的 m 次与 n 次多项式，且彼此互质，则

(1) 当 m > n 时, z =  $ \infty $ 必为 f(z) 的 m - n 阶极点;

(2) 当  $ m \leq n $ 时, z =  $ \infty $ 必为  $ f(z) $ 的可去奇点, 只要置

 $$ \dot{f}(\infty)=\lim_{z\to\infty}\frac{P(z)}{Q(z)},z=\infty 就是 f(z) 的解析点； $$ 

(3)  $ Q(z) $ 的零点必为  $ f(z) $ 的极点.

充分性 若  $ f(z) $ 在扩充 z 平面上除极点外无其他类型的奇点，则这些极点的个数只能是有限个。因若不然，这些极点在扩充 z 平面上的聚点就是  $ f(z) $ 的非孤立奇点。与假设矛盾。

今命  $ f(z) $ 在 z 平面上的极点为  $ z_{1} $、 $ z_{2} $、 $ \cdots $、 $ z_{n} $，其阶分别为  $ \lambda_{1} $、 $ \lambda_{2} $、 $ \cdots $、 $ \lambda_{n} $，则函数

 $$ g(z)=(z-z_{1})^{\lambda_{1}}(z-z_{2})^{\lambda_{2}}\cdots(z-z_{n})^{\lambda_{n}}f(z) $$

<!-- page: 227 -->

至多以  $ z = \infty $ 为极点，而在 z 平面上解析。故  $ g(z) $ 必为一多项式（或常数）。即必  $ f(z) $ 为有理函数。

由此可见，每一有理函数都是亚纯函数。

定义 5.7 非有理函数的亚纯函数称为超越亚纯函数.

例 5.17  $ \frac{1}{e^{z}-1} $ 是一个超越亚纯函数，因为它有无穷多个极点：

 $$ z=2k\pi\mathrm{i}(k=0,\pm1,\pm2,\cdots), $$ 

其聚点  $ z = \infty $ 是一个非孤立奇点. 故此函数不可能是一有理函数.

整函数也看成是亚纯函数的一种特例.

注 可去奇点既然可以除去后成为解析点,所以在定义及定理的条件中,一般都不提到它.

 $ ^{*} $例 5.18 试证： $ f(z) $是单叶整函数的充要条件为

 $$ f(z)=az+b\quad(a\neq0). $$ 

证 充分性 由于函数

 $$ \begin{array}{r}{\varpi=f(z)=a z+b(a\neq0)}\end{array} $$ 

及其反函数

 $$ z=\frac{1}{a}(w-b) $$ 

都是单值整函数（一次多项式）.所以

 $$ f(z)=az+b\quad(a\neq0) $$ 

是单叶整函数.

必要性 设  $ f(z) $ 是单叶整函数. 由定理 5.10, 整函数分三类：

(1)  $ f(z) $ 为常数，这与单叶性假设矛盾；

(2)  $ f(z) $ 为超越整函数，

 $$ \begin{align*}f(z)&=c_{0}+c_{1}z+\cdots+c_{n}z^{n}+\cdots,\ $ 0&\leqslant|z|<+\infty)\end{align*} $$ 

它的惟一奇点是本质奇点  $ z = \infty $。再由皮卡大定理，对每个 A

<!-- page: 228 -->

$ \neq\infty $，除掉可能一个值  $ A=A_{0} $ 外，必有趋于  $ \infty $ 的无限点列  $ \{z_{n}\} $ 使  $ f(z_{n})=A(n=1,2,\cdots) $. 这也与  $ f(z) $ 的单叶性假设矛盾；

(3)  $ f(z) $ 为一多项式，

 $$ f(z)=c_{0}+c_{1}z+\cdots+\dot{c}_{n}z^{n}\left(c_{n}\neq0\right). $$ 

对每个  $ A \neq \infty $，由代数学基本定理， $ f(z) = A $ 必有且只有 n 个根（是几重根就算作几个根）。但由  $ f(z) $ 的单叶性假设，必有 n = 1。即必有

 $$ f(z)=c_{0}+c_{1}z\quad(c_{1}\neq0). $$ 

也可写成

 $$ f(z)=az^{^{\prime}}+b\quad(a\neq0). $$ 

#### §5. 平面向量场——解析函数的应用（二）

1. 奇点的流体力学意义 在第三章 §5 中已经知道，流体在区域 D 内作无源、漏的无旋流动时，对应复势  $ f(z) $ 是 D 内的解析函数（可能是多值的）。现在我们举两个例子来说明某些奇点具有的流体力学意义。

例 5.19 考查复势为  $ f(z)=\frac{N}{2\pi}\ln z $ 的流动 (N 为非零实数).

解 我们知道  $ f(z)=\frac{N}{2\pi}\ln z $ 对应的流动在  $ 0<|z|<+\infty $ 内是无源、漏的并且是无旋的. 现在我们来看看原点及  $ \infty $ (作为  $ \ln z $ 的支点) 有什么性质.

令  $ z = re^{\mathrm{i}\theta} $，易知其势函数及流函数分别为

 $$ \varphi\left(r,\theta\right)=\frac{N}{2\pi}\ln r,\psi\left(r,\theta\right)=\frac{N}{2\pi}\theta. $$ 

为了确定原点、 $ \infty $及 N 的物理意义，考查沿圆周 C: r = 常数的环量及流量.

 $$ \Gamma_{c}+\mathrm{i}N_{c}=\int_{c}f^{\prime}(z)\mathrm{d}z=\frac{N}{2\pi}\int_{c}\frac{\mathrm{d}z}{z}=\mathrm{i}N. $$

<!-- page: 229 -->

故  $ \Gamma_{C}=0, N_{C}=N $. 即对于任意的同心圆周 r= 常数, 均有相同的流量流过. 这恰好说明, 每单位时间内有  $ \left|N\right| $ 这样多的流量自原点涌出  $ (N>0) $ 到点  $ \infty $ 漏掉或自点  $ \infty $ 涌出  $ (N<0) $ 到原点漏掉. 即原点就是一个源  $ (N>0) $ 或漏  $ (N<0) $. 对应的,  $ \infty $ 就算作一个漏  $ (N>0) $ 或源  $ (N<0) $. 而称  $ \left|N\right| $ 为源 (漏) 强 (图 5.4).

<div style="text-align: center;"><img src="images/p0229_img_in_image_box_981_1537_2135_2847.jpg" alt="图5.4" width="25%" /></div>


<div style="text-align: center;"><img src="images/p0229_img_in_image_box_2307_1542_3478_2837.jpg" alt="Image" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.4</div> </div>


故势线是同心圆周 r = 常数，流线是过原点的射线  $ \theta = $ 常数，

且此流动的复速度  $ \overline{v(z)} = f'(z) = \frac{N}{2\pi z} $，

以 z = 0 为一阶极点，以  $ z = \infty $ 为一阶零点（只要令  $ v(\infty) = 0 $）。

例 5.20 考查复势  $ f(z)=\frac{1}{z} $ 的流动情况：

解 我们首先指出,  $ \frac{1}{z} $ 以 z=0 为一阶极点, 以  $ z=\infty $ 为可去奇点 (一阶零点, 只要令  $ f(\infty)=0 $), 它在  $ 0<|z|<+\infty $ 内是无源 (漏) 并且是无旋的.

其次，容易算得势函数及流函数分别为

 $$ \varphi\left(x,y\right)=\frac{x}{x^{2}+y^{2}},\psi\left(x,y\right)=\frac{-y}{x^{2}+y^{2}}, $$ 

故势线及流线是经过原点，且互为正交的圆周（图 5.5）.

设 C 是不过原点但包围原点的周线，则

<!-- page: 230 -->

$$ \begin{aligned}\Gamma_{c}+\mathrm{i}N_{c}&=\int_{c}f^{\prime}(z)\mathrm{d}z\\&=-\int_{c}\frac{\mathrm{d}z}{z^{2}}=0.\end{aligned} $$ 

这种流动，可以想像为 $ \uwave{\text{在原点处}} $有充分多的流体以无限大的速度涌出，同时又以无限大的速度被漏掉.原点称为重源或称为偶极子，它是强度相同的一个源及一个漏无限接近而它们的强度无限增大时的极限情形.

<div style="text-align: center;"><img src="images/p0230_img_in_image_box_2711_588_3982_1945.jpg" alt="图5.5" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.5</div> </div>


2. 在电场中的应用举例 在平面电场中，电通  $ \varphi $ 和电位  $ \psi $ 都是调和函数，即它们都满足拉普拉斯方程，而且电力线（相当于势线） $ \varphi = k_{1} $ 和等位线（相当于流线） $ \psi = k_{2} $ 互相正交。这种性质正好和一个解析函数的实部和虚部所具有的性质相符合。因此，在研究平面电场时，常将电场的电通  $ \varphi $（相当于势函数）和电位  $ \psi $（相当于流函数）分别看作一个解析函数的实部和虚部，而将它们合为一个解析函数进行研究。这种由电通作实部，电位作虚部组成的解析函数

 $$ f(z)=\varphi(x,y)+\mathrm{i}\psi(x,y) $$ 

称为电场的复电位(相当于复势).

如果不是利用解析函数作为研究电场的工具，则研究电场的电通和电位是孤立进行的，看不出它们之间的联系，在研究过程中也无一定的方法可循。如果使用解析函数，则这些缺点都可以克服，而且计算起来亦较简单。反过来，如果知道了一个平面电场的复电位，则通过对复电位的实部和虚部的研究，便可得出电场的分布情况。

注 静电场的势函数一定是单值函数.

例 5.21 已知一电场的电力线方程为

 $$ \arctan\frac{y}{x+b}-\arctan\frac{y}{x-b}=k_{1}, $$

<!-- page: 231 -->

试求其等位线方程和复电位.

解 设复电位  $ f(z)=\varphi+i\psi $，则

 $$ \varphi(x,y)=\arctan\frac{y}{x+b}-\arctan\frac{y}{x-b}. $$ 

根据 C.-R. 方程，

 $$ \psi_{y}=\varphi_{x}=\frac{-y}{(x+b)^{2}+y^{2}}+\frac{y}{(x-b)^{2}+y^{2}}. $$ 

两边对 y 积分，得

 $$ \begin{align*}\psi\left(x,y\right)&=\int\left[\frac{y}{\left(x-b\right)^{2}+y^{2}}-\frac{y}{\left(x+b\right)^{2}+y^{2}}\right]\mathrm{d}y.\\&=\frac{1}{2}\ln\left[\left(x-b\right)^{2}+y^{2}\right]-\frac{1}{2}\ln\left[\left(x+b\right)^{2}+y^{2}\right]+\lambda\left(x\right).\end{align*} $$ 

又  $ \psi_{x} = -\varphi_{y} $,

而

 $$ \psi_{x}=\frac{x-b}{\left(x-b\right)^{2}+y^{2}}-\frac{x+b}{\left(x+b\right)^{2}+y^{2}}+\lambda^{\prime}\left(x\right), $$ 

 $$ \varphi_{y}=\frac{x+b}{\left(x+b\right)^{2}+y^{2}}-\frac{x-b}{\left(x-b\right)^{2}+y^{2}}, $$ 

故  $ \lambda'(x)=0 $，即  $ \lambda(x)=\lambda $ 为一常数。于是得等位线方程为

 $$ \frac{1}{2}\ln\left[(x-b)^{2}+y^{2}\right]-\frac{1}{2}\ln\left[(x+\bar{b})^{2}+y^{2}\right]+\lambda=\lambda_{1}, $$ 

或

 $$ \ln\sqrt{\frac{(x-b)^2+y^2}{(x+b)^2+y^2}}=k_2\quad(k_2=\lambda_1-\lambda). $$ 

复电位为

 $$ \begin{array}{l}f(z)=\left(\operatorname{a r c}\tan\frac{y}{x+b}-\arctan\frac{y}{x-b}\right)\\ \quad+\mathrm{i}\ln\sqrt{\frac{(x-b)^2+y^2}{(x+b)^2+y^2}},\end{array} $$ 

或

 $$ f(z)=\mathrm{i}\ln\left(\frac{z-b}{z+b}\right). $$ 

这是双曲线传输线所产生的电场(图 5.6).  $ f(z) $ 的支点 - b 及 + b 就是这个电场的正、负电荷位置.

<!-- page: 232 -->

通过上面的讨论，我们知道，利用解析函数对电场进行研究是十分理想的，它可将对电场的电位和电通的研究联系起来，克服了分别研究的复杂手续，而且使问题得到了简化。但找出这样的解析函数是极不容易的。因此，一般是将问题反转过来，不是根据电场去找解析函数，而是先研究一些不同的解析函数，找出它们所表示的电场图形，再由这些电场的图形，推出带电导体的形状。如此积累了一些电场图形与解析函数之间的关系，再由这些已知的关系，推出新电场的复电位函数。即使现有导体的形状为已知的关系所不具备，也可选用近似的形状，把所得的解析函数用于现有的情况，较无根据的猜测，总要好些。下面就介绍一个由解析函数所表示的电场。

<div style="text-align: center;"><img src="images/p0232_img_in_image_box_468_2796_2176_4070.jpg" alt="图5.6" width="38%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.6</div> </div>


<div style="text-align: center;"><img src="images/p0232_img_in_image_box_2400_2896_3878_4099.jpg" alt="图5.7" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.7</div> </div>


例 5.22 求由  $ f(z)=z^{\frac{1}{2}} $ 所表现的电场.

解 设  $ f(z) = u + iv $,

则

 $$ (u+\mathrm{i}v)^{2}=x+\mathrm{i}y. $$ 

故

 $$ u^{2}-v^{2}=x,2uv=y. $$ 

解两式得

 $$ y^{2}=4u^{2}\left(u^{2}-x\right), $$ 

或

 $$ y^{2}=4v^{2}\left(v^{2}+x\right). $$ 

令  $ u = k_{1} $，得电力线方程为

<!-- page: 233 -->

$$ y^{2}=4k_{1}^{2}(k_{1}^{2}-x), $$ 

即  $ y^{2} = -2p(x - a) $ (这里  $ p = 2k_{1}^{2} $,  $ a = k_{1}^{2} $), 这是抛物线.

令  $ v = k_{2} $，得等位线方程为

 $$ y^{2}=4k_{2}^{2}(k_{2}^{2}+x), $$ 

即  $ y^{2}=2p(x+a) $ (这里  $ p=2k_{2}^{2}, a=k_{2}^{2} $),

这也是抛物线.

## 第五章 习题

(一)

1 将下列各函数在指定圆环内展为洛朗级数.

(1)  $ \frac{z+1}{z^{2}(z-1)},0<|z|<1;1<|z|<+\infty $

答:1)  $ \frac{z+1}{z^{2}(z-1)} = -\frac{1}{z^{2}} - 2 \sum_{n=0}^{\infty} z^{n-1}, (0 < |z| < 1) $;

2)

 $$ \frac{z+1}{z^{2}(z-1)}=\frac{1}{z^{2}}+2\sum_{n=0}^{\infty}\frac{1}{z^{n+3}},(1<|z|<+\infty). $$ 

(2) $ \frac{z^{2}-2z+5}{(z-2)(z^{2}+1)},1<|z|<2. $

答: 原式 = 2  $ \sum_{n=1}^{\infty}(-1)^{n}\frac{1}{z^{2n}}-\sum_{n=0}^{\infty}\frac{z^{n}}{2^{n+1}} $.

(3) $ \frac{e^{z}}{z(z^{2}+1)},0<|z|<1 $, 只要含 $ \frac{1}{z} $到 $ z^{2} $各项.

答: 原式  $ =\frac{1}{z}+1-\frac{z}{2}-\frac{5}{6}z^{2}+\cdots $

2 将下列各函数在指定点的去心邻域内展成洛朗级数，并指出其收敛范围.

(1) $ \frac{1}{(z^{2}+1)^{2}},z=i. $

<!-- page: 234 -->

答: 原式 =  $ \sum_{n=0}^{\infty}(-1)^{n}(n+1)\frac{(z-i)^{n-2}}{(2i)^{n+2}}\quad(0<|z-i|<2) $.

(2） $ z^{2}e^{\frac{1}{z}}, z=0 $ 及  $ z=\infty $

答： $ z^{2}e^{\frac{1}{z}}=\sum_{n=-2}^{\infty}\frac{1}{(n+2)!}\cdot\frac{1}{z^{n}}\quad(0<|z|<+\infty) $.

 $ (0<|z|<+\infty $既是z=0的去心邻域，又是以z=0为中心 $ z=\infty $的去心邻域.)

(3)  $ e^{\frac{1}{1-x}}, z = 1 $ 及  $ z = \infty $.

 $$ \mathrm{e}^{\frac{1}{1-z}}=\sum_{n=0}^{\infty}\frac{(-1)^{n}}{n!}\frac{1}{(z-1)^{n}}\quad(0<|z-1|<+\infty); $$ 

 $ (0<|z-1|<+\infty $既是z=1的去心邻域,又是以z=1为中心点 $ \infty $的去心邻域.)

 $$ \mathrm{e}^{\frac{1}{1-z}}=1-\frac{1}{z}-\frac{1}{2}\frac{1}{z^{2}}-\frac{1}{6}\frac{1}{z^{3}}-\cdots\quad\left(1<|z|<+\infty\right). $$ 

 $ (1<|z|<+\infty $ 是以 z=0 为中心  $ z=\infty $ 的去心邻域.)

3 试证

 $$ \sin\left[t\left(z+\frac{1}{z}\right)\right]=c_{0}+\sum_{n=1}^{\infty}c_{n}\left(z^{n}+z^{-n}\right),0<|z|<+\infty $$ 

其中 t 为与 z 无关的实参数，

 $$ \begin{array}{c}c_{n}=\frac{1}{2\pi}\int_{0}^{2\pi}\sin\left(2t\cos\theta\right)\cos n\theta\mathrm{d}\theta,\ $ n=0,1,2,\cdots).\end{array} $$ 

4 求出下列函数的奇点，并确定它们的类别（对于极点，要指出它们的

阶），对于无穷远点也要加以讨论.

(1) $ \frac{z-1}{z(z^{2}+4)^{2}} $

答: z=0 为一阶极点,  $ z=\pm2i $ 为二阶极点,  $ z=\infty $ 为可去奇点.

(2) $ \frac{1}{\sin z+\cos z} $

答:  $ z = k\pi - \frac{\pi}{4} $ ( $ k = 0, \pm 1, \cdots $) 各为一阶极点,  $ z = \infty $ 为非孤立奇点.

(3) $ \frac{1-\mathrm{e}^{z}}{1+\mathrm{e}^{z}} $

答:  $ z = (2k + 1)\pi i (k = 0, \pm 1, \cdots) $ 各为一阶极点,  $ z = \infty $ 为非孤立奇点.

<!-- page: 235 -->

(4) $ \frac{1}{(z^{2}+i)^{3}}. $

答:  $ z = \pm \frac{\sqrt{2}}{2} (1 - i) $ 各为三阶极点,  $ z = \infty $ 为可去奇点.

(5)  $ \tan^{2} z $.

答:  $ z = \left( k + \frac{1}{2} \right) \pi $ （ $ k = 0, \pm 1, \cdots $）各为二阶极点,  $ z = \infty $ 为非孤立奇点.

(6)  $ \cos\frac{1}{z+i} $

答: z = -i 为本质奇点, z =  $ \infty $ 为可去奇点.

(7)  $ \frac{1 - \cos z}{z^2} $.

答: z=0 为可去奇点,  $ z=\infty $ 为本质奇点.

(8) $ \frac{1}{e^{z}-1} $

答:  $ z = 2k\pi i (k = 0, \pm 1, \cdots) $ 各为一阶极点,  $ z = \infty $ 为非孤立奇点.

5 下列函数在指定点的去心邻域内能否展为洛朗级数.

(1)  $ \cos \frac{1}{z}, z = 0 $; (2)  $ \cos \frac{1}{z}, z = \infty $;

(3) $ \frac{1}{\sin\frac{1}{z}},z=0; $ (4) $ \cot z,z=\infty $

答:(1) 能；(2) 能；(3) 否；(4) 否.

6 函数  $ f(z) $,  $ g(z) $ 分别以 z = a 为 m 阶极点及 n 阶极点. 试问 z = a 为  $ f(z) + g(z) $,  $ f(z)g(z) $ 及  $ f(z)/g(z) $ 的什么点?

7 设函数  $ f(z) $ 不恒为零且以 z = a 为解析点或极点，而函数  $ \varphi(z) $ 以 z = a 为本质奇点，试证 z = a 是  $ \varphi(z) \pm f(z) $， $ \varphi(z) \cdot f(z) $ 及  $ \varphi(z)/f(z) $ 的本质奇点.

8 判定下列函数的奇点及其类别（包括无穷远点）.

(1) $ \frac{1}{e^{2}-1}-\frac{1}{z} $

答: z=0 为可去奇点;  $ z=2k\pi i(k=\pm1,\pm2,\cdots) $ 各为一阶极点;

 $ z = \infty $ 为非孤立奇点.

<!-- page: 236 -->

(2)  $ e^{x-\frac{1}{x}} $

答: z=0 及  $ z=\infty $ 为本质奇点.

(3)  $ \sin \frac{1}{z} + \frac{1}{z^2} $.

答: z=0 为本质奇点;  $ z=\infty $ 为一阶零点（可去奇点）.

(4)  $ \mathrm{e}^{z}\cos\frac{1}{z} $

答：z=0 及 z= $ \infty $ 为本质奇点.

(5) $ \frac{e^{\frac{1}{x-1}}}{e^{x}-1} $

答: z=1 为本质奇点;  $ z=2k\pi i(k=0,\pm1,\pm2\cdots) $ 各为一阶极点; z= $ \infty $ 为非孤立奇点.

9 试证: 在扩充 z 平面上解析的函数  $ f(z) $ 必为常数(刘维尔定理).

10 刘维尔定理的几何意义是“非常数整函数的值不能全含于一圆之内”，试证明：非常数整函数的值不能全含于一圆之外。

11 设幂级数  $ f(z)=\sum_{n=0}^{\infty}a_{n}z^{n} $ 所表示的和函数  $ f(z) $ 在其收敛圆周上只有惟一的一阶极点  $ z_{0} $. 试证： $ \frac{a_{n}}{a_{n+1}}\rightarrow z_{0} $，因而  $ \left|\frac{a_{n}}{a_{n+1}}\right|\rightarrow|z_{0}|\left(|z_{0}|=r\right. $ 是收敛半径).

## (二)

1 下列多值函数在指定点的去心邻域内能否有分支可展成洛朗级数.

(1) $ \sqrt{z}, z=0; $

(2)  $ \sqrt{z(z-2)} $, z=1;

(3)  $ \sqrt{\frac{z}{(z-1)(z-2)}}, z = \infty $;

(4) Ln  $ \frac{1}{z-1} $, z= $ \infty $;

(5)  $ \ln\frac{(z-1)(z-3)}{(z-2)(z-4)},z=\infty $.

答:(1) 否;(2) 能;(3) 否;

（4）否；（5）能.

<!-- page: 237 -->

### 2 函数

 $$ f(z)=\frac{1}{z(z-1)^{2}} $$ 

在 z=1 处有一个二阶极点；这个函数又有下列洛朗展式：

 $$ \frac{1}{z\left(z-1\right)^{2}}=\frac{1}{\left(z-1\right)^{3}}-\frac{1}{\left(z-1\right)^{4}}+\frac{1}{\left(z-1\right)^{5}}+\cdots, $$ 

 $$ (1<|z-1|<+\infty) $$ 

于是就说“z=1 又是  $ f(z) $ 的本质奇点”. 这个说法对吗？

3 设函数  $ f(z) $ 在点 a 解析,试证函数

 $$ g(z)=\left\{\begin{matrix}{\frac{f(z)-f(a)}{z-a},}&{z\neq a,}\\ {f^{\prime}(a),}&{z=a,}\\ \end{matrix}\right. $$ 

在点 a 也解析.

4 设  $ f(z) $ 为整函数, 试证

 $$ \mathbf{g}\left(z\right)=\left\{\begin{matrix}{\frac{f\left(z\right)-f\left(0\right)}{z},}&{z\neq0,}\\ {f^{\prime}\left(0\right),}&{z=0,}\\ \end{matrix}\right. $$ 

也是一个整函数.

5 试证: 若 a 为  $ f(z) $ 的单值性孤立奇点, 则 a 为  $ f(z) $ 的 m 阶极点的充要条件是

 $$ \lim_{z\to a}(z-a)^{m} f(z)=\alpha(\neq0,\infty), $$ 

其中 m 是正整数.

6 若 a 为  $ f(z) $ 的单值性孤立奇点， $ (z-a)^{k}f(z) $ ( $ k $ 为正整数) 在点 a 的去心邻域内有界。试证：a 是  $ f(z) $ 的不高于 k 阶的极点或可去奇点。

7 考查函数

 $$ f(z)=\sin\left(\frac{1}{\sin\frac{1}{z}}\right) $$ 

的奇点类型.

8 试证: 在扩充 z 平面上只有一个一阶极点的解析函数  $ f(z) $ 必有如下形式:

 $$ f(z)=\frac{az+b}{cz+d},ad-bc\neq0. $$ 

9（含点00的区域的车辆面积分定理）设 C 是一条周线，区域 D 是 C 的

<!-- page: 238 -->

外部(含点 $ \infty $),  $ f(z) $在D内解析且连续到C;又设

 $$ \lim_{z\to\infty}f(z)=c_{0}\neq\infty, $$ 

则

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c^{-}}f(z)\mathrm{d}z=-c_{-1}, $$ 

这里  $ c_{0} $ 及 c_{-1} $ 是  $ f(z) $ 在无穷远点去心邻域内的洛朗展式的系数. 试证之.

提示 设 R 充分大, 使 C 及其内部全含于圆周  $ \Gamma: |z| = R $ 的内部(图 5.8). 其次, 证明

 $$ \frac{1}{2\pi\mathrm{i}}\int_{\Gamma^{-}}f(z)\mathrm{d}z=-c_{-1}. $$ 

再应用复周线的柯西积分定理,就会得证.

<div style="text-align: center;"><img src="images/p0238_img_in_image_box_671_2732_1963_3933.jpg" alt="图5.8" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.8</div> </div>


<div style="text-align: center;"><img src="images/p0238_img_in_image_box_2451_2647_3779_3936.jpg" alt="图5.9" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.9</div> </div>


10 （含点 $ \infty $的区域的柯西积分公式）假设条件同前题，则

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c^{-}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=\left\{\begin{aligned}&f(z)-f(\infty),&&z\in D,\\ &0-f(\infty),&&z\notin\overline{D}.\end{aligned}\right. $$ 

这里  $ C^{-} $表示的方向,含点  $ \infty $ 的区域 D 恰在一人沿它前进的左方.

提示 例如就定点  $ z \in D $ 来说，以 z 为心作充分大圆周  $ \Gamma_{z} $，使 C 及其内部全含于  $ \Gamma_{z} $ 内部（如图 5.9）.  $ L = \Gamma_{z} + C^{-} $ 构成一复周线。则应用有界区域的柯西积分公式

 $$ \frac{1}{2\pi\mathrm{i}}\int_{L}\frac{f(\boldsymbol{\zeta})}{\zeta-z}\mathrm{d}\zeta=f(z). $$ 

再进一步由  $ f(\zeta) $ 在  $ R<|\zeta-z|<+\infty $ 内的洛朗展式可以证明

<!-- page: 239 -->

$$ \frac{1}{2\pi\mathrm{i}}\int_{r_{z}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=f(\infty). $$ 

( $ R<|\zeta-z|<+\infty $ 就是以 z 为中心的点  $ \infty $ 的去心邻域.)

11 应用上题公式计算积分

 $$ I=\frac{1}{2\pi\mathrm{i}}\int_{|z|=99}\frac{\mathrm{d}z}{(z-2)(z-4)(z-6)\cdots(z-98)(z-100)}. $$ 

答:  $ I = -\frac{1}{\prod_{k=1}^{49}(100 - 2k)} = -\frac{1}{98!!} $.

注 第9、10两题中的区域 D 和边界 C 可代以更一般的形式: 设 D 是扩充 z 平面上包含点  $ \infty $ 的区域, 其边界 C 由有限条互不包含且互不相交的周线  $ C_{1}, C_{2}, \cdots, C_{m} $ 组成, 即

 $$ C=C_{1}+C_{2}+\cdots+C_{m}. $$ 

12 设解析函数  $ f(z) $ 在扩充 z 平面上只有孤立奇点，则奇点的个数必为有限个.试证之.

13 求在扩充 z 平面上只有 n 个一阶极点的解析函数的一般形式.

14 设(1)C 是一条周线， $ f(z) $ 在 C 的内部是亚纯的，且连续到 C；

(2)  $ f(z) $ 沿 C 不为零，

则(试证)函数  $ f(z) $ 在 C 的内部至多只有有限个零点和极点.

15 在施瓦茨引理的假设条件下,如果原点是  $ f(z) $ 的  $ \lambda $ 阶零点,求证

 $$ \left|\frac{f^{\lambda}(0)}{\lambda!}\right|\leqslant1. $$ 

要想这里的等号成立，必需  $ f(z)=\mathrm{e}^{\mathrm{i}\alpha}z^{\lambda} $ ( $ \alpha $ 为实数， $ |z|<1 $).

16 若  $ f(z) $ 在圆  $ \left|z\right| < R $ 内解析， $ f(0) = 0 $， $ \left|f(z)\right| \leq M < +\infty $，则 (1)  $ \left|f(z)\right| \leq \frac{M}{R}\left|z\right| $， $ \left|z\right| < R $，且有  $ \left|f'(0)\right| \leq \frac{M}{R} $；(2) 若在圆内有一点  $ z (0 < \left|z\right| < R) $ 使

 $$ \mid f(z)\mid=\frac{M}{R}\mid z\mid, $$ 

就有

 $ f(z)=\frac{M}{R}\mathrm{e}^{\mathrm{i}\alpha}z $ （ $ \alpha $ 为实数， $ |z|<R $）.

注 （1）当 R=1, M=1 时, 本题就是我们前面证明过的施瓦茨引理, 故本题为其更一般的形式.

（2）本题的结果也有如下一个简单改进：我们保留本题的假设条件不

<!-- page: 240 -->

变，如果 z=0 是  $ f(z) $ 的  $ \lambda $ 阶零点，则

 $$ \left|f(z)\right|\leqslant\frac{M}{R}\mid z\mid^{\lambda}(\mid z\mid<R), 且有 \left|\frac{f^{(\lambda)}(0)}{\lambda!}\right|\leqslant\frac{M}{R}. $$ 

如果这些关系中，有一个取等号，这只有

 $$ f\left(z\right)=\frac{M}{R}\mathrm{e}^{\mathrm{i}\alpha}z^{\lambda}\left(\alpha 为实数 ,\mid z\mid<R\right). $$ 

（当  $ \lambda = 1 $ 时，这些就是本题的结果。）

<!-- page: 241 -->

## 第六章 留数理论及其应用

这一章是第三章柯西积分理论的继续. 中间插入的泰勒级数和洛朗级数是研究解析函数的有力工具. 留数在复变函数论本身及实际应用中都是很重要的, 它和计算周线积分(或归结为考察周线积分)的问题有密切关系. 此外应用留数理论, 我们已有条件去解决“大范围”的积分计算问题, 还可以考察区域内函数的零点分布状况.

‖◆‖‖◆‖‖‖◆‖‖‖‖◆‖‖‖‖‖◆‖‖‖‖‖◆‖‖‖‖‖◆‖‖‖‖‖◆‖‖‖‖‖◆‖‖‖‖‖◆

#### §1. 留数

1. 留数的定义及留数定理 如果函数  $ f(z) $ 在点 a 是解析的，周线 C 全在点 a 的某邻域内，并包围点 a，则根据柯西积分定理

 $$ \int_{c}\dot{f}(z)\mathrm{d}z=0. $$ 

但是，如果 a 是  $ f(z) $ 的一个孤立奇点，且周线 C 全在 a 的某个去心邻域内，并包围点 a，则积分…

 $$ \int_{c}f(z)\mathrm{d}z $$ 

的值，一般说来，不再为零。并且利用洛朗系数公式很容易计算出它的值来。概括起来，我们有

定义 6.1 设函数  $ f(z) $ 以有限点  $ a $ 为孤立奇点，即  $ f(z) $ 在

<!-- page: 242 -->

点 a 的某去心邻域  $ 0<|z-a|<R $ 内解析,则称积分

 $$ \frac{1}{2\pi\mathrm{i}}\int_{\mathbf{r}}f(z)\mathrm{d}z(\stackrel{\cdot}{\boldsymbol{\Gamma}}\colon|\boldsymbol{z}-\boldsymbol{a}|=\rho,0<\rho<R) $$ 

为  $ f(z) $ 在点 a 的留数 (residue)，记为  $ \mathrm{Res}f(z) $.

 $$ z=a $$ 

由柯西积分定理 3.10 知道，当  $ 0 < \rho < R $，留数的值与  $ \rho $ 无关，利用洛朗系数公式 (5.5) 有

 $$ \begin{array}{c}{\frac{1}{2\pi\mathrm{i}}\displaystyle\int_{r}f(z)\mathrm{d}z=c_{-1},}\\ {\mathrm{R e s}f(z)=c_{-1}.}\\ {z=a}\end{array} $$ 

即

这里  $ c_{-1} $ 是  $ f(z) $ 在 z = a 处的洛朗展式中  $ \frac{1}{z - a} $ 这一项的系数.

“由此可知，函数在有限可去奇点处的留数为零.

定理6.1 (柯西留数定理)  $ f(z) $ 在周线或复周线 C 所范围的区域内，除  $ a_{1}, a_{2}, \cdots, a_{n} $ 外解析，在闭域  $ \overline{D} = D + C $ 上除  $ a_{1}, a_{2}, \cdots, a_{n} $ 外连续，则（“大范围”积分）

$$  \int_{C}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{R e s}_{z=a_{k}}f(z).   \tag*{(6.2)}$$

证 以  $ a_{k} $ 为心，充分小的正数  $ \rho_{k} $ 为半径画圆周  $ \Gamma_{k}: |z - a_{k}| = \rho_{k}(k = 1, 2, \cdots, n) $，使这些圆周及其内部均含于 D，并且彼此互。相隔离（图 6.1）。应用复周线的柯西积分定理 3.10 得

 $$ \int_{C}f(z)\mathrm{d}z=\sum_{k=1}^{n}\int_{R_{k}}f(z)\mathrm{d}z. $$ 

由留数的定义，有

 $$ \int_{\Gamma_{k}}f(z)\mathrm{d}z=2\pi\mathrm{i}\operatorname*{R e s}_{z=a_{k}}f(z). $$ 

代入上式，即知(6.2)为真.

（思考题 试说明柯西积分定理 3.10 与柯西积分公式都是柯西留数定理的特殊情形.

留数定理把计算周线积分的整体问题，化为计算各孤立奇点

<!-- page: 243 -->

<div style="text-align: center;"><img src="images/p0243_img_in_image_box_1255_580_3184_1963.jpg" alt="图 6.1" width="43%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.1</div> </div>


处留数的局部问题.

2. 留数的求法 为了应用留数定理求周线积分，首先应该掌握求留数的方法.而计算在孤立奇点 a 的留数时，我们只关心其

洛朗展式中的  $ \frac{1}{z - a} $ 这一项的系数，所以应用洛朗展式求留数是一般方法.下面的定理是求 n 阶极点处留数的公式，免得每求一个极点处的留数，都要去求一次洛朗展式.不过这个公式对于阶数过高（例如超过三阶）的极点，计算起来也未必简单.

定理 6.2 设 a 为  $ f(z) $ 的 n 阶极点，

 $$ f(z)=\frac{\varphi(z)}{(z-a)^{n}}, $$ 

其中  $ \varphi(z) $ (由定理 5.4) 在点 a 解析,  $ \varphi(a) \neq 0 $, 则

$$  \operatorname{Res}f(z)=\frac{\varphi^{(n-1)}(a)}{(n-1)!}.   \tag*{(6.3)}$$

这里符号  $ \varphi^{(0)}(a) $ 代表  $ \varphi(a) $，且有  $ \varphi^{(n-1)}(a)=\lim_{z\to a}\varphi^{(n-1)}(z) $.

证

 $$ \mathrm{R e s}_{z=a}f(z)=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma}\frac{\varphi(z)}{\left(z-a\right)^{n}}\mathrm{d}z=\frac{\varphi^{(n-1)}(a)}{\left(n-1\right)!}. $$ 

推论 6.3 设 a 为  $ f(z) $ 的一阶极点，

 $$ \varphi(z)=(z-a)f(z), $$

<!-- page: 244 -->

则

$$  \mathop{\operatorname{R e s f}}_{z=a}(z)=\varphi(a).   \tag*{(6.4)}$$

推论 6.4 设 a 为  $ f(z) $ 的二阶极点，

 $$ \begin{aligned}\varphi(z)&=(z-a)^{2}f(z),\\\mathbf{Res}f(z)&=\varphi^{\prime}(a).\\z&=a\end{aligned} $$ 

则

定理 6.5 设 a 为  $ f(z) = \frac{\varphi(z)}{\psi(z)} $ 的一阶极点 (只要  $ \varphi(z) $ 及  $ \psi(z) $ 在点 a 解析, 且  $ \varphi(a) \neq 0, \psi(a) = 0, \psi'(a) \neq 0. $)，则

 $$ \operatorname{Res}f(z)=\frac{\varphi(a)}{\psi^{\prime}(a)}. $$ 

证 因为 a 为  $ f(z)=\frac{\varphi(z)}{\psi(z)} $ 的一阶极点，故

 $$ \begin{aligned}\operatorname{Res}f(z)&=\lim_{z\to a}\frac{\varphi(z)}{\psi(z)}(z-a)=\lim_{z\to a}\frac{\varphi(z)}{\frac{\psi(z)-\psi(a)}{z-a}}\\&=\frac{\varphi(a)}{\psi^{\prime}(a)}.\end{aligned} $$ 

要熟练掌握应用推论 6.3、推论 6.4 及定理 6.5 来计算函数在一、二阶极点处的留数.

例 6.1 计算积分  $ \int_{|z|=2}\frac{5z-2}{z(z-1)^{2}}\mathrm{d}z $.

解 显然，被积函数  $ f(z)=\frac{5z-2}{z(z-1)^{2}} $ 在圆周  $ \left|z\right|=2 $ 的内部只有一阶极点 z=0 及二阶极点 z=1.

由推论 6.3，

 $$ \operatorname{Res}_{z=0}f(z)=\frac{5z-2}{(z-1)^2}\bigg|_{z=0}=-2; $$ 

由推论 6.4

 $$ \mathrm{R e s}_{z=1}f(z)=\left(\frac{5z-2}{z}\right)^{\prime}\bigg|_{z=1}=\frac{2}{z^{2}}\bigg|_{z=1}=2; $$ 

故由留数定理得.

<!-- page: 245 -->

$$ \int_{|z|=2}\frac{5z-2}{z(z-1)^{2}}\mathrm{d}z=2\pi\mathrm{i}(-2+2)=0. $$ 

例 6.2 计算积分  $ \int_{|z|=n}\tan\pi z dz $ （n 为正整数）.

解  $ \tan \pi z = \frac{\sin \pi z}{\cos \pi z} $ 只以  $ z = k + \frac{1}{2} $， $ (k = 0, \pm 1, \cdots) $ 为一阶极点。由定理 6.5 得

 $$ \begin{aligned}\operatorname{Res}_{\ z=k+\frac{1}{2}}(\tan\pi z)&=\frac{\sin\pi z}{(\cos\pi z)^{\prime}}\Bigg|_{z=k+\frac{1}{2}}=-\frac{1}{\pi}.\ $ k&=0,\pm1,\cdots)\end{aligned} $$ 

于是，由留数定理得

 $$ \begin{aligned}\int_{|z|=n}\tan\pi z\mathrm{d}z&=2\pi\mathrm{i}\sum_{k+\frac{1}{2}<n}\operatorname{Res}(\tan\pi z)\\&=2\pi\mathrm{i}\left(-\frac{2n}{\pi}\right)=-4n\mathrm{i}.\end{aligned} $$ 

例 6.3 计算积分  $ \int_{|z|=1}\frac{\cos z}{z^{3}}dz $.

解  $ f(z)=\frac{\cos z}{z^{3}} $ 只以 z=0 为三阶极点. 由定理 6.2 得

 $$ \mathbf{Res}_{z=0}f(z)=\frac{1}{2!}[\cos z]_{z=0}^{\prime \prime}=-\frac{1}{2}, $$ 

故由留数定理得  $ \int_{|z|=1}\frac{\cos z}{z^{3}}\mathrm{d}z=2\pi\mathrm{i}\left(-\frac{1}{2}\right)=-\pi\mathrm{i} $.

*例 6.4 计算积分  $ \int_{|z|=1}\frac{z\sin z}{(1-\mathrm{e}^{z})^{3}}\mathrm{d}z $.

解法一 被积函数在单位圆周  $ \left|z\right|=1 $ 内部只有 z=0 一个奇点，但其进一步的性质粗略一看还不明显，故我们先采用洛朗展式求留数的一般方法.

 $$ \frac{z\sin z}{\left(1-\mathrm{e}^{z}\right)^{3}}=\frac{z\left(z-\frac{z^{3}}{3!}+\cdots\right)}{-\left(z+\frac{z^{2}}{2!}+\cdots\right)^{3}}=-\frac{z^{2}}{z^{3}}\cdot\frac{\left(1-\frac{z^{2}}{3!}+\cdots\right)}{\left(1+\frac{z}{2!}+\cdots\right)^{3}}, $$

<!-- page: 246 -->

后面那个分式在 z=0 为解析,故可展为 z 的幂级数:

 $$ 1+a_{1}z+\cdots $$ 

(数字  $ a_{1} $ 及以下各项我们不需关心!). 于是在 z=0 的去心邻域内有

 $$ \frac{z\sin z}{(1-\mathrm{e}^{z})^{3}}=-\frac{1}{z}-a_{1}-\cdots, $$ 

由此即得

 $$ \mathrm{Res}_{z=0}\frac{z\sin z}{(1-\mathrm{e}^{z})^{3}}=-1, $$ 

故由留数定理, 原积分等于  $ -2\pi i $.

解法二 仔细分析,我们看出  $ 1 - e^{z} $ 的全部零点为

 $$ z=2k\pi\mathrm{i},k=0,\pm1,\cdots $$ 

只有 z=0 在单位圆周  $ \left|z\right|=1 $ 的内部，它是被积函数分母  $ (1-e^{z})^{3} $ 的三阶零点。又 z=0 显然是被积函数分子  $ z\sin z $ 的二阶零点。所以被积函数

 $$ f(z)=\frac{z\sin z}{\left(1-\mathrm{e}^{z}\right)^{3}} $$ 

在圆周  $ \left|z\right|=1 $ 的内部只有 z=0 一个一阶极点. 这时

 $$ \varphi(z)=z f(z)=\frac{z^{2}\sin z}{(1-\mathrm{e}^{z})^{3}}, $$ 

(注意 因子 z 与  $ f(z) $ 的分母形式上消不掉, 若这时将 z=0 代入, 则成  $ \frac{0}{0} $ 的不定型) 所以

 $$ \begin{array}{l}\operatorname{Res}f(z)=\varphi(0)=\limlimits_{z\to0}\varphi(z)=\lim\limits_{z\to0}\frac{z^2\sin z}{(1-\mathrm{e}^z)^3}\\=\lim\limits_{z\to0}\frac{\sin z}{z}\cdot\frac{z^3}{(1-\mathrm{e}^z)^3}\\=\left(\lim\limits_{z\to0}\frac{z}{1-\mathrm{e}^z}\right)^3=\left(\lim\limits_{z\to0}\frac{1}{-\mathrm{e}^z}\right)^3\\=(-1)^3=-1.\end{array} $$

<!-- page: 247 -->

故由留数定理, 原积分等于  $ -2\pi i $.

例 6.5 计算积分  $ \int_{|z|=1} e^{\frac{1}{z^{2}}} dz $.

解 在单位圆周  $ \left|z\right|=1 $ 的内部，函数  $ e^{\frac{1}{z^{2}}} $ 只有一个本质奇点 z=0. 在该点的去心邻域内有洛朗展式

 $$ \mathrm{e}^{z^{\frac{1}{2}}}=1+\frac{1}{z^{2}}+\frac{1}{2!}\frac{1}{z^{4}}+\cdots, $$ 

于是

 $$ \mathop{\mathrm{R e s}}_{z=0}\mathrm{e}^{\frac{1}{z^{2}}}=0. $$ 

故由留数定理得

 $$ \int_{\{z\mid=1}}\mathrm{e}^{\frac{1}{z^{2}}}\mathrm{d}z=2\pi\mathrm{i}\cdot\underset{z=0}{\mathrm{R e s}}\mathrm{e}^{\frac{1}{z^{2}}}=0. $$ 

3. 函数在无穷远点的留数 留数的概念可以推广到无穷远点的情形.

定义 6.2 设  $ \infty $ 为函数  $ f(z) $ 的一个孤立奇点，即  $ f(z) $ 在去心邻域  $ N - \{\infty\} $:  $ 0 \leq r < |z| < +\infty $ 内解析，则称

 $$ \frac{1}{2\pi\mathrm{i}}\int_{\Gamma^{-}}f(z)\mathrm{d}z,(\Gamma::|z|=\rho>r) $$ 

为 $ f(z) $在点 $ \infty $的留数，记为 $ \mathrm{Res}_{z=\infty}f(z) $，这里 $ \Gamma^{-} $是指顺时针方向（这个方向很自然地可以看作是绕无穷远点的正向）.

设  $ f(z) $ 在  $ 0 \leq r < |z| < +\infty $ 内的洛朗展式为

 $$ f(z)=\cdots+\frac{c_{-i n}}{z^{n}}+\cdots+\frac{c_{-1}}{z}+^{i}c_{0}+c_{1}\stackrel{.}{z}+\cdots+c_{n}z^{n}+\cdots, $$ 

由逐项积分定理及第三章例3.2，即知

$$  \mathrm{R e s}_{z=\infty}f_{i}(z)=\frac{1}{2\pi\mathrm{i}}\int_{\Gamma^{-}}f(z)\mathrm{d}z=-c_{-1},   \tag*{(6.6)}$$

也就是说， $ \mathrm{Res}f(z) $ 等于  $ f(z) $ 在点  $ \infty $ 的洛朗展式中  $ \frac{1}{z} $ 这一项的系数反号.

定理 6.6 如果函数  $ f(z) $ 在扩充 z 平面上只有有限个孤立

<!-- page: 248 -->

奇点（包括无穷远点在内），设为  $ a_{1}, a_{2}, \cdots, a_{n} $;  $ \infty $, 则  $ f(z) $ 在各点的留数总和为零.

证 以原点为心作圆周  $ \Gamma $，使  $ a_{1}, a_{2}, \cdots, a_{n} $ 皆含于  $ \Gamma $ 的内部，则由留数定理得

 $$ \int_{\Gamma}f(z)\mathrm{d}\dot{z}=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{R e s}f(\dot{z}), $$ 

两边除以  $ 2\pi i $，并移项即得

 $$ \sum_{k=1}^{n}\mathop{\mathrm{R e s}}_{z=a_{k}}\mathsf{f}(z)+\frac{1}{2\pi\mathrm{i}}\int_{\dot{R}^{-}}f(z)\mathrm{d}z=0, $$ 

亦即

 $$ \sum_{k=1}^{n}\mathop{\mathrm{R e s}}_{z=a_{k}}\mathsf{f}(z)+\mathop{\mathrm{R e s}}_{z=\infty}\mathsf{f}(z)=0. $$ 

要特别注意: 虽然在  $ f(z) $ 的有限可去奇点 a 处, 必有  $ \mathrm{Res}f(z)=0 $, 但是, 如果点  $ \infty $ 为  $ f(z) $ 的可去奇点 (或解析点), 则 z=a

 $ \mathrm{Res}f(z) $ 可以不是零。例如  $ f(z)=2+\frac{1}{z} $ 以  $ z=\infty $ 为可去奇点，但  $ z=\infty $

 $ \mathrm{Res}f(z) = -1 $.

 $ z = \infty $

下面我们引入计算留数 $ Resf(z) $的另一公式.

令

 $$ t=\frac{1}{z}. $$ 

于是

 $$ \varphi\left(t\right)=f\left(\frac{1}{t}\right)=f\left(z\right), $$ 

且 z 平面上无穷远点的去心邻域  $ N - \{\infty\}: 0 \leq r < |z| < +\infty $ 被变成 t 平面上原点的去心邻域  $ K - \{0\}: 0 < |t| < \frac{1}{r} $ (如  $ r = 0 $, 规定  $ \frac{1}{r} = +\infty $); 圆周  $ \Gamma: |z| = \rho > r $ 被变成圆周  $ y: |t| = \lambda = \frac{1}{\rho} < \frac{1}{r} $. 从而易证

 $$ \frac{1}{2\pi i}\int_{F^{-}}f(z)\mathrm{d}z=-\frac{1}{2\pi i}\int_{F}\left(\frac{1}{t}\right)\cdot\frac{1}{t^{2}}\mathrm{d}t. $$

<!-- page: 249 -->

所以，

$$  \mathbf{R e s}_{z=\infty}f(z)=-\mathbf{R e s}_{t=0}\left[f\left(\frac{1}{t}\right)\frac{1}{t^{2}}\right].   \tag*{(6.7)}$$

例 6.6 计算积分

 $$ I=\int_{|z|=4}\frac{z^{15}}{(z^{2}+1)^{2}(z^{4}+2)^{3}}\mathrm{d}z. $$ 

解 被积函数一共有七个奇点:  $ z = \pm i $,  $ z = \sqrt[4]{2} e^{i\frac{\pi + 2k\pi}{4}} $ (k = 0, 1, 2, 3) 以及 z =  $ \infty $. 前六个奇点均含在  $ \left|z\right| = 4 $ 内部.

要计算  $ \left|z\right|=4 $ 内部六个奇点的留数和是十分麻烦的，所以应用上述定理及留数定理得

 $$ I=2\pi\mathrm{i}\left[-\operatorname{Res}_{z=\infty}f(z)\right]. $$ 

由下式可知  $ f(z) $ 在  $ \infty $ 处的洛朗展式中  $ \frac{1}{z} $ 这一项的系数  $ c_{-1} $.

 $$ \begin{aligned}f(z)&=\frac{z^{15}}{\left(z^{2}+1\right)^{2}\left(z^{4}+2\right)^{3}}=\frac{z_{1}^{15}}{z^{16}\left(1+\frac{1}{z^{2}}\right)^{2}\left(1+\frac{2}{z^{4}}\right)^{3}}\\&=\frac{1}{z}\left(1-2\cdot\frac{1}{z^{2}}+\cdots\right)\left(1-3\cdot\frac{2}{z^{4}}+\cdots\right),\end{aligned} $$ 

因此， $ \mathrm{Res}_{z=\infty}f(z)\stackrel{(6.6)}{=} -1 $，故  $ I=2\pi i $。

另外，也可应用公式(6.7).先看

 $$ \begin{aligned}f\left(\frac{1}{t}\right)\frac{1}{t^{2}}&=\frac{\frac{1}{t^{15}}}{\left(\frac{1}{t^{2}}+1\right)^{2}\left(\frac{1}{t^{4}}+2\right)^{3}}\cdot\frac{1}{t^{2}}\\&=\frac{1}{t\left(1+t^{2}\right)^{2}\left(1+2t^{4}\right)^{3}},\end{aligned} $$ 

它以 t=0 为一阶极点. 所以

 $$ \begin{aligned}I&=2\pi\mathrm{i}\left[\begin{array}{c}-\operatorname{Res}\limits_{z=\infty}f(z)\end{array}\right]\xlongequal{(6.7)}2\pi\mathrm{i}\operatorname{Res}\limits_{t=0}\left[\begin{array}{c}f\left(\frac{1}{t}\right)\cdot\frac{1}{t^{2}}\end{array}\right]\\&=2\pi\mathrm{i}.\end{aligned} $$

<!-- page: 250 -->

思考题 试总结计算  $ f(z) $ 的周线积分  $ \int_{c} f(z) dz $ 的种种方法.

#### §2. 用留数定理计算实积分

某些实施的定积分可应用留数定理进行计算，尤其是对原函数不易直接求得的定积分和反常积分，常是一个有效的方法，其要点是将它化归为复变函数的周线积分.

1. 计算  $ \int_{0}^{2\pi} R(\cos\theta,\sin\theta)\mathrm{d}\theta $ 型积分  $ \dot{\cdot} $ 这里  $ R(\cos\theta,\sin\theta) $ 表  $ \cos\theta,\sin\theta $ 的有理函数，并且在  $ [0,2\pi] $ 上连续. 若命  $ z=e^{i\theta} $，则

 $$ \cos\theta=\frac{z+z^{-1}}{2},\sin\theta=\frac{z-z^{-1}}{2i},\mathrm{d}\theta=\frac{\mathrm{d}z}{\mathrm{i}z}, $$ 

当  $ \theta $ 经历变程  $ [0,2\pi] $ 时, z 沿圆周  $ \left|z\right|=1 $ 的正方向绕行一周. 因此有

 $$ \int_{0}^{2\pi}R\left(\cos\theta,\sin\theta\right)\mathrm{d}\theta=\int_{\mid z\mid=1}R\left(\frac{z+z^{-1}}{2},\frac{z-z^{-1}}{2\mathrm{i}}\right)\frac{\mathrm{d}z}{\mathrm{i}z}, $$ 

右端是 z 的有理函数的周线积分，并且积分路径上无奇点，应用留数定理就可求得其值.

注 这里关键一步是引进变数代换  $ z = e^{i\theta} $，至于被积函数  $ R(\cos\theta, \sin\theta) $ 在  $ [0, 2\pi] $ 上的连续性可不必先检验，只要看变换后的被积函数在  $ \left|z\right| = 1 $ 上是否有奇点.

例 6.7 计算积分

 $$ I=\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{1-2\dot{p}\cos\theta+\dot{p}^{2}}(0\leqslant|p|<1). $$ 

解 命  $ z = e^{i\theta} $，则  $ \mathrm{d}\theta = \frac{\mathrm{d}z}{iz} $。当  $ p \neq 0 $ 时，

 $$ 1-2p\cos\theta+p^{2}=1-p(z+z^{-1})+p^{2}=\frac{(z-p)(1-p z)}{z}, $$

<!-- page: 251 -->

这样就有

 $$ I=\frac{1}{\mathrm{i}}\int_{|z|=1}\frac{\mathrm{d}z}{(z-p)(1-p z)}, $$ 

且在圆 $ \left|z\right|<1 $内

 $$ f(z)=\frac{1}{(z-p)(1-p z)}, $$ 

只以 z=p 为一阶极点，在  $ \left|z\right|=1 $ 上无奇点，依公式(6.4)

 $$ \operatorname{Res}f(z)=\frac{1}{1-p z}\bigg|_{z=p}=\frac{1}{1-p^{2}}(0<|p|<1), $$ 

所以，由留数定理得  $ I=\frac{1}{\mathrm{i}}\cdot2\pi\mathrm{i}\cdot\frac{1}{1-p^{2}}=\frac{2\pi}{1-p^{2}}(0\leqslant|p|<1) $.

注 此题在数学分析中可用万能代换的方法求解，比较起来，用复变函数的方法求解要简单得多.

思考题 当  $ |p| > 1 $ 时, 积分

 $$ \int_{0}^{2\pi}\frac{\mathrm{d}\theta}{1-2p\cos\theta+p^{2}} $$ 

之值为何？

例 6.8 计算积分

 $$ I=\int_{0}^{2\pi}\frac{\sin^{2}\theta}{a+b\cos\theta}\mathrm{d}\theta(a>b>0). $$ 

解 命  $ z = e^{i\theta} $，则

 $$ \begin{align*}I&=\int_{|z|=1}\left[\frac{-(z^2-1)^2}{4z^2}\right]\cdot\frac{1}{a+b\left(\frac{z^2+1}{2z}\right)}\cdot\frac{\mathrm{d}z}{\mathrm{i}z}\\&=\frac{\mathrm{i}}{2b}\int_{|z|=1}\frac{(z^2-1)^2}{z^2\left(z^2+\frac{2a}{b}z+1\right)}\mathrm{d}z\\&=\frac{\mathrm{i}}{2b}\int_{|z|=1}\frac{(z^2-1)^2}{z^2(z-a)(z-\beta)}\mathrm{d}z,\end{align*} $$ 

其中

 $$ \alpha=\frac{-a+\sqrt{a^{2}-b^{2}}}{b},\beta=\frac{-a-\sqrt{a^{2}-b^{2}}}{b} $$ 

为实系数二次方程

<!-- page: 252 -->

$$ z^{2}+\frac{2a}{b}z+1=0 $$ 

的两个相异实根. 由根与系数的关系  $ \alpha\beta=1 $，且显然  $ |\beta|>|\alpha| $，故必  $ | \alpha |<1, |\beta|>1 $.

于是，被积函数  $ f(z) $ 在  $ \left|z\right|=1 $ 上无奇点。在单位圆  $ \left|z\right|<1 $ 内只有一个二阶极点 z=0 和一个一阶极点 z= $ \alpha $。由公式 (6.5) 及 (6.4) 得

 $$ \operatorname{Res}f(z)=\left[\frac{(z^2-1)^2}{z^2+\frac{2a}{b}z+1}\right]^{\prime}_z=-\frac{2a}{b}, $$ 

 $$ \begin{aligned}\operatorname{Res}f(z)&=\frac{(z^{2}-1)^{2}}{z^{2}(z-\beta)}\Bigg|_{z=\alpha}=\frac{(a^{2}-1)^{2}}{a^{2}(a-\beta)}=\frac{\left(a-\frac{1}{a}\right)^{2}}{a-\beta}\\&=\frac{(a-\beta)^{2}}{a-\beta}=a-\beta=\frac{2\sqrt{a^{2}-b^{2}}}{b},\end{aligned} $$ 

由留数定理得

 $$ \begin{aligned}I&=\frac{\mathrm{i}}{2b}\cdot2\pi\mathrm{i}\left[-\frac{2a}{b}+\frac{2\sqrt{a^{2}-b^{2}}}{b}\right]\\&=\frac{2\pi}{b^{2}}\left[a-\sqrt{a^{2}-b^{2}}\right].\end{aligned} $$ 

例 6.9 计算积分

 $$ I=\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{1+\cos^{2}\theta}. $$ 

解 命  $ z = e^{i\theta} $，则

 $$ I=\int_{\Gamma:\mid z\mid=1}\frac{4z\mathrm{d}z}{\mathrm{i}\left(z^{4}+6z^{2}+1\right)}, $$ 

又命  $ z^{2}=u $ ，则  $ \frac{4z\mathrm{d}z}{\mathrm{i}(z^{4}+6z^{2}+1)}=\frac{2\mathrm{d}u}{\mathrm{i}(u^{2}+6u+1)} $

当 z 绕  $ \Gamma $ 圆周一周时，u 亦在其上绕二周，故

 $$ I=2\int_{r}\frac{2\mathrm{d}u}{\mathrm{i}(u^{2}+6u+1)}=\frac{4}{\mathrm{i}}\int_{r}\frac{\mathrm{d}u}{u^{2}+6u+1}. $$

<!-- page: 253 -->

被积函数  $ f(u) $ 在  $ \Gamma $ 内部仅有一个一阶极点  $ u = -3 + \sqrt{8} $.

 $$ \mathrm{R e s}_{u=-3+\sqrt{8}}f(u)=\left.\frac{1}{u+3+\sqrt{8}}\right|_{u=-3+\sqrt{8}}=\frac{1}{2\sqrt{8}}=\frac{1}{4\sqrt{2}}. $$ 

所以由留数定理，

 $$ I=\frac{4}{\mathrm{i}}\cdot2\pi\mathrm{i}\cdot\frac{1}{4\sqrt{2}}=\sqrt{2}\pi. $$ 

若  $ R(\cos \theta, \sin \theta) $ 为  $ \theta $ 的偶函数，则  $ \int_{0}^{\pi} R(\cos \theta, \sin \theta) d\theta $ 之值亦可由上述方法求之. 因此时

 $$ \int_{0}^{\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta=\frac{1}{2}\int_{-\pi}^{\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta, $$ 

仍命  $ z = e^{i\theta} $，与前同法，我们可将  $ \int_{-\pi}^{\pi} R(\cos\theta, \sin\theta) \, d\theta $ 化为单位圆周  $ \Gamma $ 上的积分.

例 6.10 计算积分

 $$ I=\int_{0}^{\pi}\frac{\cos m x}{5-4\cos x}\mathrm{d}x, $$ 

m 为正整数.

解 因为积分号下的函数为 x 的偶函数，故

 $$ I=\frac{1}{2}\int_{-\pi}^{\pi}\frac{\cos m x}{5-4\cos x}\mathrm{d}x, $$ 

命

 $$ I_{1}=\int_{-\pi}^{\pi}\frac{\cos m x}{5-4\cos x}\mathrm{d}x,\quad I_{2}=\int_{-\pi}^{\pi}\frac{\sin m x}{5-4\cos x}\mathrm{d}x, $$ 

则

 $$ I_{1}+\mathrm{i}I_{2}=\int_{-\pi}^{\pi}\frac{\mathrm{e}^{\mathrm{i}mx}}{5-4\cos x}\mathrm{d}x. $$ 

设  $ z = e^{ix} $，则

 $$ \begin{aligned}I_{1}+\mathrm{i}I_{2}&=\frac{1}{\mathrm{i}}\int_{r}\frac{z^{m}}{5z-2(1+z^{2})}\mathrm{d}z\\&=\frac{\mathrm{i}}{2}\int_{r}\frac{z^{m}}{\left(z-\frac{1}{2}\right)(z-2)}\mathrm{d}z.\end{aligned} $$

<!-- page: 254 -->

在圆周  $ \Gamma $ 内部，积分号下函数  $ f(z) $ 仅有一个一阶极点  $ z=\frac{1}{2} $，于是

 $$ \operatorname{Res}f(z)=\frac{z^m}{z-2}\bigg|_{z=\frac{1}{2}}=-\frac{1}{3(2^{m-1})}, $$ 

故由留数定理，

 $$ I_{1}+\mathrm{i}I_{2}=\left(-\frac{1}{2\mathrm{i}}\right)\cdot2\pi\mathrm{i}\left(-\frac{1}{3(2^{m-1})}\right)=\frac{\pi}{3(2^{m-1})}, $$ 

于是知

 $$ I_{1}=\frac{\pi}{3(2^{m-1})},\quad I_{2}=0, $$ 

所以

 $$ I=\frac{1}{2}I_{1}=\frac{\pi}{3(2^{m})}. $$ 

在实际问题中，往往需要计算反常积分，如：

 $$ \begin{aligned}&\int_{0}^{+\infty}\frac{\sin x}{x}\mathrm{d}x\quad( 有  阻  尼  的  振  动 )；\\ &\int_{0}^{+\infty}\sin x^{2}\mathrm{d}x\quad( 光  的  折  射 )；\\ &\int_{0}^{+\infty}\mathrm{e}^{-ax^{2}}\cos bx\mathrm{d}x.(a>0).\quad( 热  传  导 ) 等  等 .\\ \end{aligned} $$ 

回忆数学分析中计算反常积分的方法，要计算上述几个反常积分是麻烦的，而且没有统一的处理方法。但是根据留数定理来计算，往往就比较简捷。这种方法线索如下：

对于一个实函数  $ f(x) $ 沿 x 轴上一条有限线段  $ [a, b] $ 的积分，我们来补充  $ [a, b] $ 以一条或几条辅助曲线  $ \Gamma $，使  $ [a, b] $ 和  $ \Gamma $ 一起构成一条周线，围成一个区域 D（图 6.2）。如果有在 D 内解析，在  $ \overline{D} $ 上连续（除了 D 中有限个点外）的辅助函数  $ g(z) $，在  $ [a, b] $ 内  $ g(z) $ 或  $ g(z) $ 的实部及虚部中的一个等于  $ f(x) $，则由留数定理就有

$$  \int_{a}^{b}g(x)\mathrm{d}x+\int_{\Gamma}g(z)\mathrm{d}z=2\pi\mathrm{i}\sum,   \tag*{(6.8)}$$

<!-- page: 255 -->

其中 $ \sum $是 $ g(z) $在D内的奇点的留数总和.假如上式中的第二个积分能够算出，则 $ \int_{a}^{b}f(x)dx $的计算问题就解决了.如果a或b不是有限数，则可于(6.8)式两端取极限，这时，如能求得 $ \int_{r}^{g}(z)dz $的极限，就能至少得到所求反常积分的柯西主值.但在一般给出的问题中，或者只需要要求主值，或者不难预先看出这一反常积分收敛，因此，所求出的那个主值恰好就是所需要的值.

<div style="text-align: center;"><img src="images/p0255_img_in_image_box_634_2123_1969_3184.jpg" alt="图 6.2" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.2</div> </div>


<div style="text-align: center;"><img src="images/p0255_img_in_image_box_2453_2326_3793_3181.jpg" alt="图 6.3" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.3</div> </div>


下面几段我们就分几种类型来具体讨论这个问题.

2. 计算  $ \int_{-\infty}^{+\infty} \frac{P(x)}{Q(x)} \mathrm{d}x $ 型积分 为了计算这种反常积分,我们先证明一个引理. 它主要用来估计辅助曲线  $ \Gamma $ 上的积分.

引理 6.1 设  $ f(z) $ 沿圆弧  $ S_{R}: z = Re^{\mathrm{i}\theta} (\theta_{1} \leqslant \theta \leqslant \theta_{2}, R $ 充分大) 上连续(图 6.3)，且

 $$ \lim_{R\to+\infty}z f(z)=\lambda $$ 

于  $ S_{R} $ 上一致成立（即与  $ \theta_{1} \leqslant \theta \leqslant \theta_{2} $ 中的  $ \theta $ 无关），则

$$  \lim_{R\to+\infty}\int_{S_{R}}f.(z)\mathrm{d}z\mathop{=}\limits_{\mathrm{i}}\mathrm{i}(\theta_{2}-\theta_{1})\lambda.   \tag*{(6.9)}$$

证 因为

 $$ \mathrm{i}(\theta_{2}-\theta_{1})\lambda=\lambda\int_{S_{R}}\frac{\mathrm{d}z}{z}, $$

<!-- page: 256 -->

于是有

$$  \left|\int_{S_{R}}f(z)\mathrm{d}z-\mathrm{i}(\theta_{2}-\theta_{1})\lambda\right|=\left|\int_{S_{R}}\frac{z f(z)-\lambda}{z}\mathrm{d}z\right|.   \tag*{(6.10)}$$

对于任给  $ \varepsilon>0 $，由已知条件，存在  $ R_{0}(\varepsilon)>0 $，使当  $ R>R_{0} $ 时，有不等式

 $$ |z f(z)-\lambda|<\frac{\epsilon}{\theta_{2}-\theta_{1}},\quad z\in S_{\mathrm{R}}. $$ 

于是(6.10)式不超过 $ \frac{\varepsilon}{\theta_{2}-\theta_{1}}\cdot\frac{l}{R}=\varepsilon $（其中l为 $ S_{R} $的长度，即 $ l=R(\theta_{2}-\theta_{1}) $）。

定理 6.7 设  $ f(z)=\frac{P(z)}{Q(z)} $ 为有理分式，其中

 $$ \begin{array}{r l}&{P(z)=c_{0}z^{m}+c_{1}z^{m-1}+\cdots+c_{m}(c_{0}\ne0)}\\ &{Q(\bar{z})=b_{0}\bar{z}^{n}+b_{1}z^{n-1}+\cdots+b_{n}(b_{0}\ne0).}\end{array} $$ 

与

为互质多项式，且符合条件: (1)  $ n - m \geqslant 2 $; (2) 在实轴上  $ Q(z) \neq 0 $, 于是有

$$  \int_{-\infty}^{+\infty}f(x)\mathrm{d}x=2\pi\mathrm{i}\sum_{\mathrm{I m}a_{k}>0}\mathrm{R e s}_{z=a_{k}}f(z).   \tag*{(6.11)}$$

证 由条件(1)、(2)及数学分析的结论, 知  $ \int_{-\infty}^{+\infty} f(x) \, dx $ 存在, 且等于它的主值

 $$ \begin{aligned}&\lim_{R\rightarrow+\infty}\int_{-R}^{+R}f(x)\mathrm{d}x.\\&P.V.\int_{-\infty}^{+\infty}f(x)\mathrm{d}x.\end{aligned} $$ 

记为

取上半圆周  $ \Gamma_{R}: z = Re^{i\theta} (0 \leq \theta \leq \pi) $ 作为辅助曲线（图 6.4）。于是，由线段  $ [-R, R] $ 及  $ \Gamma_{R} $ 合成一周线  $ C_{R} $，先取 R 充分大，使  $ C_{R} $ 内部包含  $ f(z) $ 在上半平面内的一切孤立奇点（实际上只有有限个极点）。而由条件 (2)， $ f(z) $ 在  $ C_{R} $ 上没有奇点。

<!-- page: 257 -->

按留数定理得

 $$ \int_{C_{R}}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{\mathrm{I m}a_{k}>0}\mathrm{R e s}_{z=a_{k}}f(z^{\prime}), $$ 

或写成

$$  \int_{-R}^{R}f(x)\mathrm{d}x+\int_{\Gamma_{R}}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{\mathrm{I m}a_{k}>0}\mathrm{R e s}_{f(z)_{k}}.   \tag*{(6.12)}$$

因为

<div style="text-align: center;"><img src="images/p0257_img_in_image_box_1412_1915_3034_2659.jpg" alt="图 6.4" width="36%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.4</div> </div>


 $$ \begin{align*}zf(z)|=&\left|z\frac{P(z)}{Q(z)}\right|=\left|z\frac{c_0z^m+\cdots+c_m}{b_0z^n+\cdots+b_n}\right|\\\overset{!}{=}\left|\frac{z^{m+1}}{z^n}\right|\left|\frac{c_0+\cdots+\frac{c_m}{z^m}}{b_0+\cdots+\frac{b_n}{z^n}}\right|,\end{align*} $$ 

由假设条件(1)知  $ n - m - 1 \geqslant 1 $，故沿  $ \Gamma_{R} $ 上就有

 $$ |z f(z)|\to0\quad(R\to+\infty). $$ 

在等式(6.12)中命  $ R \rightarrow +\infty $，并根据引理6.1，知(6.12)中第二项的积分之极限为零，这就证明了(6.11).

例 6.11 设 a>0, 计算积分

 $$ \int_{0}^{+\infty}\frac{\mathrm{d}x}{x^{4}+a^{4}}. $$ 

解 因  $ \int_{0}^{+\infty}\frac{\mathrm{d}x}{x^{4}+a^{4}}=\frac{1}{2}\int_{-\infty}^{+\infty}\frac{\mathrm{d}x}{x^{4}+a^{4}}, f(z)=\frac{1}{z^{4}+a^{4}} $

它一共有四个一阶极点

<!-- page: 258 -->

$$ a_{k}=a\mathrm{e}^{\frac{\pi+2k\pi}{4}\mathrm{i}}\quad(k=0,1,2,3), $$ 

且符合定理 6.7 的条件.而

 $$ \begin{aligned}\operatorname{Res}_{f(z)}&=\frac{1}{4z^{3}}\bigg|_{z=a_{k}}=\frac{1}{4a_{k}^{3}}=\frac{a_{k}}{4a_{k}^{4}}=-\frac{a_{k}}{4a^{4}}\\&(k=0,1,2,3)\end{aligned} $$ 

（这里用到了  $ a_{k}^{4} + a^{4} = 0 $）.  $ f(z) $ 在上半平面内只有两个极点  $ a_{0} $ 及  $ a_{1} $，于是

 $$ \begin{aligned}\int_{0}^{+\infty}\frac{\mathrm{d}x}{x^{4}+a^{4}}&=-\pi\mathrm{i}\frac{1}{4a^{4}}(a\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}+a\mathrm{e}^{\frac{3\pi}{4}\mathrm{i}})\\&=-\pi\mathrm{i}\frac{1}{4a^{3}}(\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}-\mathrm{e}^{-\frac{\pi}{4}})=\frac{\pi}{2a^{3}}\sin\frac{\pi}{4}\\&=\frac{\pi}{2\sqrt{2}a^{3}}.\end{aligned} $$ 

例 6.12 计算积分

 $$ \int_{-\infty}^{+\infty}\frac{x^{4}\mathrm{d}x}{(2+3x^{2})^{4}}. $$ 

解 函数  $ f(z)=\frac{z^{4}}{(2+3z^{2})^{4}} $ 在上半平面内只有  $ z=\sqrt{\frac{2}{3}}i $ 一个四阶极点，且符合定理 6.7 的条件.

记  $ \sqrt{\frac{2}{3}}i = a $，令  $ z - a = t $，即令 z = a + t，则

 $$ \begin{align*}f(z)&=\frac{z^4}{(2+3^2z^2)^4}=\frac{z^4}{3^4(z-a)^4(z+a)^4};\\&=\frac{(t+a)^4}{3^4t^4(t+2a)^4},\\&=\frac{1}{3^4t^4}\cdot\frac{a^4+4a^3t+6a^2t^2+4at^3+t^4}{16a^4+32a^3t+24a^2t^2+8at^3+t^4}\\&=\frac{1}{3^4t^4}\left(\frac{1}{16}+\frac{t}{8a}+\frac{t^2}{32a^2}-\frac{t^3}{32a^3}+\cdots\right).\end{align*} $$ 

故

<!-- page: 259 -->

$$ \mathrm{Res}_{z=a}f(z)=-\frac{1}{3^{4}\cdot32a^{3}}. $$ 

即

 $$ \begin{aligned}\operatorname{Res}_{z=\sqrt{\frac{2}{3}i}}f(z)&=-\frac{1}{3^4\cdot32\left(\sqrt{\frac{2}{3}i}\right)^3}\\&=\frac{-i}{32\sqrt{2^3\cdot3^5}}=\frac{-i}{576\sqrt{6}}.\end{aligned} $$ 

故  $ \int_{-\infty}^{+\infty}\frac{x^{4}}{(2+3x^{2})^{4}}\mathrm{d}x=2\pi\mathrm{i}\cdot\frac{-i}{576\sqrt{6}}=\frac{\pi}{288\sqrt{6}} $.

3. 计算  $ \int_{-\infty}^{+\infty}\frac{P(x)}{Q(x)}\mathrm{e}^{\mathrm{i}mx}\mathrm{d}x $ 型积分

引理 6.2(若尔当引理) 设函数  $ g(z) $ 沿半圆周  $ \Gamma_{R}: z = R e^{i\theta} $  $ (0 \leq \theta \leq \pi, R $ 充分大) 上连续，且

 $$ \lim_{R\to+\infty}g\left(z\right)=0 $$ 

在  $ \Gamma_{R} $ 上一致成立. 则

 $$ \lim_{R\to+\infty}\int_{\Gamma_{R}}g\left(z\right)\mathrm{e}^{\mathrm{i}m z}\mathrm{d}z=0\quad\left(m>0\right). $$ 

证 对于任给的  $ \varepsilon>0 $，存在  $ R_{0}(\varepsilon)>0 $，使当  $ R>R_{0} $ 时，有

 $$ |g(z)|<\varepsilon,z\in\Gamma_{R}. $$ 

于是，就有

$$  \begin{align*}\left|\int_{\Gamma_{R}}g(z)\mathrm{e}^{\mathrm{i}mz}\mathrm{d}z\right|&=\left|\int_{0}^{\pi}g(R\mathrm{e}^{\mathrm{i}\theta})\mathrm{e}^{\mathrm{i}mR\mathrm{e}^{\mathrm{i}\theta}}R\mathrm{e}^{\mathrm{i}\theta}\mathrm{id}\theta\right|\\&\leqslant R\varepsilon\int_{0}^{\pi}\mathrm{e}^{-mR\sin\theta}\mathrm{d}\theta,\end{align*}   \tag*{(6.13)}$$

这里利用了  $ \left|g(R\mathrm{e}^{\mathrm{i}\theta})\right|<\varepsilon,\left|R\mathrm{e}^{\mathrm{i}\theta}\mathrm{i}\right|=R $ 以及

 $$ \mid\mathrm{e}^{\mathrm{i}m R\mathrm{e}^{\mathrm{i}\theta}}\mid=\mid\mathrm{e}^{-m R\sin\theta+\mathrm{i}m R\cos\theta}\mid=\mathrm{e}^{-m R\sin\theta}. $$ 

于是，由（若尔当不等式）

 $$ \frac{2\theta}{\pi}\leqslant\sin\theta\leqslant\theta\quad\left(0\leqslant\theta\leqslant\frac{\pi}{2}\right), $$ 

将(6.13)化为

<!-- page: 260 -->

$$ \begin{align*}\left|\int\limits_{r_R} g(z)e^{\mathrm{im}z}\mathrm{d}z\right|&\leqslant2R\varepsilon\int_{0}^{\frac{\pi}{2}}e^{-mR\sin\theta}\mathrm{d}\theta\\&\leqslant2R\varepsilon\int_{0}^{\frac{\pi}{2}}e^{-\frac{2mR\theta}{\pi}}\mathrm{d}\theta=2\varepsilon R\left[-\frac{e^{-\frac{2mR}{\pi}\theta}}{2mR}\right]^{\theta=\frac{\pi}{2}}\\&=\frac{\pi\varepsilon}{m}(1-e^{-mR})<\frac{\pi\varepsilon}{m}.\end{align*} $$ 

应用引理 6.2, 完全和证明定理 6.7 一样可得

定理 6.8 设  $ g(z) = \frac{F(z)}{Q(z)} $，其中  $ P(z) $ 及  $ Q(z) $ 是互质多项式，且符合条件：

（1） $ Q(z) $的次数比 $ P(z) $的次数高，

(2) 在实轴上  $ Q(z) \neq 0 $,

(3) m > 0,

则有

$$  \int_{-\infty}^{+\infty}g(x)\mathrm{e}^{\mathrm{i}m x}\mathrm{d}x=2\pi\mathrm{i}\sum_{\mathrm{I m}a_{k}>0}\mathrm{R e s}\big[g(z)\mathrm{e}^{\mathrm{i}m z}\big].   \tag*{(6.14)}$$

特别说来，将(6.14)分开实虚部，就可以得到形如

 $$ \int_{-\infty}^{+\infty}\frac{P(x)}{Q(x)}\cos m x\mathrm{d}x 及 \int_{-\infty}^{+\infty}\frac{P(x)}{Q(x)}\sin m x\mathrm{d}x 的积分 . $$ 

由数学分析的结论,可知上面两个反常积分都存在,其值就等于其柯西主值.

例 6.13 计算积分  $ \int_{0}^{+\infty}\frac{\cos mx}{1+x^{2}}dx $ （ $ m>0 $）.

解 被积函数为偶函数，故

 $$ \int_{0}^{+\infty}\frac{\cos m x}{1+x^{2}}\mathrm{d}x=\frac{1}{2}\int_{-\infty}^{+\infty}\frac{\cos m x}{1+x^{2}}\mathrm{d}x. $$ 

根据定理 6.8 得

 $$ \int_{-\infty}^{+\infty}\frac{\mathrm{e}^{\mathrm{i}mx}}{1+x^{2}}\mathrm{d}x=2\pi\mathrm{i}\operatorname{Res}_{z=\mathrm{i}}\left[\frac{\mathrm{e}^{\mathrm{i}mz}}{1+z^{2}}\right] $$

<!-- page: 261 -->

$$ =2\pi\mathrm{i}\frac{\mathrm{e}^{-m}}{2\mathrm{i}}=\pi\mathrm{e}^{-m}. $$ 

于是有

 $$ \int_{-\infty}^{+\infty}\frac{\cos m x}{1+x^{2}}\mathrm{d}x=\pi\mathrm{e}^{-m}, $$ 

 $$ \int_{0}^{+\infty}\frac{\cos m x}{1+x^{2}}\mathrm{d}x=\frac{\pi}{2}\mathrm{e}^{-m}. $$ 

例 6.14 计算积分  $ \int_{-\infty}^{+\infty}\frac{x\cos x}{x^{2}-2x+10} $.

解 不难验证,函数

 $$ f(z)=\frac{z\mathrm{e}^{\mathrm{i}z}}{z^{2}-2z+10} $$ 

满足若尔当引理的条件,这里 m=1,  $ g(z)=\frac{z}{z^{2}-2z+10} $.

函数  $ f(z) $ 有两个一阶极点  $ z=1+3i $ 及 z=1-3i.

 $$ \begin{aligned}\operatorname{Res}_{z=1+3\mathrm{i}}f(z)&=\frac{z\mathrm{e}^{\mathrm{i}z}}{(z^{2}-2z+10)^{\prime}}\Bigg|_{z=1+3\mathrm{i}}\\&=\frac{(1+3\mathrm{i})\mathrm{e}^{-3+\mathrm{i}}}{6\mathrm{i}}.\end{aligned} $$ 

于是

 $$ \begin{align*}\int_{-\infty}^{+\infty}\frac{x\mathrm{e}^{\mathrm{i}x}\mathrm{d}x}{x^{2}-2x+10}&=2\pi\mathrm{i}\frac{(1+3\mathrm{i})\mathrm{e}^{-3+\mathrm{i}}}{6\mathrm{i}}\\&=\frac{\pi}{3}\mathrm{e}^{-3}(1+3\mathrm{i})(\cos1+\mathrm{i}\sin1)\\&=\frac{\pi}{3}\mathrm{e}^{-3}(\cos1-3\sin1)+\mathrm{i}\frac{\pi}{3}\mathrm{e}^{-3}(3\cos1+\sin1).\end{align*} $$ 

比较等式两端的实部与虚部，就得

 $$ \begin{aligned}\int_{-\infty}^{+\infty}\frac{x\cos x d x}{x^{2}-2x+10}&=\frac{\pi}{3}\mathrm{e}^{-3}\left(\cos1-3\sin1\right),\\\int_{-\infty}^{+\infty}\frac{x\sin x d x}{x^{2}-2x+10}&=\frac{\pi}{3}\mathrm{e}^{-3}\left(3\cos1+\sin1\right).\end{aligned} $$ 

4. 计算积分路径上有奇点的积分 在数学分析中,对于瑕积

<!-- page: 262 -->

分,也可以类似地定义它的柯西主值.又在定理6.8中假定Q(z)无实零点,现在我们可以把条件放宽一点,容许Q(z)有有限多个一阶零点,即允许函数 $ f(z)=\frac{P(z)}{Q(z)}\mathrm{e}^{\mathrm{i}mz} $在实轴上有有限个一阶极点.为了估计挖去这种极点后沿辅助路径的积分,除了上面两个引理外,再引进一个与引理6.1相似的引理.

引理 6.3 设  $ f(z) $ 沿圆弧  $ S_{r}: z - a = r e^{i\theta} (\theta_{1} \leqslant \theta \leqslant \theta_{2}, r $ 充分小) 上连续，且

 $$ \lim_{r\to0}(z-a)f(z)=\lambda $$ 

于  $ S_{r} $ 上一致成立，则有

 $$ \lim_{r\to0}\int_{S_{r}}f(z)\mathrm{d}z=\mathrm{i}(\theta_{2}-\theta_{1})\lambda. $$ 

证 因为  $ i(\theta_{2}-\theta_{1})\lambda=\lambda\int_{s_{r}}\frac{\mathrm{d}z}{z-a} $，于是有

 $ \left|\int_{s_{r}}f(z)\mathrm{d}z-i(\theta_{2}-\theta_{1})\lambda\right|=\left|\int_{s_{r}}\frac{(z-a)f(z)-\lambda}{z-a}\mathrm{d}z\right| $.

与引理6.1的证明相仿,得知上式在r充分小时,其值不超过任意给定的正数 $ \varepsilon $.

例 6.15 计算积分  $ \int_{0}^{+\infty}\frac{\sin x}{x}dx $.

解  $ \int_{0}^{+\infty}\frac{\sin x}{x}\mathrm{d}x $ 存在，且

 $$ \int_{0}^{+\infty}\frac{\sin x}{x}\mathrm{d}x=\frac{1}{2}\mathrm{P.V.}\int_{-\infty}^{+\infty}\frac{\sin x}{x}\mathrm{d}x. $$ 

考虑函数  $ f(z)=\frac{e^{iz}}{z} $ 沿图 6.5 所示之闭曲线路径 C 的积分.

根据柯西积分定理得

 $$ \int_{c}f(z)\mathrm{d}z=0. $$ 

或写成

<!-- page: 263 -->

<div style="text-align: center;"><img src="images/p0263_img_in_image_box_1358_632_3052_1449.jpg" alt="图 6.5" width="38%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.5</div> </div>


$$  \int_{r}^{R}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x+\int_{C_{R}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z+\int_{-R}^{-r}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x-\int_{C_{r}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z=0.   \tag*{(6.15)}$$

这里  $ C_{R} $ 及  $ C_{r} $ 分别表示半圆周  $ z = Re^{\mathrm{i}\theta} $ 及  $ z = r\mathrm{e}^{\mathrm{i}\theta} $ ( $ 0 \leqslant \theta \leqslant \pi $,  $ r < R $).

由引理 6.2 知

 $$ \lim_{R\to+\infty}\int_{C_{R}}\frac{\mathrm{e}^{\mathrm{i}z}}{\dot{z}}\mathrm{d}z=0. $$ 

由引理 6.3 知

 $$ \lim_{r\to0}\int_{C_{r}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z=\mathrm{i}\pi. $$ 

在(6.15)中，令  $ r \to 0, R \to +\infty $ 取极限即得  $ \int_{-\infty}^{+\infty} \frac{e^{ix}}{x} dx $ 的主值

 $$ \mathrm{P.V.}\int_{-\infty}^{+\infty}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x=\mathrm{i}\pi. $$ 

所以

 $$ \int_{0}^{+\infty}\frac{\sin x}{x}\mathrm{d}x=\frac{1}{2}\mathbf{P}\cdot\mathbf{V}\cdot\int_{-\infty}^{+\infty}\frac{\sin x}{x}\mathrm{d}x=\frac{\pi}{2}. $$ 

5. 杂例 下面我们举出两个例子来说明，计算反常积分有时要用种种不同的方式来选择积分路径.

例 6.16 假定已知泊松(Poisson)积分

$$  \int_{0}^{+\infty}\mathrm{e}^{-t^{2}}\mathrm{d}t=\frac{\sqrt{\pi}}{2},   \tag*{(6.16)}$$

<!-- page: 264 -->

试计算弗莱聂尔(Frensnel)积分 $ ^{①} $

 $$ \int_{0}^{+\infty}\cos x^{2}\mathrm{d}x\text{ 及 }\int_{0}^{+\infty}\sin x^{2}\mathrm{d}x. $$ 

解 考察辅助函数

 $$ f(z)=\mathrm{e}^{-z^{2}}, $$ 

它是一个整函数. 并取如图 6.6 的辅助积分路径  $ C_{R} $. 则

<div style="text-align: center;"><img src="images/p0264_img_in_image_box_1450_1773_2977_2681.jpg" alt="图6.6" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.6</div> </div>


$$  \begin{aligned}0&=\int_{C_{R}}\mathrm{e}^{-z^{2}}\mathrm{d}z\\&=\int_{0}^{R}\mathrm{e}^{-x^{2}}\mathrm{d}x+\int_{r_{R}}\mathrm{e}^{-z^{2}}\mathrm{d}z+\int_{R}^{0}\mathrm{e}^{-x^{2}\mathrm{e}^{\frac{\pi}{2}\mathrm{i}}}\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}\mathrm{d}x.\end{aligned}   \tag*{(6.17)}$$

而

 $$ \begin{align*}\left|\int\limits_{R_{R}}\mathrm{e}^{-z^{2}}\mathrm{d}z\right|&=\left|\int_{0}^{\frac{\pi}{4}}\mathrm{e}^{-R^{2}(\cos2\varphi+\sin2\varphi)}\mathrm{i}R\mathrm{e}^{\mathrm{i}\varphi}\mathrm{d}\varphi\right|\\&\leqslant\int_{0}^{\frac{\pi}{4}}\mathrm{e}^{-R^{2}\cos2\varphi}R\mathrm{d}\varphi\\&\xlongequal{(令2\varphi=\frac{\pi}{2}-\theta)}\frac{R}{2}\int_{0}^{\frac{\pi}{2}}\mathrm{e}^{-R^{2}\sin\theta}\mathrm{d}\theta\\&\leqslant\frac{(若尔当不等式)\frac{R}{2}\int_{0}^{\frac{\pi}{2}}\mathrm{e}^{-R^{2}\cdot\frac{2\theta}{\pi}}\mathrm{d}\theta}{}\end{align*} $$

<!-- page: 265 -->

$$ \begin{aligned}&=-\frac{R}{2}\bullet\frac{\pi}{2R^{2}}\mathrm{e}^{-\frac{2R^{2}}{\pi}\theta}\bigg|_{\theta=0}^{\theta=\frac{\pi}{2}}\\&=\frac{\pi}{4R}[1-\mathrm{e}^{-R^{2}}].\end{aligned} $$ 

故当  $ R \to +\infty $ 时，

 $$ \left|\int_{\Gamma_{R}}\mathrm{e}^{-z^{2}}\mathrm{d}z\right|\to0. $$ 

于是当  $ R \rightarrow +\infty $ 时，(6.17)变成

 $$ \begin{array}{l}\frac{1+\mathrm{i}}{\sqrt{2}}\int_{0}^{+\infty}\left(\cos x^{2}-\mathrm{i}\sin x^{2}\right)\mathrm{d}x\\=\int_{0}^{+\infty}\mathrm{e}^{-x^{2}}\mathrm{d}x\xlongequal{(6.16)\rightarrow\sqrt{\pi}}\frac{2}{2}.\end{array} $$ 

即

 $$ \int_{0}^{+\infty}\left(\cos x^{2}-\mathrm{i}\sin x^{2}\right)\mathrm{d}x=\frac{1}{2}\sqrt{\frac{\pi}{2}}(1-\mathrm{i}). $$ 

比较两端实部与虚部，即得

 $$ \int_{0}^{+\infty}\cos x^{2}dx=\int_{\theta_{t}}^{+\infty}\sin x^{2}dx=\frac{1}{2}\sqrt{\frac{\pi}{2}}. $$ 

 $ ^{*} $例 6.17 计算积分

 $$ I=\int_{0}^{+\infty}\mathrm{e}^{-a x^{2}}\cos b x\mathrm{d}x,a>0. $$ 

解 若 b=0 , 则

$$  \begin{aligned}I=&\int_{0}^{+\infty}\mathrm{e}^{-ax^{2}}\mathrm{d}x\xlongequal{t=\sqrt{ax}}\frac{1.}{\sqrt{a}}\int_{0}^{+\infty}\mathrm{e}^{-t^{2}}\mathrm{d}t\\&\xlongequal{(6.16)}\frac{1}{\sqrt{a}}\cdot\frac{\sqrt{\pi}}{2}=\frac{1}{2}\sqrt{\frac{\pi}{a}}.\end{aligned}   \tag*{(6.18)}$$

若  $ b \neq 0 $，因为  $ \cos bx $ 是偶函数，所以只需考虑 b > 0 的情况.

根据前面的经验,似乎应该取辅助函数  $ f(z) = \mathrm{e}^{-az^2} \mathrm{e}^{ibz} $. 下面分析应该取什么样的辅助路径及辅助函数才合适:

<!-- page: 266 -->

因为

$$  \begin{align*}I&=\frac{1}{2}\mathrm{Re}\int_{-\infty}^{+\infty}\mathrm{e}^{-\left(ax^{2}+\mathrm{i}bx\right)}\mathrm{d}x=\frac{1}{2}\mathrm{\dot{R}e}\mathrm{e}^{-\frac{b^{2}}{4a}\int_{-\infty}^{+\infty}}\mathrm{e}^{-a\left(x+\frac{b}{2a}\mathrm{i}\right)^{2}}\mathrm{d}x\\&=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\mathrm{Re}\int_{-\infty+\frac{b}{2a}\mathrm{i}}^{+\infty+\frac{b}{2a}\mathrm{i}}\mathrm{e}^{-az^{2}}\mathrm{d}z,\tag{6}\end{align*}   \tag*{(6.19)}$$

而由(6.18)知道

$$  \int_{-\infty}^{+\infty}e^{-ax^{2}}dx=\sqrt{\frac{\pi}{a}}.   \tag*{(6.20)}$$

<div style="text-align: center;"><img src="images/p0266_img_in_image_box_1433_2145_3018_3100.jpg" alt="图 6.7" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.7</div> </div>


由此可见，应该取辅助函数  $ f(z) = \mathrm{e}^{-az^{2}} $，并可取如图 6.7 的辅助路径  $ C_{R} $。由柯西积分定理得到

$$  \begin{aligned}0=\int_{C_{R}}\mathrm{e}^{-az^{2}}\mathrm{d}z&=\int_{AB}\mathrm{e}^{-az^{2}}\mathrm{d}z+\int_{BC}\mathrm{e}^{-az^{2}}\mathrm{d}z+\int_{CD}\mathrm{e}^{-az^{2}}\mathrm{d}z\\&\quad+\int_{DA}\mathrm{e}^{-az^{2}}\mathrm{d}z.\end{aligned}\tag{6.2}   \tag*{(6.21)}$$

比较(6.19)与(6.21)，就得到

 $$ \begin{align*}I&\xlongequal{^{\prime}(6.19)}\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\mathrm{Re}\left[\lim_{R\to+\infty}\left(\int_{DC}\mathrm{e}^{-az^{2}}\mathrm{d}z\right)\right]\\&\xlongequal{(6.21)}\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\mathrm{Re}\left[\lim_{R\to+\infty}\left(\int_{AB}\mathrm{e}^{-az^{2}}\mathrm{d}z+\int_{BC}\mathrm{e}^{-az^{2}}\mathrm{d}z\right.\right.\\&\left.\left.+\int_{DA}\mathrm{e}^{-az^{2}}\mathrm{d}z\right)\right].\end{align*} $$ 

另外，在线段 BC 及 DA 上，

<!-- page: 267 -->

$$ z=\pm R+\mathrm{i}y\left(0\leqslant y\leqslant\frac{b}{2a}\right), $$ 

 $$ \mid\mathrm{e}^{-a z^{2}}\mid=\mathrm{e}^{-a\cdot(R^{2}-y^{2})}\leqslant\mathrm{e}^{\frac{b^{2}}{4a}}\mathrm{e}^{-a R^{2}}. $$ 

故

 $$ \operatorname*{l i m}_{R\to+\infty}\int_{B C}\mathrm{e}^{-a z^{2}}\mathrm{d}z=0,\operatorname*{l i m}_{R\to+\infty}\int_{D A}\mathrm{e}^{-a z^{2}}\mathrm{d}z=0. $$ 

最后得到

 $$ \begin{aligned}I=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\mathrm{Re}\left[\lim_{R\rightarrow+\infty}\int_{AB}\mathrm{e}^{-az^{2}}\mathrm{d}z\right]\\\underline{\underline{(6.20)}}\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\sqrt{\frac{\pi}{a}}.\end{aligned} $$ 

从前面几个模式可见，利用留数计算定积分，关键在于选择一个合适的辅助函数及一条相应的辅助闭路（周线），从而把定积分的计算化成沿闭路的复积分的计算，除了一些标准模式外，辅助函数尤其是辅助闭路的选择很不规则。一般说来，辅助函数  $ F(z) $ 总要选得使当 z=x 时： $ F(x)=f(x)(f(x) $ 是原定积分中的被积函数)或  $ \mathrm{Re}(F(z))=f(x) $ 或  $ \mathrm{Im}(F(z))=f(x) $。辅助闭路的选择原则是：使添加的路线上的积分能够通过一定的办法（包括用我们给出的几个引理）估计出来；或者是能够转化为原来的定积分。但具体选取时，形状则是多种多样，有半圆周周线、长方形周线、扇形周线、三角形周线等等；此外，周线上有奇点还要绕开过去。

6. 应用多值函数的积分 被积函数或辅助函数是多值解析函数的情形，一定要适当割开平面，使其能分出单值解析分支，才能应用柯西积分定理或柯西留数定理来求出给定的积分的值.

 $ ^{*} $例 6.18 试计算积分

 $$ \int_{0}^{+\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x. $$ 

解 以原点 O 为中心，r 及 R 为半径，在 Ox 轴上方画两个半圆周，r 可充分小，R 可充分大。此两个半圆周与 Ox 轴上的 AB 及  $ B^{\prime}A^{\prime} $ 二线段构成一周线 C（如图 6.8）。

<!-- page: 268 -->

<div style="text-align: center;"><img src="images/p0268_img_in_image_box_1375_582_3054_1753.jpg" alt="图6.8" width="37%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.8</div> </div>


辅助函数

 $$ f(z)=\frac{\ln z}{(1+z^{2})^{2}} $$ 

在 C 内部仅有一个二阶极点 z = i，而其支点 z = 0 及 z =  $ \infty $ 已不属于 C 的内部。故  $ f(z) $ 在 C 所界的有界闭域上，除 z = i 外，是单值解析的。令

 $$ \varphi\left(z\right)=\left(z-\mathrm{i}\right)^{2}\frac{\ln z}{\left(z+\mathrm{i}\right)^{2}\left(z-\mathrm{i}\right)^{2}}=\frac{\ln z}{\left(z+\mathrm{i}\right)^{2}}, $$ 

则

 $$ \varphi^{\prime}(z)=\frac{1}{z}\cdot\frac{1}{(z+\mathrm{i})^{2}}-\frac{2}{(z+\mathrm{i})^{3}}\ln z, $$ 

 $$ \mathrm{Res}_{z=\mathrm{i}}f(z)\xlongequal{(6.5)}\varphi^{\prime}(\mathrm{i})=-\frac{1}{4\mathrm{i}}-\frac{2}{-8\mathrm{i}}\cdot\frac{\pi\mathrm{i}}{2}=\frac{\pi+2\mathrm{i}}{8}. $$ 

由留数定理，

$$  \begin{aligned}\int_{\widehat{B M B^{\prime}}}&+\int_{B^{\prime}A^{\prime}}+\int_{\widehat{A^{\prime}N A}}+\int_{A B}\!=\int_{C}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z\\ &=2\pi\mathrm{i}\cdot\frac{\pi+2\mathrm{i}}{8}=-\frac{\pi}{2}+\frac{\pi^{2}}{4}\mathrm{i}.\end{aligned}   \tag*{(6.22)}$$

今分别计算(6.22)左边各个积分：

（1）因  $ \lim_{|z|\to+\infty}z\frac{\ln z}{(1+z^{2})^{2}}=0 $，由引理6.1即知

 $$ \int_{\widehat{B M B^{\prime}}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=0. $$

<!-- page: 269 -->

(2) 因  $ \lim_{|z|\to0} z \frac{\ln z}{(1 + z^2)^2} = 0 $，故由引理 6.3 即知

 $$ \int_{\widehat{A^{\prime}NA}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=0. $$ 

（3）命 AB 上的  $ z = x \cdot e^{i \cdot 0} (x > 0) $，则

 $$ \lim_{r\to0\atop r\to+\infty}\int_{AB}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=\int_{0}^{+\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x. $$ 

（4） $ A^{\prime}B^{\prime} $ 上的  $ z = xe^{\mathrm{i}\pi}(x > 0) $，于是

 $$ \ln z=\ln x+\mathrm{i}\pi,\mathrm{d}z=\mathrm{e}^{\mathrm{i}\pi}\mathrm{d}x=-\mathrm{d}x. $$ 

故

 $$ \begin{aligned}\lim_{r\to0\atop R\to+\infty}\int_{B^{\prime}A^{\prime}}&\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=\int_{+\infty}^{0}\frac{\ln x+\mathrm{i}\pi}{(1+x^{2})^{2}}(-\mathrm{d}x)\\&=\int_{0}^{+\infty}\frac{\ln x+\mathrm{i}\pi}{(1+x^{2})^{2}}\mathrm{d}x.\end{aligned} $$ 

于是，当  $ R \rightarrow +\infty, r \rightarrow 0 $ 时，(6.22)变成

 $$ \int_{0}^{+\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x+\int_{0}^{+\infty}\frac{\ln x+\mathrm{i}\pi}{(1+x^{2})^{2}}\mathrm{d}x=-\frac{\pi}{2}+\frac{\pi^{2}}{4}\mathrm{i}. $$ 

比较两端的实部，得

 $$ 2\int_{0}^{+\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x=-\frac{\pi}{2}, $$ 

故

 $$ \int_{0}^{+\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x=-\frac{\pi}{4}. $$ 

例 6.19 计算积分

 $$ I=\int_{-1}^{1}\frac{\mathrm{d}x}{\sqrt[3]{(1-x)(1+x)^{2}}}, $$ 

解 考虑辅助函数

 $$ f(z)=\sqrt[3]{(1-z)(1+z)^{2}}, $$ 

它在 z 平面上是(2.24)型的多值函数，+1 及 -1 显然是它的支点.

当 z 沿图 6.9 中点线所表示的闭曲线  $ (-1 $ 及  $ +1 $ 于其内部）按反时针方向绕行一周， $ \varphi_{1}=\arg(1+z) $ 和  $ \varphi_{2}=\arg(1-z) $ 同时增

<!-- page: 270 -->

加  $ 2\pi $，而

 $$ \arg f(z)=\frac{2\varphi_{1}+\varphi_{2}}{3} $$ 

也增加  $ 2\pi $. 这表示  $ f(z) $ 回到原来的数值, 因而  $ \infty $ 不是  $ f(z) $ 的支点.

作支割线 $ [-1,1] $， $ f(z) $在其外部可以分出三个单值解析分支.

<div style="text-align: center;"><img src="images/p0270_img_in_image_box_1386_1910_3039_3399.jpg" alt="图6.9" width="37%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.9</div> </div>


我们选定在[-1,1]上岸 AB 上取正值的那个分支，并取在图6.9中所表示的那条复周线  $ \Gamma = C_{R} + C'_{r}^{-} + AB + C'_{r}^{-} + B'A' $，当z 在[-1,1]上岸 AB 上， $ \arg f(z) = 0 $，即

 $$ f(z)=\sqrt[3]{(1-x)(1+x)^{2}}>0. $$ 

当 z 从 B 沿  $ C_{r}^{\prime\prime} $ 转到  $ B^{\prime}, f(z) $ 的辐角增加  $ -\frac{2}{3}\pi $，于是在  $ [-1,1] $ 下岸  $ B^{\prime}A^{\prime} $ 上， $ \arg f(z) = -\frac{2}{3}\pi $，即

 $$ f(z)=\mathrm{e}^{-\frac{2\pi}{3}\mathrm{i}}\sqrt[3]{(1-x)(1+x)^{2}}. $$ 

这样我们有

 $$ \left|\int\limits_{C_{r}^{\prime}}\frac{1}{f(z)}d z\right|\leqslant\int\limits_{|1-z|=r}\frac{\left|d z\right|}{\left(\left|1+z\right|^{2}\left|1-z\right|\right)^{\frac{1}{3}}} $$

<!-- page: 271 -->

$$ \begin{aligned}&\leqslant\int_{|1-z|=r}\frac{1}{r^{\frac{1}{3}}}|\mathrm{d}z|\\&=2\pi r\cdot\frac{1}{r^{\frac{1}{3}}}=2\pi r^{\frac{2}{3}}.\end{aligned} $$ 

 $$ \left|\int\limits_{C_{r}^{\prime}}\frac{1}{f(z)}\mathrm{d}z\right|\leqslant\int\limits_{|1+z|=r}\frac{\left|\mathrm{d}z\right|}{\left(|1+z|^{2}|1-z|\right)^{\frac{1}{3}}}\leqslant2\pi r^{\frac{1}{3}}. $$ 

所以当  $ r \rightarrow 0 $ 时，上述两个积分趋于零。

因为，按复周线的柯西积分定理，

 $$ \int_{\Gamma}\frac{1}{f(z)}\mathrm{d}z=0, $$ 

所以当  $ r \to 0 $ 时，有

$$  \begin{align*}(1-\mathrm{e}^{\frac{2\pi\mathrm{i}}{3}})\int_{-1}^{1}\frac{\mathrm{d}x}{\sqrt[3]{(1-x)(1+x)^{2}}}=\int_{c_{R}^{-}}\frac{\mathrm{d}z}{f(z)}\\=2\pi\mathrm{i}\operatorname{Res}\limits_{z=\infty}\frac{1}{f(z)}.\end{align*}   \tag*{(6.23)}$$

我们来观察  $ f(z) $ 已选取的分支. 当 z 从上岸 AB 变化到  $ (1, +\infty) $ 上时; 即 z 从上岸的点 B 沿  $ C_{r}^{\prime\prime} $ (如图 6.9) 绕 1 转到  $ (1, +\infty) $ 上的点 e 时,  $ 1 + z $ 的辐角最终无改变, 只有 1-z 的辐角减少了  $ \pi $, 从而  $ f(z) $ 的辐角就减少  $ \frac{\pi}{3} $.

故在线段 $ (1, +\infty) $上

 $$ \begin{array}{l}f(z)=\sqrt[3]{|1-z||1+z|^{2}}\mathrm{e}^{-\frac{\pi}{3}\mathrm{i}},\\ f(z)=\sqrt[3]{(z-1)(1+z)^{2}}\mathrm{e}^{-\frac{\pi}{3}\mathrm{i}}.\end{array} $$ 

即

由公式(6.7)，

 $$ \begin{aligned}\operatorname{Res}\frac{1}{z=\infty f(z)}&=\operatorname{Res}\left[\frac{1}{\sqrt[3]{(1-z)(1+z)^{2}}}\right]\\&=-\operatorname{Res}\left[\begin{array}{c}1\\ \frac{1}{\sqrt[3]{(1-\frac{1}{t})(\sqrt{1+\frac{1}{t}})^{2}}}}\end{array}\right]\end{aligned} $$

<!-- page: 272 -->

$$ \begin{aligned}&=-Re\sum_{t=0}^{}\left[\frac{1}{t\cdot\sqrt[3]{(t-1)(t+1)^{2}}}\right]\\&=-\frac{1}{\sqrt[3]{(t-1)(t+1)^{2}}}\left|\begin{array}{l}1\\t=0\end{array}\right.\\&\frac{(6.24)}{}-\frac{1}{e^{-\frac{\pi}{3}i}}=-e^{\frac{\pi}{3}i}.\end{aligned}(t=0 为一阶极点 ) $$ 

因此，

 $$ \left(1-\mathrm{e}^{\frac{2\pi}{3}\mathrm{i}}\right)I\xlongequal{\left(6.23\right)}-\mathrm{e}^{\frac{\pi}{3}\mathrm{i}}\cdot2\pi\mathrm{i}. $$ 

由此，最后得到

 $$ I=\int_{-1}^{1}\frac{\mathrm{d}x}{\sqrt[3]{(1-x)(1+x)^{2}}}=\frac{\pi}{\sin\frac{\pi}{3}}=\frac{2\pi}{\sqrt{3}}. $$ 

 $ ^{*} $例 6.20 计算积分

 $$ \int_{0}^{1}\frac{\mathrm{d}x}{\left(x-2\right)\sqrt[5]{x^{2}\left(1-x\right)^{3}}}. $$ 

解 考虑辅助函数

 $$ f(z)=\frac{1}{(z-2)\sqrt[5]{z^{2}(1-z)^{3}}}, $$ 

其中  $ \sqrt[5]{z^{2}(1-z)^{3}}=F(z) $ 是 (2.24) 型的多值函数，它只以 z=0 及 z=1 为支点，z= $ \infty $ 不是支点。作支割线 [0,1]，F[z] 在其外部能分出五个单值解析分支，选取在  $ z=2(>1) $ 取负值的那一支，从而对应的单值解析函数  $ f(z) $ 在 [0,1] 外部只以 z=2 为一阶极点，z= $ \infty $ 为可去奇点。

以原点 O 为圆心画两个圆周，大圆周  $ C_{1} $ 的半径大于 2，小圆周  $ C_{2} $ 的半径在 1 与 2 之间（如图 6.10）；再各以 0 及 1 为圆心画两个小圆周  $ \gamma_{0} $ 及  $ \gamma_{1} $，半径 r 均可无限小.

(1) 因  $ \int_{C_{1}} f(z) \, \mathrm{d}z = -2\pi i \mathop{\mathrm{Res}}\limits_{z = \infty} f(z) $,

<!-- page: 273 -->

<div style="text-align: center;"><img src="images/p0273_img_in_image_box_981_550_3417_2641.jpg" alt="图6.10" width="54%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.10</div> </div>


又因  $ f(z) $ 在点  $ \infty $ 的去心邻域内的洛朗展式从  $ \frac{1}{z^{2}} $ 项开始，无  $ \frac{1}{z} $ 项，故

 $$ \mathop{\mathrm{R e s}}_{z=\infty}f(z)=0. $$ 

所以

 $$ \int_{c_{1}}f(z)\mathrm{d}z=0. $$ 

(2) 含点 $ \infty $的区域的留数定理(列入本章习题(二)5).

设 D 是扩充 z 平面上含点  $ \infty $ 的区域，其边界 C 是由有限条互不包含且互不相交的周线  $ C_{1}, C_{2}, \cdots, C_{m} $ 组成；又设函数  $ f(z) $ 在 D 内除去有限个孤立奇点  $ z_{1}, z_{2}, \cdots, z_{n} $ 及  $ \infty $ 外解析，且连续到边界 C，则

 $$ \int_{C^{-}}f(z)\mathrm{d}z=2\pi\mathrm{i}\left[\sum_{k=1}^{n}\operatorname{R e s}_{z=z_{k}}f(z)+\operatorname{R e s}_{z=\infty}f(z)\right]. $$ 

由此定理，我们得到

<!-- page: 274 -->

$$ \begin{aligned}\int_{C_{2}^{-}}f(z)\mathrm{d}z&=2\pi\mathrm{i}\left[\underset{z=2}{\operatorname{Res}}f(z)+\underset{z=\infty}{\operatorname{Res}}f(z)\right]\\&=2\pi\mathrm{i}\operatorname{Res}_{z=2}f(z).\end{aligned} $$ 

但

 $$ \mathrm{Res}_{z=2}f(z)=\frac{1}{\sqrt[5]{-4}}\frac{ 按选的分支 }{}\frac{1}{-\sqrt[5]{4}}=-\frac{\sqrt[5]{8}}{2}, $$ 

故

 $$ \int_{C_{2}}f(z)\mathrm{d}z=-2\pi\mathrm{i}\left(-\frac{\sqrt[5]{8}}{2}\right)=\sqrt[5]{8}\pi\mathrm{i}. $$ 

（3）应用复周线的柯西积分定理

 $$ \operatorname*{l i m}_{r\to0}\left(\int_{C_{2}}f(z)\mathrm{d}z+\int_{A B}f(z)\mathrm{d}z+\int_{B^{\prime}A^{\prime}}f(z)\mathrm{d}z\right)=0, $$ 

因由引理 6.3,  $ f(z) $ 沿两个小圆周的积分均为零.

于是我们有

$$  \begin{aligned}\lim_{r\to0}\left(\int_{AB}f(z)\mathrm{d}z+\int_{B^{\prime}A^{\prime}}f(z)\mathrm{d}z\right)&=-\int_{C_{2}}f(z)\mathrm{d}z\\&=-\sqrt[5]{8}\pi\mathrm{i}.\end{aligned}   \tag*{(6.25)}$$

(4) 考察  $ \sqrt[3]{z^{2}(1-z)^{3}} $ 的辐角的连续改变量. 已知所选分支在小圆周  $ \gamma_{1} $ 上起点  $ x (>1) $ 的函数值为  $ \sqrt[5]{x^{2}(x-1)^{3}} e^{i\pi} $，从而沿反时针方向转回上岸的点  $ x (0 < x < 1) $ 的值为

 $$ \sqrt[5]{x^{2}(1-x)^{3}}\mathrm{e}^{\mathrm{i}\left(\pi+\frac{3\pi}{5}\right)} $$ 

(因这时 z 的辐角改变量为零, 只有 1-z 的辐角改变量为  $ \pi $); 沿顺时针方向转至下岸的点 x (0 < x < 1) 的值为

 $$ \sqrt[5]{x^{2}(1-x)^{3}}\mathrm{e}^{\mathrm{i}\left(\pi-\frac{3\pi}{5}\right)} $$ 

(因这时只有 1-z 的辐角改变量为  $ -\pi $).

当两个小圆周的半径  $ r \to 0 $ 时（图 6.11），我们有

 $$ -\sqrt[5]{8}\pi\mathrm{i}\xlongequal{(6.25)}\int_{0}^{1}\frac{\mathrm{d}x}{\left(x-2\right)\sqrt[5]{x^{2}\left(1-x\right)^{3}}\mathrm{e}^{\mathrm{i}\left(\pi+\frac{3\pi}{5}\right)}}. $$

<!-- page: 275 -->

$$ \begin{align*}&+\int_{1}^{0}\frac{\mathrm{d}x}{(x-2)\sqrt[5]{x^{2}(1-x)^{3}}\mathrm{e}^{\mathrm{i}\left(\pi-\frac{3\pi}{5}\right)}}\\&=\int_{0}^{1}\frac{\mathrm{e}^{-\frac{8\pi.}{5}\mathrm{i}}-\mathrm{e}^{-\frac{2\pi.}{5}\mathrm{i}}}{(x-2)\sqrt[5]{x^{2}(1-x)^{3}}}\mathrm{d}x\\&=\int_{0}^{1}\frac{\mathrm{e}^{\frac{2\pi.}{5}\mathrm{i}}-\mathrm{e}^{-\frac{2\pi.}{5}\mathrm{i}}}{(x-2)\sqrt[5]{x^{2}(1-x)^{3}}}\mathrm{d}x\,.\end{align*} $$ 

<div style="text-align: center;"><img src="images/p0275_img_in_image_box_1477_1831_2954_2321.jpg" alt="图6.11" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.11</div> </div>


最后得到

 $$ \begin{aligned}\int_{0}^{1}\frac{\mathrm{d}x}{(x-2)\sqrt[5]{x^{2}(1-x)^{3}}}&=\frac{-\sqrt[5]{8}\pi\mathrm{i}}{\mathrm{e}^{\frac{2\pi}{5}\mathrm{i}}-\mathrm{e}^{-\frac{2\pi}{5}\mathrm{i}}}\\&=\frac{-\sqrt[5]{8}\pi}{2\sin\frac{2\pi}{5}}.\end{aligned} $$ 

#### §3. 辐角原理及其应用

1. 对数留数 留数理论的重要应用之一是计算积分

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f^{\prime}(z)}{f(z)}\mathrm{d}z, $$ 

它称为  $ f(z) $ 的对数留数（这个名称来源于  $ \frac{f'(z)}{f(z)} = \frac{\mathrm{d}}{\mathrm{d}z} [\ln f(z)] $，由它推出的辐角原理提供了计算解析函数零点个数的一个有效方法. 特别是，可以借此研究在一个指定区域内多项式零点的个数问题.

显然，函数  $ f(z) $ 的零点和奇点都可能是  $ \frac{f'(z)}{f(z)} $ 的奇点.

<!-- page: 276 -->

引理 6.4 （1）设 a 为  $ f(z) $ 的 n 阶零点，则 a 必为函数  $ \frac{f'(z)}{f(z)} $ 的一阶极点，并且

 $$ \mathrm{Res}_{z=a}\left[\frac{f^{\prime}(z)}{f(z)}\right]=n; $$ 

(2) 设 b 为  $ f(z) $ 的 m 阶极点，则 b 必为函数  $ \frac{f'(z)}{f(z)} $ 的一阶极点，并且

 $$ \mathrm{Res}_{z=b}\left[\frac{f^{\prime}(z)}{f(z.)}\right]=-m. $$ 

证 （1）如 a 为  $ f(z) $ 的 n 阶零点，则在点 a 的邻域内有

 $$ f(z)=(z-a)^{n}g(z), $$ 

其中  $ g(z) $ 在点 a 的邻域内解析，且  $ g(a) \neq 0 $。于是

 $$ \begin{align*}f^{\prime}\left(z\right)&=n\left(z-a\right)^{n-1}g\left(z\right)+\left(z-a\right)^{n}g^{\prime}\left(z\right),\\\frac{f^{\prime}\left(z\right)}{f\left(z\right)}&=\frac{n}{z-a}+\frac{g^{\prime}\left(z\right)}{g\left(z\right)}.\end{align*} $$ 

由于 $ \frac{g'(z)}{g(z)} $在点a的邻域内解析，故a必为 $ \frac{f'(z)}{f(z)} $的一阶极点，且

 $$ \mathrm{Res}_{z=a}\left[\frac{f^{\prime}(z)}{f(z)}\right]=n. $$ 

(2) 如 b 为  $ f(z) $ 的 m 阶极点, 则在点 b 的去心邻域内有

 $$ f(z)=\frac{h(z)}{(z-b)^{m}}, $$ 

其中  $ h(z) $ 在点 b 的邻域内解析，且  $ h(b) \neq 0 $。由此易得

 $$ \frac{f^{\prime}(z)}{f(z)}=\frac{-m}{z-b}+\frac{h^{\prime}(z)}{h(z)}, $$ 

而 $ \frac{h'(z)}{h(z)} $在点b的邻域内解析.故b必为 $ \frac{f'(z)}{f(z)} $的一阶极点,且

 $$ \mathrm{Res}_{z=b}\left[\frac{f^{\prime}(z)}{f(z)}\right]=-m. $$ 

定理 6.9 设 C 是一条周线,  $ f(z) $ 符合条件:

(1)  $ f(z) $ 在 C 的内部是亚纯的；

<!-- page: 277 -->

(2) $ f(z) $在 C 上解析且不为零.

则有  $ \frac{1}{2\pi i}\int_{c}\frac{f^{\prime}(z)}{f(z)}\mathrm{d}z=N(f,C)-P(f,C) $，(6.26)

式中  $ N(f, C) $ 与  $ P(f, C) $ 分别表示  $ f(z) $ 在 C 内部的零点与极点的个数（一个 n 阶零点算作 n 个零点，而一个 m 阶极点算作 m 个极点）.

证 由第五章习题(二)14, 可知  $ f(z) $ 在 C 内部至多只有有限个零点和极点. 设  $ a_{k}(k=1,2,\cdots,p) $ 为  $ f(z) $ 在 C 内部的不同零点, 其阶相应地为  $ n_{k}; b_{j}(j=1,2,\cdots,q) $ 为  $ f(z) $ 在 C 内部的不同极点, 其阶相应地为  $ m_{j} $, 则根据引理 6.4 知,  $ \frac{f'(z)}{f(z)} $ 在 C 的内部及 C 上除去在 C 内部有一阶极点  $ a_{k}(k=1,2,\cdots,p) $ 及  $ b_{j}(j=1,2,\cdots,q) $ 外均是解析的. 故由留数定理及引理 6.4 得

 $$ \begin{align*}\frac{1}{2\pi\mathrm{i}}\int_{C}&\frac{f^{\prime}(z)}{f(z)}\mathrm{d}z=\sum_{k=1}^{p}\operatorname{Res}_{z=a_{k}}\left[\frac{f^{\prime}(z)}{f(z)}\right]+\sum_{j=1}^{q}\operatorname{Res}_{z=b_{j}}\left[\frac{f^{\prime}(z)}{f(z)}\right]\\&=\sum_{k=1}^{p}n_{k}+\sum_{j=1}^{q}\left(-m_{j}\right)=N(f,C)-P(f,C).\end{align*} $$ 

2. 辐角原理 公式(6.26)的左端是  $ f(z) $ 的对数函数, 它有简单的意义.

为了说明这个意义,我们将它写成

 $$ \begin{align*}\frac{1}{2\pi i}\int_{c}\frac{f'(z)}{f(z)}\mathrm{d}z&=\frac{1}{2\pi i}\int_{c}\frac{\mathrm{d}}{\mathrm{d}z}\left[\ln f(z)\right]\mathrm{d}z\\&=\frac{1}{2\pi i}\int_{c}\mathrm{d}\ln f(z)\\&=\frac{1}{2\pi i}\left[\int_{c}\mathrm{d}\ln|f(z)|+\mathrm{i}\int_{c}\mathrm{d}\arg f(z)\right],\end{align*} $$ 

函数  $ \ln|f(z)| $ 是 z 的单值函数，当 z 从  $ z_{0} $ 起绕行周线 C 一周回到  $ z_{0} $ 时，有

 $$ \int_{C}\mathrm{d}\ln|f(z)|=\ln|f(z_{0})|-\ln|f(z_{0})|=0. $$

<!-- page: 278 -->

另一方面，当 z 从  $ z_{0} $ 起沿周线 C 的正方向绕行一周而回到  $ z_{0} $ 时， $ \arg f(z) $ 的值可能改变。如图 6.12，对应的  $ w = f(z) $ 从  $ w_{0} = f(z_{0}) $ 起围绕原点 w = 0 二周后又回到起点  $ w_{0} = f(z_{0}) $。显然， $ \arg f(z) $ 的终值  $ \varphi_{1} $ 与始值  $ \varphi_{0} $ 相差  $ 4\pi $。于是我们得

<div style="text-align: center;"><img src="images/p0278_img_in_image_box_463_1416_3973_3011.jpg" alt="图 6.12" width="79%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.12</div> </div>


 $$ \begin{aligned}\frac{1}{2\pi\mathrm{i}}\int_{c}\frac{f^{\prime}(z)}{f(z)}\mathrm{d}z&=\frac{\mathrm{i}(\varphi_{1}-\varphi_{0})}{2\pi\mathrm{i}}\\&=\frac{\Delta_{c}\arg f(z)}{2\pi},\end{aligned} $$ 

式中  $ \Delta_{C}\operatorname{arg}f(z) $ 表示 z 沿 C 之正方向绕行一周后  $ \arg f(z) $ 的改变量. 它一定是  $ 2\pi $ 的整倍数.

这样，我们可以将定理 6.9 改写成：

辐角原理 在定理 6.9 的条件下,  $ f(z) $ 在周线 C 内部的零点个数与极点个数之差, 等于当 z 沿 C 之正向绕行一周后  $ \arg f(z) $ 的改变量  $ \Delta_{c}\arg f(z) $ 除以  $ 2\pi $, 即

$$  N(f,C)-P(f,C)=\frac{\Delta_{C}\arg f(z)}{2\pi}.   \tag*{(6.27)}$$

特别说来,如  $ f(z) $ 在周线 C 上及 C 之内部均解析,且  $ f(z) $ 在 C 上不为零,则.

<!-- page: 279 -->

$$  N(f,C)=\frac{\Delta_{C}\arg f(z)}{2\pi}.   \tag*{(6.28)}$$

例 6.21 设  $ f(z)=(z-1)(z-2)^{2}(z-4) $，C:  $ \left|z\right|=3 $，试验证辐角原理.

解  $ f(z) $ 在 z 平面上解析，在 C 上无零点，且在 C 的内部只有一阶零点 z=1 及二阶零点 z=2。所以，一方面有

 $$ N(f,C)=1+2=3； $$ 

另一方面，当 z 沿正方向绕 C 一周时，有

 $$ \begin{align*}\Delta_{C}\arg f(z)&=\Delta_{C}\arg(z-1)+\Delta_{C}\arg(z-2)^{2}\\&\quad+\Delta_{C}\arg(z-4)\\&=\Delta_{C}\arg(z-1)+2\Delta_{C}\arg(z-2)\\&=2\pi+4\pi=6\pi,\end{align*} $$ 

于是，(6.28)成立.

注 若将定理 6.9 的条件 (2) 减弱为：“ $ f(z) $ 连续到边界 C，且沿  $ Cf(z) \neq 0 $”，则辐角原理 (6.27) 式 [特别是当  $ f(z) $ 在 C 内部解析时，(6.28) 式] 仍成立.

事实上，首先取一条全含于 C 内部的周线  $ C' $，使  $ C' $ 的内部包含 C 内部的全部零点和极点，则对此周线  $ C' $，根据定理 6.9 就有

 $$ \begin{align*}N(f,C)-P(f,C)&=N(f,C^{\prime})\\&-P(f,C^{\prime})=\frac{\Delta_{c^{\prime}}\arg f(z)}{2\pi},\end{align*} $$ 

然后过渡到极限  $ C^{\prime} \rightarrow C $，利用函数  $ f(z) $ 的连续性即得.

例 6.22 设 n 次多项式

 $$ P(z)=a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n}\qquad(a_{0}\neq0) $$ 

在虚轴上没有零点，试证明它的零点全在左半平面  $ \mathrm{Re}\ z<0 $ 内的充要条件是

 $$ \underset{y(-\infty\nearrow+\infty)}{\Delta\mathrm{a r g}}P(\mathrm{i}y)=n\pi. $$ 

即当点 z 自下而上沿虚轴从点  $ \infty $ 走向点  $ \infty $ 的过程中,  $ P(z) $ 绕原点

<!-- page: 280 -->

转了 $ \frac{n}{2} $圈.

证 令周线  $ C_{R} $ 是右半圆周

 $$ \Gamma_{_{\cal R}}:z=R e^{\mathrm{i}\theta}\left(-\frac{\pi}{2}{\leqslant}\theta{\leqslant}\frac{\pi}{2}\right) $$ 

以及虚轴上从  $ R_{i} $ 到  $ -R_{i} $ 的有向线段所构成（图 6.13）.

<div style="text-align: center;"><img src="images/p0280_img_in_image_box_1611_1684_2772_3230.jpg" alt="图 6.13" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.13</div> </div>


于是  $ P(z) $ 的零点全在左半平面的充要条件为  $ N(P, C_{R}) = 0 $

对任意 R 均成立，由 (6.28) 即知此条件可写成

$$  \begin{aligned}&0=\lim_{R\rightarrow+\infty}\Delta_{C_{R}}\arg P(z)\\&=\lim_{R\rightarrow+\infty}\Delta_{\Gamma_{R}}\arg P(z)-\lim_{R\rightarrow+\infty}\Delta_{y(-\mathscr{R}\mathscr{P}+R)}\arg P(iy).\\ \end{aligned}   \tag*{(6.29)}$$

但我们有

 $$ \begin{aligned}&\Delta_{\Gamma_{R}}\arg P(z)=\Delta_{\Gamma_{R}}\arg a_{0}z^{n}\left[1+g(z)\right]\\=&\Delta_{\Gamma_{R}}\arg a_{0}z^{n}+\Delta_{\Gamma_{R}}\arg\left[1+g(z)\right],\\ \end{aligned} $$ 

其中  $ g(z)=\frac{a_{1}z^{n-1}+\cdots+a_{n}}{a_{0}z^{n}} $，在  $ R\rightarrow+\infty $ 时  $ g(z) $ 沿  $ \Gamma_{R} $ 一致趋于零.

由此知

<!-- page: 281 -->

$$ \operatorname*{l i m}_{R\to+\infty}\Delta_{\varGamma_{R}}\arg[1+g(z)]=0. $$ 

另一方面又有

 $$ \Delta_{r_{_{R}}}\arg a_{_{0}}z^{^{n}}=\Delta_{\theta}\big[-\tfrac{\pi}{2}\nearrow+\tfrac{\pi}{2}\big]\arg a_{_{0}}R^{^{n}}\mathrm{e}^{\mathrm{i}n\theta}=n\pi. $$ 

这样一来，(6.29)就是我们所要证明的

 $$ \Delta_{y(-\infty\nearrow+\infty)}\arg P(\mathrm{i}y)=n\pi. $$ 

注 在自动控制中,若干物理和技术装置的稳定性归结为,要求常系数线性微分方程

 $$ a_{0}\ \frac{\mathrm{d}^{n}y}{\mathrm{d}t^{n}}+a_{1}\ \frac{\mathrm{d}^{n-1}y}{\mathrm{d}t^{n-1}}+\cdots+a_{n}y=f(t) $$ 

解的稳定性.此问题要求其特征多项式

 $$ P(z)=a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n} $$ 

的根全在左半平面.例 6.22 给出了此问题的一个判据.

3. 儒歇(Rouché)定理 下面的定理是辐角原理的一个推论，在考察函数的零点分布时，用起来更为方便.

定理 6.10(儒歇定理) 设 C 是一条周线, 函数  $ f(z) $ 及  $ \varphi(z) $ 满足条件:

（1）它们在 C 的内部均解析，且连续到 C；

(2) 在 C 上,  $ \left|f(z)\right| > \left|\varphi(z)\right| $,

则函数  $ f(z) $ 与  $ f(z) + \varphi(z) $ 在 C 的内部有同样多（几阶算作几个）的零点，即

 $$ N(f+\varphi,C)=N(f,C). $$ 

证 由假设知  $ f(z) $ 及  $ f(z) + \varphi(z) $ 在 C 的内部解析，且连续到 C，在 C 上有  $ \left|f(z)\right| > 0 $，

 $$ |f(z)+\varphi(z)|\geqslant|f(z)|-|\varphi(z)|>0. $$ 

这样一来，这两个函数  $ f(z) $ 及  $ f(z) + \varphi(z) $ 都满足定理 6.9 及其注的条件. 由于这两个函数在 C 的内部解析，于是由(6.28)，下面只须证明

$$  \Delta_{c}\arg[f(z)+\varphi(z)]=\Delta_{c}\arg f(z).   \tag*{(6.30)}$$

<!-- page: 282 -->

由关系式

 $$ f(z)+\varphi(z)=f(z)\left[1+\frac{\varphi(z)}{f(z)}\right], $$ 

$$  \Delta_{c}\arg\left[f(z)+\varphi(z)\right]=\Delta_{c}\arg f(z)+\Delta_{c}\arg\left[1+\frac{\varphi(z)}{f(z)}\right],   \tag*{(6.31)}$$

根据条件(2)，当 z 沿 C 变动时  $ \left|\varphi(z)/f(z)\right|<1 $。借助函数  $ \eta=1+\frac{\varphi(z)}{f(z)} $ 将 z 平面上的周线 C 变成  $ \eta $ 平面上的闭曲线  $ \Gamma $。于是  $ \Gamma $ 全在圆周  $ \left|\eta-1\right|=1 $ 的内部（图 6.14），而原点  $ \eta=0 $ 又不在此圆周的内部。即是说，点  $ \eta $ 不会围着原点  $ \eta=0 $ 绕行。故

<div style="text-align: center;"><img src="images/p0282_img_in_image_box_528_2598_3906_3802.jpg" alt="图 6.14" width="76%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.14</div> </div>


 $$ \Delta_{c}\arg\left[1+\frac{\varphi\left(z\right)}{f\left(z\right)}\right]=0, $$ 

由(6.31)即知(6.30)为真.

例 6.23 设 n 次多项式

 $$ p\left(z\right)=a_{0}z^{n}+\cdots+a_{t}z^{n-t}+\cdots+a_{n}\quad\left(a_{0}\neq0\right) $$ 

符合条件

 $$ |a_{t}|>|a_{0}|+\cdots+|a_{t-1}|+|a_{t+1}|+\cdots+|a_{n}|, $$ 

则  $ p(z) $ 在单位圆  $ \left|z\right|<1 $ 内有 n-t 个零点.

证 取  $ f(z)=a_{t}z^{n-t} $,

<!-- page: 283 -->

$$ \varphi(z)=a_{0}z^{n}+\cdots+a_{t-1}z^{n-t+1}+a_{t+1}z^{n-t-1}+\cdots+a_{n}, $$ 

易于验证在单位圆周  $ |z|=1 $ 上，有

 $$ |f(z)|>|\varphi(z)|. $$ 

依儒歇定理知， $ p(z)=f(z)+\varphi(z) $ 在单位圆  $ \left|z\right|<1 $ 内的零点，与  $ f(z)=a_{t}z^{n-t} $ 在单位圆  $ \left|z\right|<1 $ 内的零点一样多，即 n-t 个.

据此，一望而知：

方程  $ z^{8}-5z^{5}-2z+1=0 $ 在单位圆内有 5 个根；

方程  $ z^{7}-5z^{4}+z^{2}-2=0 $ 在单位圆内有 4 个根；

方程  $ z^{4}-5z+1=0 $ 在单位圆内有 1 个根；

方程  $ z^{6}+6z+10=0 $ 在单位圆内无根.

例 6.24 试证: 当  $ |a| > e $ 时, 方程  $ e^{z} - az^{n} = 0 $ 在单位圆  $ |z| < 1 $ 内有 n 个根.

证 在单位圆周  $ |z|=1 $ 上，有

 $$ |-a z^{n}|=|a|>e, $$ 

 $$ \left|\mathrm{e}^{z}\right|=\mathrm{e}^{\mathrm{Re}^{z}}\leqslant\mathrm{e}^{\left|z\right|}=\mathrm{e}, $$ 

即有

 $$ |-a z^{n}|>|\mathrm{e}^{z}|, $$ 

而函数  $ e^{z} $ 及  $ -az^{n} $ 均在单位闭圆  $ \left|z\right|\leq1 $ 上解析. 故由儒歇定理

 $$ N\left(\mathrm{e}^{z}-a z^{n},\mid z\mid=1\right)=N\left(-a z^{n},\mid z\mid=1\right)=n. $$ 

即方程  $ e^{z} - az^{n} = 0 $ 在单位圆  $ \left|z\right| < 1 $ 内有 n 个根.

例 6.25 应用儒歇定理证明代数学基本定理: 任一 n 次方程

 $$ a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n-1}z+a_{n}=0\quad(a_{0}\neq0) $$ 

有且只有 n 个根（几重根就算作几个根）.

证 命  $ f(z)=a_{0}z^{n} $,  $ \varphi(z)=a_{1}z^{n-1}+\cdots+a_{n} $, 当 z 在充分大的圆周  $ C:|z|=R $ 上时, 例如取

 $$ R>\max\left\{\frac{\left|a_{1}\right|+\cdots+\left|a_{n}\right|}{a_{0}}\right\},1, $$ 

有

 $$ \begin{aligned}\mid\varphi(z)\mid\leqslant\mid a_{1}\mid R^{n-1}+\cdots+\mid a_{n-1}\mid R+\mid a_{n}\mid\\ <\mid(a_{1}\mid+\cdots+\mid a_{n}\mid)R^{n-1}\end{aligned} $$

<!-- page: 284 -->

$$ <\mid a_{0}\mid R^{n}=\mid f(z)\mid, $$ 

由儒歇定理即知在圆  $ \left|z\right|<R $ 内，方程

 $$ a_{0}z^{n}+a_{1}z^{n-1}+\cdots+a_{n-1}z+a_{n}=0\mathrm{~ 与 ~}a_{0}z^{n}=0 $$ 

有相同个数的根.而  $ a_{0}z^{n}=0 $ 在  $ \left|z\right|<R $ 内有一个 n 重根 z=0.因此原 n 次方程在  $ \left|z\right|<R $ 内有 n 个根.

另外，在圆周  $ \left|z\right|=R $ 上，或者在它的外部，任取一点  $ z_{0} $，则  $ \left|z_{0}\right|=R_{0}\geqslant R $，于是

 $$ \begin{array}{r l}&{\quad|a_{0}z_{0}^{n}+a_{1}z_{0}^{n-1}+\cdots+a_{n-1}z_{0}+a_{n}|}\\ &{\geqslant|a_{0}z_{0}^{n}|-|a_{1}z_{0}^{n-1}+a_{2}z_{0}^{n-2}+\cdots+a_{n}|}\\ &{\geqslant|a_{0}|R_{0}^{n}-(|a_{1}|R_{0}^{n-1}+|a_{2}|R_{0}^{n-2}+\cdots+|a_{n}|)}\\ &{>|a_{0}|R_{0}^{n}-(|a_{1}|+|a_{2}|+\cdots+|a_{n}|)R_{0}^{n-1}}\\ &{>|a_{0}|R_{0}^{n}-|a_{0}|R_{0}^{n}=0,}\end{array} $$ 

这说明原 n 次方程在圆周  $ \left|z\right|=R $ 上及其外部都没有根. 所以原 n 次方程在 z 平面上有且只有 n 个根.

例 6.26 试证：方程

$$  z^{7}-z^{3}+12=0   \tag*{(6.32)}$$

的根全在圆环  $ 1<|z|<2 $ 内.

证 由例 6.23 知方程(6.32)在圆周  $ \left|z\right|=1 $ 的内部无根.

又在圆周 $ \left|z\right|=2 $上

 $$ \left|12-z^{3}\right|\leqslant12+\left|z\right|^{3}=12+8=20<128=2^{7}=\left|z^{7}\right|, $$ 

故由儒歇定理,方程(6.32)的7个根全在

 $$ 1\leq\mid z\mid<2 $$ 

上. 但当  $ \left|z\right|=1 $ 时

 $$ \begin{aligned}\mid z^{7}-z^{3}\mid&=\mid z\mid^{3}\mid z^{4}-1\mid\leqslant\mid z\mid^{3}(\mid z\mid^{4}+1)=2,\\\mid z^{7}-z^{3}+12\mid&\geqslant12-\mid z^{7}-z^{3}\mid\geqslant12-2=10>0.\end{aligned} $$ 

故方程(6.32)的根全在圆环  $ 1<|z|<2 $ 内.

下面应用儒歇定理证明的定理是单叶解析函数的一个重要性质.在下一章共形映射中要用.

<!-- page: 285 -->

定理 6.11 若函数  $ f(z) $ 在区域 D 内单叶解析，则在 D 内  $ f'(z) \neq 0 $.

证 若有 D 的点  $ z_{0} $ 使  $ f^{\prime}(z_{0})=0 $，则  $ z_{0} $ 必为  $ f(z)-f(z_{0}) $ 的一个 n 阶零点  $ (n \geqslant 2) $。由零点的孤立性，故存在  $ \delta>0 $，使在圆周  $ C: |z-z_{0}|=\delta $ 上

 $$ f(z)-f(z_{0})\neq0, $$ 

在 C 的内部,  $ f(z) - f(z_{0}) $ 及  $ f'(z) $ 无异于  $ z_{0} $ 的零点.

命 m 表  $ \left|f(z)-f(z_{0})\right| $ 在 C 上的下确界，则由儒歇定理即知，当  $ 0<|-a|<m $ 时， $ f(z)-f(z_{0})-a $ 在圆周 C 的内部亦恰有 n 个零点。但这些零点无一为多重点，理由是  $ f'(z) $ 在 C 内部除  $ z_{0} $ 外无其他零点，而  $ z_{0} $ 显然非  $ f(z)-f(z_{0})-a $ 的零点。

故命  $ z_{1}, z_{2}, \cdots, z_{n} $ 表  $ f(z) - f(z_{0}) - a $ 在 C 内部的 n 个相异零点. 于是

 $$ f(z_{k})=f(z_{0})+a\quad(k=1,2,\cdots,n). $$ 

这与  $ f(z) $ 的单叶性假设矛盾.

故在区域 D 内  $ f'(z) \neq 0 $.

思考题 试举一个初等解析函数,说明定理6.11的逆不真.

## 第六章习题

(一)

1 求下列函数  $ f(z) $ 在指定点的留数.

(1) $ \frac{z}{(z-1)(z+1)^{2}} $在 $ z=\pm1,\infty $

答:  $ \mathrm{Res}_{z=1}f(z)=\frac{1}{4};\mathrm{Res}_{z=-1}f(z)=-\frac{1}{4}. $

(2) $ \frac{1}{\sin z} $在 $ z=n\pi(n=0,\pm1,\cdots) $.

<!-- page: 286 -->

答:  $ \mathrm{Res}_{z=n\pi}f(z)=\frac{1}{\cos n\pi}=(-1)^{n} $.

(3) $ \frac{1-\mathrm{e}^{2z}}{z^{4}} $在z=0, $ \infty $.

答: $ Res_{z=0}f(z)=-\frac{4}{3} $

（4） $ e^{\frac{1}{x-1}} $ 在 z = 1,  $ \infty $.

答: Res  $ f(z) = 1 $.

(5) $ \frac{z^{2n}}{(z-1)^{n}} $在z=1, $ \infty $.

答:  $ \mathrm{Res}_{z=1}f(z)=\frac{(2n)!}{(n-1)!(n+1)!} $.

(6) $ \frac{e^{z}}{z^{2}-1} $在 $ z=\pm1,\infty $

答:  $ \mathrm{Res}_{z=\infty} f(z)=\frac{e^{-1}-e}{2} $.

2 求下列函数  $ f(z) $ 在其孤立奇点（包括无穷远点）处的留数 (m 是正整数).

(1)  $ z^{m}\sin\frac{1}{z} $

答：m 为奇数时， $ \mathrm{Res}_{z=0}f(z)=0 $;

m 为偶数 2k 时， $ \mathrm{Res}_{z=0}f(z)=\frac{(-1)^{k}}{(2k+1)!} $.

(2) $ \frac{z^{2m}}{1+z^{m}}. $

答： $ \mathrm{Res}_{z=e_{k}}f(z)=-\frac{e_{k}}{m} $，其中  $ e_{k}=e^{\frac{(2k+1)\pi i}{m}}(k=0,1,\cdots,m-1) $;

 $$ \begin{align*}\mathrm{Res}_{z=\infty}f(z)=&-\sum_{k=0}^{m-1}\left(-\frac{\mathrm{e}_{k}}{m}\right)(\mathrm{e}_{k}^{m}=-1)\\=&\frac{1}{m}\sum_{k=0}^{m-1}\mathrm{e}_{k}=\left\{\begin{array}{c}0,m>1,\\-1,m=1.\end{array}\right.\end{align*} $$ 

(3)  $ \frac{1}{(z - \alpha)^m (z - \beta)} $ ( $ \alpha \neq \beta $).

 $$ \mathop{\mathrm{R e s}}\limits_{z=\alpha}f(z)=-\frac{1}{\left(\beta-\alpha\right)^{m}};\mathop{\mathrm{R e s}}\limits_{z=\beta}f(z)=\frac{1}{\left(\beta-\alpha\right)^{m}}. $$

<!-- page: 287 -->

(4)  $ \frac{e^{z}}{z^{2}(z-\pi i)^{4}} $.

答： $ \mathrm{Res}_{z=0}f(z)=\frac{\pi-4i}{\pi^{5}}; $

 $$ \mathrm{R e s}_{z=\pi\mathrm{i}}f(z)=\frac{1}{6\pi^{5}}(\pi^{3}+6\pi^{2}\mathrm{i}-18\pi-24\mathrm{i}). $$ 

3 计算下列各积分：

(1)

 $$ \int_{|z|=1}\frac{\mathrm{d}z}{z\sin z};(2)\quad\frac{1}{2\pi\mathrm{i}}\int_{|z|=2}\frac{\mathrm{e}^{z\mathrm{i}}}{1+z^{2}}\mathrm{d}z; $$ 

(3)

 $$ \int_{c}\frac{\mathrm{d}z}{(z-1)^{2}(z^{2}+1)},C:x^{2}+y^{2}=2(x+y); $$ 

(4)

 $$ \int_{|z|=1}\frac{\mathrm{d}z}{\left(z-a\right)^{n}\left(z-b\right)^{n}}\quad\left(\begin{aligned}&|a|<1\\ &|b|<1\end{aligned}\right.,a\neq b,n 为正整数 \left)\right. $$ 

答: (1)  $ 0 $; (2)  $ \sin t $; (3)  $ -\frac{1}{2}\pi i $; (4) 0.

4 求下列各积分之值：

(1)

 $$ \int_{0}^{2\pi}\frac{\mathrm{d}\theta}{a+\cos\theta}(a>1)\;;(2)\int_{0}^{2\pi}\frac{\mathrm{d}x}{(2+\sqrt{3}\cos x)^{2}}\;; $$ 

(3) $ \int_{0}^{\pi}\tan\left(\theta+\mathrm{i}a\right)\mathrm{d}\theta $（a为实数且 $ a\neq0 $）.

答: (1)  $ \frac{2\pi}{\sqrt{a^{2}-1}} $; (2)  $ 4\pi $; (3)  $ \pi i(a>0) $;  $ -\pi i(a<0) $.

5 求下列各积分：

 $$ (1)\int_{0}^{+\infty}\frac{x^{2}}{(x^{2}+1)(x^{2}+4)}\mathrm{d}x\;;\;(2)\int_{-\infty}^{+\infty}\frac{x^{2}}{(x^{2}+a^{2})^{2}}\mathrm{d}x(a>0)\;; $$ 

(3)

 $$ \int_{-\infty}^{+\infty}\frac{\cos x}{(x^{2}+1)(x^{2}+9)}\mathrm{d}x\;;\quad(4)\int_{0}^{+\infty}\frac{x\sin m x}{x^{4}+a^{4}}\mathrm{d}x\left(\begin{matrix}m>0\\ a>0\end{matrix}\right). $$ 

答: (1)  $ \frac{\pi}{6} $; (2)  $ \frac{\pi}{2a} $; (3)  $ \frac{\pi}{24e^{3}}(3e^{2}-1) $;

(4)

 $$ \frac{\pi}{2a^{2}}\mathrm{e}^{-\frac{ma}{\sqrt{2}}}\sin\frac{ma}{\sqrt{2}}. $$ 

6 仿照例 6.15 的方法计算下列积分：

(1)  $ \int_{0}^{+\infty}\frac{\sin x}{x(x^{2}+a^{2})}dx(a>0) $; (2)  $ \int_{0}^{+\infty}\frac{\sin x}{x(x^{2}+1)^{2}}dx $.

<!-- page: 288 -->

答: (1)  $ \frac{\pi}{2a^{2}}(1 - e^{-a}); $ (2)  $ \frac{\pi}{2}\left(1 - \frac{3}{2e}\right) $.

7 从  $ \int_{C}\frac{e^{iz}}{\sqrt{z}}dz $ 出发，其中 C 是如图 6.15 所示之周线  $ (\sqrt{z} $ 沿正实轴取正值)，证明

 $$ \int_{0}^{+\infty}\frac{\cos x}{\sqrt{x}}\mathrm{d}x=\int_{0}^{+\infty}\frac{\sin x}{\sqrt{x}}\mathrm{d}x=\sqrt{\frac{\pi}{2}}. $$ 

<div style="text-align: center;"><img src="images/p0288_img_in_image_box_695_2053_1884_3105.jpg" alt="图 6.15" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.15</div> </div>


<div style="text-align: center;"><img src="images/p0288_img_in_image_box_2471_1856_3755_3099.jpg" alt="图 6.16" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.16</div> </div>


8 从  $ \int_{C}\frac{\sqrt{z}\ln z}{(1+z)^{2}}\mathrm{d}z $ 出发, 其中 C 是如图 6.16 所示的周线, 证明:

 $$ \int_{0}^{+\infty}\frac{\sqrt{x}\ln\dot{x}}{\left(1+x\right)^{2}}\mathrm{d}x=\pi, $$ 

 $$ \int_{0}^{+\infty}\frac{\sqrt{x}}{\left(1+x\right)^{2}}\mathrm{d}x=\frac{\pi}{2}. $$ 

9 证明

 $$ I=\int_{0}^{1}\frac{\mathrm{d}x}{\left(1+x^{2}\right)\sqrt{1-x^{2}}}=\frac{\pi}{2\sqrt{2}}. $$ 

提示 取辅助函数

 $$ f(z)=\frac{1}{(1+z^{2})\sqrt{1-z^{2}}}. $$ 

沿图 6.17 所示之路径 C 积分，其中根式是沿  $ l' $ 取正值的那一支。 $ C'_{r}: |z + 1| = r $,  $ C'_{r}: |z - 1| = r $,  $ C_{R}: |z| = R $, r 充分小，R 充分大。

### 10 证明方程

<!-- page: 289 -->

<div style="text-align: center;"><img src="images/p0289_img_in_image_box_1399_555_3006_2059.jpg" alt="图 6.17" width="36%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 6.17</div> </div>


 $$ c^{z-\lambda}=z\quad(\lambda>1) $$ 

在单位圆  $ \left|z\right|<1 $ 内恰有一个根，且为实根.

### 11 证明方程

 $$ \mathrm{e}^{z}-\mathrm{e}^{\lambda}z^{n}=0\quad(\lambda>1) $$ 

在单位圆  $ \left|z\right|<1 $ 内有 n 个根.

12 若  $ f(z) $ 在周线 C 内部除有一个一阶极点外解析，且连续到 C，在 C 上  $ \left|f(z)\right|=1 $ 。证明

 $$ f(z)=a\quad(\mid a\mid>1) $$ 

在 C 内部恰好有一个根.

##### 提示 用辐角原理证明

 $$ N(f(z)-a,C)-P(f(z)-a,C)=0. $$ 

13 若  $ f(z) $ 在周线 C 内部亚纯且连续到 C，试证：

(1) 若  $ z \in C $ 时,  $ \left|f(z)\right| < 1 $, 则方程  $ f(z) = 1 $ 在 C 的内部根的个数, 等于  $ f(z) $ 在 C 的内部的极点个数.

(2) 若  $ z \in C $ 时,  $ \left|f(z)\right| > 1 $, 则方程  $ f(z) = 1 $ 在 C 的内部根的个数, 等于  $ f(z) $ 在 C 的内部的零点个数.

14 设  $ \varphi(z) $ 在 C:  $ \left|z\right|=1 $ 内部解析，且连续到 C，在 C 上  $ \left|\varphi(z)\right|<1 $.

试证：在 C 内部只有一个点  $ z_{0} $，使  $ \varphi(z_{0})=z_{0} $.

## (二)

### 1 计算积分

<!-- page: 290 -->

(1)

 $$ \int_{C:\mid z\mid=2}\frac{z}{\frac{1}{2}-\sin^{2}z}\mathrm{d}z; $$ 

(2)

 $$ \int_{C:|z|=2}\frac{z}{z^{4}-1}\mathrm{d}z; $$ 

(3)

 $$ \int_{C:\mid z\mid=2}\frac{\mathrm{d}z}{\left(z+\mathrm{i}\right)^{10}\left(z-1\right)\left(z-3\right)}; $$ 

(4)

 $$ \int_{0}^{\frac{\pi}{2}}\frac{\mathrm{d}x}{a+\sin^{2}x}\quad(a>0); $$ 

(5)

 $$ \int_{0}^{+\infty}\frac{x\sin ax}{x^{2}+b^{2}}\mathrm{d}x\quad\left(a>0,b>0\right). $$ 

答: (1)

 $$ -\pi^{2}\mathrm{i};(2)0;(3)-\frac{\pi\mathrm{i}}{(3+\mathrm{i})^{10}}; $$ 

(4)

 $$ \frac{\pi}{2\sqrt{a(a+1)}};\left(5\right)\frac{\pi}{2}\mathrm{e}^{-a b}. $$ 

2 计算积分

 $$ \frac{1}{2\pi\mathrm{i}}\int_{c}\frac{\mathrm{d}\zeta}{\zeta(\zeta-z)}, $$ 

其中 C 为单位圆周  $ \left|\zeta\right|=1, z\notin C $.

3 设  $ f(z) $ 在  $ \mid z\mid < 1 $ 内解析，在  $ \mid z\mid \leqslant 1 $ 上连续，试证：

 $$ \left(1-\mid z\mid^{2}\right)f(z)=\frac{1}{2\pi\mathrm{i}}\int_{C:\mid\zeta\mid=1}f(\zeta)\left(\frac{1-\bar{z}\zeta}{\zeta-z}\right)\mathrm{d}\zeta, $$ 

其中 z 属于 C 的内部.

4 试证：

 $$ \left(\frac{z^{n}}{n!}\right)^{2}=\frac{1}{2\pi\mathrm{i}}\int_{C}\frac{z^{n}\mathrm{e}^{z\zeta}}{n!\quad\zeta^{n}}\cdot\frac{\mathrm{d}\zeta}{\zeta}, $$ 

这里 C 是围绕原点的一条周线.

5 试证: 含点  $ \infty $ 的区域的留数定理(在例 6.20 中列出并引用过).

6 试证：

 $$ I_{1}=\int_{0}^{2\pi}\mathrm{e}^{\cos\theta}\cos(n\theta-\sin\theta)\mathrm{d}\theta=\frac{2\pi}{n!}. $$ 

提示 考虑  $ I_{1} + iI_{2} $，其中

 $$ I_{2}=\int_{0}^{2\pi}\mathrm{e}^{\cos\theta}\sin(n\theta-\sin\theta)\mathrm{d}\theta. $$ 

7 设函数  $ f(z) $ 在  $ \left|z\right| \leqslant r $ 上解析，在  $ \left|z\right| = r $ 上  $ f(z) \neq 0 $. 试证：在  $ \left|z\right| $

<!-- page: 291 -->

= r 上，

 $$ \mathrm{R e}\left(z\frac{f^{\prime}(z)}{f(z)}\right) $$ 

的最大值至少等于  $ f(z) $ 在  $ \left|z\right| < r $ 内的零点个数.

提示 应用定理 6.9.

8 设 C 是一条周线，且设

(1)  $ f(z) $ 符合定理 6.9 的条件  $ [a_{k}(k=1,2,\cdots,p) $ 为  $ f(z) $ 在 C 内部的不同的零点，其阶相应为  $ n_{k} $;  $ b_{j}(j=1,2,\cdots,q) $ 为  $ f(z) $ 在 C 内部的不同的极点，其阶相应为  $ m_{j} $;

(2)  $ \varphi(z) $ 在闭域  $ \overline{I(C)} $ 上解析.

则有(试证)

 $$ \frac{1}{2\pi\mathrm{i}}\int_{C}\varphi(z)\frac{f^{\prime}(z)}{f(z)}\mathrm{d}z=\sum_{k=1}^{p}n_{k}\varphi(a_{k})-\sum_{j=1}^{q}m_{j}\varphi(b_{j}) $$ 

（这是定理 6.9 的推广， $ \varphi(z)=1 $ 时就是定理 6.9）.

9 设 C 是一条周线，且设

(1)  $ f(z) $、 $ \varphi(z) $ 在 C 内部亚纯，且连续到 C，

(2) 沿  $ C, |f(z)| > |\varphi(z)| $,

则（试证）

 $$ \begin{align*}&N(f(z)+\varphi(z),C)-P(f(z)+\varphi(z),C)\\=&N(f(z),C)-P(f(z),C).\end{align*} $$ 

注 这是儒歇定理的推广形式.为了给出它的一个应用,可参阅:“钟玉泉.一个解析函数定理的推广.四川大学学报(自然科学版),1990(1),86~87.”

10 如果  $ \left|a\right| > \frac{e^{R}}{R^{n}} $，试证方程

 $$  e^{z}=az^{n}\quad(n 为正整数 ) $$ 

在圆 $ \left|z\right|<R $内恰有n个根.

11 试证方程

 $$ \sin z=2z^{4}-7z+1 $$ 

在单位圆  $ \left|z\right|<1 $ 内恰有一个根.

提示 应用第二章习题(二)5.

12 试证方程

 $$ z+\mathrm{e}^{-z}=a\quad(a>1) $$

<!-- page: 292 -->

在 Re z > 0 内只有一个根，且为实根.

### 13 方程

 $$ z^{4}-8z+10=0 $$ 

在圆  $ \left|z\right|<1 $ 与在圆环  $ 1<\left|z\right|<3 $ 内各有几个根？

答: 前者无根; 后者有 4 个根.

14 应用儒歇定理证明例 3.11.

15 设 D 是周线 C 的内部,  $ f(z) $ 在闭域  $ \overline{D} = D + C $ 上解析. 试证: 在 D 内不可能存在一点  $ z_{0} $ 使

 $$ |f(z)|<|f(z_{0})|\quad(z\in C). $$ 

16 设(1)  $ f(z) $ 在点  $ z_{0} $ 解析,  $ f(z_{0}) = w_{0} $;

(2)  $ f(z) - w_{0} $ 以  $ z_{0} $ 为 n 阶零点.

试证:对于充分小的  $ \varepsilon>0 $, 能确定  $ \delta>0 $, 使对满足  $ \left|a-w_{0}\right|<\delta $ 的 a, 函数  $ f(z)-a $ 在圆  $ \left|z-z_{0}\right|<\varepsilon $ 内恰有 n 个一阶零点.

<!-- page: 293 -->

## 第七章 共形映射

前几章主要是用分析的方法，也就是用微分、积分和级数等来讨论解析函数的性质和应用。内容主要涉及柯西理论。在这一章中，我们将从几何的角度来对解析函数的性质和应用进行讨论。

第一章我们曾经说过，一个复变函数  $ w = f(z)(z \in E) $，从几何观点看来，可以解释为从 z 平面到 w 平面之间的一个变换，本章将讨论解析函数所构成的变换（简称解析变换）的某些重要性。我们将看到，这种变换在导数不为零的点处具有一种保角的特性，它在数学本身以及在解决流体力学、弹性力学、电学等学科的某些实际问题中，都是一种使问题化繁为简的重要方法。

#### §1. 解析变换的特性

### 1. 解析变换的保域性

定理 7.1(保域定理) 设  $ w = f(z) $ 在区域 D 内解析且不恒为常数，则 D 的像  $ G = f(D) $ 也是一个区域.

证 首先证明 G 的每一点都是内点. 设  $ \omega_{0} \in G $, 则有一点  $ z_{0} \in D $, 使  $ \omega_{0} = f(z_{0}) $. 要证  $ \omega_{0} $ 为 G 的内点, 只须证明  $ \omega_{*} $ 与  $ \omega_{0} $ 充分接近时,  $ \omega_{*} $ 亦属于 G, 即是说, 只须证明, 当  $ \omega_{*} $ 与  $ \omega_{0} $ 充分接近时, 方程  $ \omega_{*} = f(z) $ 在 D 内有解. 为此, 考查

 $$ f(z)-w_{*}=f(z)-w_{0}+w_{0}-w_{*}, $$

<!-- page: 294 -->

由解析函数零点的孤立性，必有以  $ z_{0} $ 为心的某个圆周 C，C 及 C 的内部全含于 D，使得  $ f(z) - w_{0} $ 在 C 上及 C 的内部（除  $ z_{0} $ 外）均不为零。因而在 C 上  $ |f(z) - w_{0}| \geq \delta > 0 $。对在邻域  $ |w_{*} - w_{0}| < \delta $ 内的点  $ w_{*} $ 及在 C 上的点 z 有

 $$ |f(z)-w_{0}|\geqslant\delta>|w_{*}-w_{0}|. $$ 

因此根据第六章的儒歇定理，在 C 的内部

 $$ \begin{aligned}{f(z)-w_{*}=}&{{}\left[f(z)-w_{0}\right]+w_{0}-w_{*}}\\ {}&{{}f(z)-w_{0}}\\ \end{aligned} $$ 

与

有相同的零点个数.于是 $ w_{*} = f(z) $在D内有解.

其次，要证明 G 中任意两点  $ w_{1}=f(z_{1}) $， $ w_{2}=f(z_{2}) $ 均可以用一条完全含于 G 的折线联结起来。为此，由于 D 是区域，可在 D 内取一条联结  $ z_{1}, z_{2} $ 的折线 C:  $ z=z(t) $  $ [t_{1} \leqslant t \leqslant t_{2}, z(t_{1})=z_{1}, z(t_{2})=z_{2}] $。于是， $ \Gamma: w=f[z(t)] $ ( $ t_{1} \leqslant t \leqslant t_{2} $) 就是联结  $ w_{1} $、 $ w_{2} $ 的并且完全含于 G 的一条曲线。从而，参照柯西积分定理的古莎证明第三步，可以找到一条联结  $ w_{1}, w_{2} $，内接于  $ \Gamma $ 且完全含于 G 的折线  $ \Gamma_{1} $。

总结以上两点，即知  $ G = f(D) $ 是区域.

推论 7.2 设  $ w = f(z) $ 在区域 D 内单叶解析，则 D 的像 G = f(D) 也是一个区域.

证 因  $ f(z) $ 在区域 D 内单叶, 必  $ f(z) $ 在 D 内不恒为常数.

注 定理 7.1 可以推广成这样的形式：“ $ w = f(z) $ 在扩充  $ z $ 平面的区域  $ D $ 内亚纯，且不恒为常数，则  $ D $ 的像  $ G = f(D) $ 为扩充  $ w $ 平面上的区域。”

上一章末,我们证明了单叶解析函数的一个重要性质,定理6.11,其逆不真,但有下面我们引出的另一个定理,局部单叶性,列入本章习题(二)1,让读者自己证明.

定理 7.3 设函数  $ w = f(z) $ 在点  $ z_{0} $ 解析，且  $ f'(z_{0}) \neq 0 $，则  $ f(z) $ 在  $ z_{0} $ 的一个邻域内单叶解析.

<!-- page: 295 -->

由此可见，符合本定理条件的解析变换  $ w = f(z) $ 将  $ z_{0} $ 的一个充分小邻域变成  $ w_{0} = f(z_{0}) $ 的一个曲边邻域。

### 2. 解析变换的保角性——导数的几何意义

设  $ w = f(z) $ 于区域 D 内解析， $ z_{0} \in D $，在点  $ z_{0} $ 有导数  $ f'(z_{0}) \neq 0 $。通过  $ z_{0} $ 任意引一条有向光滑曲线

 $$ C:z=z\left(t\right)\quad\left(t_{0}{\leqslant}t{\leqslant}t_{1}\right), $$ 

 $ z_{0}=z(t_{0}) $. 则必  $ z^{\prime}(t_{0}) $ 存在且  $ z^{\prime}(t_{0})\neq0 $, 从而由第二章习题

(一)1, C 在  $ z_{0} $ 有切线,  $ z^{\prime}(t_{0}) $ 就是切向量, 它的倾角为  $ \psi = \arg z^{\prime}(t_{0}) $. 经过变换  $ \boldsymbol{w} = f(z) $, C 之像曲线  $ \Gamma = f(C) $ 的参数方程应为

 $$ \Gamma:\mathcal{w}=f[z(t)]\quad(t_{0}{\leqslant}t{\leqslant}t_{1}). $$ 

由定理 7.3 及第三章习题(一)13,  $ \Gamma $ 在点  $ w_{0}=w(t_{0}) $ 的邻域内是光滑的。又由于  $ w'(t_{0})=f'(z_{0})z'(t_{0})\neq0 $，故  $ \Gamma $ 在  $ w_{0}=f(z_{0}) $ 也有切线， $ w'(t_{0}) $ 就是切向量，其倾角为

 $$ \Psi=\arg w^{\prime}(t_{0})=\arg f^{\prime}(z_{0})+\arg z^{\prime}(t_{0}), $$ 

即

 $$ \Psi=\psi+\arg f^{\prime}\left(z_{0}\right). $$ 

假设

 $$ f^{\prime}(z_{0})=R\mathrm{e}^{i\alpha}, $$ 

则必

 $$ \mid f^{\prime}(z_{0})\mid=R,\arg f^{\prime}(z_{0})=\alpha, $$ 

于是

$$  \Psi-\psi=\alpha\,,   \tag*{(7.1)}$$

 $$ \lim_{\Delta z\to0}\left|\frac{\Delta w}{\Delta z}\right|=R\neq0. $$ 

且

如果我们假定 x 轴与 u 轴、y 轴与 v 轴的正方向相同（如图7.1），而且将原曲线的切线正方向与变换后像曲线的切线正方向间的夹角，理解为原曲线经过变换后的旋转角，则

(7.1)说明:像曲线  $ \Gamma $ 在点  $ w_{0}=f(z_{0}) $ 的切线正向,可由原像曲线 C 在点  $ z_{0} $ 的切线正向旋转一个角  $ \arg f'(z_{0}) $ 得出.  $ \arg f'(z_{0}) $ 仅与  $ z_{0} $ 有关,而与过  $ z_{0} $ 的曲线 C 的选择无关,称为变换  $ w=f(z) $ 在点  $ z_{0} $ 的旋转角.这也就是导数辐角的几何意义.

<!-- page: 296 -->

<div style="text-align: center;"><img src="images/p0296_img_in_image_box_552_631_3896_1717.jpg" alt="图7.1" width="75%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.1</div> </div>


(7.2)说明:像点间的无穷小距离与原像点间的无穷小距离之比的极限是  $ R = \big|\underbrace{f'(z_0)}_{}\big| $，它仅与  $ z_0 $ 有关，而与过  $ z_0 $ 的曲线 C 之方向无关。称为变换  $ w = f(z) $ 在点  $ z_0 $ 的伸缩率。这也就是导数模的几何意义。

上面提到的旋转角与 C 的选择无关这个性质,称为旋转角不变性;伸缩率与 C 的方向无关这个性质,称为伸缩率不变性.

从几何意义上看: 如果忽略高阶无穷小, 伸缩率不变性就表示  $ w = f(z) $ 将  $ z = z_{0} $ 处的无穷小的圆变成  $ w = w_{0} $ 处的无穷小的圆, 其半径之比为  $ \left| f'(z_{0}) \right| $.

上面的讨论说明: 解析函数在导数不为零的地方具有旋转角不变性和伸缩率不变性.

例 7.1 试求变换  $ w = f(z) = z^{2} + 2z $ 在点  $ z = -1 + 2i $ 处的旋转角，并且说明它将 z 平面的哪一部分放大？哪一部分缩小？

解 因

 $$ f^{\prime}\left(z\right)=2z+2=2\left(z+1\right), $$ 

 $$ f^{\prime}\left(-1+2\mathrm{i}\right)=2\left(-1+2\mathrm{i}+1\right)=4\mathrm{i}, $$ 

故在点  $ -1+2i $ 处的旋转角  $ \arg f'(-1+2i)=\frac{\pi}{2} $.

又因  $ \left|f^{\prime}(z)\right|=2\sqrt{(x+1)^{2}+y^{2}} $，这里  $ z=x+iy $，而  $ \left|f^{\prime}(z)\right|<1 $ 的充要条件是  $ (x+1)^{2}+y^{2}<\frac{1}{4} $，故  $ w=f(z)=z^{2}+2z $ 把以

<!-- page: 297 -->

-1 为心,  $ \frac{1}{2} $ 为半径的圆周内部缩小, 外部放大.

现在，我们再继续上面的讨论.

经点  $ z_{0} $ 的两条有向曲线  $ C_{1} $、 $ C_{2} $ 的切线方向所构成的角，称为两曲线在该点的夹角。今设  $ C_{i}(i=1,2) $ 在点  $ z_{0} $ 的切线倾角为  $ \psi_{i}(i=1,2) $;  $ C_{i} $ 在变换  $ \boldsymbol{w}=\boldsymbol{f}(z) $ 下的像曲线  $ \Gamma_{i} $ 在点  $ \boldsymbol{w}_{0_{i}}=f(z_{0}) $ 的切线倾角为  $ \Psi_{i}(i=1,2) $，则由 (7.1) 有

 $$ \Psi_{1}-\psi_{1}=\alpha\mathrm{~ 及 ~}\Psi_{2}-\psi_{2}=\alpha, $$ 

即有

 $$ \Psi_{1}-\psi_{1}=\Psi_{2}-\psi_{2}, $$ 

所以

 $$ \Psi_{1}-\Psi_{2}=\psi_{1}-\psi_{2}=\delta. $$ 

这里  $ \psi_{1}-\psi_{2} $ 是  $ C_{1} $ 和  $ C_{2} $ 在点  $ z_{0} $ 的夹角（反时针方向为正）， $ \Psi_{1}-\Psi_{2} $ 是  $ \Gamma_{1} $ 和  $ \Gamma_{2} $ 在像点  $ \omega_{0}=f(z_{0}) $ 的夹角（反时针方向为正）。由此可见，这种保角性既保持夹角的大小，又保持夹角的方向（图 7.2）。

<div style="text-align: center;"><img src="images/p0297_img_in_image_box_491_3594_3943_4677.jpg" alt="图 7.2" width="77%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.2</div> </div>


定义 7.1 若函数  $ w = f(z) $ 在点  $ z_{0} $ 的邻域内有定义，且在点  $ z_{0} $ 具有：

（1）伸缩率不变性，

(2) 过  $ z_{0} $ 的任意两曲线的夹角在变换  $ \omega = f(z) $ 下，既保持大小，又保持方向，

<!-- page: 298 -->

则称函数  $ w = f(z) $ 在点  $ z_{0} $ 是保角的，或称  $ w = f(z) $ 在点  $ z_{0} $ 处是保角变换。如果  $ w = f(z) $ 在区域 D 内处处都是保角的，则称  $ w = f(z) $ 在区域 D 内是保角的，或称  $ w = f(z) $ 在区域 D 内是保角变换。

总结以上的讨论，我们得到

定理 7.4 如  $ w = f(z) $ 在区域 D 内解析，则它在导数不为零的点处是保角的.

从而在这些点的各自充分小邻域内也是保角的(何故?).

推论 7.5 如  $ w = f(z) $ 在区域 D 内单叶解析，则 w = f(z) 在 D 内是保角的.

证 因由定理 6.11，在 D 内  $ f'(z) \neq 0 $.

例 7.2 试证： $ w = e^{iz} $ 将互相正交的直线族  $ \mathrm{Re} z = C_{1} $ 与  $ \mathrm{Im} z = C_{2} $ 依次变为互相正交的直线族  $ v = u \tan C_{1} $ 与圆周族

 $$ u^{2}+v^{2}=\mathrm{e}^{-2C_{2}} $$ 

证 正交直线族 Re z = C_{1} 与 Im z = C_{2}

在变换

 $$ w=e^{iz} $$ 

下，有

 $$ u+\mathrm{i}v=\mathrm{~}\omega=\mathrm{e}^{\mathrm{i}z}=\mathrm{e}^{\mathrm{i}\left(C_{1}+\mathrm{i}C_{2}\right)}=\mathrm{e}^{-C_{2}}\mathrm{e}^{\mathrm{i}C_{1}}, $$ 

即有像曲线族

 $$ u^{2}+v^{2}=\mathrm{e}^{-2C_{2}} 与 \ \operatorname{a r c}\tan\frac{v}{u}=C_{1}. $$ 

由于在 z 平面上  $ e^{iz} $ 处处解析，且

 $$ \frac{\mathrm{d}w}{\mathrm{d}z}=\mathrm{i}\mathrm{e}^{\mathrm{i}z}\neq0, $$ 

所以在 w 平面上圆周族

 $$ u^{2}+v^{2}=\mathrm{e}^{-2C_{2}} $$ 

与直线族

 $$ v=u\tan\ C_{1} $$ 

也是互相正交的.

<!-- page: 299 -->

### 3. 单叶解析变换的共形性

定义 7.2 如果  $ w = f(z) $ 在区域 D 内是单叶且保角的，则称此变换  $ w = f(z) $ 在 D 内是共形的，也称它为 D 内的共形映射.

注 解析变换  $ w = f(z) $ 在解析点  $ z_{0} $ 如有  $ f'(z_{0}) \neq 0 $ (由  $ f'(z) $ 在  $ z_{0} $ 的连续性, 必在  $ z_{0} $ 的邻域内  $ \neq 0 $), 于是  $ w = f(z) $ 在点  $ z_{0} $ 保角, 因而在  $ z_{0} $ 的邻域内单叶保角, 从而在  $ z_{0} $ 的邻域内共形 (局部); 在区域 D 内  $ w = f(z) $ (整体) 共形, 必然在 D 内处处 (局部) 共形, 但反过来不必真.

例 7.3 讨论解析函数  $ w = z^{n} $ (n 为正整数) 的保角性和共形性.

解 （1）因为

 $$ \frac{\mathrm{d}w}{\mathrm{d}z}=nz^{n-1}\neq0\quad(z\neq0), $$ 

故  $ w = z^{n} $ 在 z 平面上除原点 z = 0 外，处处都是保角的.

(2) 由于  $ w = z^{n} $ 的单叶性区域是顶点在原点张度不超过  $ \frac{2\pi}{n} $ 的角形区域. 故在此角形区域内  $ w = z^{n} $ 是共形的. 在张度超过  $ \frac{2\pi}{n} $ 的角形区域内, 则不是共形的, 但在其中各点的邻域内是共形的 (由定理 7.3).

定理 7.6 设  $ w = f(z) $ 在区域 D 内单叶解析，则

(1)  $ w = f(z) $ 将 D 共形映射成区域  $ G = f(D) $.

(2) 反函数  $ z = f^{-1}(w) $ 在区域 G 内单叶解析，且

 $$ f^{-1^{\prime}}(w_{0})=\frac{1}{f^{\prime}(z_{0})}\quad(z_{0}\in D,w_{0}=f(z_{0})\in G). $$ 

证 （1）由推论 7.2, G 是区域，由推论 7.5 及定义 7.2,  $ w = f(z) $ 将 D 共形映射成 G.

(2) 由定理 6.11,  $ f'(z_0) \neq 0 (z_0 \in D) $, 又因  $ w = f(z) $ 是 D 到 G 的单叶满变换, 因而是 D 到 G 的一一变换. 于是, 当  $ w \neq w_0 $

<!-- page: 300 -->

时， $ z \neq z_{0} $，即反函数  $ z = f^{-1}(w) $ 在区域 G 内单叶。故

 $$ \frac{f^{-1}(w)-f^{-1}(w_{0})}{w-w_{0}}=\frac{z-z_{0}}{w-w_{0}}=\frac{1}{\frac{w-w_{0}}{z-z_{0}}}. $$ 

由假设  $ f(z)=u(x,y)+iv(x,y) $ 在区域 D 内解析，即在 D 内满足 C.-R. 方程

 $$ u_{x}=v_{y},u_{y}=-v_{x}. $$ 

故

 $$ \begin{array}{r l}{\left|\begin{array}{l l}{u_{x}}&{u_{y}}\\ {v_{x}}&{v_{y}}\end{array}\right|}&{=\left|\begin{array}{l l}{u_{x}}&{-v_{x}}\\ {v_{x}}&{u_{x}}\end{array}\right|=u_{x}^{2}+v_{x}^{2}}\\ &{=\mid u_{x}+\mathrm{i}v_{x}\mid^{2}=\mid f^{\prime}(z)\mid^{2}\neq0,\quad(z\in D)}\end{array} $$ 

由数学分析中隐函数存在定理，存在两个函数

 $$ x=x\left(u,v\right),y=y\left(u,v\right) $$ 

在点  $ w_{0}=u_{0}+i v_{0} $ 及其一个邻域  $ N_{\varepsilon}(w_{0}) $ 内为连续. 即在邻域  $ N_{\varepsilon}(w_{0}) $ 中，当  $ w\to w_{0} $ 时，必有  $ z=f^{-1}(w)\to z_{0}=f^{-1}(w_{0}) $.

故

 $$ \begin{aligned}&\lim_{w\to w_{0}}\frac{f^{-1}(w)-f^{-1}(w_{0})}{w-w_{0}}=\frac{1}{}\\\overset{=}{}&=\frac{1}{\lim\limits_{z\to z_{0}}\frac{f(z)-f(z_{0})}{z-z_{0}}}=\frac{1}{f^{\prime}(z_{0})}.\end{aligned} $$ 

即

 $$ f^{-1^{\prime}}(\mathcal{w}_{0})=\frac{1}{f^{\prime}(z_{0})}\quad(z_{0}\in D,\mathcal{w}_{0}=f(z_{0})\in G). $$ 

由于  $ w_{0} $ 或  $ z_{0} $ 的任意性，即知  $ z = f^{-1}(w) $ 在区域 G 内解析.

注 D. Menchoff 曾经证明本定理 (1) 款之逆亦真. 即“如  $ w = f(z) $ 将区域 D 共形映射成区域 G, 则  $ w = f(z) $ 在 D 内单叶解析.”其证明可见 D. Menchoff, Les conditions de monogénéité (单演性条件), 巴黎, 1936, 39 页及以后.

由此可见，如  $ w = f(z) $ 将区域 D 共形映射成区域  $ G = f(D) $，则其反函数  $ z = f^{-1}(w) $ 将区域 G 共形映射成区域 D。这时，区域

<!-- page: 301 -->

D 内的一个无穷小曲边三角形  $ \delta $ 变换成区域 G 内的一个无穷小曲边三角形  $ \triangle $（如图 7.3）；由于保持了曲线间的夹角大小及方向，故  $ \delta $ 与  $ \triangle $ “相似”。这就是共形映射这一名称的由来。

<div style="text-align: center;"><img src="images/p0301_img_in_image_box_662_1166_3766_2213.jpg" alt="图7.3" width="69%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.3</div> </div>


共形映射理论的基本任务是，给定一个区域 D 及另一个区域 G，要求找出将 D 共形映射成 G 的函数  $ f(z) $ 以及惟一性条件。共形映射的这种一般理论，我们将放到本章 §4 叙述。

显然，两个共形映射的复合仍然是一个共形映射。具体地说，如  $ \xi = f(z) $ 将区域 D 共形映射成区域 E，而  $ w = h(\xi) $ 将 E 共形映射成区域 G，则  $ w = h[f(z)] $ 将区域 D 共形映射成区域 G。利用这一事实，可以复合若干基本的共形映射而构成较为复杂的共形映射。

下面§2及§3研究分式线性变换和由某些初等函数构成的函数的共形性.它们在共形映射中都是很基本的.

#### §2. 分式线性变换

### 1. 分式线性变换及其分解

$$  w=\frac{az+b}{cz+d},\left|\begin{array}{cc}a&b\\c&d\end{array}\right|=ad-bc\neq0   \tag*{(7.3)}$$

称为分式线性变换.简记为  $ w = L(z) $.

<!-- page: 302 -->

条件  $ ad - bc \neq 0 $ 是必要的，否则将导致  $ L(z) $ 恒为常数.

此外，我们将(7.3)式在扩充 z 平面上加以如下补充定义：

如  $ c \neq 0 $，在  $ z = -\frac{d}{c} $ 处定义  $ \omega = \infty $，在  $ z = \infty $ 处定义  $ \omega = \frac{a}{c} $；

如 c = 0，在  $ z = \infty $ 处定义  $ \omega = \infty $。

这样，我们总认为分式线性变换  $ w = L(z) $ 是定义在整个扩充 z 平面上的. 变换 (7.3) 将扩充 z 平面一一地因而单叶地变成扩充 w 平面. 事实上，(7.3) 具有逆变换

$$  z=\frac{-d w+b}{c w-a}.   \tag*{(7.4)}$$

根据定理 7.1 的注，分式线性变换 (7.3) 在扩充 z 平面上是保域的.

注 分式线性变换(7.3)由德国数学家莫比乌斯(Möbius)作过大量的研究.在许多文献中,它就称为莫比乌斯变换.

分式线性变换(7.3)总可以分解成下述简单类型变换的复合：

（Ⅰ） $ w = kz + h $  $ (k \neq 0) $，

（Ⅱ） $ w=\frac{1}{z} $

事实上，当 c=0 时，(7.3) 已经是 (I) 型变换

 $$ w=\frac{a}{d}z+\frac{b}{d}; $$ 

当  $ c \neq 0 $ 时，(7.3)式可改写为

$$  w=\frac{a}{c}+\frac{bc-ad}{c(cz+d)}=\frac{bc-ad}{c}\cdot\frac{1}{cz+d}+\frac{a}{c},   \tag*{(7.3)  ^{\prime} }$$

它就是下面三个形如(Ⅰ.)和(Ⅱ)的变换

 $$ \begin{array}{l}\xi=cz+d,\eta=\frac{1}{\xi},\\w=\frac{bc-ad}{c}\eta+\frac{a}{c}\end{array} $$ 

的复合.

因此，弄清楚(Ⅰ)，(Ⅱ)型变换的几何性质，就可弄清楚一般

<!-- page: 303 -->

分式线性变换(7.3)的性质.

下面，我们来考察（Ⅰ）和（Ⅱ）型变换的几何意义.

（Ⅰ）型变换  $ w = kz + h $ ( $ k \neq 0 $) 可称为整线性变换。如果  $ k = \rho e^{ia} (\rho > 0, \alpha $ 为实数)，则

 $$ w=\rho\mathrm{e}^{i\alpha}z+h, $$ 

由此可见，此变换可以分解成三个更简单的变换：旋转、伸缩和平

移.也就是先将z旋转角度 $ \alpha $，然后作一个以原点为中心的伸缩变换（按比例系数 $ \rho $），最后平移一个向量 $ h $（如图7.4，此图是将原像与像画在同一平面上）。即是说，在整线性变换之下，原像与像相似。不过，这种变换不是任意的相似变换，而是不改变图形方向的相似变换（如图7.4，原像那个三角形的顶点顺

<div style="text-align: center;"><img src="images/p0303_img_in_image_box_2389_1776_3980_3079.jpg" alt="图7.4" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.4</div> </div>


序如果是反时针方向的，则其像三角形的像顶点顺序也应是反时针方向的).

（Ⅱ）型变换  $ w = \frac{1}{z} $ 可称为反演变换. 它可分解为下面两个更简单变换的复合：

$$  \begin{array}{c}\omega=\frac{1}{\overline{z}},\\\omega=\overline{\omega}.\end{array}   \tag*{(7.5)}$$

前者称为关于单位圆周的对称变换，并称 z 与  $ \omega $ 是关于单位圆周的对称点。后者称为关于实轴的对称变换，并称  $ \omega $ 与  $ \omega $ 是关于实轴的对称点。

已知点 z，可用如图 7.5 的几何方法作出  $ \omega = \frac{1}{\overline{z}} $，然后就可作出  $ \omega = \overline{\omega} = \frac{1}{z} $（如图 7.5，此图也是将像与原像画在同一平面上）.

<!-- page: 304 -->

由图 7.5 可知，直角三角形  $ OzA $ 与直角三角形  $ OA\omega $ 相似. 于是

 $$ \frac{1}{\left\lceil\omega\right\rceil}=\frac{\left|z\right|}{1}, $$ 

从而

 $ \left|\omega\right|\left|z\right|=1^{2} $（即等于半径平方），

并且  $ \omega $、z 都在过单位圆圆心 O 的同一条射线上，这就是  $ \omega $、z 关于单位圆周对称的性质.

<div style="text-align: center;"><img src="images/p0304_img_in_image_box_2498_780_3994_2012.jpg" alt="图7.5" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.5</div> </div>


另外，我们还规定圆心 O 与点  $ \infty $ 为关于单位圆周的对称点.

例 7.4 试证: 除恒等变换  $ w = z $ 之外, 一切分式线性变换 (7.3) 恒有两个相异的或一个二重的不动点 (即自己变成自己的点).

证 分式线性变换

$$  w=\frac{az+b}{cz+d}\quad(ad-bc\neq0)   \tag*{(7.3)}$$

的不动点一定适合方程

 $$ \begin{aligned}z&=\frac{az+b}{cz+d},\\cz^{2}+(d-a)z-b&=0.\end{aligned} $$ 

即

如果(7.7)的系数全为零，则(7.3)就成为恒等变换 w = z. 故(7.7)的系数不能全为零.

（1）若  $ c \neq 0 $，则(7.7)有两个根

 $$ z_{1,2}=\frac{a-d\pm\sqrt{\Delta}}{2c},\Delta=(a-d)^{2}+4b c, $$ 

当  $ \Delta\neq0 $ 时，(7.3) 有两个相异的不动点  $ z_{1} $ 和  $ z_{2} $.

当  $ \Delta=0 $ 时，(7.3) 有一个二重不动点  $ z=\frac{a-d}{2c} $.

（2）若 c=0. 这时 (7.7) 成为  $ (d-a)z-b=0 $.

<!-- page: 305 -->

当  $ a \neq d \neq 0 $ 时，(7.7)有根  $ z = \frac{b}{d - a} $.

这时(7.3)成为

 $$ w=\frac{a}{d}z+\frac{b}{d}, $$ 

所以这时(7.3)有不动点  $ z=\frac{b}{d-a} $ 和  $ z=\infty $.

当  $ a = d \neq 0 $ 时，必  $ b \neq 0 $ 。不动点

 $$ z=\frac{b}{d-a}=\infty. $$ 

故这时(7.3)以  $ z = \infty $ 为二重不动点.

本段最后,我们要说:分式线性变换的复合仍然是分式线性变换.

2. 分式线性变换的共形性 为了证明分式线性变换(7.3)在扩充 z 平面上是共形的,我们只要证明(Ⅰ)和(Ⅱ)型变换在扩充 z 平面上是保角的,因为(7.3)在扩充 z 平面上是单叶的.

对于(Ⅱ)型变换  $ \omega = \frac{1}{z} $ 来说，只要  $ z \neq 0, z \neq \infty $，则有

 $$ \frac{\mathrm{d}w}{\mathrm{d}z}=-\frac{1}{z^{2}}\neq0, $$ 

根据定理 7.4, 即知在  $ z \neq 0 $,  $ z \neq \infty $ 的各处是保角的. 至于在 z = 0 及  $ z = \infty $ 处, 就涉及到我们如何理解两条曲线在无穷远点处交角的意义.

由于第五章 §3 对无穷远点情形的讨论，启发我们有

定义 7.3 二曲线在无穷远点处的交角为  $ \alpha $，就是指它们在反演变换下的像曲线在原点处的交角为  $ \alpha $。

按照这样的定义，(Ⅱ)型变换  $ w = \frac{1}{z} $ 在 z = 0 及 z =  $ \infty $ 处是保角的.

因而(Ⅱ)型变换在扩充z平面上是保角的.

下面我们来看(Ⅰ)型变换

<!-- page: 306 -->

$$ w=kz+h(k\neq0) $$ 

在扩充 z 平面上的保角性.

因为

 $$ \frac{\mathrm{d}w}{\mathrm{d}z}=k\neq0, $$ 

根据定理 7.4, 即知在  $ z \neq \infty $ 的各处是保角的.

要证(Ⅰ)型变换在  $ z = \infty $ (像点为  $ \omega = \infty $) 保角，由定义 7.3，我们引入两个反演变换：

 $$ \lambda=\frac{1}{z},\qquad\mu=\frac{1}{w}. $$ 

它们分别将 z 平面的无穷远点保角变换为  $ \lambda $ 平面的原点；将 w 平面的无穷远点保角变换为  $ \mu $ 平面的原点。现将它们代入(Ⅰ)型变换得

 $$ \frac{1}{\mu}=k\frac{1}{\lambda}+h, $$ 

即

$$  \mu=\frac{\lambda}{h\lambda+k},   \tag*{(7.8)}$$

它将  $ \lambda $ 平面的原点  $ \lambda = 0 $ 变为  $ \mu $ 平面的原点  $ \mu = 0 $.

而

 $$ \frac{\mathrm{d}\mu}{\mathrm{d}\lambda}=\frac{h\lambda+k-h\lambda}{\left(h\lambda+k\right)^{2}}\bigg|_{\lambda=0}=\frac{k}{k^{2}}=\frac{1}{k}\neq0. $$ 

故变换(7.8)在  $ \lambda=0 $ 是保角的.

于是(Ⅰ)型变换在  $ z = \infty $ 是保角的，因而在扩充 z 平面上是保角的.

这样，我们就证明了

定理 7.7 分式线性变换(7.3)在扩充 z 平面上是共形的.

注 在无穷远点处不考虑伸缩率的不变性.

定义 7.4 扩充平面上有顺序的四个相异点  $ z_{1}, z_{2}, z_{3}, z_{4} $ 构

3. 分式线性变换的保交比性

<!-- page: 307 -->

成下面的量,称为它们 $ ^{的} $交比,记为 $ (z_{1},z_{2},z_{3},z_{4}) $:

 $$ \left(\mathcal{z}_{1},\mathcal{z}_{2},\mathcal{z}_{3},\mathcal{z}_{4}\right)=\frac{\mathcal{z}_{4}-\mathcal{z}_{1}}{\mathcal{z}_{4}-\mathcal{z}_{2}}:\frac{\mathcal{z}_{3}-\mathcal{z}_{1}}{\mathcal{z}_{3}-\mathcal{z}_{2}}. $$ 

当四点中有一点为 $ \infty $时，应将包含此点的项用1代替.例如 $ z_{1}=\infty $时，即有

 $$ (\infty,z_{2},z_{3},z_{4})=\frac{1}{z_{4}-z_{2}}:\frac{1}{z_{3}-z_{2}}, $$ 

亦即先视  $ z_{1} $ 为有限，再令  $ z_{1} \rightarrow \infty $ 取极限而得.

定理 7.8 在分式线性变换下, 四点的交比不变.

证 设

 $$ w_{i}=\frac{az_{i}+b}{cz_{i}+d},i=1,2,3,4, $$ 

则

$$  w_{i}-w_{j}=\frac{(a d-b c)(z_{i}-z_{j})}{(c z_{i}+d)(c z_{j}+d)},   \tag*{(7.9)}$$

因此

 $$ \begin{align*}&\left(w_{1},w_{2},w_{3},w_{4}\right)=\frac{w_{4}-w_{1}}{w_{4}-w_{2}}:\frac{w_{3}-w_{1}}{w_{3}-w_{2}}\\&\underbrace{(7.9)}_{\substack{\mathcal{Z}_{4}-\\ \mathcal{Z}_{4}-\\ \mathcal{Z}_{2}}},\underbrace{z_{4}-z_{1}}_{\substack{\mathcal{Z}_{4}-\\ \mathcal{Z}_{2}}}:\frac{z_{3}-z_{1}}{z_{3}-z_{2}}=\left(z_{1},z_{2},z_{3},z_{4}\right).\end{align*} $$ 

其他可能情形的证明留给读者.

从形式上看，分式线性变换(7.3)具有四个复参数 a, b, c, d。但由条件  $ ad - bc \neq 0 $，可知至少有一不为零，因此就可用它去除(7.3)的分子及分母，于是(7.3)实际上就只依赖于三个复参数（即六个实参数）。

为了确定这三个复参数，由定理 7.8 可知，只须任意指定三对对应点：

 $$ z_{i}\xleftarrow{w=L\left(z\right)}w_{i}\quad\left(i=1,2,3\right) $$ 

即可. 因从

<!-- page: 308 -->

$$ (\omega_{1},\omega_{2},\omega_{3},\omega)=(\boldsymbol{z}_{1},\boldsymbol{z}_{2},\boldsymbol{z}_{3},\boldsymbol{z}) $$ 

就可得到变换(7.3)，即  $ w = L(z) $. 其中 a, b, c, d 就可由  $ z_{i} $ 及  $ w_{i}(i=1,2,3) $ 来确定，且除了相差一个常数因子外是惟一的.

这就证明了：

定理 7.9 设分式线性变换将扩充 z 平面上三个相异点  $ z_{1} $， $ z_{2} $， $ z_{3} $ 指定变为  $ w_{1} $， $ w_{2} $， $ w_{3} $，则此分式线性变换就被唯一确定，并且可以写成

$$  \frac{\mathcal{W}-\mathcal{W}_{1}}{\mathcal{W}-\mathcal{W}_{2}}:\frac{\mathcal{W}_{3}-\mathcal{W}_{1}}{\mathcal{W}_{3}-\mathcal{W}_{2}}=\frac{\mathcal{Z}-\mathcal{Z}_{1}}{\mathcal{Z}-\mathcal{Z}_{2}}:\frac{\mathcal{Z}_{3}-\mathcal{Z}_{1}}{\mathcal{Z}_{3}-\mathcal{Z}_{2}}   \tag*{(7.10)}$$

（即三对对应点惟一确定一个分式线性变换）.

例 7.5 求将 2, i, -2 对应地变成 -1, i, 1 的分式线性变换.

解 所求分式线性变换为

 $$ \left(-1,i,1,\mathcal{w}\right)=\left(2,i,-2,z\right), $$ 

即

 $$ \frac{w+1}{w-i}:\frac{1+1}{1-i}=\frac{z-2}{z-i}:\frac{-2-2}{-2-i}, $$ 

化简为

 $$ \frac{w+1}{w-i}=\frac{1+3i}{4}\cdot\frac{z-2}{z-i}, $$ 

于是

 $$ \frac{w+1}{w+1-w+i}=\frac{(1+3i)(z-2)}{(1+3i)(z-2)-4(z-i)}, $$ 

化简后得

 $$ w=\frac{z-6\mathrm{i}}{3\mathrm{i}z-2}. $$ 

4. 分式线性变换的保圆周(圆)性 形如(Ⅰ)的整线性变换，显然将圆周(直线)变为圆周(直线)，这可由变换(Ⅰ)的几何意义得知.

形如（Ⅱ）的反演变换将圆周（直线）变为圆周或直线.事实上，圆周或直线可表为（见第一章习题（一）8）

$$  \begin{aligned}&\boldsymbol{A}z\overline{z}+\bar{\beta}z+\beta\overline{z}+\boldsymbol{C}=\boldsymbol{0},\\&(\boldsymbol{A},\boldsymbol{C} 为实数 ,|\beta|^{2}>\boldsymbol{A}\boldsymbol{C})\end{aligned}   \tag*{(7.11)}$$

当 A=0 时就表直线. 经过反演变换  $ \omega=\frac{1}{z} $，(7.11)成为

<!-- page: 309 -->

$$ C\bar{\tau}\bar{\tau}\bar{\omega}+\bar{\beta}\bar{\tau}\bar{\omega}+\beta\bar{\tau}\bar{\omega}+A=0, $$ 

它表示直线或圆周（视 C 是否为零而定）.

因为分式线性变换(7.3)是几个(Ⅰ)和(Ⅱ)型变换的复合,这样,我们就证明了

定理 7.10 分式线性变换将平面上的圆周（直线）变为圆周或直线.

注 在扩充平面上, 直线可视为经过无穷远点的圆周. 事实上, (7.11) 可改写为

 $$ A+\frac{\overline{\beta}}{\overline{z}}+\frac{\beta}{z}+\frac{C}{z\overline{z}}=0, $$ 

欲其经过 $ \infty $，必须且只须 A = 0。因此可以说： $ \uwave{\text{在分式线性变换(7.3)下，扩充z平面上的圆周周变为扩充w平面上的圆周}} $，同时，圆被保形变换成圆。

这就是分式线性变换的保圆周(圆)性.

设  $ w = L(z) $ 是一分式线性变换， $ \gamma $ 为扩充 z 平面上的一个圆周，则  $ \Gamma = L(\gamma) $ 是扩充 w 平面上的一个圆周。由于扩充平面被圆周划分为两个区域，如  $ \gamma $ 分扩充 z 平面为区域  $ d_{1}, d_{2} $； $ \Gamma $ 分扩充 w 平面为  $ D_{1}, D_{2} $，则我们可以断定  $ d_{1} $ 的像必然是  $ D_{1} $ 和  $ D_{2} $ 中的一个，而  $ d_{2} $ 的像是  $ D_{1} $ 和  $ D_{2} $ 中的另一个。为了确定对应的区域，有两个办法：其一是，在一区域，例如  $ d_{1} $ 中，取一点  $ z_{0} $，如  $ w_{0} = L(z_{0}) \in D_{1} $，则可以断定  $ D_{1} = L(d_{1}) $；否则， $ D_{2} = L(d_{1}) $。另一办法是，在  $ \gamma $ 上任取三点  $ z_{1}, z_{2}, z_{3} $，使沿  $ z_{1}, z_{2}, z_{3} $ 绕行  $ \gamma $ 时， $ d_{1} $ 在观察者的左方，沿对应的  $ w_{1}, w_{2}, w_{3} $ 绕行  $ \Gamma $ 时，在观察者左方的那个区域就是  $ d_{1} $ 的像，其理由如下：过  $ z_{1} $ 作  $ \gamma $ 的一段法线 n，使 n 含于  $ d_{1} $（图 7.6），于是顺着  $ z_{1}, z_{2}, z_{3} $ 看，n 在观察者左方。n 的像 N = L(n) 是过  $ w_{1} $ 并与  $ \Gamma $ 正交的一段圆弧（或直线段），由于在  $ z_{1} $ 的保角性，顺着  $ w_{1}, w_{2}, w_{3} $ 看，N 也应当在观察者的左方。因此，在  $ w_{1}, w_{2}, w_{3} $ 左方的那个区域就是  $ d_{1} $ 的像。

<!-- page: 310 -->

<div style="text-align: center;"><img src="images/p0310_img_in_image_box_594_619_3806_1956.jpg" alt="图7.6" width="72%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.6</div> </div>


反之，在扩充平面上给定区域 d 及 D，其边界都是圆周，则 d 必然可以共形映射成 D。分式线性变换就能实现，且在一定条件下，这种分式线性变换还是惟一的。

注 （1）当  $ \gamma $ 或  $ \Gamma = L(\gamma) $ 为直线时，其所界的圆是以它为边界的两个半平面；

（2）要使分式线性变换  $ w = L(z) $ 把有限圆周 C 变成直线，其条件是：C 上的某点  $ z_{0} $ 变成  $ \infty $.

5. 分式线性变换的保对称点性 在第一段中, 我们曾经讲过关于单位圆周的对称点这一概念, 现推广如下:

定义 7.5  $ z_{1}, z_{2} $ 关于圆周  $ \dot{\gamma}: |z - a| = R $ 对称是指  $ z_{1}, z_{2} $ 都在过圆心 a 的同一条射线上，且合

$$  \left|z_{1}-a\right|\mid z_{2}-a\mid=R^{2}.   \tag*{(7.6)'}$$

此外，还规定圆心 a 与点  $ \infty $ 也是关于  $ \gamma $ 为对称的（如图 7.7）.

由定义即知, $ z_{1},z_{2} $关于圆周 $ \gamma:|z-a|=R $对称,必须且只须

$$  z_{2\cdot}-a=\frac{R^{2}}{z_{1}-a}.   \tag*{(7.5)'}$$

下述定理从几何方面说明了对称点的特性.

<!-- page: 311 -->

<div style="text-align: center;"><img src="images/p0311_img_in_image_box_615_716_1959_1736.jpg" alt="图7.7" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.7</div> </div>


<div style="text-align: center;"><img src="images/p0311_img_in_image_box_2387_625_3890_1694.jpg" alt="图7.8" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.8</div> </div>


定理 7.11 扩充 z 平面上两点  $ z_{1}, z_{2} $ 关于圆周  $ \gamma $ 对称的充要条件是，通过  $ z_{1}, z_{2} $ 的任意圆周都与  $ \gamma $ 正交.

证 当  $ \gamma $ 为直线的情形, 定理的正确性是很明显的. 我们只就  $ \gamma $ 为有限圆周  $ \left|z - a\right| = R $ 的情形予以证明(图 7.8).

必要性 设  $ z_{1}, z_{2} $ 关于圆周  $ \gamma: |z - a| = R $ 对称. 则过  $ z_{1}, z_{2} $ 的直线必然与  $ \gamma $ 正交 (按对称点的定义,  $ z_{1}, z_{2} $ 在从 a 出发的同一条射线上).

设  $ \delta $ 是过  $ z_{1}, z_{2} $ 的任一圆周（非直线），由 a 引  $ \delta $ 的切线  $ a\zeta, \zeta $ 为切点。由平面几何的定理得

 $$ \mid\zeta-a\mid^{2}=\mid z_{1}-a\mid\mid z_{2}-a\mid. $$ 

但由  $ z_{1}, z_{2} $ 关于圆周  $ \gamma $ 对称的定义，有

 $$ \left|z_{1}-a\right|\mid z_{2}-a\mid=R^{2}. $$ 

所以

 $$ \mid\zeta-a\mid=R. $$ 

即是说  $ \alpha\zeta $ 是圆周  $ \gamma $ 的半径. 因此  $ \delta $ 与  $ \gamma $ 正交.

充分性 设过  $ z_{1}, z_{2} $ 的每一圆周都与  $ \gamma $ 正交. 过  $ z_{1}, z_{2} $ 作一圆周 (非直线)  $ \delta $, 则  $ \delta $ 与  $ \gamma $ 正交. 设交点之一为  $ \zeta $, 则  $ \gamma $ 的半径  $ \alpha\zeta $ 必为  $ \delta $ 的切线.

联结  $ z_{1}, z_{2} $，延长后必经过 a（因为过  $ z_{1}, z_{2} $ 的直线与  $ \gamma $ 正交）。于是  $ z_{1}, z_{2} $ 在从 a 出发的同一条射线上，并且由平面几何的定理得

<!-- page: 312 -->

$$ \boldsymbol{R}^{2}=\left|\mathrm{\boldmath~\zeta-a~}\right|^{2}=\left|\mathrm{\boldmath~z_{1}-a~}\right|\left|\mathrm{\boldmath~z_{2}-a~}\right|. $$ 

因此， $ z_{1}, z_{2} $ 关于圆周  $ \gamma $ 对称.

下述定理就是分式线性变换的保对称点性.

定理 7.12 设扩充 z 平面上两点  $ z_{1}, z_{2} $ 关于圆周  $ \gamma $ 对称， $ w = L(z) $ 为一分式线性变换，则  $ w_{1} = L(z_{1}), w_{2} = L(z_{2}) $ 两点关于圆周  $ \Gamma = L(\gamma) $ 为对称.

证 设  $ \Delta $ 是扩充 w 平面上经过  $ w_{1}, w_{2} $ 的任意圆周. 此时, 必然存在一个圆周  $ \delta $, 它经过  $ z_{1}, z_{2} $, 并使  $ \Delta = L(\delta) $. 因为  $ z_{1}, z_{2} $ 关于  $ \gamma $ 对称, 故由定理 7.11,  $ \delta $ 与  $ \gamma $ 正交. 由于分式线性变换  $ w = L(z) $ 的保角性,  $ \Delta = L(\delta) $ 与  $ \Gamma = L(\gamma) $ 亦正交. 这样, 再由定理 7.11 即知  $ w_{1}, w_{2} $ 关于  $ \Gamma = L(\gamma) $ 对称.

6. 分式线性变换的应用 分式线性变换在处理边界为圆弧或直线的区域的变换中, 具有很大的作用.

下面三例就是反映这个事实的重要特例：

例 7.6 把上半 z 平面共形映射成上半 w 平面的分式线性变换可以写成

 $$ w=\frac{az+b}{cz+d}, $$ 

其中 a, b, c, d 是实数，且满足条件

$$  ad-bc>0.   \tag*{(7.12)}$$

事实上，所述变换将实轴变为实轴，且当 z 为实数时

 $$ \frac{\mathrm{d}w}{\mathrm{d}z}=\frac{ad-bc}{\left(cz+d\right)^{2}}>0, $$ 

即实轴变成实轴是同向的（如图 7.9），因此上半 z 平面共形映射成上半 w 平面.

当然，这也可以直接由下面的推导看出：

 $$ \begin{aligned}\operatorname{Im}\ w&=\frac{1}{2\mathrm{i}}(\overline{w-\overline{w}})=\frac{1}{2\mathrm{i}}\left(\frac{az+b}{cz+d}-\frac{a\overline{z}+b}{c\overline{z}+d}\right)\\&=\frac{1}{2\mathrm{i}}\frac{ad-bc}{\mid cz+d\mid^{2}}(z-\frac{\cdot}{z})=\frac{ad\cdot bc}{\mid cz+d\mid^{2}}\operatorname{Im}z.\end{aligned} $$

<!-- page: 313 -->

<div style="text-align: center;"><img src="images/p0313_img_in_image_box_854_573_3566_1577.jpg" alt="图7.9" width="61%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.9</div> </div>


注 满足条件(7.12)的分式线性变换也将下半平面共形映射成下半平面.

例 7.7 求出将上半平面  $ \mathrm{Im} z > 0 $ 共形映射成单位圆  $ |w| < 1 $ 的分式线性变换，并使上半平面一点  $ z = a (\mathrm{Im} a > 0) $ 变为 w = 0.

解 根据分式线性变换保对称点的性质，点  $ a $ 关于实轴的对称点  $ \bar{a} $ 应该变到 w = 0 关于单位圆周的对称点  $ w = \infty $。因此，这个变换应当具有形式：

$$  \begin{array}{r}{\omega=k\frac{z-a}{z-\bar{a}},}\end{array}   \tag*{(7.13)  ^{\prime} }$$

其中 k 是常数. k 的确定, 可使实轴上的一点, 例如 z = 0, 变到单位圆周上的一点

 $$ w=k\frac{a}{\overline{a}}. $$ 

因此

 $$ 1=\left|k\right|\left|\frac{a}{\overline{a}}\right|=\left|k\right|. $$ 

所以,可以令  $ k = e^{i\beta} $ ( $ \beta $ 是实数),最后得到所要求的变换为

$$  \begin{array}{r}{\mathcal{w}=\acute{\mathrm{e}}^{\mathrm{i}\beta}\frac{z-a}{z-\overline{a}}(\mathrm{I m}\ a>0).}\end{array}   \tag*{(7.13)}$$

在变换(7.13)中，即使 a 给定了，还有一个实参数  $ \beta $ 需要确定。为了确定此  $ \beta $，或者指出实轴上一点与单位圆周上某点的对应关系，或者指出变换在 z = a 处的旋转角  $ \arg w'(a) $。（读者可以验

<!-- page: 314 -->

证，变换(7.13)在 z = a 处的旋转角  $ \arg w'(a) = \beta - \frac{\pi}{2} $.

由(7.13)可见，同心圆周族 $ |w|=k(k<1) $的原像是圆周族

 $$ \left|\frac{z-a}{z-\bar{a}}\right|=k, $$ 

这是上半 z 平面内以  $ a $、 $ \bar{a} $ 为对称点的圆周族，又根据保对称性可知，单位圆  $ |w| < 1 $ 内的直径的原像是过  $ a $、 $ \bar{a} $ 的圆周在上半 z 平面内的半圆弧。

例 7.8 求出将单位圆  $ \left|z\right|<1 $ 共形映射成单位圆  $ \left|w\right|<1 $ 的分式线性变换，并使一点  $ z=a\left(\left|a\right|<1\right) $ 变到 w=0.

解 根据分式线性变换保对称点的性质，点  $ a $（不妨假设  $ a \neq 0 $）关于单位圆周  $ |z| = 1 $ 的对称点  $ a^* = \frac{1}{\bar{a}} $，应该变成  $ w = 0 $ 关于单位圆周  $ |w| = 1 $ 的对称点  $ w = \infty $，因此所求变换具有形式

$$  \omega=k\frac{z-a}{z-\frac{1}{\overline{a}}},   \tag*{(7.14)  ^{\prime} }$$

整理后得

 $$ \omega=k_{1}\frac{z-a}{1-\bar{a}z}, $$ 

其中  $ k_{1} $ 是常数. 选择  $ k_{1} $，使得 z=1 变成单位圆周  $ \left|w\right|=1 $ 上的点，于是

 $$ \left|k_{1}\frac{1-a}{1-\bar{a}}\right|=1, $$ 

即  $ \left|k_{1}\right|=1 $，因此可令  $ k_{1}=\mathrm{e}^{\mathrm{i}\beta} $ ( $ \beta $ 是实数)，最后得到所求的变换为

$$  \begin{array}{c}w=\mathrm{e}^{\mathrm{i}\beta}\frac{z-a}{1-\overline{a}z}(|a|<1).\end{array}   \tag*{(7.14)}$$

 $ \beta $ 的确定还要求附加条件，如像例 7.7 中所说过的类似。（读者可以验证，对于变换(7.14)，有  $ \arg w'(a) = \beta $.）

由(7.14)可见，同心圆周族 $ \left|w\right|=k(k<1) $的原像是

<!-- page: 315 -->

$$ \left|\frac{z-a}{1-\bar{a}z}\right|=k, $$ 

这是 z 平面上单位圆内以  $ a, \frac{1}{a} $ 为对称点的圆周族：

 $$ \left|\frac{z-a}{z-\frac{1}{\overline{a}}}\right|=|a|\cdot k. $$ 

而单位圆  $ \left|w\right|<1 $ 内的直径的原像是过  $ a $ 与  $ \frac{1}{a} $ 两点的圆周在单位圆  $ \left|z\right|<1 $ 内的圆弧.

注 上两例我们见到的分式线性变换  $ w = L(z) $ 的惟一性条件是下列两种形式：

（1） $ L(a)=b $（一对内点对应），再加一对边界点对应.

(2)  $ L(a) = b $ (一对内点对应),  $ \arg L'(a) = \alpha $ (即在点 a 处的旋转角固定).

思考题 （1）求将上半平面  $ \mathrm{Im}\ z>0 $ 共形映射成下半平面  $ \mathrm{Im}\ w<0 $ 的分式线性变换，条件(7.12)应怎样修改？

(2) 求将上半平面  $ \mathrm{Im}\ z>0 $ 共形映射成单位圆周外部  $ |w|>1 $ 的分式线性变换，(7.13) 括弧中的条件应作怎样修改？

（3）求将单位圆  $ \left|z\right| < 1 $ 共形映射成单位圆周外部  $ \left|w\right| > 1 $ 的分式线性变换，(7.14)括弧中的条件应作怎样修改？

例 7.9 求将上半 z 平面共形映射成上半 w 平面的分式线性变换  $ w = L(z) $，使符合条件：

 $$ 1+\mathrm{i}=L\left(\mathrm{i}\right),\quad0=L\left(0\right). $$ 

解 设所求分式线性变换  $ w = L(z) $ 为

 $$ w=\frac{az+b}{cz+d}, $$ 

其中 a, b, c, d 都是实数, ad - bc > 0.

由于  $ 0 = L(0) $，必 b = 0，因而  $ a \neq 0 $。用 a 除分子分母，则  $ w = L(z) $ 变形为

<!-- page: 316 -->

$$ w=\frac{z}{e z+f}, $$ 

其中  $ e=\frac{c}{a} $， $ f=\frac{d}{a} $ 都是实数，

再由第一个条件得

 $$ 1+\mathrm{i}=\frac{\mathrm{i}}{e\mathrm{i}+f}, $$ 

即

 $$ (f-e)+\mathrm{i}(f+e)=\mathrm{i}, $$ 

所以

 $$ f-e=0,f+e=1, $$ 

解之得

 $$ f=e=\frac{1}{2}, $$ 

故所求的分式线性变换为

 $$ w=\frac{z}{\frac{1}{2}z+\frac{1}{2}}, 即 w=\frac{2z}{z+1}. $$ 

例 7.10 求将上半 z 平面共形映射成圆  $ \left|w - w_{0}\right| < R $ 的分式线性变换  $ w = L(z) $，使符合条件

 $$ L\left(\mathrm{i}\right)=w_{0},L^{\prime}\left(\mathrm{i}\right)>0. $$ 

解 作分式线性变换

 $$ \xi=\frac{w-w_{0}}{R} $$ 

将圆  $ \left|w-w_{0}\right|<R $ 共形映射成单位圆  $ \left|\xi\right|<1 $.

其次，作出上半平面  $ \mathrm{Im} z > 0 $ 到单位圆  $ \left|\xi\right| < 1 $ 的共形映射，使 z = i 变成  $ \xi = 0 $，此分式线性变换为（如图 7.10）

 $$ \xi=\mathrm{e}^{\mathrm{i}\theta}\frac{z-i}{z+i}. $$ 

（为了能应用上述三个特例的结果.我们在 z 平面与 w 平面间插入一个“中间”平面—— $ \xi $ 平面.）

复合上述两个分式线性变换得

 $$ \frac{w-w_{0}}{R}=\mathrm{e}^{i\theta}\frac{z-i}{z+i}, $$

<!-- page: 317 -->

<div style="text-align: center;"><img src="images/p0317_img_in_image_box_851_598_3580_2530.jpg" alt="图 7.10" width="61%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.10</div> </div>


它将上半z平面共形映射成圆 $ \left|w-w_{0}\right|<R $，i变成 $ w_{0} $。再由条件 $ L^{\prime}(i)>0 $，先求得

 $$ \frac{1}{R}\frac{\mathrm{d}w}{\mathrm{d}z}\bigg|_{z=\mathrm{i}}=\mathrm{e}^{\mathrm{i}\theta}\frac{z+\mathrm{i}-z+\mathrm{i}}{(z+\mathrm{i})^{2}}\bigg|_{z=\mathrm{i}}=\mathrm{e}^{\mathrm{i}\theta}\frac{1}{2\mathrm{i}}, $$ 

即

 $$ L^{\prime}(\mathrm{i})=R\mathrm{e}^{\mathrm{i}\theta}\cdot\frac{1}{2\mathrm{i}}=\frac{R}{2}\mathrm{e}^{\mathrm{i}\left(\theta-\frac{\pi}{2}\right)}, $$ 

于是

 $$ \theta-\frac{\pi}{2}=0,\theta=\frac{\pi}{2},\mathrm{e}^{\mathrm{i}\theta}=\mathrm{i}, $$ 

所求分式线性变换为

 $$ \begin{array}{r}{\omega=R\mathrm{i}\frac{z-\mathrm{i}}{z+\mathrm{i}}+\omega_{0}.}\end{array} $$ 

#### §3. 某些初等函数所构成的共形映射

初等函数构成的共形映射对今后研究较复杂的共形映射大有作用.

### 1. 幂函数与根式函数 先讨论幂函数

<!-- page: 318 -->

$$  w=z^{n},   \tag*{(7.15)}$$

其中 n 是大于 1 的自然数. 除了 z=0 及 z= $ \infty $ 外, 它处处具有不为零的导数, 因而在这些点是保角的.

由第二章§3，(7.15)的单叶性区域是顶点在原点张度不超过 $ \frac{2\pi}{n} $的角形区域。例如说，(7.15)在角形区域 $ d:0<\arg z<a $和 $ \left(0<\alpha\leq\frac{2\pi}{n}\right) $内是单叶的，因而也是共形的（因为不保角的点 $ z=0 $及 $ z=\infty $在 $ d $的边界上，不在 $ d $内）。于是幂函数(7.15)将图7.11的角形区域 $ d:0<\arg z<\alpha $和 $ z=\frac{2\pi}{n} $共形映射成角形区域 $ D:0<\arg w<n\alpha $。

<div style="text-align: center;"><img src="images/p0318_img_in_image_box_474_2831_3897_3722.jpg" alt="图 7.11" width="77%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.11</div> </div>


特别， $ w = z^{n} $ 将角形区域  $ 0 < \arg z < \frac{2\pi}{n} $ 共形映射成 w 平面上除去原点及正实轴的区域（图 7.12）.

<div style="text-align: center;"><img src="images/p0318_img_in_image_box_487_4842_3947_5767.jpg" alt="图 7.12" width="77%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.12</div> </div>

<!-- page: 319 -->

作为  $ w = z^{n} $ 的逆变换

$$  z=\sqrt[n]{w}\,,   \tag*{(7.16)}$$

将 w 平面上的角形区域  $ D: 0 < \arg w < n\alpha $  $ \left(0 < \alpha \leq \frac{2\pi}{n}\right) $ 共形映射成 z 平面上的角形区域  $ d: 0 < \arg z < \alpha $ (图 7.11). (这里  $ \sqrt[n]{w} $ 是 D 内的一个单值解析分支, 它的值完全由区域 d 确定).

总之，以后我们要将角形区域的张度拉大或缩小时，就可以利用幂函数(7.15)或根式函数(7.16)所构成的共形映射.

例 7.11 求一变换，把具有割痕“ $ \mathrm{Re} z = a, 0 \leqslant \mathrm{Im} z \leqslant h $”的上半 z 平面共形映射成上半 w 平面.

解 复合图 7.13 所示五个变换，即得所要求的变换为

 $$ \omega=\sqrt{(z-a)^{2}+h^{2}}+a, $$ 

例 7.12 将区域  $ -\frac{\pi}{4} < \arg z < \frac{\pi}{2} $ 共形映射成上半平面. 使 z = 1 - i, i, 0 分别变成 w = 2, -1, 0 (图 7.14).

解 易知  $ \xi = \left[ (\mathrm{e}^{\hat{\bar{\tau}}^{i}} \cdot z)^{\hat{\bar{\tau}}} \right]^{4} = (\mathrm{e}^{\hat{\bar{\tau}}^{i}} \cdot z)^{\hat{\bar{\tau}}} $ 将指定区域变成上半平面，不过 z = 1 - i, i, 0 变成  $ \xi = \sqrt[3]{4}, -1, 0 $.

现再作上半平面到上半平面的分式线性变换，使  $ \xi=\sqrt[3]{4}, -1, 0 $ 变成 w=2,-1,0. 此变换为

 $$ \omega=\frac{2(\sqrt[3]{4}+1)\xi}{(\sqrt[3]{4}-2)\xi+3\sqrt[3]{4}}. $$ 

复合两个变换，即得所求的变换为

 $$ \omega=\frac{2(\sqrt[3]{4}+1)\left(\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}z\right)^{\frac{4}{3}}}{(\sqrt[3]{4}-2)\left(\mathrm{e}^{\frac{\pi}{4}\mathrm{i}}z\right)^{\frac{4}{3}}+3\sqrt[3]{4}} $$ 

2. 指数函数与对数函数 指数函数

$$  w=\mathrm{e}^{z}   \tag*{(7.17)}$$

在任意有限点均有 $ (e^{z})^{\prime} \neq 0 $，因而它在 z 平面上是保角的.

由第二章 §3，(7.17) 的单叶性区域是平行于实轴宽不超过

<!-- page: 320 -->

<div style="text-align: center;"><img src="images/p0320_img_in_image_box_670_624_3718_4805.jpg" alt="图 7.13" width="68%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.13</div> </div>


2 $ \pi $ 的带形区域.例如,指数函数(7.17)在带形区域  $ g:0<Im z<h $ (0<h≤2 $ \pi $)是单叶的,因而也是共形的( $ z=\infty $ 不在 g 内,而在 g 的边界上).于是指数函数(7.17)将带形区域  $ g:0<Im z<h $ (0<h≤2 $ \pi $)共形映射成角形区域  $ G:0<arg w<h $ (图 7.15).

<!-- page: 321 -->

<div style="text-align: center;"><img src="images/p0321_img_in_image_box_545_550_3874_2532.jpg" alt="图 7.14" width="74%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.14</div> </div>


<div style="text-align: center;"><img src="images/p0321_img_in_image_box_540_3178_3895_4232.jpg" alt="图 7.15" width="75%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.15</div> </div>


特别， $ w=e^{z} $ 将带形区域  $ 0<Im z<2\pi $ 共形映射成 w 平面除去原点及正实轴的区域.

作为  $ w = e^{z} $ 的逆变换

 $$ z=\ln w, $$ 

将图 7.15 所示 w 平面上的角形区域 G:0 < arg w < h (0 < h ≤ 2\pi) 共形映射成 z 平面上的带形区域 g:0 < Im z < h (这里 ln w 是 G 内的一个单值解析分支, 它的值完全由区域 g 确定.)

<!-- page: 322 -->

例 7.13 求一变换将带形  $ 0 < \mathrm{Im} z < \pi $ 共形映射成单位圆  $ |w| < 1 $.

解 复合如图 7.16 所示的两个变换，即得所求的变换为

 $$ \omega=\frac{\mathrm{e}^{z}-\mathrm{i}}{\mathrm{e}^{z}+\mathrm{i}}. $$ 

<div style="text-align: center;"><img src="images/p0322_img_in_image_box_836_1461_3596_3136.jpg" alt="图 7.16" width="62%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.16</div> </div>


3. 由圆弧构成的两角形区域的共形映射 借助于分式线性函数,以及幂函数或指数函数的复合,可以将二圆弧或直线段所构成的两角形区域,共形映射成一个标准区域,比如上半平面.

由于分式线性变换的保圆性，它把已给两角形区域共形映射成同样形状的区域、或弓形区域、或角形区域。只要已给圆周（或直线）上有一个点变为  $ w = \infty $，则此圆周（或直线）就变成直线。如果它上面没有点变为  $ w = \infty $，则它就变为有限半径的圆周。所以，若二圆弧的一个公共点变为  $ w = \infty $，则此二圆弧所围成的两角形区域就共形映射成角形区域。

例 7.14 考虑交角为  $ \frac{n}{n} $ 的两个圆弧所构成的区域，将其共形映射成上半平面.

解 用 a, b 表示两个圆弧的交点. 我们先设法将两圆弧变成从原点出发的两条射线. 为此, 作分式线性变换

<!-- page: 323 -->

$$ \xi=k\frac{z-a}{z-b}. $$ 

其中 k 是一常数. 选择适当的 k, 就可以使给定的区域共形映射成角形区域

 $$ 0<\arg\xi<\frac{\pi}{n}. $$ 

再通过幂函数

 $$ w=\xi^{n} $$ 

就共形映射成上半平面.故所求变换具有形式

 $$ \begin{array}{r}{\omega=\left(k\frac{z-a}{z-b}\right)^{n}.}\end{array} $$ 

例 7.15 求出一个上半单位圆到上半平面的共形映射.

解 作分式线性变换

 $$ \xi=k\frac{z+1}{z-1} $$ 

将上半单位圆（视为两角形）变成第一象限，为此只要选择 k = -1 就行了. 事实上，此变换将线段  $ [-1,1] $ 变成了正实轴，将上半圆周变成了正虚轴. 于是

 $$ \mathcal{w}=.\left(-\frac{z+1}{z-1}\right)^{2} $$ 

就是所求的一个变换.

例 7.16 为了作出使相切于点 a 的两个圆周所构成的月牙形区域到上半平面的共形映射,我们先用分式线性变换

 $$ \xi=\frac{cz+d}{z-a} $$ 

将二圆周变成二平行直线.只要适当地选取 c,d,所述区域就能共形映射成带形区域

 $$ 0<\mathrm{I m}\xi<\pi. $$ 

再通过指数函数  $ w = e^{\xi} $，得到

 $$ \begin{array}{r}{\omega=\mathrm{e}^{\frac{c z+d}{z-a}},}\end{array} $$

<!-- page: 324 -->

它能将指定的区域共形映射成上半平面.

 $ ^{*} $4. 机翼剖面函数及其反函数所构成的共形映射 首先考虑机翼剖面外部区域到单位圆周外部区域的共形映射.

为什么要研究把如图 7.17(a) 的机翼剖面外部区域 D, 共形映射成单位圆周外部  $ G: |w| > 1 $ 呢？因为要研究机翼剖面轮廓线形状以及它在空中飞行时所受的阻力、上升力等，计算时如按原图，则困难且复杂，往往就把它共形映射成单位圆（如图 7.17(b)），研究它在单位圆周外部的相应条件。而在复变函数中，我们知道对于单位圆周的外部是比较好处理的。

<div style="text-align: center;"><img src="images/p0324_img_in_image_box_827_3008_1798_3662.jpg" alt="图 7.17(a)" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(a)</div> </div>


<div style="text-align: center;"><img src="images/p0324_img_in_image_box_2512_2479_3724_3639.jpg" alt="图 7.17(b)" width="27%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(b)</div> </div>


为了讲得更确切起见，我们考虑比较特殊一些的形状，其坐标关系选成如图 7.17(a')与(b')所示。现在，我们分下列几步来作出机翼剖面函数及其反函数所构成的共形映射。

<div style="text-align: center;"><img src="images/p0324_img_in_image_box_636_4655_2009_5856.jpg" alt="图 7.17(a')" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(a')</div> </div>


<div style="text-align: center;"><img src="images/p0324_img_in_image_box_2401_4661_3868_5894.jpg" alt="图 7.17(b')" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(b')</div> </div>

<!-- page: 325 -->

<div style="text-align: center;"><img src="images/p0325_img_in_image_box_663_636_1993_1905.jpg" alt="图 7.17(a')" width="29%" /></div>


<div style="text-align: center;"><img src="images/p0325_img_in_image_box_2455_882_3815_1913.jpg" alt="图 7.17(c)" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(a")</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 7.17(c)</div> </div>


（1）分式线性变换

 $$ \zeta_{1}=\frac{z-a}{z+a} $$ 

将 z 平面上圆弧AB外部区域  $ D_{0} $ 共形映射成  $ \zeta_{1} $ 平面上去掉射线

 $$ \arg\ \zeta_{1}=\pi-\alpha $$ 

所成的区域  $ D_{1} $，其中

 $$ \alpha=2\arctan\frac{h}{a} $$ 

（图 7.17(a")及图 7.17(c)）.

（2）分式线性变换

 $$ \mathrm{w}_{1}=\frac{\mathrm{w}-\mathrm{a}}{\mathrm{w}+\mathrm{a}} $$ 

将 w 平面上圆周 K 外部的区域  $ G_{0} $ (图 7.17(b′)) 共形映射成  $ w_{1} $ 平面上的半平面区域

 $$ G_{1}:\beta-\pi<\arg w_{1}<\beta. $$ 

其中  $ \beta=\frac{\pi}{2}-\frac{a}{2} $（图 7.17(d)）. 而圆周 K 为以 hi 为心，过 -a, a 两点，且在 a 点有切线倾角  $ \beta $.

（3）变换

 $$ \zeta_{1}=w_{1}^{2} $$ 

将  $ G_{1} $ 共形映射成  $ D_{1} $，这是因为  $ 2\beta = \pi - \alpha $.

<!-- page: 326 -->

于是

 $$ \left(\frac{w-a}{w+a}\right)^{2}=\frac{z-a}{z+a}. $$ 

解出 z 来，即

$$  z=\frac{1}{2}\left(w+\frac{a^{2}}{w}\right).   \tag*{(7.18)}$$

其反函数

 $$ \omega=z+\sqrt{z^{2}-a^{2}} $$ 

将  $ D_{0} $ 共形映射成  $ G_{0} $

<div style="text-align: center;"><img src="images/p0326_img_in_image_box_2817_597_4002_1734.jpg" alt="图 7.17(d)" width="26%" /></div>


(7.18)称为机翼剖面函数或机翼变换，也称为儒可夫斯基（Жуковский）变换.

<div style="text-align: center;"><div style="text-align: center;">图 7.17(d)</div> </div>


在机翼变换(7.18)下，当 w 为自变量时，它将 w 平面上的区域  $ G_{0} $ 共形映射成 z 平面上的区域  $ D_{0} $。再看任何一个在 w = a 与圆周 K 相切的圆周  $ K' $ 经变换(7.18)变成 z 平面上的什么曲线？注意到  $ K' $ 与 K 相切（两个单侧切线在 a 的夹角为  $ \pi $，变到 z 平面时，设  $ K' $ 变为  $ C' $ 曲线，则  $ C' $ 与 AB 在 z = a 也相切（两个单侧切线在点 a 的夹角为  $ 2\pi $。如图 7.18(a)及(b)所示。

<div style="text-align: center;"><img src="images/p0326_img_in_image_box_540_3673_2031_4910.jpg" alt="(a)" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0326_img_in_image_box_2417_3702_3853_4841.jpg" alt="(b)" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 7.18</div> </div>


在 B 点有一个尖点。闭曲线  $ K' $ 包含了闭曲线  $ K $（在  $ K' $ 的内部）。相应地，闭曲线  $ C' $ 包含了  $ AB $（在  $ C' $ 的内部），而  $ C' $ 的形状就好像飞机机翼的截线（翼型），这就是儒可夫斯基最先采用的机翼

<!-- page: 327 -->

断面的周线.这里 $ K' $的圆心 $ w_{0} $到 $ h_{i} $的距离d,以及当初的a,h这三者是机翼的翼型参数.a,h,d分别反映了机翼剖面的宽度、弯度和厚度.一个翼型的选择,主要是由这三个参数来描述的.

注 （1）函数(7.18)在 w=a 的导数为零，在 w=a 的邻近，变换不是保角的.这只要看

 $$ \left(\frac{w-a}{w+a}\right)^{2}=\frac{z-a}{z+a} $$ 

的近似式

 $$ \frac{(w-a)^{2}}{2a}=z-a, $$ 

可知函数把过点  $ w = a $ 的曲线(两个单侧切线的夹角为  $ \pi $)变成过点 z = a 的曲线(两个单侧切线的夹角为  $ 2\pi $).

（2）在工程应用上，儒可夫斯基断面作机翼时有一个缺点，就是此种断面的后缘角是零，过于尖锐，不满足工程上坚固性的要求。故需先加修正，使其圆化。

### 5. 儒可夫斯基函数的单叶性区域

下面我们进一步观察儒可夫斯基函数(7.18)的单叶性区域.为此,我们首先将它改写成通常形式:

$$  \varpi=\frac{1}{2}\left(z+\frac{1}{z}\right),   \tag*{(7.18)  ^{\prime} }$$

这个函数在扩充 z 平面上除 z = 0, ∞ 外解析, z = 0, ∞ 都是它的一阶极点.

由上面的讨论易知，儒可夫斯基函数(7.18)’是一个单叶解析函数，它把扩充z平面上单位圆周外部 $ |z|>1 $共形映射成扩充w平面上去掉割线 $ -1\leq\mathrm{Re}w\leq1 $,  $ \mathrm{Im}w=0 $而得的区域 $ D_{0} $.

##### 又，分式线性函数

 $$ \eta=\frac{1}{z} $$ 

把扩充 z 平面上区域  $ \left|z\right| > 1 $ 共形映射成单位圆  $ \left|\eta\right| < 1 $. 将其代入 (7.18) 后得到

<!-- page: 328 -->

$$ w=\frac{1}{2}\left(\eta+\frac{1}{\eta}\right). $$ 

由此可见，(7.18)′把单位圆| $ \eta $|<1也共形映射成 $ D_{0} $

总之，儒可夫斯基函数(7.18)′在 $ |z|=1 $的内部及外部都是单叶的，且将它们都共形映射成扩充w平面上去掉割线 $ -1\leq\mathrm{Re}w\leq1 $， $ \mathrm{Im}w=0 $而得的区域 $ D_{0} $。这样一来，儒可夫斯基函数(7.18)′在区域 $ D_{0} $内就有两个单值反函数（称为单值解析分支）

 $$ z=w+\sqrt{w^{2}-1}, $$ 

它们分别将区域  $ D_{0} $ 共形映射成单位圆周  $ \left|z\right|=1 $ 的内部  $ \left|z\right|<1 $ 及外部  $ \left|z\right|>1 $.

### § 4. 关于共形映射的黎曼存在 定理和边界对应定理

1. 黎曼存在定理 不少实际问题要求我们将一个指定的区域共形映射成另一个区域来予以处理，前两节中的多数例子就是.

定理 7.6 告诉我们，一个单叶解析函数能够将它的单叶性区域共形映射成另一个区域.于是，我们很自然地反过来考虑共形映射理论中的一个基本问题：

“在扩充平面上任意给定两个单连通区域 D 与 G，是否存在一个（单叶）解析函数，使 D 共形映射成 G？简单地说，单连通区域 D 能共形映射成单连通区域 G 的条件为何？惟一性条件为何？”

上述问题可以简化成这样：

“在扩充平面上任给单连通区域 D，能否共形映射成单位圆？在什么条件下，这种变换还是惟一的？

事实上，在简化后的问题中，如果存在性有肯定的答案，又知道了惟一性条件，则先将 D 共形映射成单位圆，然后再将此单位圆共形映射成 G，两者复合起来即可将 D 共形映射成 G，也能弄

<!-- page: 329 -->

清楚这时的惟一性条件.

对于上述简化后的基本问题，有两种极端情形的回答是否定的：第一，区域 D 是扩充平面（这时 D 无边界点）；第二，区域 D 是扩充平面除去一点（这时 D 只有一个边界点。我们不妨假设除去的是点  $ \infty $。如果除去的是有限点 a，只须先作一个分式线性变换  $ \xi = \frac{1}{z - a} $，就将 D 先化成扩充  $ \xi $ 平面除去点  $ \infty $ 的区域了）。无论哪一种情形，如果  $ w = f(z) $ 将它们共形映射成单位圆，则由刘维尔定理知  $ f(z) $ 必恒为常数，它就不可能成为我们要求的变换。

除开这两种情形，答案总是肯定的，即有

定理 7.13 （黎曼存在与惟一性定理）扩充 z 平面上的单连通区域 D，其边界点不止一点，则有一个在 D 内的单叶解析函数  $ w = f(z) $，它将 D 共形映射成单位圆  $ |w| < 1 $；且当符合条件

$$  f(a)=0,\quad f^{\prime}(a)>0\quad(a\in D)   \tag*{(7.19)}$$

时，这种函数  $ f(z) $ 就只有一个.

注（1）这个定理的存在性证明比较难，超出大纲要求，故不给证明 $ ^{①} $.可参看普里瓦洛夫著：《复变函数引论》第十二章§6.

(2) 惟一性条件(7.19)的几何意义是: 指定  $ a \in D $ 变成单位圆的圆心, 而在点 a 的旋转角  $ \arg f'(a) = 0 $. 它依赖于三个实参数.

（3）在将单连通区域 D 共形映射成单连通区域 G 的一般情形，惟一性条件可表成

 $$ f(a)=b,\arg f^{\prime}(a)=\alpha. $$ 

其中  $ a \in D $,  $ b \in G $, 而  $ \alpha $ 为实参数.

在 D,G 的边界均是周线的情形,惟一性条件也可表成

 $$ f(a)=b,f(\xi)=\eta, $$

<!-- page: 330 -->

其中  $ a \in D $, b  $ \in G $.  $ \xi $ 为 D 之边界点,  $ \eta $ 为 G 之边界点.

在上述情形，惟一性条件还可表成

 $$ f(\xi_{i})=\eta_{i}\left(i=1,2,3\right), $$ 

其中  $ \xi_{i} $ 及  $ \eta_{i} $ 分别是 D 及 G 的边界上指定的三点（但绕行方向应一致）。区域的边界点的位置可用一个实参数来确定，例如，用某一个固定边界为起点的弧坐标即可确定。

利用施瓦茨引理，我们来证明黎曼定理的惟一性部分.

今设单叶解析函数  $ w_{1}=f_{1}(z) $ 也适合条件 (7.19)，并把单连通区域 D 共形映射成单位圆  $ \left|w_{1}\right|<1 $。这时，函数

 $$ \begin{array}{r}{\varpi_{1}=f_{1}\left[f^{-1}(\varpi)\right]=\varPhi(\varpi)}\end{array} $$ 

在单位圆  $ |w|<1 $ 内单叶解析，且满足条件：

 $$ \begin{aligned}&\Phi(0)=f_{1}\left[f^{-1}(0)\right]=f_{1}(a)=0,\\ &\mid\Phi(w)\mid=\mid w_{1}\mid<1,(|w|<1)\\ \end{aligned} $$ 

 $$ \Phi^{\prime}(0)\underline{\underline{ 定理 7.6}}\frac{f^{\prime}_{1}(a)}{f^{\prime}(a)}>0. $$ 

所以由施瓦茨引理知

$$  |\Phi(w)|=|\dot{w}_{1}|\leq|w|.   \tag*{(7.20)}$$

同样的结论可用于函数  $ \Phi(w) $ 的反函数

 $$ \begin{aligned}\boldsymbol{w}&=\boldsymbol{f}\left[\boldsymbol{f}_{1}^{-1}\left(\boldsymbol{w}_{1}\right)\right]=\boldsymbol{\varPhi}^{-1}\left(\boldsymbol{w}_{1}\right),\\&\left|\boldsymbol{w}\right|\leqslant\left|\boldsymbol{w}_{1}\right|=\left|\boldsymbol{\varPhi}(\boldsymbol{w})\right|.\end{aligned} $$ 

得到

由（7.20）及（7.21）得到

因此

 $$ \begin{array}{l}\left|\Phi(w)\right|=\left|w\right|,\\ \Phi(w)=\mathrm{e}^{\mathrm{i}\alpha}w\left(\alpha 为实数 \right).\\ 0<\Phi^{\prime}(0)=\mathrm{e}^{\mathrm{i}\alpha},\\ \mathrm{e}^{\mathrm{i}\alpha}=1\left( 因 \left|\mathrm{e}^{\mathrm{i}\alpha}\right|=1\right),\\ f_{1}\left\lceil f^{-1}(w)\right\rceil=\Phi(w)=w\end{array} $$ 

由于

故必

因而有

 $$ f_{1}\left[f^{-1}\left(\boldsymbol{\varpi}\right)\right]=\varPhi\left(\boldsymbol{\varpi}\right)=\varpi. $$ 

故必

 $$ f_{1}(z)=f(z). $$ 

例 7.17 如果函数  $ w = f(z) $ 在 z 平面上是解析的，并且不

<!-- page: 331 -->

取位于某一条简单弧  $ \gamma $ 上的那些值，则它必是一个常数.

证 设单叶解析函数  $ \omega = \varphi(w) $ 作出把曲线  $ \gamma $ 外部的单连通区域共形映射成单位圆  $ |\omega| < 1 $，根据黎曼存在定理，这函数是存在的，并且当然不是一个常数.

我们来看复合函数  $ \omega = \varphi[f(z)] = g(z) $，它在 z 平面上是解析的，并且所有它的值都位于单位圆  $ |\omega| < 1 $ 内。根据刘维尔定理，函数  $ \omega = g(z) $ 是个常数。但由非常数的解析函数  $ \omega = \varphi(w) $ 的单叶性，函数  $ w = f(z) $ 是一个常数。

思考题 说明刘维尔定理是例 7.17 所述定理的特殊情形.

2. 边界对应定理 上面所讨论的限于区域内部间的共形映射,未涉及边界;下面我们举出两个有关边界对应的定理,第一个不给证明①②.

定理 7.14(边界对应定理) 设

（1）有界单连通区域 D 与 G 的边界分别为周线 C 与  $ \Gamma $;

(2)  $ w = f(z) $ 将 D 共形映射成 G，

则  $ f(z) $ 可以扩张成  $ F(z) $，使在 D 内  $ F(z) = f(z) $，在  $ \overline{D} = D + C $ 上  $ F(z) $ 连续，并将 C 双方单值且双方连续地变成  $ \Gamma $.

从例 7.8 可验证此定理.

定理 7.15 （边界对应定理的逆定理，判断解析函数单叶性的充分条件）.

设单连通区域 D 及 G，分别是两条周线 C 及  $ \Gamma $ 的内部. 且设函数  $ w = f(z) $ 满足下列条件：

(1)  $ w = f(z) $ 在区域 D 内解析，在  $ D + C $ 上连续，

(2)  $ w = f(z) $ 将 C 双方单值地变成  $ \Gamma $,

则 (1) w = f(z) 在 D 内单叶；

<!-- page: 332 -->

(2)  $ G = f(D) $ (从而 w = f(z)) 将 D 共形映射成 G).

证 证明的关键，在应用辐角原理来证明集合等式

 $$ G=f(D). $$ 

（1）设  $ w_{0} $ 为 G 内任一点. 我们证明  $ w_{0} \in f(D) $，而且方程  $ f(z) - w_{0} = 0 $ 在 C 内部只有一个根. 根据辐角原理

 $$ N(f(z)-w_{0},C)=\frac{1}{2\pi}\Delta_{r}\arg(w-w_{0}) $$ 

(在 z 沿 C 的正向绕行一周的假定下). 由假设条件(2), 这时  $ w = f(z) $ 应该沿  $ \Gamma $ 的正向或负向绕行一周. 因此, 起点在  $ w_{0} $ 终点在  $ \Gamma $ 上的向量  $ w - w_{0} $ 应该转角  $ \pm 2\pi $. 于是

 $$ N(f(z)-\omega_{0},C)=\frac{1}{2\pi}\Delta_{r}\mathrm{a r g}(w-w_{0})=\pm1, $$ 

负号显然应该除去(因为  $ N \geqslant 0 $). 因此我们肯定  $ w = f(z) $ 必须沿  $ \Gamma $ 的正向 ( $ \Gamma $ 的内部在此方向的左边) 绕行, 并且方程  $ f(z) - w_{0} = 0 $ 在区域 D 内只有一个根.

（2）设  $ w_{0} $ 位于  $ \Gamma $ 的外部，则必  $ w_{0} \notin f(D) $. 因为

 $$ N(f(z)-\omega_{0},C)=\frac{1}{2\pi}\Delta_{r}\mathrm{a r g}(w-w_{0})=0, $$ 

即方程  $ f(z)-w_{0}=0 $ 在 D 内无根.

(3) 设  $ w_{1} $ 为  $ \Gamma $ 上的任一点，我们来证明方程  $ f(z) = w_{1} $ 在 D 内无根。假定 D 内有一点  $ z_{1} $ 使  $ f(z_{1}) = w_{1} $，则可得一个以  $ w_{1} $ 为中心的圆周  $ \gamma $，使对  $ \gamma $ 内部任意一点  $ w' $，方程  $ f(z) = w' $ 在 D 内有根（因  $ f(D) $ 为区域， $ w_{1} $ 为其内点）。特别在  $ \gamma $ 内部取一点  $ w' $ 位于  $ \Gamma $ 的外部，由 (2) 段证明，方程  $ f(z) = w' $ 在 D 内无根，发生矛盾。

由以上各结果, 可见函数  $ w = f(z) $ 在 D 内单叶, 并将 D 共形映射为  $ \Gamma $ 的内部 G.

例 7.18 如果将函数  $ w = z^{2} $ 表成极坐标的形式. 令

 $$ \begin{array}{r}{\varpi=\rho\mathrm{e}^{\mathrm{i}\varphi},z=r\mathrm{e}^{\mathrm{i}\theta},}\end{array} $$

<!-- page: 333 -->

则它把 z 平面上的圆周（图 7.19）

 $$ r=\cos\ \theta $$ 

变成心脏线

 $$ \rho=\cos^{2}\frac{\varphi}{2}=\frac{1}{2}(1+\cos\varphi), $$ 

<div style="text-align: center;"><img src="images/p0333_img_in_image_box_832_1528_3575_2562.jpg" alt="图7.19" width="61%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.19</div> </div>


并且是双方单值的.

由定理 7.15(单叶性原理),  $ w = z^{2} $ 将这个圆周的内部共形映射成心脏线的内部.

思考题 一个多连通区域(比如 $ \underset{\cdot}{如} $有一个“洞”的区域)可否共形映射成一个单连通区域？

## 第七章 习题

(一)

1 求  $ w = z^{2} $ 在 z = i 处的伸缩率和旋转角. 问此变换将经过点 z = i 且平行于实轴正方向的曲线的切线方向变换成 w 平面上哪一个方向？并作图.

答: 伸缩率 = 2, 旋转角 =  $ \frac{\pi}{2} $.

2 试利用保域定理 7.1 简捷地证明第二章习题(一)6(3)、(4).

3 在整线性变换 w = iz 下，下列图形分别变成什么图形？

<!-- page: 334 -->

（1）以  $ z_{1}=i, z_{2}=-1, z_{3}=1 $ 为顶点的三角形；

(2) 闭圆  $ \left| z - 1 \right| \leqslant 1 $.

答: (1) 以  $ w_{1} = -1, w_{2} = -i, w_{3} = i $ 为顶点的三角形; (2) 闭圆  $ \left|w - i\right| \leqslant 1 $.

4 下列各题中，给出了三对对应点  $ z_{1} \xleftarrow{} w_{1}, z_{2} \xleftarrow{} w_{2}, z_{3} \xleftarrow{} w_{3} $ 的具体数值，写出相应的分式线性变换，并指出此变换把通过  $ z_{1}, z_{2}, z_{3} $ 的圆周的内部，或直线左边（顺着  $ z_{1}, z_{2}, z_{3} $ 观察）变成什么区域.

(1)  $ 1 \longleftrightarrow 1, i \longleftrightarrow 0, -i \longleftrightarrow -1; $

(2)  $ 1 \longleftrightarrow \infty, i \longleftrightarrow -1, -1 \longleftrightarrow 0 $;

(3)  $ \infty \longleftrightarrow 0, i \longleftrightarrow i, 0 \longleftrightarrow \infty $;

(4)  $ \infty \longleftrightarrow 0,0 \longleftrightarrow 1,1 \longleftrightarrow \infty $.

答: (1)  $ w = \frac{(1 + \mathrm{i})(z - \mathrm{i})}{1 + z + 3\mathrm{i}(1 - z)}; $ (2)  $ w = \frac{\mathrm{i}(z + 1)}{1 - z}; $ (3)  $ w = -\frac{1}{z}; $ (4)  $ w = \frac{1}{1 - z}. $

5 z平面上有三个互相外切的圆周，切点之一在原点，函数  $ w = \frac{1}{z} $ 将此三个圆周所围成的区域变成 w 平面上什么区域？

6 如  $ w=\frac{az+b}{cz+d} $ 将单位圆周变成直线，其系数应满足什么条件？

答： $ \left|c\right|=\left|d\right| $ 且 ad - bc \neq 0.

7 分别求将上半 z 平面  $ \mathrm{Im} z > 0 $ 共形映射成单位圆  $ |w| < 1 $ 的分式线性变换  $ w = L(z) $，使符合条件：

(1)  $ L(i) = 0, L'(i) > 0; $

(2)  $ L(i) = 0, \arg L'(i) = \frac{\pi}{2} $.

答: (1)  $ w = i \frac{z - i}{z + i}; $ (2)  $ w = \frac{i - z}{i + z}. $

8 分别求将单位圆  $ \left|z\right|<1 $ 共形映射成单位圆  $ \left|w\right|<1 $ 的分式线性变换  $ w=L(z) $，使符合条件：

(1)  $ L\left(\frac{1}{2}\right)=0, L(1)=-1; $

(2)  $ L\left(\frac{1}{2}\right)=0 $,  $ \arg L'\left(\frac{1}{2}\right)=-\frac{\pi}{2} $.

<!-- page: 335 -->

答: (1)  $ w = \frac{2z - 1}{z - 2} $; (2)  $ w = \frac{\mathrm{i}(2z - 1)}{-2 + z} $.

9 求出将圆  $ \left|z-4i\right|<2 $ 变成半平面 v>u 的共形映射，使得圆心变到 -4，而圆周上的点 2i 变到 w=0.

答： $ w = -4i \cdot \frac{z - 2i}{z - 2(1 + 2i)} $

10 求出将上半 z 平面  $ \mathrm{Im} z > 0 $ 共形映射成圆  $ \left| w \right| < R $ 的分式线性变换  $ w = L(z) $，使符合条件  $ L(i) = 0 $；如果再要求  $ L'(i) = 1 $，此变换是否存在？

答： $ w = R e^{i\theta} \cdot \frac{z - i}{z + i}; w = 2 i \cdot \frac{z - i}{z + i} $

11 求将圆  $ \left|z\right| < \rho $ 共形映射成圆  $ \left|w\right| < R $ 的分式线性变换，使 z =  $ a(|a| < \rho) $ 变成 w = 0.

答： $ w = R\rho e^{i\theta} \cdot \frac{z - a}{\rho^{2} - \overline{a}z} (\theta \text{ 为实参数}) $.

12 求出圆  $ \left|z\right|<2 $ 到半平面  $ \mathrm{Re} w>0 $ 的共形映射  $ w=f(z) $，使符合条件

 $$ f(0)=1\quad\arg f^{\prime}(0)=\frac{\pi}{2}. $$ 

答： $ w = -\frac{z - 2i}{z + 2i} $

13 试求以下各区域(除去阴影的部分)到上半平面的一个共形映射.

(1)  $ \left|z + i\right| < 2 $, Im z > 0 (图 7.20).

答： $ w = -\left(\frac{z + \sqrt{3}}{z - \sqrt{3}}\right)^{3} $

<div style="text-align: center;"><img src="images/p0335_img_in_image_box_1491_4520_2950_5632.jpg" alt="图 7.20" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.20</div> </div>

<!-- page: 336 -->

(2)  $ \left|z + \mathrm{i}\right| > \sqrt{2}, \left|z - \mathrm{i}\right| < \sqrt{2} $ (图 7.21).

答： $ w = -i\left(\frac{z+1}{z-1}\right)^{2} $

<div style="text-align: center;"><img src="images/p0336_img_in_image_box_662_1141_1949_2530.jpg" alt="图 7.21" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.21</div> </div>


<div style="text-align: center;"><img src="images/p0336_img_in_image_box_2442_1183_3850_2511.jpg" alt="图 7.22" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 7.22</div> </div>


(3) $ |z|<2,|z-1|>1 $ (图7.22).

答： $ w = e^{2\pi i\frac{z}{z-2}} $

14 求出角形区域  $ 0 < \arg z < \frac{\pi}{4} $ 到单位圆  $ \left|w\right| < 1 $ 的一个共形映射.

答： $ w = \frac{z^{4} - i}{z^{4} + i} $（非惟一的）.

15 求出将上半单位圆变成上半平面的共形映射，使 z=1,-1,0 分别变成  $ w = -1,1,\infty $.

答： $ w = -\frac{1}{2}\left(z + \frac{1}{z}\right) $.

16 求出第一象限到上半平面的共形映射，使  $ z=\sqrt{2}i, \theta, 1 $ 对应地变成  $ w=0, \infty, -1 $.

答： $ w = -\frac{z^{2} + 2}{3z^{2}}. $

17 将扩充 z 平面割去  $ 1+i $ 到  $ 2+2i $ 的线段后剩下的区域共形映射成上半平面.

答： $ w=\sqrt{\frac{(1+\mathrm{i})-z}{z-(2+2\mathrm{i})}} $

18 将单位圆割去 0 到 1 的半径后剩下的区域共形映射成上半平面.

<!-- page: 337 -->

答： $ w=\left(\frac{\sqrt{z}+1}{\sqrt{z}-1}\right)^{2} $

19 将一个从中心起沿实轴上的半径割开了的单位圆共形映射成单位圆，使符合条件：割缝上岸的1变成1，割缝下岸的1变成-1，0变成-i.

答： $ w = \frac{z + 1 + 2i\sqrt{z}}{i(z + 1) + 2\sqrt{z}}. $

## (二)

1 证明定理 7.3. (只须就  $ z_{0}=0 $ 的情形证明)

提示 不妨假设  $ f(0)=0 $，否则，代替  $ f(z) $ 总可以考虑  $ F(z)=f(z)-f(0) $，而  $ F(0)=0, F'(0)=f'(0)\neq0 $；接着可以应用儒歇定理.

2 如果单叶解析函数  $ w = f(z) $，面上可求面积的区域 D 共形映射成 w 平面上的区域 G，试证 G 的

 $$ \int_{D}\left|f^{\prime}(z)\right|^{2}\mathrm{d}x\mathrm{d}y,\left(z=x+\mathrm{i}y\right). $$ 

3 试证： $ w = z + \frac{1}{z} $ 把圆周  $ \left|z\right| = c $ 变成椭圆周

 $$ \begin{align*}u=\left(c+\frac{1}{c}\right)\cos\theta,v=\left(c-\frac{1}{c}\right)\sin\theta\\ (0\leqslant\theta\leqslant2\pi).\end{align*} $$ 

4  $ w = \frac{i}{z} $ 把半带形

 $$ \mathrm{R e}z>0,0<\mathrm{I m}z<1 $$ 

变成什么？

答：Re w > 0,  $ \left|w - \frac{1}{2}\right| > \frac{1}{2} $, Im w > 0.

5 求分式线性变换 w = L(z)，使点 1 变到  $ \infty $，点 i 是二重不动点.

答： $ w=\frac{(2i-1)z+1}{z-1} $

6 证明:有二相异有限不动点 p,q 的分式线性变换可写成

 $ \frac{w-p}{w-q}=k\frac{z-p}{z-q} $，k 是非零复常数.

7 证明: 只有一个不动点 (二重有限) p 的分式线性变换可写成

<!-- page: 338 -->

$ \frac{1}{w-p}=\frac{1}{z-p}+k $, k 是非零复常数.

8 证明：以 p, q 为对称点的圆周的方程为

 $$ \left|\frac{z-p}{z-q}\right|=k>0, $$ 

当 k=1 时，退化为以 p,q 为对称点的直线.

9 求分式线性变换

 $$ w=\frac{az+b}{cz+d},ad-bc\ne0 $$ 

使扩充 z 平面上由三圆弧所围成的三角形与扩充 w 平面上的直线三角形相对应的充要条件.

答: 三圆弧过点  $ -\frac{d}{c} $.

10 设函数  $ w = f(z) $ 在  $ |z| < 1 $ 内解析，且是将  $ |z| < 1 $ 共形映射成  $ |w| < 1 $ 的分式线性变换。试证

(1)  $ \mid f'(z) \mid = \frac{1 - \mid f(z) \mid^2}{1 - \mid z \mid^2} (\mid z \mid < 1) $;

(2)  $ \left|f'(a)\right|=\frac{1}{1-\left|a\right|^2} $,

其中 a 在单位圆  $ \left|z\right|<1 $ 内， $ f(a)=0 $.

##### 提示 应用例 7.8.

11 若  $ w = f(z) $ 是将  $ \left|z\right| < 1 $ 共形映射成  $ \left|w\right| < 1 $ 的单叶解析函数，且

 $$ f(0)=0,\arg f^{\prime}(0)=0. $$ 

试证:这个变换只能是恒等变换,即  $ f(z) \equiv z $.

提示 应用施瓦茨引理先证明  $ f(z)=\mathrm{e}^{\mathrm{i}\alpha}z $.

12 设函数  $ w = f(z) $ 在  $ \mid z \mid < 1 $ 内单叶解析，且将  $ \mid z \mid < 1 $ 共形映射成  $ \mid w \mid < 1 $，试证  $ w = f(z) $ 必是分式线性函数.

提示 设  $ f(0) = w_{0}, \cdot |w_{0}| < 1 $. 由例 7.8 则可作出符合上题条件的变换.

13 设在  $ \left|z\right|<1 $ 内  $ f(z) $ 解析，且  $ \left|f(z)\right|<1 $; 但  $ f(a)=0(\left|a\right|<1) $. 试证：在  $ \left|z\right|<1 $ 内，

 $$ |f(z)|\leqslant\left|\frac{z-a}{1-\bar{a}z}\right|. $$ 

提示 应用例 7.8 及施瓦茨引理.

<!-- page: 339 -->

14 应用施瓦茨引理证明：把  $ |z|<1 $ 变成  $ |w|<1 $，且把  $ a(|a|<1) $ 变成 0 的共形映射一定有下列形状

 $$ \omega=\mathrm{e}^{\mathrm{i}\theta}\frac{z-a}{1-\bar{a}z}, $$ 

这里  $ \theta $ 是实常数.

<!-- page: 340 -->

## 第八章 解析延拓

我们将在本章讨论已知区域内解析函数定义域的扩大问题。也就是研究在什么条件下能够延拓成为更大区域上的解析函数，并给出两个具体的解析延拓方法——幂级数延拓与对称原理。最后，我们引进完全解析函数与黎曼面的概念，并将多值函数 $ \sqrt{z} $及 $ \ln z $看作其黎曼面上的单值解析函数。

#### §1. 解析延拓的概念与幂级数延拓

### 1. 解析延拓的概念

定义 8.1 设函数  $ f(z) $ 在区域 D 内解析，考虑一个包含 D 的更大区域 G，如果存在函数  $ F(z) $ 在 G 内解析，并且在 D 内  $ F(z) = f(z) $，则称函数  $ f(z) $ 可以解析延拓到  $ G $ 内，并称  $ F(z) $ 为  $ f(z) $ 在区域 G 内的解析延拓。

我们这样定义的解析延拓如果存在，必是惟一的。因为，如果有两个函数  $ F_{1}(z) $ 及  $ F_{2}(z) $ 在包含着区域 D 的更大的区域 G 内解析，且在 D 内  $ F_{1}(z) = f(z) $ 及  $ F_{2}(z) = f(z) $。由解析函数的内部惟一性定理，在 G 内必有  $ F_{1}(z) \equiv F_{2}(z) $。这就证明了解析延拓的惟一性。

例 8.1 设  $ \sum_{n=0}^{\infty} z^{n} = f(z) $ （ $ D: |z| < 1 $）. 而  $ \frac{1}{1 - z} $ 在 z 平面

<!-- page: 341 -->

上只有一个奇点 z=1. 故  $ F(z)=\frac{1}{1-z} $ 就是  $ f(z)=\sum_{n=0}^{\infty}z^{n} $ 在区域 G(z 平面去掉 1) 内的解析延拓，因在 D 内  $ F(z)=f(z) $.

复变函数论的目的,是研究在某一区域内解析的函数.解析性这一要求,就使得在区域 $ D_{1} $内解析的函数的数值,与另一和 $ D_{1} $紧接的区域 $ D_{2} $内解析的函数的数值之间,有着紧密的有机联系.

所谓“紧接”的区域，一个含义是指两个具有公共部分的区域，这个公共部分也是一个区域。

定义 8.2 设 D 是一区域， $ f(z) $ 是 D 内的单值解析函数，这种区域和函数的组合称为一个解析函数元素，记成  $ \{D, f(z)\} $；两个解析函数元素当且仅当其区域重合，而且在其上对应的函数值相等时，则称为是恒等的。

定理 8.1 （相交区域的解析延拓原理）

设 $ \{D_{1}, f_{1}(z)\} $， $ \{D_{2}, f_{2}(z)\} $为两个解析函数元素，符合于





<div style="text-align: center;"><img src="images/p0341_img_in_image_box_2992_2759_4010_3592.jpg" alt="图 8.1" width="22%" /></div>


（1）区域  $ D_{1} $ 及  $ D_{2} $ 有一公共区域  $ d_{12} $ （如图 8.1）；

<div style="text-align: center;"><div style="text-align: center;">图 8.1</div> </div>


 $$ (2)\ f_{1}(z)=f_{2}(z)(z\in d_{12}), $$ 

则  $ \left\{D_{1}+D_{2},F(z)\right\} $ 也是一个解析函数元素，其中

 $$ \begin{aligned}F(z)=\left\{\begin{aligned}&f_{1}\left(z\right),& 当 z\in D_{1}-d_{12};\\ &f_{2}\left(z\right),& 当 z\in D_{2}-d_{12};\\ &f_{1}\left(z\right)=f_{2}\left(z\right),& 当 z\in d_{12}.\end{aligned}\right.\end{aligned} $$ 

证 显然在  $ D_{1} $ 内  $ F(z) = f_{1}(z) $，并且在  $ D_{2} $ 内  $ F(z) = f_{2}(z) $。故在  $ D_{1} $ 及  $ D_{2} $ 内  $ F(z) $ 均解析，因而在  $ D_{1} + D_{2} $ 内  $ F(z) $ 解析。

这里  $ D_{1} + D_{2} $ 相当于定义 8.1 中提到的更大区域 G，它既包含区域  $ D_{1} $ 又包含区域  $ D_{2} $。所以  $ F(z) $ 既是  $ f_{1}(z) $ 在 G 内的解析延拓，又是  $ f_{2}(z) $ 在 G 内的解析延拓。于是，我们有

<!-- page: 342 -->

定义 8.3 如果(1) $ D_{1}\cdot D_{2}=d_{12} $ 为一区域（如图 8.1）；

(2)  $ f_{1}(z)=f_{2}(z)(z\in d_{12}) $,

则两个解析函数元素  $ \{D_{1}, f_{1}(z)\} $ 及  $ \{D_{2}, f_{2}(z)\} $ 称为互为直接解析延拓.

例 8.2 设  $ f_{1}(z)=\sum_{n=0}^{\infty}(-1)^{n}(z-1)^{n},(z\in D_{1}:|z-1|<1) $

 $$ f_{2}\left(z\right)=\frac{1}{\mathrm{i}}\sum_{n=0}^{\infty}\left(-1\right)^{n}\left(\frac{z-\mathrm{i}}{\mathrm{i}}\right)^{n}\quad\left(z\in D_{2}:\mid z-\mathrm{i}\mid<1\right), $$ 

则易知：

(1)  $ \{D_{1}, f_{1}(z)\} $ 及  $ \{D_{2}, f_{2}(z)\} $ 均是解析函数元素；

（2）圆  $ D_{1} $ 及  $ D_{2} $ 的公共部分  $ d_{12} $ (图 8.2) 是一个区域；

<div style="text-align: center;"><img src="images/p0342_img_in_image_box_1391_2783_3066_4391.jpg" alt="图 8.2" width="37%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.2</div> </div>


（3）根据等比级数求和公式，当  $ z \in D_{1} \cdot D_{2} $ 时，

 $$ f_{1}(z)=f_{2}(z)\left(=\frac{1}{z}\right), $$ 

因此， $ \{D_{1},f_{1}(z)\} $ 及  $ \{D_{2},f_{2}(z)\} $ 互为直接解析延拓.

根据在定义 8.1 意义下的解析延拓的惟一性，易知一个解析函数元素  $ \{D_{1}, f_{1}(z)\} $ 在同一区域  $ D_{2} $ 内的直接解析延拓  $ f_{2}(z) $ 也必是惟一的（因为  $ \{D_{1} + D_{2}, F(z)\} $ 是惟一的）。这样的一个直接延

<!-- page: 343 -->

拓确实将原来的解析函数推广了,解析区域也比原区域扩大了.

如果  $ \{D_{1}, f_{1}(z)\} $ 及  $ \{D_{2}, f_{2}(z)\} $ 互为直接解析延拓，根据定理8.1，从一开始我们已经有可能来研究解析函数元素  $ \{D_{1} + D_{2}, F(z)\} $，所以上面说的好像没有什么进展。但是，如果我们现在来考查第三个解析函数元素  $ \{D_{3}, f_{3}(z)\} $，假定它是  $ \{D_{2}, f_{2}(z)\} $ 的一个直接解析延拓，则很可能是  $ D_{3} $ 与  $ D_{1} $ 交叠，而  $ \{D_{3}, f_{3}(z)\} $ 却不是  $ \{D_{1}, f_{1}(z)\} $ 的直接解析延拓。在这种情况下，解析函数元素集  $ \{D_{1}, f_{1}(z)\} $， $ \{D_{2}, f_{2}(z)\} $， $ \{D_{3}, f_{3}(z)\} $ 就不能用一个单值解析函数元素来代替，但从此却可得出一个多值解析函数。

##### 例 8.3 紧接例 8.2, 我们再设

 $$ f_{3}\left(z\right)=-\sum_{n=0}^{\infty}\left(z+1\right)^{n},\left(z\in D_{3}:\mid z+1\mid<1\right) $$ 

 $$ f_{4}(z)=-\frac{1}{\mathrm{i}}\sum_{n=0}^{\infty}\left(\frac{z+\mathrm{i}}{\mathrm{i}}\right)^{n},(z\in D_{4}:|z+\mathrm{i}|<1) $$ 

则易知  $ \left\{D_{2},f_{2}(z)\right\} $ 及  $ \left\{D_{3},f_{3}(z)\right\} $ 互为直接解析延拓；

 $ \left\{D_{3},f_{3}(z)\right\} $ 及  $ \left\{D_{4},f_{4}(z)\right\} $ 互为直接解析延拓；

 $ \left\{D_{4},f_{4}(z)\right\} $ 及  $ \left\{D_{1},f_{1}(z)\right\} $ 互为直接解析延拓.

于是，解析函数元素集  $ \left\{D_{1}, f_{1}(z)\right\}, \left\{D_{2}, f_{2}(z)\right\}, \left\{D_{3}, f_{3}(z)\right\} $， $ \left\{D_{4}, f_{4}(z)\right\} $ 就能用一个单值解析函数元素  $ \left\{D, F(z)\right\} $ 来代替. 其中 D 是区域  $ D_{1} + D_{2} + D_{3} + D_{4} $，即以闭曲线 ABCEFGHIA 及原点 z=0 为边界的区域（如图 8.3）； $ F(z) $ 为

 $$ F(z)=\left\{\begin{array}{ll}f_1(z),&z\in D_1;\\f_2(z),&z\in D_2;\\f_3(z),&z\in D_3;\\f_4(z),&z\in D_4;\\f_1(z)=f_2(z),&z\in d_{12};\\f_2(z)=f_3(z),&z\in d_{23};\\f_3(z)=f_4(z),&z\in d_{34};\\f_4(z)=f_1(z),&z\in d_{41}.\end{array}\right. $$

<!-- page: 344 -->

<div style="text-align: center;"><img src="images/p0344_img_in_image_box_1244_617_3172_2481.jpg" alt="图 8.3" width="43%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.3</div> </div>


定义 8.4 给定解析函数元素集  $ \left\{\left\{D_{1}, f_{1}(z)\right\}, \left\{D_{2}, f_{2}(z)\right\}, \cdots, \left\{D_{n}, f_{n}(z)\right\}\right\} $，如果每一个解析函数元素是前一个解析函数元素的直接解析延拓，则称这些解析函数元素组成解析延拓链。链把开始元素  $ \left\{D_{1}, f_{1}(z)\right\} $ 和最后元素  $ \left\{D_{n}, f_{n}(z)\right\} $ 连接起来。显然，方向相反的同一个链把解析函数元素  $ \left\{D_{n}, f_{n}(z)\right\} $ 和  $ \left\{D_{1}, f_{1}(z)\right\} $ 连接起来。这两个解析函数元素称为互为（间接）解析延拓。

例如，在例 8.3 中， $ \{D_{1}, f_{1}(z)\} $ 及  $ \{D_{3}, f_{3}(z)\} $， $ \{D_{2}, f_{2}(z)\} $ 及  $ \{D_{4}, f_{4}(z)\} $，都是互为（间接）解析延拓的。

注上述函数“延拓”这一概念是以解析原理：“在延拓函数的时候，不得破坏函数的解析性”作为它的基础的。

思考题 试问连续原理：“在延拓函数的时候，不得破坏函数的连续性”能否作为延拓函数的基础，而保证延拓函数的惟一性？

2. 解析延拓的幂级数方法 给定一个解析函数元素，求它的解析延拓的最基本的方法是采用幂级数法.

<!-- page: 345 -->

给定解析函数元素  $ \{D, f(z)\} $，并设  $ z_{1} $ 是 D 内的任一点，则  $ f(z) $ 可在点  $ z_{1} $ 的邻域内展成幂级数：

$$  \begin{aligned}&\sum_{n=0}^{\infty}c_{n}^{(1)}\left(z-z_{1}\right)^{n},\\&c_{n}^{(1)}=\frac{1}{n!}f^{(n)}\left(z_{1}\right).\\ \end{aligned}   \tag*{(8.1)}$$

其中

如果这个级数的收敛半径为  $ +\infty $，换句话说，在 z 平面上每一点处，级数 (8.1) 都收敛。这时 (8.1) 的和  $ f_{1}(z) $ 表示一个在 z 平面上处处解析的函数，而在 D 内与  $ f(z) $ 相同。因之，根据解析延拓的惟一性，这个函数  $ f_{1}(z) $ 就是  $ f(z) $ 在 D 以外的解析延拓。

如果级数(8.1)的收敛半径为有限正数  $ R_{1} $，且其收敛圆  $ \Gamma_{1} $：

 $ |z - z_{1}| < R_{1} $ 部分超出 D 外（否则，就在 D 内另选一点  $ z_{1} $，再重复上面的过程），则我们在  $ \Gamma_{1} $ 内取一个不是圆心  $ z_{1} $ 的点  $ z_{2} $，并在点  $ z_{2} $ 的邻域内把  $ f_{1}(z) $ 展开为幂级数

$$  \begin{array}{l}{\displaystyle\sum_{n=0}^{\infty}c_{n}^{(2)}\left(z-z_{2}\right)^{n},}\\ {\displaystyle c_{n}^{(2)}=\frac{1}{n!}f_{1}^{(n)}\left(z_{2}\right),}\end{array}   \tag*{(8.2)}$$

其中

而  $ f_{1}^{(n)}(z_{2})(n=0,1,2,\cdots) $ 则由级数 (8.1) 计算之.

如级数(8.2)的收敛半径为  $ R_{2} $，则  $ R_{2} $ 一定满足不等式

$$  R_{2}\geqslant R_{1}-\mid z_{2}-z_{1}\mid.   \tag*{(8.3)}$$

但  $ R_{2} $ 无论如何不能大于  $ R_{1} + |z_{2} - z_{1}| $，即无论如何（8.2）的收敛圆不能全包含（8.1）的收敛圆（加上边界）于其内，因为这与（8.1）的收敛半径为  $ R_{1}(0 < R_{1} < +\infty) $ 的假设矛盾.

下面分别就(8.3)的两种情形讨论.

若  $ R_{2}=R_{1}-|z_{2}-z_{1}| $，则级数(8.2)给出的函数  $ f_{2}(z) $，在收敛圆  $ \Gamma_{2}:|z-z_{2}|<R_{2} $ 内那些点的值已被级数(8.1)给出的函数  $ f_{1}(z) $ 确定了。即，沿着半径从  $ z_{1} $ 到  $ z_{2} $ 的方向， $ f_{1}(z) $ 不能进行

<!-- page: 346 -->

延拓. 此时, 级数 (8.1) 和级数 (8.2) 的收敛圆周的切点  $ \xi $ 就是  $ f_{1}(z) $ 的一个奇点 (图 8.4(a)).

事实上，由定理4.16， $ f_{2}(z) $在圆 $ \Gamma_{2} $的边界 $ \gamma_{2} $上至少有一个奇点。但 $ \gamma_{2} $上的点除 $ \xi $外都在 $ \Gamma_{1} $内，因而是 $ f_{1}(z) $的解析点，当然也是 $ f_{2}(z) $的解析点。所以只剩下一点 $ \xi $不在 $ \Gamma_{1} $内，而在圆的边界 $ \gamma_{1} $上，它必定是 $ f_{2}(z) $的一个奇点，也就是 $ f_{1}(z) $的一个奇点。

<div style="text-align: center;"><img src="images/p0346_img_in_image_box_925_2122_2012_3136.jpg" alt="(a)" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0346_img_in_image_box_2387_2037_3521_3131.jpg" alt="(b)" width="25%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 8.4</div> </div>


若  $ R_{2} > R_{1} - |z_{2} - z_{1}| $，则新的收敛圆  $ \Gamma_{2}: |z - z_{2}| < R_{2} $ 就越出了原来的圆  $ \Gamma_{1} $ 外（图 8.4(b)）。于是，级数（8.2）在圆  $ \Gamma_{2} $ 内表一解析函数，设为  $ f_{2}(z) $。则在  $ \Gamma_{1} \cdot \Gamma_{2} $ 内  $ f_{1}(z) = f_{2}(z) $（由惟一性定理推得）。因而， $ \{\Gamma_{2}, f_{2}(z)\} $ 是  $ \{\Gamma_{1}, f_{1}(z)\} $ 的直接解析延拓。

再在  $ \Gamma_{2} $ 内任取一点  $ z_{3} \neq z_{2} $，并在点  $ z_{3} $ 的邻域内把  $ f_{2}(z) $ 展开为幂级数

$$  \sum_{n=0}^{\infty}c_{n}^{(3)}\left(z-z_{3}\right)^{n},   \tag*{(8.4)}$$

其中

 $$ c_{n}^{(3)}=\frac{1}{n!}f_{2}^{(n)}\left(z_{3}\right), $$ 

而  $ f_{2}^{(n)}(z_{3})(n=0,1,2,\cdots) $ 则由级数(8.2)计算之.

<!-- page: 347 -->

设级数(8.4)的收敛圆为  $ \Gamma_{3}: |z-z_{3}| < R_{3} $. 当圆  $ \Gamma_{3} $ 有一部分在  $ \Gamma_{2} $ 的外部时，则又得  $ \{\Gamma_{2}, f(z)\} $ 在  $ \Gamma_{3} $ 内的直接解析延拓（沿着半径从  $ z_{2} $ 到  $ z_{3} $ 的方向）.

用这样的方法，就能得到 $ \{\Gamma_{1}, f_{1}(z)\} $的所有解析延拓（也就得到了 $ \{D, f(z)\} $的所有解析延拓）。换句话说，我们从一个解析函数元素出发，沿所有可能的方向延拓，新的组成部分也向一切可能的方向进行延拓，一直延拓到不能延拓为止。

从上面的讨论,我们还可以看出:如果在一个确定的方向上,有可能进行延拓时,一般来说,这个延拓可以借助于幂级数来实现.

最后，我们还必须指出两点：

（1）由于幂级数的收敛圆周上，至少存在一个和函数的奇点，所以在收敛圆内所定义的解析函数，向任意方向都可以延拓的情形是不可能发生的.

（2）从下面的例 8.4 可见，幂级数的和函数在收敛圆内沿任一方向都不能进行解析延拓的情形也是存在的。

例 8.4 试证: 在单位圆  $ \left|z\right|<1 $ 内的解析函数

 $$ f(z)=\sum_{n=1}^{\infty}z^{2^{n}} $$ 

不能延拓到单位圆周  $ \left|z\right|=1 $ 的外部.

证 级数的收敛半径 R=1，故在单位圆  $ \left|z\right|<1 $ 内  $ f(z) $ 表一解析函数. 以下证明， $ f(z) $ 的奇点稠密于单位圆周  $ \left|z\right|=1 $ 上.

首先证明，当 z 沿半径而趋于 1 时， $ f(z) \to \infty $：命

 $$ z=x,0<x<1, $$ 

则

 $$ f(x)=x^{2}+x^{4}+\cdots+x^{2^{n}}+\cdots>x^{2}+x^{4}+\cdots+x^{2^{n}}, $$ 

故

 $$ \lim_{x\to1}f(x)\geqslant\lim_{x\to1}(x^{2}+x^{2^{2}}+\cdots+x^{2^{n}})=n, $$

<!-- page: 348 -->

由 n 的任意性，故

 $$ \lim_{x\to1}f(x)=+\infty, $$ 

显然, z=1 是  $ f(z) $ 的一个奇点.

其次，由于

 $$ \begin{aligned}f\big(\mathcal{z}\big)}&=\mathcal{z}^{2}+\mathcal{z}^{4}+\cdots+\mathcal{z}^{2^{n}}+\big(\mathcal{z}^{2^{n+1}}+\mathcal{z}^{2^{n+2}}+\cdots\big)\\&=\mathcal{z}^{2}+\mathcal{z}^{4}+\cdots+\mathcal{z}^{2^{n}}+f\big(\mathcal{z}^{2^{n}}\big),\end{aligned} $$ 

故能使

 $$ z^{2^{n}}=1 $$ 

的点 z 均为  $ f(z) $ 的奇点. 即单位圆周上的点

 $$ \mathcal{Z}_{k}=\mathrm{e}^{\frac{2k\pi\mathrm{i}}{2^{n}}} $$ 

 $$ (k=0,1,\cdots,2^{n}-1;n=1,2,\cdots) $$ 

均为  $ f(z) $ 的奇点，这种点稠密于圆周  $ \left|z\right|=1 $ 上。故  $ f(z) $ 不能再向单位圆周  $ \left|z\right|=1 $ 外延拓。

例 8.5 函数  $ \frac{1}{1-z} $ 在原点邻域内可展成幂级数：

 $$ \frac{1}{1-z}=1+z+z^{2}+\cdots+z^{n}+\cdots=\sum_{n=0}^{\infty}z^{n}. $$ 

这个级数的收敛圆为  $ \left|z\right|<1 $。因此，它表示一个在单位圆内的解析函数。

如在单位圆内取一点  $ b \neq 0 $; 则函数  $ \frac{1}{1 - z} $ 在点 b 的某一邻域内可展成幂级数

 $$ \sum_{n=0}^{\infty}\frac{1}{\left(1-b\right)^{n+1}}(z-b)^{n}. $$ 

当  $ b = -\frac{1}{2} $ 时，展开式成为

 $$ \sum_{n=0}^{\infty}\left(\frac{2}{3}\right)^{n+1}\left(z+\frac{1}{2}\right)^{n}, $$

<!-- page: 349 -->

此级数的收敛半径为 $ \frac{3}{2} $，显然这个级数是级数 $ \sum_{n=0}^{\infty}z^{n} $的一个解析

延拓，因为在圆 $ \left|z+\frac{1}{2}\right|<\frac{3}{2} $内确实含有单位圆以外的点（图8.5

的阴影部分）.

当  $ b = + \frac{1}{2} $ 时，展开式成为

 $$ \sum_{n=0}^{\infty}2^{n+1}\left(z-\frac{1}{2}\right)^{n}, $$ 

而它的收敛半径为  $ \frac{1}{2} $，此时 z = +1 为新旧两个收敛圆周的切点，所以是函数  $ \frac{1}{1-z} $ 的奇点.

<div style="text-align: center;"><img src="images/p0349_img_in_image_box_2646_1472_4003_2742.jpg" alt="图 8.5" width="30%" /></div>


事实上，除实轴正方向外，单位圆

<div style="text-align: center;"><div style="text-align: center;">图 8.5</div> </div>


内的解析函数  $ \sum_{n=0}^{\infty} z^{n} $ 可沿其半径的任一方向进行延拓，因为 z=1 是它的惟一奇点.

例 8.6

 $$ f(z)=\frac{1}{1-z^{p}}\qquad(p\neq1, 是一个正整数 ), $$ 

这是一个有理函数，它的奇点就是它的极点：

 $$ \mathcal{z}_{k}=\mathrm{e}^{\frac{2k\pi}{p}\mathrm{i}}(k=0,1,2,\cdots,p-1). $$ 

这些极点(个数总是有限的)以等距离分布在单位圆周  $ \left|z\right|=1 $ 上，所说的距离随 p 的增大而减小.

我们取在原点的展开式

 $$ f(z)=1+z^{p}+z^{2p}+\cdots+z^{np}+\cdots=\sum_{n=0}^{\infty}z^{np} $$ 

及其收敛圆  $ |z| < 1 $ 作为第一个解析函数元素，沿着任何不穿过收敛圆周  $ |z| = 1 $ 上  $ f(z) $ 的极点的曲线（即用幂级数延拓时，收敛圆心都取在此曲线上）都可作解析延拓。

<!-- page: 350 -->

#### §2. 透弧解析延拓、对称原理

在前节中提到的直接解析延拓概念是关于相交区域的.如果两个区域不相交，但有一段公共边界(这是两个区域“紧接”的又一个含义)，我们可以在下列连续延拓原理的基础上，建立透弧直接解析延拓的概念.并指出解析延拓的一个几何方法——对称原理.

### 1. 透弧直接解析延拓

定理 8.2 潘勒韦(Painleve')连续延拓原理 设  $ \{D_{1}, f_{1}(z)\} $ 及  $ \{D_{2}, f_{2}(z)\} $ 为两个解析函数元素，符合于

（1）区域  $ D_{1} $ 与  $ D_{2} $ 不相交，但有一段公共边界，除掉其端点后的开弧记为  $ \Gamma $；

（2） $ f_{1}(z) $ 在  $ D_{1}+\Gamma $ 上连续， $ f_{2}(z) $ 在  $ D_{2}+\Gamma $ 上连续；

（3）沿  $ \Gamma, f_{1}(z) = f_{2}(z) $

则  $ \left\{D_{1}+T+D_{2}, F(z)\right\} $ 也是一个解析函数元素. 其中

 $$ \begin{aligned}F(z)=\left\{\begin{aligned}&f_{1}(z),& 当 z\in D_{1},\\&f_{1}(z)=f_{2}(z),& 当 z\in\Gamma,\\&f_{2}(z),& 当 z\in D_{2}.\end{aligned}\right.\end{aligned} $$ 

证  $ F(z) $ 在区域  $ G = D_{1} + \Gamma + D_{2} $ 内是连续的. 我们来证明：

 $ F(z) $沿着任何一条位于 G 内的周线 C (只要其内部全含于 G)的积分都等于零.

如果 C 全部位于  $ D_{1} $ 或  $ D_{2} $ 内，结果从柯西积分定理立即可推出。如果 C 分属于  $ D_{1} $ 与  $ D_{2} $ (图 8.6)，C 落在  $ D_{1} $ 与  $ D_{2} $ 内的部分分别记为  $ C_{1} $ 与  $ C_{2} $， $ \Gamma $ 落在 C 内部的一段记成  $ \gamma $。根据柯西积分定理

<div style="text-align: center;"><img src="images/p0350_img_in_image_box_2495_4435_4020_5749.jpg" alt="图 8.6" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.6</div> </div>

<!-- page: 351 -->

$$ \int_{C_{1}+\gamma}F(z)\mathrm{d}z=0, $$ 

 $$ \int_{c_{2}+\gamma^{-}}F(z)\mathrm{d}z=0. $$ 

从而

 $$ \begin{aligned}\int_{C}F(z)\mathrm{d}z&=\int_{C_{1}+\gamma}F(z)\mathrm{d}z\\&+\int_{C_{2}+\gamma^{-}}F(z)\mathrm{d}z=0.\end{aligned} $$ 

根据摩勒拉定理,我们得出函数  $ F(z) $ 在区域 G 内是解析的.

故  $ \left\{D_{1}+T+D_{2}, F(z)\right\} $ 是一个解析函数元素.

定义 8.5 满足定理 8.2 条件的两个解析函数元素  $ \{D_{1}, f_{1}(z)\} $， $ \{D_{2}, f_{2}(z)\} $ 称为互为（透弧）直接解析延拓.

在定义 8.4 中，关于相交区域的解析延拓 $ \uwave{\text{链}} $和 $ \uwave{\text{互为(间接)解}} $析延拓的意义，也可代以透弧解析延拓.

### 2. 黎曼－施瓦茨对称原理

##### 定理 8.3 设

(1) D 及  $ D^{*} $ 为 z 平面上两个区域, 分别在上半平面与下半平面, 对于 x 轴对称, 并且它们的边界都包含 x 轴上一条线段 S;

(2)  $ \{D, f(z)\} $ 为解析函数元素,  $ f(z) $ 在  $ D + S $ 上连续且在 S 上取实数值,

则存在一个函数  $ F(z) $ 满足下列条件：

（1） $ F(z) $ 在区域  $ D^{+}S + D^{*} $ 内解析；

(2) 在 D 内  $ F(z) = f(z) $;

(3) 在  $ D^{*} $ 内  $ F(z)=\overline{f(\bar{z})} $.

（即  $ \left\{D^{*}, \overline{f(\overline{z})}\right\} $ 是  $ \left\{D, f(z)\right\} $ 透过弧 S 的直接解析延拓。）

证 在区域  $ D + S + D^{*} $ 内确定一个函数  $ F(z) $ 如下：

 $$ F(z)=\left\{\begin{aligned}&f(z),&\quad 当 z\in D+S,\\&\overline{f(\bar{z})},&\quad 当 z\in D^{*}.\end{aligned}\right. $$

<!-- page: 352 -->

我们现在来证明这个函数  $ F(z) $ 就满足定理的要求.

（1） $ f(z) $ 在区域 D 内解析，在  $ D + S $ 上连续（假设条件）.

(2) $ \overline{f(\bar{z})} $在 $ D^{*} $内解析.事实上,设 $ z_{0} $及z为 $ D^{*} $内二点,则 $ \bar{z}_{0} $及 $ \bar{z} $为D内相应二点,且

 $$ \begin{align*}\lim_{z\to z_{0}}\frac{f(\bar{z})-\overline{f(\bar{z}_{0})}}{z-z_{0}}&=\lim_{z\to z_{0}}\left[\frac{f(\bar{z})-f(\bar{z}_{0})}{\bar{z}-\bar{z}_{0}}\right]\\&=\lim_{\bar{z}\to\bar{z}_{0}}\left[\frac{f(\bar{z})-f(\bar{z}_{0})}{\bar{z}-\bar{z}_{0}}\right]=\overline{f^{\prime}(\bar{z}_{0})}.\end{align*} $$ 

（3） $ \overline{f(\overline{z})} $ 在  $ D^{*} + S $ 上连续. 因设  $ x_{0} $ 为 S 上任一点，则

 $$ \lim_{\substack{z\to x_{0}\\ (z\in D^{*}+S)}}\overline{f(\bar{z})}=\overline{\lim_{\substack{\bar{z}\to x_{0}\\ (\bar{z}\in D+S)}}f(\bar{z})}\overline{\overline{f(x_{0})}}=f(\bar{x}_{0}). $$ 

(4)  $ z \in S $ 时  $ \overline{f(\overline{z})} = f(z) $. 因此时

 $$ z=\bar{z},\overline{f(\bar{z})}=\overline{f(z)}\overline{\overline{( 假设 )}}f(z). $$ 

故由潘勒韦连续延拓原理， $ \left\{D^{*}, \overline{f(\overline{z})}\right\} $ 是  $ \{D, f(z)\} $ 透过 S 的直接解析延拓。因而  $ F(z) $ 在区域  $ D + S + D^{*} $ 内解析。

对称原理可使解析函数的定义区域扩大一倍.下面我们将对称原理引入共形映射,它使我们能够充分地在本质上扩大那类可以用初等函数来作共形映射的区域.

定理 8.4 设(1)D 及  $ D^{*} $ 为 z 平面上的两个区域，分别在上半平面与下半平面，关于 x 轴对称，并且它们边界都包含 x 轴上一条线段 S（如图 8.7）；

<div style="text-align: center;"><img src="images/p0352_img_in_image_box_1048_4830_3354_5775.jpg" alt="图 8.7" width="51%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.7</div> </div>

<!-- page: 353 -->

(2) G 及  $ G^{*} $ 为 w 平面上的两个区域，分别在上半平面与下半平面，关于 u 轴对称，并且它们的边界都包含 u 轴上一条线段 T；

(3) w = f(z) 在 D 内单叶解析，在  $ D + S $ 上连续，且将 D 共形映射成 G，将 S 一一变换成  $ T = f(S) $，

则存在一个函数 w = F(z) 满足下列条件：

(1)  $ w = F(z) $ 在区域  $ D + S + D^{*} $ 内单叶解析，并将区域  $ D + S + D^{*} $ 共形映射成  $ G + T + G^{*} $;

(2) 在 D 内， $ F(z) = f(z) $;

(3) 在  $ D^{*} $ 内,  $ F(z) = \overline{f(\bar{z})} $.

(即 $ \left\{D^{*},\overline{f(\bar{z})}\right\} $是 $ \left\{D,f(z)\right\} $透过弧S的直接解析延拓).

证 接着定理 8.3 的证明，再补充证明  $ F(z) $ 在  $ D + S + D^{*} $ 内单叶，并将  $ D + S + D^{*} $ 共形映射成  $ G + T + G^{*} $.

根据  $ F(z) = f(z)(z \in D) $， $ F(z) $ 在 D 内单叶解析，并将 D 共形映射成 G；根据  $ F(z) = f(z)(z \in S) $， $ F(z) $ 建立起 S 上的点与 T 上的点的一一对应；根据  $ F(z) = \overline{f(\overline{z})}(z \in D^{*}) $， $ F(z) $ 在  $ D^{*} $ 内单叶解析，并将  $ D^{*} $ 共形映射成  $ G^{*} $。

总起来, $ F(z) $在 $ D+S+D^{*} $内单叶解析,并将 $ D+S+D^{*} $共形映射成 $ G+T+G^{*} $.

##### 定理 8.5 （对称原理的一般形式）设（图 8.8）

(1) d 及  $ d^{*} $ 是 z 平面上关于圆弧或直线段 s 对称的两个区域，它们分居于 s 的两侧，且它们边界都包含 s.

<div style="text-align: center;"><img src="images/p0353_img_in_image_box_1126_4852_3323_5819.jpg" alt="图 8.8" width="49%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.8</div> </div>

<!-- page: 354 -->

(2) g 及  $ g^{*} $ 为 w 平面上关于圆弧或直线段 t 对称的两个区域，它们分居于 t 的两侧，且它们边界都包含 t.

(3)  $ w = f_{1}(z) $ 在 d 内单叶解析，在  $ d + s $ 上连续，并将 d 共形映射成 g，把 s 一一地变换成  $ t = f_{1}(s) $，则存在一个函数 w = F(z) 满足下列条件：

(1)  $ w = F(z) $ 在区域  $ d + s + d^{*} $ 内单叶解析，并将区域  $ d + s + d^{*} $ 共形映射成  $ g + t + g^{*} $.

（2）在 d 内  $ F(z)=f_{1}(z) $.

(3) 在  $ d^{*} $ 内  $ F(z) = f_{2}(z) $.

 $ \{d^{*}, f_{2}(z)\} $ 是  $ \{d, f_{1}(z)\} $ 透过弧 s 的直接解析延拓.

#####  $ ^{*} $ 证

为了证明，我们作线性变换

$$  \zeta=\frac{az+b}{cz+e},\quad\omega=\frac{a w+\beta}{\gamma w+\varepsilon}.   \tag*{(8.5)}$$

它们分别将 s 与 t，这样地变为  $ \zeta $ 与  $ \omega $ 平面（即图 8.7 中的 z 与 w 平面）的实轴上的线段 S 与 T，使得区域 d 与 g 分别共形映射成 D 与 G。将 (8.5) 的逆变换

 $$ z=\frac{-e\zeta+b}{c\zeta-a},w=\frac{-\varepsilon\omega+\beta}{\gamma\omega-\alpha} $$ 

代入函数  $ w = f_{1}(z) $ 的两端，使其化为将 D 共形映射成 G 的函数  $ \omega = f_{1}^{*}(\zeta) $.

我们在  $ \zeta $ 平面的区域  $ D^{*} $ 上定义函数

 $$ \omega=f_{2}^{*}\left(\zeta\right)=f_{1}^{*}\left(\overline{\zeta}\right). $$ 

由定理 8.4,  $ \left\{D^{*}, f_{2}^{*}\left(\zeta\right)\right\} $ 是  $ \left\{D, f_{1}^{*}\left(\zeta\right)\right\} $ 透过弧 S 的直接解析延拓.  $ \omega = f_{2}^{*}\left(\zeta\right) $ 将  $ D^{*} $ 共形映射成  $ G^{*} $. 而函数

 $$ \omega=f^{*}\left(\zeta\right)=\left\{\begin{array}{l}{f_{1}^{*}\left(\zeta\right),\zeta\in D,}\\ {f_{2}^{*}\left(\zeta\right),\zeta\in D^{*},}\\ {f_{1}^{*}\left(\zeta\right)=f_{2}^{*}\left(\zeta\right),\zeta\in S.}\end{array}\right. $$

<!-- page: 355 -->

在  $ D + S + D^{*} $ 内单叶解析，并将  $ D + S + D^{*} $ 共形映射成  $ G + T + G^{*} $.

我们将(8.5)代入函数  $ \omega = f_{2}^{*} $ ( $ \zeta $), 换回到变量 z 与 w, 于是在 d 关于 s 对称的区域  $ d^{*} $ 内得到函数  $ w = f_{2}(z) $, 它在  $ d^{*} $ 内单叶解析, 并将  $ d^{*} $ 共形映射成 g 关于 t 对称的区域  $ g^{*} $.

这时，函数

 $$ \begin{aligned}\omega=F(z)=\left\{\begin{matrix}f_{1}(z),z\in d,\\&f_{2}(z),z\in d^{*},\\&f_{1}(z)=f_{2}(z),z\in s.\\&\end{matrix}\right.\end{aligned} $$ 

在区域  $ d + s + d^{*} $ 内单叶解析，并将  $ d + s + d^{*} $ 共形映射成区域  $ g + t + g^{*} $. 其中  $ \{d^{*}, f_{2}(z)\} $ 是  $ \{d, f_{1}(z)\} $ 透过弧 s 的直接解析延拓.

例 8.7 将上半平面从原点起顺着虚轴割开一条长为 h 的割缝，试求此区域到上半平面的共形映射.

解 z 平面上所述区域可以表成  $ D + S + D^{*} $，其中 S 是从 hi 顺着虚轴到  $ \infty $ 的射线。上半 w 平面可以表成  $ G + T + G^{*} $，其中 T 是上半虚轴（图 8.9）。

<div style="text-align: center;"><img src="images/p0355_img_in_image_box_1027_4049_3425_5043.jpg" alt="图 8.9" width="54%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.9</div> </div>


我们要作出一个在 D 内单叶解析，在  $ D + S $ 上连续的函数  $ w = f(z) $ 将 D 共形映射成 G，使 S 一一地变成 T.

就作

$$  z_{1}=z^{2},   \tag*{(8.6)}$$

<!-- page: 356 -->

它在 D 内单叶解析，在  $ D + S $ 上连续，将 D 共形映射成上半  $ z_{1} $ 平面  $ D_{1} $，S 一一地变成负实轴上从  $ -h^{2} $ 到  $ \infty $ 的射线  $ S_{1} $.

再作平移变换

$$  z_{2}=z_{1}+h^{2},   \tag*{(8.7)}$$

它在  $ D_{1} + S_{1} $ 上连续，将  $ D_{1} $ 共形映射成上半  $ z_{2} $ 平面  $ D_{2} $， $ S_{1} $ 一地变成负实轴  $ S_{2} $ （如图 8.10）.

再作

$$  w=\sqrt{z_{2}},   \tag*{(8.8)}$$

它在  $ D_{2} + S_{2} $ 上连续，并将  $ D_{2} $ 共形映射成 G， $ S_{2} $ 一一地变成 T.

将(8.6)、(8.7)及(8.8)依顺序叠合得

 $$ w=\sqrt{z^{2}+h^{2}}, $$ 

它在  $ D + S $ 上连续，将 D 共形映射成 G，并将 S 一一地变成 T.

按对称原理， $ \sqrt{z^{2}+h^{2}} $ 在  $ D+S+D^{*} $ 内的解析延拓将区域  $ D+S+D^{*} $ 共形映射成区域  $ G+T+G^{*} $. 但因  $ \sqrt{z^{2}+h^{2}} $ 本身就在  $ D+S+D^{*} $ 内单叶解析，故所求的一个共形映射函数就是

 $$ w=\sqrt{z^{2}+h^{2}}. $$ 

<div style="text-align: center;"><img src="images/p0356_img_in_image_box_762_3895_3653_5797.jpg" alt="图 8.10" width="65%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.10</div> </div>

<!-- page: 357 -->

#### §3. 完全解析函数及黎曼面的概念

1. 完全解析函数 以前我们所定义的解析函数是局限于一个特定区域的.解析延拓使我们有可能将定义于一个特定区域的解析函数,推广其定义区域,得到在更大区域内解析的函数.

定义 8.6 一个一般解析函数  $ F(z) $ 是由解析函数元素 \{D, f(z)\} 的一个非空集这样组成的：当其非一元集时，任意两个解析函数元素经由一条链而互为解析延拓，其中链的每一环节都是  $ F(z) $ 的一元， $ F(z) $ 的定义区域是各  $ f(z) $ 定义区域之并集（它也是一个区域）。

定义 8.7 一个完全解析函数  $ F(z) $ 是一个一般解析函数，它包含其一解析函数元素的所有解析延拓。 $ F(z) $ 的定义区域 G 称为它的存在区域。G 的边界称为  $ F(z) $ 的自然边界。

根据我们在本章 §1 第 2 段中的论述，可知完全解析函数  $ F(z) $ 的自然边界必为  $ F(z) $ 一切解析函数元素的一切奇点所组成，从而  $ F(z) $ 的自然边界点也就是  $ F(z) $ 的奇点。

一个完全解析函数  $ F(z) $ 显然是不能再扩大的，它可能是单值的（这时，它的存在区域就是通常 z 平面上的区域），也可能是多值的.还可看出，每一个解析函数元素必属于惟一的完全解析函数.

过去讲的孤立奇点(单值性或多值性的)就是函数自然边界上的孤立点.

例 8.8 非常数的整函数的存在区域是 z 平面,  $ z = \infty $ 就是它的自然边界.

例 8.9 函数

 $$ \frac{1}{z-a_{1}}+\frac{1}{z-a_{2}}+\cdots+\frac{1}{z-a_{n}} $$ 

的自然边界是由  $ a_{1}, a_{2}, \cdots, a_{n} $ 等 n 个极点组成；而函数  $ \frac{1}{\sin z} $ 的自

<!-- page: 358 -->

然边界是由无限多个点  $ n\pi(n=0,\pm1,\cdots) $ 及点  $ \infty $ 所组成，在例 8.4 中，我们知道函数

 $$ f(z)=\sum_{n=1}^{\infty}z^{2^{n}} $$ 

就以单位圆周  $ |z|=1 $ 为其自然边界.

2. 单值性定理 设  $ f(z) $ 是区域 D 内的完全解析函数, a, b 是 D 内任意两点,  $ \gamma_{1} $ 和  $ \gamma_{2} $ 是连接 a, b 的两条曲线.  $ f(z) $ 的一个解析函数元素从点 a 出发, 沿  $ \gamma_{1} $ 和  $ \gamma_{2} $ 两条路线进行解析延拓, 如到达点 b 的函数值不同, 也就是说, 如果解析延拓取不同的路线得到不同的解析函数元素, 则函数  $ f(z) $ 就是多值的. 我们先看

例 8.10 设有区域：

 $$ \begin{array}{l}D_{1}:\mid z-1\mid<R,\\ D_{2}:\mid z-\omega\mid<R,\\ D_{3}:\mid z-\omega^{2}\mid<R.\\\quad\omega=e^{\frac{2\pi i}{3}},\\\quad\frac{\sqrt{3}}{2}<R<1.\end{array} $$ 

其中

且

若将解析函数元素  $ \{D_{1},\sqrt{z}\} $ 进行解析延拓  $ (\sqrt{z} $ 已取定一支 $ ) $。从  $ D_{1} $ 到  $ D_{2} $，从  $ D_{2} $ 到  $ D_{3} $，再从  $ D_{3} $ 到  $ D_{1} $，结果所得解析函数元素为  $ \{D_{1},-\sqrt{z}\} $ (图 8.11).

这可以用本章§1、2段幂级数延拓的“圆锥法”来实现，圆锥的各圆圆心可选在一条闭曲线上，这条闭曲线从 $ D_{1} $内的某点a出发，经 $ D_{1} $与 $ D_{2} $的公共区域到 $ D_{2} $，再经 $ D_{2} $与 $ D_{3} $的公共区域到 $ D_{3} $，最后，经 $ D_{3} $与 $ D_{1} $的公共区域又回到 $ D_{1} $的点a.起点a的函数值如为 $ \sqrt{a} $，沿此闭曲线延拓一圈回来后，同一点a的函数值就应改变为 $ -\sqrt{a} $，原因是这条闭曲线包围了原点z=0，a的辐角就要改变 $ 2\pi $.

<!-- page: 359 -->

<div style="text-align: center;"><img src="images/p0359_img_in_image_box_1251_607_3215_2692.jpg" alt="图 8.11" width="44%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.11</div> </div>


另一方面，若将解析函数元素  $ \{D_{1}, -\sqrt{z}\} $ 从  $ D_{1} $ 出发延拓到  $ D_{2} $，从  $ D_{2} $ 延拓到  $ D_{3} $，再从  $ D_{3} $ 回到  $ D_{1} $，结果所得解析函数元素为  $ \{D_{1}, \sqrt{z}\} $。

按这种方式不断延拓，可以看出， $ \sqrt{z} $ 与  $ -\sqrt{z} $ 组成一个二值的完全解析函数，以 z=0 及  $ z=\infty $ 为支点（注意  $ D_{1}, D_{2}, D_{3} $ 无公共部分，但它们含有一条周线围绕原点），其存在区域 D 是个二连通区域.

如果 D 为单连通区域， $ f(z) $ 在 D 内解析，则  $ f(z) $ 就不能像上面那样是多值函数，事实上，魏尔斯特拉斯给出了如下的单值性定理：

定理 8.6 若  $ f(z) $ 在扩充平面上的单连通区域 D 内解析，则  $ f(z) $ 在 D 内单值.

证 设  $ \gamma_{1} $， $ \gamma_{2} $ 是 D 内连接任意两点 a 与 b 的两条简单逐段光滑曲线，使  $ \gamma = \gamma_{1} + \gamma_{2} $ 是 D 内的一条周线.

首先假设周线  $ \gamma = \gamma_{1} + \gamma_{2} $ 不包含 D 的界点于其内部. 由海涅

<!-- page: 360 -->

- 波莱尔覆盖定理，可有有限个圆心在  $ \gamma_{1} $， $ \gamma_{2} $ 上而全部在 D 内的圆足以覆盖  $ \gamma_{1} $ 与  $ \gamma_{2} $。在每个圆内， $ f(z) $ 可以表成泰勒级数。从而  $ f(z) $ 在每个圆内的解析点（圆与 D 的公共部分）为单值。因此  $ \gamma_{1} $， $ \gamma_{2} $ 在每个圆内的弧可以弦来代替。设这些弦所成的折线为  $ P_{1} $， $ P_{2} $，于是  $ \gamma_{1} $， $ \gamma_{2} $ 可以用  $ P_{1} $， $ P_{2} $ 来代替。分多边形  $ P_{1} + P_{2} $ 为若干三角形。如  $ f(z) $ 在  $ P_{1} + P_{2} $ 内为多值，则存在一个三角形  $ T_{1} $， $ f(z) $ 沿  $ T_{1} $ 解析延拓一周得到不同的解析函数元素。将  $ T_{1} $ 最长的一边加以等分，连接等分点与此边的对顶点，得两个三角形。则在此两个三角形中必有一个，命为  $ T_{2} $， $ f(z) $ 沿  $ T_{2} $ 解析延拓一周，将得到不同的解析函数元素。如此继续进行，则得一个三角形序列：

 $$ T_{1}{\sqsupset}T_{2}{\sqsupset}\cdots{\sqsupset}T_{n}{\sqsupset}\cdots $$ 

当 n 无限增加， $ T_{n} $ 缩成 D 内一点  $ \alpha $。由假设  $ f(z) $ 在点  $ \alpha $ 解析，则必在一个圆  $ |z - \alpha| < R $ 内单值解析。因此，只须经过有限次分法，则得一个全含于此圆内的三角形  $ T_{m} $，而  $ f(z) $ 沿  $ T_{m} $ 解析延拓一周，所得的解析函数元素不能为不同，这和  $ f(z) $ 在  $ P_{1} + P_{2} $ 内为多值相矛盾。

其次，假设  $ \gamma $ 包含区域 D 的一个界点于其内部。由于 D 是单连通区域，则  $ \gamma $ 必包含 D 的全部界点于其内部。因此  $ f(z) $ 在点  $ z = \infty $ 的邻域内解析。从而存在一个以原点为心的圆周 C，包含  $ \gamma = \gamma_{1} + \gamma_{2} $ 于其内部， $ f(z) $ 在  $ z = \infty $ 的邻域内的洛朗展式在圆周 C 的外部及其上单值解析。用线段  $ aa' $ 及  $ bb' $ 分别将点 a, b 连接到圆周 C 上，则得两条闭路  $ L_{1}: a'a\gamma_{1}bb'C_{1}a' $ 及  $ L_{2} $:  $ a'ay_{2}bb'C_{2}a' $.  $ L_{1} $ 与  $ L_{2} $ 各不包含 D 的界点于其内部（图 8.12）。由圆周 C 的定义， $ C_{1}, C_{2} $ 两条路线对解析延拓是等价的，即是  $ f(z) $ 从  $ a' $ 出发分别



<div style="text-align: center;"><img src="images/p0360_img_in_image_box_2548_4376_4033_5759.jpg" alt="图 8.12" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.12</div> </div>

<!-- page: 361 -->

沿  $ C_{1} $,  $ C_{2} $ 解析延拓达到  $ b^{\prime} $ 的值是相同的. 由将上面第一步的证明分别应用到闭路  $ L_{1} $ 与  $ L_{2} $ 上, 则得  $ a^{\prime}ay_{1}bb^{\prime} $ 与  $ C_{1} $ 等价;  $ a^{\prime}ay_{2}bb^{\prime} $ 与  $ C_{2} $ 等价; 因此  $ \gamma_{1} $ 与  $ \gamma_{2} $ 是等价的. 所以定理成立.

定义 8.8 若围绕以  $ z_{0} $ 为心的充分小的圆周，延拓一完全解析函数  $ F(z) $ 的解析函数元素  $ \{D_{1}, f_{1}(z)\} $，当变点回转至原来的位置时，若函数值与原来的值相异，则称此  $ z_{0} $ 点为此函数  $ F(z) $ 的支点。具有支点的完全解析函数  $ F(z) $ 称为多值解析函数。

尽管  $ F(z) $ 是一个多值函数，但是如果我们可以限制 z 的变动区域（单连通的），使得当 z 点在这个区域内沿任意周线变动一圈，函数值连续变动回到原来的值，那么我们就说这个区域内所有对应的函数值（即这个区域的像点集）就组成  $ F(z) $ 的一个单值解析分支（如图 2.4 的各  $ T_{k} $ 及图 2.10 的各  $ B_{k} $）。

支点是多值性奇点. 凡多值解析函数的每一单值分支也可以有单值性奇点——可去奇点、极点、本质奇点以及非孤立的奇点. 但一点若为某一支的单值性奇点, 则不必为另一支的单值性奇点.

例如

 $$ \frac{1}{z}\ln\frac{1}{1-z}=\frac{1}{z}\left(z+\frac{z^{2}}{2}+\frac{z^{3}}{3}+\cdots\right),\left(0<\mid z\mid<1\right) $$ 

 $ z=0 $ 为此支的可去奇点（解析点），但为其他每一支

 $$ \begin{aligned}\frac{1}{z}\Big[\left(z+\frac{z^{2}}{2}+\frac{z^{3}}{3}+\cdots\right)+2k\pi\mathrm{i}\Big]\\ (k=\pm1,\pm2,\cdots)\end{aligned} $$ 

的一阶极点.

3. 黎曼面概念 设  $ w = F(z) $ 是多值解析函数，即具有支点的完全解析函数，则对其存在区域中 z 的一个值，w 有多个值和它对应。黎曼采取一种方法，使 w 的值和 z 的值成一一对应。他创造一种模型（称为黎曼面）代替通常的 z 平面。利用黎曼面，可以使以前所说的解析延拓的过程，多值解析函数概念本身、分支、支点及支割线的概念，在几何上有了明显的表示和说明。更重要的

<!-- page: 362 -->

是，可以使多值完全解析函数  $ F(z) $ 成为其黎曼面上的单值解析函数（这时， $ F(z) $ 的存在区域就是一个推广了的区域，即黎曼面）。于是，单值解析函数的理论便可以对它应用了。因此，由于函数多值性所引起的复杂性，利用几何方法可以消除掉。

下面我们举几个简单的例子来讨论黎曼面.一般对于多值解析函数,要用若干叶片来适当地“粘合”成一个黎曼面的工作是相当复杂的,并且需要相当的技巧.

例 8.11 函数  $ w = z^{\frac{1}{2}} $ 的黎曼面.

解 由于对 z 平面上每一个异于零的点，此函数有两个值和它相对应；如对不同函数值的相同的点 z 能加以区别，就能满足我们的要求.

令  $ z = re^{i\theta} $，于是相同的点 z 可以不同的  $ \theta $ 来决定，从而不同的函数值可用不同的  $ \theta $ 来规定。因当 z 绕原点一周，w 的值由  $ \sqrt{z} $ 变为  $ -\sqrt{z} $；当 z 再绕原点一周， $ -\sqrt{z} $ 又变为  $ \sqrt{z} $。所以如  $ \sqrt{z} $ 相当于  $ 0 < \theta < 2\pi $，则  $ -\sqrt{z} $ 相当于  $ 2\pi < \theta < 4\pi $。现在设想两个 z 平面相重叠，原点的位置与实轴的方向都相同。在上的平面用  $ M_{0} $ 表示，相当于  $ 0 < \theta < 2\pi $；在下的平面用  $ M_{1} $ 表示，相当于  $ 2\pi < \theta < 4\pi $。由于 z=0 及 z= $ \infty $ 是 w= $ z^{\frac{1}{2}} $ 的两个支点，我们现在可以选正实轴为支割线，将两个平面各沿正实轴割开，使 z 分别在  $ M_{0} $ 及  $ M_{1} $ 上不能越过支割线在同一平面上变动。再沿支割线使  $ M_{0} $ 的下岸 ( $ \theta = 2\pi $) 与  $ M_{1} $ 的上岸 ( $ \theta = 2\pi $) 粘合，并使  $ M_{1} $ 的下岸 ( $ \theta = 4\pi $) 与  $ M_{0} $ 的上岸 ( $ \theta = 0 $) 粘合。这样的模型就是 w= $ z^{\frac{1}{2}} $ 的黎曼面（如图 8.13 (a)），两叶在截口处互相交叉，其在支割线处的垂直纵截面如图 8.13 (b).

当点 z 在黎曼面的  $ M_{0} $ 叶上，从正实轴上一点出发，围绕支点 z=0 以反时针方向连续变动两圈时，辐角  $ \theta $ 先由 0 增至  $ 2\pi $，并由叶片  $ M_{0} $ 进入叶片  $ M_{1} $，在后一叶片  $ M_{1} $ 中， $ \theta $ 再由  $ 2\pi $ 增至  $ 4\pi $。当

<!-- page: 363 -->

<div style="text-align: center;"><img src="images/p0363_img_in_image_box_724_516_1898_1211.jpg" alt="(a)" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0363_img_in_image_box_656_1439_1951_1744.jpg" alt="(b)" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><img src="images/p0363_img_in_image_box_2442_592_3819_1824.jpg" alt="图 8.13" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.13</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 8.14</div> </div>


点 z 再继续转动时，它仍回到叶片  $ M_{0} $ 上（如图 8.14）。在  $ M_{0} $ 上， $ \theta $ 的值可以认为是由  $ 4\pi $ 增到  $ 6\pi $，或由 0 增到  $ 2\pi $，对于函数值没有影响。余可类推。这样一来，函数  $ w = z^{\frac{1}{2}} $ 就是黎曼面上的单值函数了。只是在支割线处，两个叶片的点需要设法去判别。

 $ \uwave{\text{应该注意的是}} $:要想由以上的描述,把黎曼面按通常办法具体地制作出来是办不到的.因为当先把叶片 $ M_{0} $的截口的下岸与 $ M_{1} $截口的上岸粘合以后,再把 $ M_{1} $的下岸与 $ M_{0} $的上岸粘合就无法进行,因为中间已有一个粘合好的平面存在着.尽管如此,我们仍然要想像它们是粘合起来了.

这黎曼面的叶片  $ M_{0} $ 的像是上半 w 平面，而叶片  $ M_{1} $ 的像是下半 w 平面。因为

 $$ \begin{array}{c}w_{k}=\sqrt{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{2}}=\sqrt{r}\mathrm{e}^{\mathrm{i}\frac{\theta_{0}+2k\pi}{2}},\\0\leqslant\theta_{0}<2\pi,k=0,1,\end{array} $$ 

在 $ M_{0} $上

 $$ 0<\frac{\theta}{2}<\pi, $$ 

在 $ M_{1} $上

 $$ \pi<\frac{\theta}{2}<2\pi. $$

<!-- page: 364 -->

每个叶片上所确定的函数都是单值解析的，并可连续到粘合的边界，在粘合的边界上它们是等值的。于是，它们的一个就是另一支穿过支割线的解析延拓（由本章的潘勒韦原理可见）。因此，黎曼面上点的单值函数  $ w = z^{\frac{1}{2}} $ 在除去支点 z = 0 及  $ z = \infty $ 外，到处都是解析的。

例 8.12 函数  $ w=\sqrt[n]{z} $ (n 是正整数, n>2) 的黎曼面.

类似上例的讨论,它的黎曼面是由 n 个沿着支割线正实轴割开的 z 平面粘合而成的,仍只以 z=0 及 z= $ \infty $ 为支点.

令  $ z = re^{i\theta} $，则

 $$ \begin{array}{r}{\omega_{k}=\sqrt[n]{r}\mathrm{e}^{\mathrm{i}\frac{\theta_{0}+2k\pi}{n}},}\end{array} $$ 

 $$ 0\leqslant\theta_{0}<2\pi,k=0,1,\cdots,n-1, $$ 

图 8.15 是 n=4 的情形.

<div style="text-align: center;"><img src="images/p0364_img_in_image_box_444_3115_3916_4354.jpg" alt="图 8.15" width="78%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.15</div> </div>


例 8.13 函数  $ w = \mathrm{Ln} z $ 的黎曼面.

解 令  $ z = r e^{i\theta} $，则

 $$ \begin{aligned}\varpi_{k}&=(\ln z)_{k}=\ln r+\mathrm{i}(\theta_{0}+2k\pi)\\&0\leqslant\theta_{0}<2\pi,k=0,\pm1,\cdots\end{aligned} $$ 

仍只以 z=0 及  $ z=\infty $ 为支点，取正实轴为支割线，其黎曼面含有无穷多叶（图 8.16 左）. 其在支割线处的垂直纵截面如图 8.16 右.

<!-- page: 365 -->

<div style="text-align: center;"><img src="images/p0365_img_in_image_box_578_591_3823_1868.jpg" alt="图 8.16" width="73%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.16</div> </div>


上面三个例题是应用透弧解析延拓制作  $ w=\sqrt{z} $ 及  $ w=\mathrm{Ln}z $ 的黎曼面，当然也可应用相交区域的直接解析延拓制作它们的黎曼面.

例 8.14 函数  $ \sqrt[3]{(z-a)(z-b)}(a\neq b) $ 的黎曼面.

解 函数  $ \sqrt[3]{(z-a)(z-b)} $ 以 z=a, z=b 及  $ z=\infty $ 为支点. 从 a 到 b 连接直线段, 从 b 到  $ \infty $ 连接任一射线 (不通过 a) 作为支割线. 这样割开 z 平面后, 可以分出三个单值分支

 $$ f_{k}\left(z\right)=\omega^{k}f_{0}\left(z\right),k=0,1,2, $$ 

其中  $ \omega = e^{\frac{2\pi i}{3}} $， $ f_{0}(z) $ 为  $ \sqrt[3]{(z-a)(z-b)} $ 的一个确定支.

现将三张平面  $ M_{k} $， $ (k=0,1,2) $ 均按前述方法割破，各分支  $ f_{k}(z) $ 分别在  $ M_{k} $ 上是单值的，但在割线两岸之值不同。在  $ \overrightarrow{ab} $ 左岸（顺着 a 到 b 的方向）取值为  $ f_{0}(z) $， $ f_{1}(z) $， $ f_{2}(z) $ 时连续变动到右岸，由于绕 a 转了一周的缘故，增加了一个因子  $ \omega = e^{\frac{2\pi i}{3}} $，就对应取值为  $ f_{1}(z) $、 $ f_{2}(z) $、 $ f_{0}(z) $；在  $ \overrightarrow{b\infty} $ 左岸取值为  $ f_{0}(z) $， $ f_{1}(z) $， $ f_{2}(z) $ 时连续变动到右岸，由于绕 a，b 两点同时转了一周的缘故，增加了一个因子  $ \omega^{2} = e^{\frac{4\pi i}{3}} $，就对应取值为  $ f_{2}(z) $， $ f_{0}(z) $， $ f_{1}(z) $。即前者各分支构成以下置换：

<!-- page: 366 -->

$$ \left\{\begin{matrix}f_{0}(z)&f_{1}(z)&f_{2}(z)\\ f_{1}(z)&f_{2}(z)&f_{0}(z)\end{matrix}\right\} $$ 

后者各分支构成以下置换：

 $$ \left\{\begin{matrix}f_{0}(z)&f_{1}(z)&f_{2}(z)\\ f_{2}(z)&f_{0}(z)&f_{1}(z)\end{matrix}\right\} $$ 

将三个叶片叠起来，并粘合那些取值相同的各岸，即得所求的黎曼面.图8.17表示在割线处的粘合法.

黎曼面的最大优点不仅使 w 平面上的点和 z 平面上的点建立一一对应，而且可使 z 平面上的连续曲线和 w 平面上的连续曲线成对应. 利用黎曼面，所有关于单值函数的性质都可以推广到多值函数.

<div style="text-align: center;"><img src="images/p0366_img_in_image_box_2558_2026_3986_2969.jpg" alt="图 8.17" width="32%" /></div>


设  $ f(z) $ 是定义于黎曼面上的函

<div style="text-align: center;"><div style="text-align: center;">图 8.17</div> </div>


数，如 z = a 是  $ f(z) $ 的解析点，则在 a 的一个邻域内， $ f(z) $ 可以展开为泰勒级数。其收敛圆可能有一部分在黎曼面的某一叶上，而另一部分则在与之粘合的另一叶上，但支点不能在收敛圆之内。

最后，我们还必须指出：一个多值解析函数与代表多个函数的一个表达式是有区别的。例如，函数  $ w = \sqrt{z^{2}} $ 相当于  $ w = +z $ 和  $ w = -z $，而这两个单值解析函数不是互为解析延拓的。所以  $ w = \sqrt{z^{2}} $ 仅是表示两个单值解析函数  $ w = +z $ 与  $ w = -z $ 的一个表达式。

####  $ ^{*} $§4. 多角形区域的共形映射

本节我们将介绍在实际构成共形映射时起着很大作用的一个

方法.它在应用上特别重要,因为它使我们能够写出一个函数(固

然,一般地讲,只能写成积分的形状),把上半平面共形映射成预先

<!-- page: 367 -->

给定的一个多角形区域.

### 1. 克里斯托费尔（Christoffel）－施瓦茨变换

定理 8.7 设(1) $ P_{n} $为有界 n 角形，其顶点为  $ A_{1}, A_{2}, \cdots, A_{n} $，其顶角为  $ \alpha_{1}\pi, \alpha_{2}\pi, \cdots, \alpha_{n}\pi $.

 $$ (0<\alpha_{j}<2,\quad j=1,2,\cdots,n) $$ 

（2）函数  $ w = f(z) $ 将上半平面  $ \mathrm{Im} z > 0 $ 共形映射成  $ P_{n} $.

(3) z 平面实轴上对应于 w 平面多角形  $ P_{n} $ 的顶点 A, 的那些点  $ a_{j} $:

 $$ -\infty<a_{1}<a_{2}<\cdots<a_{j}<\cdots<a_{n}<+\infty $$ 

都是已知的.则

$$  f(z)=C\int_{z_{0}}^{z}\left(z-a_{1}\right)^{a_{1}-1}(z-a_{2})^{a_{2}-1}\cdots(z-a_{n})_{.}^{a_{n}-1}\mathrm{d}z+C_{1},   \tag*{(8.9)}$$

其中  $ z_{0} $，C 与  $ C_{1} $ 是三个复常数.

注意，显然有

$$  \sum_{j=1}^{n}\alpha_{j}=n-2.   \tag*{(8.10)}$$

(8.9)的逆变换  $ z = f^{-1}(w) $ 将 w 平面上的单连通区域多角形  $ P_{n} $ 共形映射成标准区域上半 z 平面.

 $ ^{*} $ 证 根据黎曼存在惟一性定理，存在有而且只有一个函数

 $$ w=f(z), $$ 

它将上半 z 平面共形映射成 w 平面上的有界 n 角形  $ P_{n} $ (图 8.18)，而且将实轴上的三个定点（例如， $ a_{1}, a_{2} $ 与  $ a_{3} $）变成  $ P_{n} $ 边界上的三个任意点，例如顶点  $ A_{1}, A_{2}, A_{3} $.

先假设这个函数是我们已知的，尤其是已知 x 轴上与 n 角形的顶点  $ A_{j} $ 对应的点点  $ a_{j}, j = 4, 5, \cdots $，现在来求它的解析式.

因为在 x 轴的任何一段  $ (a_{j}, a_{j+1}) $ 上，函数  $ w = f(z) $ 取直线段  $ A_{j}A_{j+1} $ 上的值，所以对于它可以应用对称原理，因而它可以越

<!-- page: 368 -->

<div style="text-align: center;"><img src="images/p0368_img_in_image_box_542_584_3860_1909.jpg" alt="图 8.18" width="74%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.18</div> </div>


过这条线段而解析延拓到下半平面  $ \mathrm{Im}\ z<0 $. 这个解析延拓将下半平面共形映射为与  $ P_{n} $ 关于线段  $ A_{j}A_{j+1} $ 对称的 n 角形  $ P'_{n} $. 它又可以越过任意线段  $ (a'_{j}, a'_{j+1}) $ 而解析延拓到上半平面，而且这个解析延拓将上半平面共形映射成与  $ P'_{n} $ 关于线段  $ A'_{j}A'_{j+1} $ 对称的 n 角形  $ P'_{n} $.

我们可以想像:我们把所有可能的上面所描述的那种解析延拓[在特别情形,越过包含点 $ z=\infty $的线段 $ (a_{n},a_{1}) $都作过了]作了任意多次.结果得到无穷多值完全解析函数 $ w=F(z) $,原来的解析函数 $ w=f(z) $是它的一个单值解析分支.

注意，这个函数的任意两个在上半 z 平面中的单值解析分支  $ w = f^{*}(z) $ 与  $ w = f^{**}(z) $ 由一个极为简单的关系式相互关联着。事实上，这两个分支，按我们的作法，由偶数次越过  $ (a_{j}, a_{j+1}) $ 的解析延拓互相得到，而且将上半 z 平面分别共形映射为  $ n' $ 角形  $ P_{n}^{*} $ 与  $ P_{n}^{**} $。 $ P_{n}^{*} $ 与  $ P_{n}^{**} $ 由偶数次关于边的对称变换可以互相得出。又因每一对称变换都可化为某一平移与旋转，所以多角形  $ P_{n}^{*} $ 与  $ P_{n}^{**} $ 一个由另外一个用平移与旋转相互得出。由此推出：在上半 z 平面上

$$  f^{*}\ast(z)\equiv\mathrm{e}^{\mathrm{i}\beta}f^{*}(z)+b,   \tag*{(8.11)}$$

其中  $ \beta $ 是确定旋转的实常数，而 b 是确定平移的复常数。同样的

<!-- page: 369 -->

结论对  $ F(z) $ 在下半 z 平面上的任意两个单值解析分支也成立.

进一步，函数

 $$ \varphi(z)=\frac{f^{\prime \prime}(z)}{f^{\prime}(z)} $$ 

在上半 z 平面是解析的，因由假设  $ w = f(z) $ 必是单叶解析的，从而  $ f'(z) \neq 0 $（在上半 z 平面）。又， $ \varphi(z) $ 对于  $ f(z) $ 的所有可能的解析延拓都保持是单值的。事实上，无论我们取  $ F(z) $ 的哪两个分支，由（8.11）都可以推出

 $$ \begin{aligned}&f^{**\prime}(z)=\mathrm{e}^{\mathrm{i}\beta}f^{*\prime}(z),\\&f^{**\prime\prime}(z)=\mathrm{e}^{\mathrm{i}\beta}f^{*\prime\prime}(z),\\&\frac{f^{*\prime\prime}(z)}{f^{*\prime\prime}(z)}=\frac{f^{*\prime\prime}(z)}{f^{*\prime}(z)},\end{aligned} $$ 

即  $ \varphi(z) $ 在任意点 z 的值与  $ F(z) $ 的分支的选取无关.

这样，我们可以断言：函数  $ \varphi(z) $ 与它的解析延拓（我们用同一记号来表示它们）在扩充 z 平面上除点  $ z = a_{j} $ ( $ j = 1, 2, \cdots, n $) 以外的所有点上都是单值解析的。（为什么？请读者思考）。我们现在来说明  $ \varphi(z) $ 在这些点  $ z = a_{j} $ ( $ j = 1, 2, \cdots, n $) 上的性质。用  $ a_{j}\pi $ 表示 n 角形  $ P_{n} $ 在顶点  $ A_{j} $ 即 w，的角  $ (0 < a_{j} < 2) $，并来考察变量

 $$ \omega=(\omega-\omega_{j})^{\frac{1}{a_{j}}} $$ 

的辅助平面. 显然, 过渡到  $ \omega $ 平面后, n 角形  $ P_{n} $ 的角“被弄平”(图 8.19), 因而对于将点  $ z = a_{j} $ 的某一个半邻域共形映射为  $ \omega = 0 $ 的半邻域(图 8.19)的复合函数

 $$ \omega=\omega(z)=\left[f(z)-w_{j}\right]^{\frac{1}{a_{j}}} $$ 

<div style="text-align: center;"><img src="images/p0369_img_in_image_box_1163_4887_3253_5919.jpg" alt="图 8.19" width="47%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.19</div> </div>

<!-- page: 370 -->

我们可应用对称原理. 所以它可以解析延拓于  $ a_{j} $ 的整个邻域，而且在此邻域内可以展成泰勒级数：

$$  \begin{aligned}\omega(z)&=\left[f(z)-w_{j}\right]^{\frac{1}{a_{j}}}\\&=c_{1}\left(z-a_{j}\right)+c_{2}\left(z-a_{j}\right)^{2}+\cdots\end{aligned}   \tag*{(8.12)}$$

其中  $ c_{0}=\omega(a_{j})=0 $; 但  $ c_{1}=\omega'(a_{j})\neq0 $, 因为  $ \omega(z) $ 在 a_{j} 点邻域内单叶解析.

由（8.12），我们进一步得到

 $$ f(z)=w_{j}+(z-a_{j})^{a_{j}}\left[c_{1}+c_{2}(z-a_{j})+\cdots\right]^{a_{j}},c_{1}\neq0 $$ 

但因为方括号的  $ a_{j} $ 次幂在  $ a_{j} $ 的邻域内是解析的（由一般幂函数的意义，再由方括号本身当  $ z = a_{j} $ 时不为 0 即可推出），所以它本身可展为  $ (z - a_{j}) $ 的幂级数. 于是，我们有

 $$ \begin{aligned}{f(z)}&{{}=\mathcal{w}_{j}+\left(z-a_{j}\right)^{a_{j}}\left[c_{1}^{\prime}+c_{2}^{\prime}(z-a_{j})+\cdots\right]}\\ {}&{{}=\mathcal{w}_{j}+c_{1}^{\prime}(z-a_{j})^{a_{j}}+c_{2}^{\prime}(z-a_{j})^{a_{j}+1}+\cdots.}\\ \end{aligned} $$ 

由此而得

 $$ \begin{align*}\varphi(z)&=\frac{f^{\prime}(z)}{f^{\prime}(z)}=\frac{(a_{j}-1)\alpha_{j}c_{1}^{\prime}(z-a_{j})^{a_{j}-2}+\cdots}{\alpha_{j}c_{1}^{\prime}(z-a_{j})^{a_{j}-1}+\cdots}\\&=\frac{1}{z-a_{j}}\cdot\frac{(a_{j}-1)\alpha_{j}c_{1}^{\prime}+\cdots}{\alpha_{j}c_{1}^{\prime}+\cdots},\end{align*} $$ 

其中第二个因子表示在点  $ z = a_{j} $ 解析的函数，因而它在  $ z = a_{j} $ 的邻域内可以展成

 $$ \left(\alpha_{j}-1\right)+c_{1}^{^{\prime \prime}}(z-a_{j})+c_{2}^{^{\prime \prime}}(z-a_{j})^{2}+\cdots. $$ 

所以

 $$ \begin{align*}\varphi\left(z\right)&=\frac{1}{z-a_{j}}\big[\left(\alpha_{j}-1\right)+c_{1}^{^{\prime \prime}}\left(z-a_{j}\right)+c_{2}^{^{\prime \prime}}\left(z-a_{j}\right)^{2}+\cdots\big]\\&=\frac{\alpha_{j}-1}{z-a_{i}}+c_{1}^{^{\prime \prime}}+c_{2}^{^{\prime \prime}}\left(z-a_{j}\right)+\cdots,\end{align*} $$ 

这是  $ \varphi(z) $ 在 z = a; 的去心邻域内的洛朗展开式. 由此可以推得：函数  $ \varphi(z) $ 在 z = a; 有一阶极点，留数等于  $ \alpha, -1 $.

<!-- page: 371 -->

这样，函数  $ \varphi(z) $ 在扩充 z 平面上只有 n 个一阶极点  $ a_{j}(j=1,2,\cdots,n) $. 由  $ \varphi(z) $ 减去其所有的主要部分，我们就得到函数

$$  \psi(z)=\varphi(z)-\frac{a_{1}-1}{z-a_{1}}-\frac{a_{2}-1}{z-a_{2}}-\cdots-\frac{a_{n}-1}{z-a_{n}},   \tag*{(8.13)}$$

它在整个扩充 z 平面上是解析的，由第五章习题(一)9 的刘维尔定理，可知  $ \psi(z) $ 必是常数.

函数  $ f(z) $ 在点  $ z=\infty $ 是解析的 [因为  $ z=\infty $ 是线段  $ (a_{n}, a_{1}) $ 的内点]，由此，在  $ z=\infty $ 的邻域内

$$  f(z)=c_{0}+\frac{c_{-p}}{z^{p}}+\frac{c_{-p-1}}{z^{p+1}}+\cdots,   \tag*{(8.14)}$$

其中  $ c_{-p} $ 是  $ f(z) $ 的洛朗展开式的第一个不等于零的系数. 由 (8.14) 得: 在  $ z = \infty $ 的邻域内

 $$ \begin{align*}\varphi(z)&=\frac{f^{\prime}(z)}{f^{\prime}(z)}=\frac{p(p+1)\frac{c-p}{z^{p+2}}+\cdots}{-\frac{p c_{-p}}{z^{p+1}}+\cdots}\\&=\frac{1}{z}\cdot\frac{p(p+1)c_{-p}+\cdots}{-p c_{-p}+\cdots}=-\frac{p+1}{z}+\cdots,\end{align*} $$ 

由此可见  $ \varphi(\infty)=0 $. 但因在(8.13)中当  $ z=\infty $ 时所有其余的项都变成零, 所以  $ \psi(\infty) $ 也变成零, 即  $ \psi(z)\equiv0 $. 这样,

 $$ \varphi(z)=\frac{\mathrm{d}}{\mathrm{d}z}\ln f^{\prime}(z)=\frac{a_{1}-1}{z-a_{1}}+\frac{a_{2}-1}{z-a_{2}}+\cdots+\frac{a_{n}-1}{z-a_{n}}. $$ 

然后，沿上半 z 平面中的任意路线积分，则得

 $$ \begin{align*}\ln f^{\prime}(z)=&(\alpha_{1}-1)\ln(z-a_{1})+(\alpha_{2}-1)\ln(z-a_{2})+\cdots\\&+(\alpha_{n}-1)\ln(z-a_{n})+\ln C.\end{align*} $$ 

这里，右边的  $ \ln $ 表示对数的主值，而左边则表示它的对应值，因而去对数，我们就得到共形映射的导函数的式子

 $$ f^{\prime}(z)=C(z-a_{1})^{a_{1}-1}(z-a_{2})^{a_{2}-1}\cdots(z-a_{n})^{a_{n}-1}. $$ 

也沿上半 z 平面中任意路线来积分上式，则得所求的克里斯托费

<!-- page: 372 -->

尔－施瓦茨积分公式(8.9).

(8.9)是在这样的假设下得到的:即实轴上的经过共形映射后与多角形  $ P_{n} $ 的顶点对应的点  $ a_{1}, a_{2}, \cdots, a_{n} $ 是已知的,但应用问题只给出多角形  $ P_{n} $ 的顶点,而点  $ z = a_{j} (j = 1, 2, \cdots, n) $ 是不知道的.按共形映射的黎曼存在定理,有三个这样的点(例如  $ a_{1}, a_{2} $ 与  $ a_{3} $)是我们可以任意给定的,而其余的点  $ a_{j} (j = 4, 5, \cdots, n) $ 以及常数 C 与  $ C_{1} $ 应当由问题的条件来决定(常数  $ z_{0} $ 也可任意选定).这种情况造成了利用克里斯托费尔－施瓦茨积分的主要困难.

2. 退化情形 首先,由于线性变换的保圆周性及定义 7.3,我们易得:

定理 8.8 两直线在无穷远点的交角，等于它们在第二交点（有限点）的交角反号.

证 设  $ L_{1}, L_{2} $ 是从无穷远点出发的两条射线，为明了起见，

还设它们在有限点  $ \xi_{0} (\xi_{0} \neq 0) $ 相交。通过反演变换  $ w = \frac{1}{z} $ 后，得到的像曲线为经过 w = 0 的两条圆弧  $ \Gamma_{1} $ 及  $ \Gamma_{2} $，于是其第二交点为  $ w = \frac{1}{\xi_{0}} $。圆弧  $ \Gamma_{1} $ 及  $ \Gamma_{2} $ 在两交点处的交角必互为相反数（图 8.20）。再由  $ w = \frac{1}{z} $ 在点  $ \xi_{0} $ 保角，又由定义 7.3， $ w = \frac{1}{z} $ 在  $ z = \infty $ 处保角，定理就得到证明。

<div style="text-align: center;"><img src="images/p0372_img_in_image_box_582_4605_3822_5782.jpg" alt="图 8.20" width="72%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.20</div> </div>

<!-- page: 373 -->

其次，上面定理 8.7 的下列两个退化情形是很有用的：

（1）n 角形  $ P_{n} $ 有一个顶点是无穷远点的像. 即  $ a_{1}, a_{2}, \cdots, a_{n} $ 中有一个例如  $ a_{n} = \infty $.

为了要把这种情形化成上面定理的情形,我们作一个分式线性变换

$$  \zeta=-\frac{1}{z}+a_{n}^{\prime}   \tag*{(8.15)}$$

把上半平面  $ \mathrm{Im} z > 0 $ 共形映射成上半平面  $ \mathrm{Im} \zeta > 0 $，且把点  $ a_{1} $， $ a_{2} $， $ \cdots $， $ a_{n} = \infty $ 分别变成有限点  $ a_{1}^{\prime} $， $ a_{2}^{\prime} $， $ \cdots $， $ a_{n}^{\prime} $（见下面注）.

应用公式(8.9)，我们得出

 $$ \begin{align*}\varpi&=C^{\prime}\int_{\zeta_{0}}^{\zeta}\left(\zeta-a_{1}^{\prime}\right)^{a_{1}-1}\left(\zeta-a_{2}^{\prime}\right)^{a_{2}-1}\cdots\left(\zeta-a_{n}^{\prime}\right)^{a_{n}-1}\mathrm{d}\zeta+C_{1}^{\prime}\\&=C^{\prime}\int_{z_{0}}^{z}\left(a_{n}^{\prime}-a_{1}^{\prime}-\frac{1}{z}\right)^{a_{1}-1}\left(a_{n}^{\prime}-a_{2}^{\prime}-\frac{1}{z}\right)^{a_{2}-1}\cdots\\&\quad\cdot\left(-\frac{1}{z}\right)^{a_{n}-1}\frac{\mathrm{d}z}{z^{2}}+C_{1}^{\prime}.\end{align*} $$ 

利用(8.10)经过简单的变换,我们得到

 $$ \begin{align*}\varpi&=C^{\prime}\int_{z_{0}}^{z}\left[(a_{n}^{\prime}-a_{1}^{\prime})z-1\right]^{a_{1}-1}\left[(a_{n}^{\prime}-a_{2}^{\prime})z-1\right]^{a_{2}-1}\cdots\\&\left[(a_{n}^{\prime}-a_{n-1}^{\prime})z-1\right]^{a_{n-1}-1}(-1)^{a_{n}-1}\frac{\mathrm{d}z}{z^{a_{1}+a_{2}+\cdots+a_{n}-n+2}}+C_{1}^{\prime}\\&=C\int_{z_{0}}^{z}\left(z-a_{1}^{0}\right)^{a_{1}-1}(z-a_{2}^{0})^{a_{2}-1}\cdots(z-a_{n-1}^{0})^{a_{n-1}-1}\mathrm{d}z+C_{1},\end{align*} $$ 

其中  $ a_{j}^{0}=\frac{1}{a_{n}-a_{j}}(j=1,2,\cdots,n-1) $ 是实常数. 为简单起见, 我们将  $ a_{j}^{0} $ 就记成  $ a_{j}(j=1,2,\cdots,n-1) $, 于是公式 (8.9) 就退化成下列公式

 $$ \mathcal{w}=C\int_{z_{0}}^{z}\left(z-a_{1}\right)^{a_{1}-1}(z-a_{2})^{a_{2}-1}\cdots(z-a_{n-1})^{a_{n-1}-1}\mathrm{d}z+C_{1}. $$ 

因此,如果 n 角形  $ P_{n} $ 的那些顶点中,有一顶点与无穷远点相

<!-- page: 374 -->

应，则在公式(8.9)中就丢掉那个关于这个顶点的因子.

在实际应用上，可以利用这个事实来简化克里斯托费尔－施瓦茨积分.

注 在(8.15)中， $ a_{n} $是任意实常数，且已假定 $ a_{1},\cdots,a_{n} $都不为零；为了使上半z平面 $ \mathrm{Im}z>0 $共形映射为上半 $ \zeta $平面 $ \mathrm{Im}\zeta>0 $，所以 $ \frac{1}{z} $前面要冠负号，以满足例7.6的条件。如果点 $ a_{j}(j=1,2,\cdots,n) $之一等于零，则必须不取(8.15)，而取

 $$ \zeta=a_{n}^{\prime}-\frac{1}{z-a}, $$ 

其中 a 是一个与所有的  $ a_{j}(j=1,\cdots,n) $ 都不相同的数. 否则  $ a_{j}^{\prime}(j=1,\cdots,n) $ 之一就要成为  $ \infty $ 了.

(2) n 角形  $ P_{n} $ 有一个或几个顶点在无穷远点（这时  $ P_{n} $ 称为广义多角形）.

设  $ A_{j}=\infty $ (图 8.21)

<div style="text-align: center;"><img src="images/p0374_img_in_image_box_1596_3454_2805_4844.jpg" alt="图 8.21" width="27%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.21</div> </div>


在射线  $ A_{j-1}A $ 与  $ A_{j+1}A $ 上任意各取一点  $ A' $，与  $ A'' $，用线段联结这两点，并考查所得到的  $ (n+1) $ 角形。按公式 (8.9)，将  $ \mathrm{Im} z > 0 $ 共形映射成这个多角形内部的函数，可用下列公式表出：

 $$ \varpi=C\int_{z_{0}}^{z}\left(z-a_{1}\right)^{a_{1}-1}\cdots\left(z-a_{j}^{^{\prime}}\right)^{a_{j}^{^{\prime}}-1}\left(z-a_{j}^{^{\prime \prime}}\right)^{a_{j}^{^{\prime \prime}}-1}\cdots $$

<!-- page: 375 -->

$$  \bullet\left(z-a_{n}\right)^{a_{n}-1}\mathrm{d}z+C_{1},   \tag*{(8.16)}$$

这里  $ a', a'' $, 分别为  $ A', A'' $, 的对应点. 当  $ A', A'' $, 趋于  $ A_i = \infty $ 时,  $ a', a'' $, 必趋于某一实数  $ a_i $, 它与  $ A_i $ 对应.

由定理 8.8，射线  $ A_{j-1}A_{j} $ 与  $ A_{j+1}A_{j} $ 在有限点  $ A_{j}^{*} $ 处的那个交角，应等于在  $ A_{j}=\infty $ 的交角  $ \alpha, \pi $ 反号，即  $ -\alpha, \pi $。于是，由三角形  $ A_{j}^{\prime}A_{j}^{\prime\prime}A_{j}^{*} $，我们有  $ \alpha_{j}^{\prime} + \alpha_{j}^{\prime\prime} - \alpha_{j} = 1 $，而这就是说， $ \alpha_{j}^{\prime} + \alpha_{j}^{\prime\prime} - 2 = \alpha_{j} - 1 $。因此，当  $ A_{j}^{\prime}, A_{j}^{\prime\prime} $ 趋于  $ \infty $ 时，(8.16) 仍然化成 (8.9) 的形状：

 $$ \begin{array}{r}{\varpi=C\displaystyle\int_{z_{0}}^{z}\big(z-a_{1}\big)^{a_{1}-1}\cdots\big(z-a_{j}\big)^{a_{j}-1}\cdots\big(z-a_{n}\big)^{a_{n}-1}\mathrm{d}z+C_{1}.}\end{array} $$ 

当多角形有几个顶点在无穷远点时，可以作同样的讨论.

因此，对于一个或几个顶点在无穷远处的那些多角形来说，克里斯托费尔－施瓦茨积分公式仍然有效，只需把顶点在无穷远处的那两条直线间的角度，用这两条直线在有限点处的那个交角反号代替.

### 3. 广义多角形举例

（1）广义三角形（图 8.22）

<div style="text-align: center;"><img src="images/p0375_img_in_image_box_800_3898_1734_5083.jpg" alt="图 8.22(a)" width="21%" /></div>


<div style="text-align: center;"><img src="images/p0375_img_in_image_box_2193_3899_4001_5080.jpg" alt="图 8.22(b)" width="40%" /></div>


（这里  $ \alpha_{1}=\alpha_{2}=\frac{1}{2},\alpha_{3}=0 $）

合于  $ \frac{1}{2}+\frac{1}{2}+0=3-2 $

<div style="text-align: center;"><div style="text-align: center;">图 8.22(a)</div> </div>


 $$ \begin{aligned}\left(\begin{aligned}& 这里 \quad\alpha_{1}=0,\alpha_{2}=-\frac{1}{2},\alpha_{3}=\frac{3}{2}\\& 介于 \quad0+\left(-\frac{1}{2}\right)+\frac{3}{2}=3-2\end{aligned}\right)\end{aligned} $$ 

<div style="text-align: center;"><div style="text-align: center;">图 8.22(b)</div> </div>


（2）广义四角形（图 8.23）

<!-- page: 376 -->

<div style="text-align: center;"><img src="images/p0376_img_in_image_box_415_629_3904_1980.jpg" alt="图 8.23(a)" width="78%" /></div>


 $$ \begin{aligned}\left(\begin{array}{l} 这里 \quad\alpha_{1}=-1,\alpha_{2}=\alpha_{4}=\frac{1}{2},\alpha_{3}=2\\\\ 合于 \quad-1+\frac{1}{2}+\frac{1}{2}+\stackrel{.}{2}=4-2\end{array}\right)&\quad\left(\begin{array}{l} 这里 \quad\alpha_{1}=\alpha_{2}=\alpha_{4}=0,\alpha_{3}=2\\\\ 合于 \quad0+0+0+2=4-2\end{array}\right)\end{aligned} $$ 

<div style="text-align: center;"><div style="text-align: center;">图 8.23(a)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图 8.23(b)</div> </div>


<div style="text-align: center;"><img src="images/p0376_img_in_image_box_1444_2884_2971_3482.jpg" alt="图 8.23(b)" width="34%" /></div>


<div style="text-align: center;"><img src="images/p0376_img_in_image_box_1439_3667_2975_4322.jpg" alt="图 8.23(c)" width="34%" /></div>


<div style="text-align: center;"><img src="images/p0376_img_in_image_box_1267_4415_3148_4989.jpg" alt="例 8.15 半带形区域" width="42%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.23(c)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">例 8.15 半带形区域</div> </div>


 $$ -\frac{\pi}{2}<{\mathrm{R e~}}w<\frac{\pi}{2},\quad{\mathrm{I m~}}w>0 $$ 

是顶点为  $ A_{1} = -\frac{\pi}{2} $， $ A_{2} = \frac{\pi}{2} $， $ A_{3} = \infty $ 的广义三角形，其各顶角处

<!-- page: 377 -->

$ \alpha_{1}=\frac{1}{2},\alpha_{2}=\frac{1}{2},\alpha_{3}=0 $，合于  $ \alpha_{1}+\alpha_{2}+\alpha_{3}=1 $（如图8.22(a)）。为了明显起见，我们把数据列成表，在其中指出点  $ a_{j}(j=1,2,3) $，它们共三个，因而我们可以任意给定。



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$A_{j}$</td><td style='text-align: center; word-wrap: break-word;'>$a_{j}$</td><td style='text-align: center; word-wrap: break-word;'>$a_{j}$</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$-\frac{\pi}{2}$</td><td style='text-align: center; word-wrap: break-word;'>$\frac{1}{2}$</td><td style='text-align: center; word-wrap: break-word;'>-1</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$\frac{\pi}{2}$</td><td style='text-align: center; word-wrap: break-word;'>$\frac{1}{2}$</td><td style='text-align: center; word-wrap: break-word;'>1</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$\infty$</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$\infty$</td></tr></table>

克里斯托费尔－施瓦茨积分取形式

 $$ \begin{array}{l}w=C\displaystyle\int_{0}^{z}\left(z+1\right)^{-\frac{1}{2}}\left(z-1\right)^{-\frac{1}{2}}\mathrm{d}z+C_{1}\\ \quad=C^{\prime}\displaystyle\int_{0}^{z}\frac{\mathrm{d}z}{\sqrt{1-z^{2}}}+C_{1}\\ \quad=C^{\prime}\arcsin z+C_{1}.\end{array} $$ 

利用点  $ a_{1}, a_{2} $ 与  $ A_{1}, A_{2} $ 的对应关系, 我们得到

 $$ -\frac{\pi}{2}=-C^{\prime}\cdot\frac{\pi}{2}+C_{1},\frac{\pi}{2}=C^{\prime}\cdot\frac{\pi}{2}+C_{1}. $$ 

由此，

 $$ C_{1}=0,C^{\prime}=1. $$ 

故所求将上半 z 平面  $ \mathrm{Im}\ z>0 $ 共形映射成 w 平面上给定的半带形区域的函数为

 $$ w=\arcsin z $$ 

（取 z=1 时， $ w=\arcsin z=\frac{\pi}{2} $ 的那一支）.

例 8.16 割去线段  $ 0 < v < h $, u = 0 (w = u + iv) 的上半平面 v > 0 是广义四角形 (如图 8.23(a)), 它的已知量以及与顶点对应的点列于下表中 (点  $ a, j = 1, 2, 3, 4 $ 中的三个是任意给定的, 第四

<!-- page: 378 -->

个暂时用  $ \xi $ 来表示). 在无穷远点的顶角等于  $ -\pi $, 因为  $ A_{2}A_{1} $ 与  $ A_{4}A_{1} $ 一个是另一个的延长线, 即它们之间的角等于  $ \pi $; 而

 $$ \begin{aligned}&\alpha_{1}+\alpha_{2}+\alpha_{3}+\alpha_{4}\\&=-1+\frac{1}{2}+2+\frac{1}{2}\\&=4-2=2.\end{aligned} $$ 

利用对称原理可以决定点  $ a_{4}=\xi $。将由 z 平面的第二象限到 w 平面的第二象限，且具有点的对应关系  $ \infty\leftrightarrow \infty $， $ h_{i}\leftrightarrow0 $，的共形映射解析延拓越过 y 轴的结果，就得到所求的共形映射。所以  $ a_{4} $ 应当关于虚轴与点  $ a_{2} $ 对称，即  $ a_{4}=\xi=1 $。



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>A_{j}</td><td style='text-align: center; word-wrap: break-word;'>$ \alpha_{j} $</td><td style='text-align: center; word-wrap: break-word;'>a_{j}</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \infty $</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>$ \infty $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{2} $</td><td style='text-align: center; word-wrap: break-word;'>-1</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>hi</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>0</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{2} $</td><td style='text-align: center; word-wrap: break-word;'>$ \xi $</td></tr></table>

克里斯托费尔－施瓦茨积分取形式

 $$ \begin{align*}\omega&=C\int(z+1)^{-\frac{1}{2}}z(z-1)^{-\frac{1}{2}}\mathrm{d}z\\&=C\int\frac{z\mathrm{d}z}{\sqrt{z^{2}-1}}=C^{\prime}\sqrt{z^{2}-1}+C_{1},\end{align*} $$ 

（我们取不定积分，而未取定积分，是因为常数  $ C_{1} $ 是任意的）. 为了确定常数  $ C^{\prime} $ 与  $ C_{1} $，我们利用点  $ a_{2}, A_{2} $ 与  $ a_{3}, A_{3} $ 的对应关系：

 $$ 0=0+C_{1},\mathrm{i}h=\mathrm{i}C^{\prime}+C_{1}, $$ 

由此， $ C_{1}=0 $， $ C^{\prime}=h $，因而所求的函数为

 $$ w=h\sqrt{z^{2}-1}, $$

<!-- page: 379 -->

（取 z=0 时， $ \sqrt{z^{2}-1}=i $ 的那一支）.

注 从上面关于广义多角形的举例可以看出，广义多角形实际上代表了扩充 w 平面上许多特殊形状的单连通区域（边界不止一点）。而变换（8.9）的逆变换  $ z = f^{-1}(w) $ 就能把这许多特殊形状的单连通区域共形映射成（即“简化成”）标准区域——上半 z 平面。

## 第八章 习题

## (一)

1 证明：函数  $ z^{-2} $ 是函数

 $$ f(z)=\sum_{n=0}^{\infty}(n+1)(z+1)^{n} $$ 

由区域 $ \left|z+1\right|<1 $向外的解析延拓.

2 证明：函数  $ \frac{1}{1+z^{2}} $ 是函数

 $$ f(z)=\sum_{n=0}^{\infty}\left(-1\right)^{n}z^{2n} $$ 

由单位圆  $ \left|z\right|<1 $ 向外的解析延拓.

3 已给函数

 $$ f_{1}\left(z\right)=1+2z+\left(2z\right)^{2}+\left(2z\right)^{3}+\cdots, $$ 

证明：函数

 $$ f_{2}\left(z\right)=\frac{1}{1-z}+\frac{z}{\left(1-z\right)^{2}}+\frac{z^{2}}{\left(1-z\right)^{3}}+\cdots $$ 

是函数  $ f_{1}(z) $ 的解析延拓.

4 试证：

 $$ f_{1}\left(z\right)=\sum_{n=0}^{\infty}\left(-1\right)^{n}\mathrm{i}^{n}z^{n} $$ 

及

 $$ f_{2}\left(z\right)=\sum_{n=0}^{\infty}\left(-1\right)^{n}\frac{\left(1+\mathrm{i}\right)^{n}z^{n}}{\left(1-z\right)^{n+1}} $$

<!-- page: 380 -->

互为直接解析延拓.

5 级数

 $$ -\frac{1}{z}-\sum_{n=0}^{\infty}z^{n} $$ 

与级数

 $$ \sum_{n=0}^{\infty}\frac{1}{z^{n+1}} $$ 

的收敛区域无公共部分，试证：它们互为（间接）解析延拓.

6 已给函数

 $$ f_{1}(z)=\sum_{n=1}^{\infty}\frac{z^{n}}{n}, $$ 

证明：函数

 $$ f_{2}\left(z\right)=\ln\frac{2}{3}+\sum_{n=1}^{\infty}\left(\frac{2}{3}\right)^{n}\frac{\left(z+\frac{1}{2}\right)^{n}}{n} $$ 

是函数  $ f_{1}(z) $ 的解析延拓.

7 设

 $$ f(z)=z-\frac{z^{2}}{2}+\frac{z^{3}}{3}-\cdots\left(\mid z\mid<1\right), $$ 

试证：

 $$ f(a)+f\left(\frac{z-a}{1+a}\right) $$ 

与  $ f(z) $ 互为直接解析延拓 ( $ |a|<1 $ 且  $ \mathrm{Im}a\neq0 $).

8 证明

 $$ f(z)=\sum_{n=1}^{\infty}z^{n!}=z+z^{2}+z^{6}+\cdots+z^{n!}+\cdots $$ 

以单位圆周  $ \left|z\right|=1 $ 为自然边界.

9 假设函数  $ f(z) $ 在原点邻域内是解析的，且适合方程

 $$ f(2z)=2f(z)\cdot f^{\prime}(z), $$ 

试证： $ f(z) $ 可以解析延拓到整个 z 平面上.

10 试作出函数 $ \sqrt{z(z-1)} $的黎曼面.

(二)

### 1 已给函数

<!-- page: 381 -->

$$ f_{1}\left(z\right)=z-\frac{1}{2}z^{2}+\frac{1}{3}z^{3}-\cdots, $$ 

证明：函数

 $$ f_{2}\left(z\right)=\ln2-\frac{1-z}{2}-\frac{\left(1-z\right)^{2}}{2.2^{2}}-\frac{\left(1-z\right)^{3}}{3.2^{3}}-\cdots $$ 

是函数  $ f_{1}(z) $ 的解析延拓.

2 幂级数

 $$ \sum_{n=1}^{\infty}\frac{1}{n}z^{n} $$ 

与

 $$ \mathrm{i}\pi+\sum_{n=1}^{\infty}(-1)^{n}\frac{1}{n}(z-2)^{n} $$ 

的收敛圆无公共部分，试证：它们互为解析延拓.

3 试证：级数

 $$ \sum_{n=0}^{\infty}\left[z(4-z)\right]^{n} $$ 

的和函数  $ f(z) $ 在点 z=0 的邻域及 z=4 的邻域内都可以展成幂级数，且其和函数  $ f_{1}(z) $ 与  $ f_{2}(z) $ 可以从一方解析延拓至另一方.

4 试证：级数

 $$ f(z)=\sum_{n=0}^{\infty}\left(\frac{1+z}{1-z}\right)^{n} $$ 

所定义的函数在左半平面内解析，并可解析延拓到除去点 z=0 外的整个 z 平面.

5 试证：单位圆周  $ |z|=1 $ 是函数

 $$ f(z)=\sum_{n=0}^{\infty}\frac{z^{2^{n}+2}}{(2^{n}+1)(2^{n}+2)} $$ 

的自然边界

6 试证: 如果  $ f(z) $ 在区域 D 内是连续的, 并且除去 D 内一条直线段上的点外, 在区域 D 内的每一点都有导数, 则  $ f(z) $ 在区域 D 内是解析的.

7 试证：如果整函数

 $$ f(z)=\sum_{n=0}^{\infty}a_{n}z^{n} $$ 

在实轴上取实值，则系数  $ a_{n} $ 都是实的.

8 试判定下列函数，哪些是单值函数？哪些是多值函数？

(1)  $ \sqrt{1 - \sin^{2} z} $;

(2)  $ \sqrt{\cos z} $;

<!-- page: 382 -->

(3) $ \frac{\sin\sqrt{z}}{\sqrt{z}}; $

(4)  $ \sqrt{e^{z}} $;

(5)  $ \mathrm{Ln}\sin z $.

9 求将上半平面  $ \mathrm{Im}\ z>0 $ 共形映射成边长为 2 的等边三角形的函数（设三个顶点为  $ -1, 1, \sqrt{3}i $）.

答： $ w=(-1+\mathrm{i}\sqrt{3})\frac{\Gamma\left(\frac{2}{3}\right)}{\Gamma^{2}\left(\frac{1}{3}\right)}\int_{0}^{z}z^{-\frac{2}{3}}(z-1)^{-\frac{2}{3}}\mathrm{d}z-1. $

10 试求由上半平面到图 8.24 所示广义多角形区域的共形映射.

<div style="text-align: center;"><img src="images/p0382_img_in_image_box_498_2196_3940_3518.jpg" alt="图 8.24" width="77%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图 8.24</div> </div>


答：

 $$ \begin{array}{r}{\varpi=A\int_{0}^{z}\frac{\sqrt{z}\mathrm{d}z}{(z-1)(z+a)},}\end{array} $$ 

其中

 $$ a=\frac{H^{2}}{h^{2}},A=\frac{H^{2}+h^{2}}{\pi h\mathrm{i}}. $$

<!-- page: 383 -->

## 第九章 调和函数

我们在第三章 §4 曾经介绍过解析函数与调和函数这两个概念之间的关系，即定理 3.18 与定理 3.19.

本章我们将进一步研究调和函数的性质. 我们会发现调和函数与解析函数有某些类似的性质. 对于解析函数, 我们有柯西积分公式; 而对于调和函数, 就有下面要介绍的与柯西积分公式性质相类似的泊松(Poisson)积分公式. 解析函数有平均值定理和极值原理; 调和函数也有相类似的结果. 最后给出单位圆内和上半平面内狄利克雷(Dirichlet)问题的解.

为了方便起见,我们有时将用  $ u(z) $ 来代替  $ u(x,y) $,就如同对于含几个变数的函数,用  $ u(p) $ 来代替  $ u(x_{1},x_{2},\cdots,x_{n}) $ 那样,这时 p 被了解为其坐标为  $ (x_{1},x_{2},\cdots,x_{n}) $ 的点.

#### § 1. 平均值定理与极值原理

### 1. 平均值定理

定理 9.1 如果函数  $ u(z) $ 在圆  $ \left|\zeta - z_{0}\right| < R $ 内是一个调和函数，在闭圆  $ \left|\zeta - z_{0}\right| \leqslant R $ 上连续，则

$$  u\left(z_{0}\right)=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(z_{0}+R\mathrm{e}^{\mathrm{i}\varphi}\right)\mathrm{d}\varphi,   \tag*{(9.1)}$$

即 u(z) 在圆心  $ z_{0} $ 的值等于它在圆周上的值的算术平均数.

<!-- page: 384 -->

证 由第三章定理3.19，存在  $ u(z) $ 的共轭调和函数  $ v(z) $ 使  $ u(z)+iv(z)=f(z) $ 在  $ \left|\zeta-z_{0}\right|<R $ 内解析，若  $ 0<R_{1}<R $，于是由第三章的平均值定理得

 $$ u\left(z_{0}\right)+\mathrm{i}v\left(z_{0}\right)=f(z_{0})=\frac{1}{2\pi}\int_{0}^{2\pi}f(z_{0}+R_{1}\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi, $$ 

即

 $$ \begin{align*}u\left(z_{0}\right)+i v\left(z_{0}\right)&=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(z_{0}+R_{1}\mathrm{e}^{\mathrm{i}\varphi}\right)\mathrm{d}\varphi+\\&\quad i\frac{1}{2\pi}\int_{0}^{2\pi}v\left(z_{0}+R_{1}\mathrm{e}^{\mathrm{i}\varphi}\right)\mathrm{d}\varphi.\end{align*} $$ 

比较两端的实部，且令  $ R_{1} \rightarrow R $ 即得(9.1).

特别，当  $ z_{0}=0 $ 时有公式

$$  u\left(0\right)=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(R\mathrm{e}^{\mathrm{i}\varphi}\right)\mathrm{d}\varphi.   \tag*{(9.1)^{\prime}}$$

### 2. 极值原理

定理 9.2 设  $ u(z) $ 在区域 D 内是调和函数，且不恒等于常数，则  $ u(z) $ 在 D 的内点处不能达到最大值或最小值.

证 只对于最大值的情形证明定理就够了, 因为调和函数  $ u(z) $ 的最小值点便是函数  $ -u(z) $ 的最大值点, 而  $ -u(z) $ 也是一个调和函数.

用反证法，假设  $ u(z) $ 在区域 D 的某一内点  $ z_{0} $ 达到最大值，在单连通区域 D（若 D 为多连通区域，则须引一组割线，使 D 化成单连通区域  $ D' $，并使  $ z_{0} \in D' $，下面就以  $ D' $ 代 D）内作与 u(z) 共轭的调和函数  $ \dot{v}(z) $，并记  $ f(z) = u(z) + iv(z) $。则函数  $ e^{f(z)} $ 在 D 内单值解析，且其模

 $$ |\mathrm{e}^{f(x)}|=\mathrm{e}^{u(x)}. $$ 

但此函数在点  $ z_{0} $ 与 u(z) 一块儿达到最大值，这便与第四章的最大模原理相矛盾. 因此定理得证.

调和函数的极值原理也有下面的形式：

<!-- page: 385 -->

推论 9.3 设(1)  $ u(z) $ 在有界区域 D 内调和，在 D 上连续；(2) 沿边界 C 常有  $ u(z) \leq M $，则除  $ u(z) $ 为常数的情形外，在 D 内一切点处必常有  $ u(z) < M $。即，如  $ u(z) $ 非常数，则  $ u(z) $ 在 D 内不能达到最大值 M，而只能在边界上达到。

#### §2. 泊松积分公式与狄利克雷问题

1. 泊松积分公式 设函数  $ f(z) $ 在圆  $ K: |z| < R $ 内解析，在闭圆  $ \overline{K}: |z| \leq R $ 上连续，则对于 K 内任一点  $ z = re^{\mathrm{i}\varphi} $，根据柯西积分公式，有

$$  \begin{align*}f(z)&=\frac{1}{2\pi\mathrm{i}}\int_{|\zeta|=R}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\\&=\frac{1}{2\pi}\int_{0}^{2\pi}f(R\mathrm{e}^{\mathrm{i}\theta})\frac{R\mathrm{e}^{\mathrm{i}\theta}}{R\mathrm{e}^{\mathrm{i}\theta}-r\mathrm{e}^{\mathrm{i}\varphi}}\mathrm{d}\theta.\end{align*}   \tag*{(9.2)}$$

点 z 关于圆周  $ \left|\zeta\right|=R $ 的对称点

 $$ z^{*}=\frac{R^{2}}{\overline{z}}=\frac{R^{2}\mathrm{e}^{\mathrm{i}\varphi}}{r}. $$ 

因为点  $ z^{*} $ 在圆周  $ \left|\zeta\right|=R $ 的外部，所以

$$  \begin{aligned}0&=\frac{1}{2\pi\mathrm{i}}\int_{|\zeta|=R}\frac{f(\zeta)}{\zeta-z^{*}}\mathrm{d}\zeta\\&=\frac{1}{2\pi}\int_{0}^{2\pi}f(R\mathrm{e}^{\mathrm{i}\theta})\frac{r\mathrm{e}^{\mathrm{i}\theta}}{r\mathrm{e}^{\mathrm{i}\theta}-R\mathrm{e}^{\mathrm{i}\varphi}}\mathrm{d}\theta.\end{aligned}   \tag*{(9.3)}$$

从(9.2)减去(9.3)，得

 $$ f(z)=\frac{1}{2\pi}\int_{0}^{2\pi}f(R\mathrm{e}^{\mathrm{i}\theta})\left[\frac{R\mathrm{e}^{\mathrm{i}\theta}}{R\mathrm{e}^{\mathrm{i}\theta}-r\mathrm{e}^{\mathrm{i}\varphi}}-\frac{r\mathrm{e}^{\mathrm{i}\theta}}{r\mathrm{e}^{\mathrm{i}\theta}-R\mathrm{e}^{\mathrm{i}\varphi}}\right]\mathrm{d}\theta. $$ 

经过一些计算，即得

 $$ u+\mathrm{i}v=f(z)=\frac{1}{2\pi}\int_{0}^{2\pi}f(R\mathrm{e}^{\mathrm{i}\theta})\frac{R^{2}-r^{2}}{R^{2}-2R r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta. $$ 

比较上式两端的实部，得到公式

<!-- page: 386 -->

$$  u\left(r,\varphi\right)=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(R,\theta\right)\frac{R^{2}-r^{2}}{R^{2}-2R r\cos\left(\theta-\varphi\right)+r^{2}}\mathrm{d}\theta.   \tag*{(9.4)}$$

上式也可写成

$$  u\left(z\right)=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(R\mathrm{e}^{\mathrm{i}\theta}\right)\frac{R^{2}-r^{2}}{R^{2}-2R r\cos\left(\theta-\varphi\right)+r^{2}}\mathrm{d}\theta.   \tag*{(9.4)'}$$

特别，对于单位圆来说，R=1，上式变为

$$  u\left(z\right)=\frac{1}{2\pi}\int_{0}^{2\pi}u\left(\mathrm{e}^{\mathrm{i}\theta}\right)\frac{1-r^{2}}{1-2r\cos\left(\theta-\varphi\right)+r^{2}}\mathrm{d}\theta.   \tag*{(9.5)}$$

公式(9.4)，(9.4) $ ^{\prime} $及(9.5)均称为对于圆的泊松积分.

由此可以得出

定理 9.4 任何一个在圆内调和且在闭圆上连续的函数，圆内的值都可以用圆周上的值的积分即泊松积分表示.

注 泊松积分公式推广了平均值公式，而把后者作为特例 $ (r=0 $的情形).

思考题 试列举调和函数与解析函数还具有什么类似的性质.

2. 狄利克雷问题 $ ^{①} $ 拉普拉斯方程

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0 $$ 

的通解，就是全体调和函数，此方程是最简单的二阶偏微分方程之一。对于常微分方程，给出了一定的附加条件，便可以确定出一个特解来。为了要确定拉普拉斯方程的一个解，也需要一些附加的条件（虽然条件的形式不完全一样），例如，常见的条件之一是表达成边值问题的形状，即表达成所求函数在区域的边界上应当满足的一些已知关系式的形状。这样的边界条件，往往可以由所给问题的解的那些物理条件本身得到。

这类条件中最简单的那一种，引出了所谓第一边值问题，或者

<!-- page: 387 -->

狄利克雷问题：

求出一个在区域 D 内调和并且在  $ \overline{D} = D + C $ 上连续的函数  $ u(z) $，使它在 C 上取已知值  $ \tilde{u}(\zeta) $：

 $$ u\left(\zeta\right)=\tilde{u}\left(\zeta\right),\qquad\zeta\in C. $$ 

例如，在某区域内求流体（无源、无旋）的速度或静电场（无电荷）的电位，当这区域边界上的速度或电位已经知道时，这便是狄利克雷问题.

先来证明狄利克雷问题解的惟一性定理：

定理 9.5 在已知区域 D, 对于给定的边界值  $ \tilde{u}(\zeta) $, 狄利克雷问题的解不能多于一个.

证 假设  $ u_{1}(z) $ 与  $ u_{2}(z) $ 是狄利克雷问题的两个解，则  $ u_{1}(z)-u_{2}(z) $ 在区域 D 内调和，在  $ \bar{D}=D+C $ 上连续，沿 C， $ u_{1}(z)-u_{2}(z)=0 $，(因沿 C， $ u_{1}(\zeta)=u_{2}(\zeta)=\tilde{u}(\zeta) $) 由定理 9.2， $ u_{1}(z)-u_{2}(z) $ 在  $ \bar{D} $ 上的最大值与最小值两个都等于零，因而在  $ \bar{D} $ 上  $ u_{1}(z)-u_{2}(z)=0 $。由此可见，在  $ \bar{D} $ 上  $ u_{1}(z)=u_{2}(z) $，于是定理得证。

3. 单位圆内狄利克雷问题的解 定理 9.4 启发我们来证明，对于单位圆的泊松积分 (9.5) 就是单位圆  $ D: |z| < 1 $ 内狄利克雷问题的解。首先，在 (9.5) 中令  $ u(z) \equiv 1 $，立刻得到，

$$  \frac{1}{2\pi}\int_{0}^{2\pi}\frac{1-r^{2}}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta=1.   \tag*{(9.6)}$$

其次,我们下面证明  $ u(z) $ 是在单位圆  $ \left|z\right|<1 $ 内的调和函数.

 $$ \zeta=\mathrm{e}^{\mathrm{i}\theta},\qquad z=r\mathrm{e}^{\mathrm{i}\varphi}\qquad(\mathrm{d}0\leqslant r<1). $$ 

我们有

 $$ \begin{array}{c}{\displaystyle\frac{1-r^{2}}{1-2r\cos\left(\theta-\varphi\right)+\bar{r}^{2}}=\frac{\zeta}{\zeta-z}+\frac{\bar{z}}{\bar{\zeta}-\bar{z}}}\\ {\displaystyle=\frac{1}{2}\left(\frac{\zeta+z}{\zeta-z}+1\right)+\frac{1}{2}\left(\frac{\bar{\zeta}+\bar{z}}{\bar{\zeta}-\bar{z}}-1\right)}\\ {\displaystyle=\frac{1}{2}\left[\frac{\zeta+z}{\zeta-z}+\left(\frac{\zeta+z}{\zeta-z}\right)\right]=\mathrm{R e}\left(\frac{\zeta+z}{\zeta-z}\right).}\end{array} $$

<!-- page: 388 -->

$$ \mathrm{d}\boldsymbol{\zeta}=\mathrm{i}\mathrm{e}^{\mathrm{i}\theta}\mathrm{d}\boldsymbol{\theta}=\mathrm{i}\boldsymbol{\zeta}\mathrm{d}\boldsymbol{\theta},\quad\frac{\mathrm{d}\boldsymbol{\zeta}}{\mathrm{i}\boldsymbol{\zeta}}=\mathrm{d}\boldsymbol{\theta}. $$ 

从而  $ u(z) $ 是函数

 $$ f(z)\xlongequal{( 记 )}\frac{1}{2\pi\mathrm{i}}\int_{|\zeta|=1}u(\zeta)\frac{\zeta+z}{\zeta-z}\cdot\frac{\mathrm{d}\zeta}{\zeta}\quad(|z|<1) $$ 

的实部，上式中的积分称为施瓦茨积分.

显然

 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\left[\int_{|\zeta|=1}\frac{u(\zeta)}{\zeta-z}\mathrm{d}\zeta+z\int_{|\zeta|=1}\frac{u(\zeta)}{\zeta-z}\mathrm{d}\zeta\right]. $$ 

即

 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\int_{|\zeta|=1}\frac{u(\zeta)}{\zeta-z}\mathrm{d}\zeta+z\cdot\frac{1}{2\pi\mathrm{i}}\int_{|\zeta|=1}\frac{u(\zeta)}{\zeta-z}\mathrm{d}\zeta. $$ 

等号右端的两个积分都是柯西型积分. 由第三章的定理 3.13' 可见,  $ f(z) $ 在  $ \left|z\right| < 1 $ 内解析. 从而证得其实部  $ u(z) $ 在  $ \left|z\right| < 1 $ 内是调和的.

最后，问题的证明转化为只须证明

$$  \lim_{z\to\zeta_{0}}\frac{1}{2\pi}\int_{0}^{2\pi}\left[u(\zeta)-u(\zeta_{0})\right]\frac{1-r^{2}}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta=0,   \tag*{(9.7)}$$

其中  $ \zeta = e^{i\theta} $， $ \zeta_{0} = e^{i\theta_{0}} $， $ z = re^{i\varphi} $，

 $$ 0\leqslant r<1,0\leqslant\theta<2\pi,0\leqslant\varphi<2\pi. $$ 

由于  $ u(\zeta) = u(e^{i\theta}) $ 在  $ \theta = \theta_{0} $ 处连续，对于任给一个正数  $ \epsilon $，总可以选取一个  $ \delta > 0 $，使当  $ |\theta - \theta_{0}| < 2\delta $ 时

 $$ |u(\zeta)-u(\zeta_{0})|<\varepsilon. $$ 

我们可得

 $$ \left|\frac{1-r^{2}}{2\pi}\int_{\theta_{0}-2\delta}^{\theta_{0}+2\delta}\frac{u(\zeta)-u(\zeta_{0})}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta\right| $$

<!-- page: 389 -->

$$  \begin{align*}&\leq\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{|u(\zeta)-u(\zeta_0)|}{1-2r\cos(\theta-\varphi)+r^2}\mathrm{d}\theta\\&<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{\mathrm{d}\theta}{1-2r\cos(\theta-\varphi)+r^2}\\&<\varepsilon\frac{1-r^2}{2\pi}\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{1-2r\cos(\theta-\varphi)+r^2}\\&\phantom{<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{1-2r\cos(\theta-\varphi)+r^2}{1-2r\cos(\theta-\varphi)+r^2}}\\&\phantom{<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{1-2r\cos(\theta-\varphi)+r^2}{1-2r\cos(\theta-\varphi)+r^2}}\\&\phantom{<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{1-2r\cos(\theta-\varphi)+r^2}{1-2r\cos(\theta-\varphi)+r^2}}\\&\phantom{<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{1-2r\cos(\theta-\varphi)+r^2}{1-2r\cos(\theta-\varphi)+r^2}}\\&\phantom{<\varepsilon\frac{1-r^2}{2\pi}\int_{\theta_0-2\delta}^{\theta_0+2\delta}\frac{1-2r\cos(\theta-\varphi)+r^2}{1-2r\cos(\theta-\varphi)+r^2}}\end{align*}   \tag*{(9.8)}$$

因为点 $ (r, \varphi) $趋于点 $ (1, \theta_{0}) $，所以对于适合 $ |\varphi - \theta_{0}| < \delta $， $ |\theta - \theta_{0}| \geq 2\delta $的 $ \varphi, \theta $，有

 $$ \begin{aligned}|\theta-\varphi|&=|\theta-\theta_{0}+\theta_{0}-\varphi|\geqslant|\theta-\theta_{0}|-|\theta_{0}-\varphi|\\&>2\delta-\delta=\delta.\end{aligned} $$ 

因此  $ \cos(\theta - \varphi) \leq \cos\delta $，从而

 $$ \begin{align*}1-2r\cos(\theta-\varphi)+r^2&\geqslant1-2r\cos\delta+r^2\\&=1-2r\left(1-2\sin^2\frac{\delta}{2}\right)+r^2\\&=(1-r)^2+4r\sin^2\frac{\delta}{2}\\&>4r\sin^2\frac{\delta}{2}.\end{align*} $$ 

令  $ A = 4r\sin^{2}\frac{\delta}{2} $，M 是  $ \left| u(\zeta) \right| $ 在单位圆周上的最大值. 因此得到

$$  \begin{align*}\left|\frac{1-r^2}{2\pi}\right|&\int_{0}^{2\pi+\theta_0-2\delta}\frac{u(\zeta)-u(\zeta_0)}{1-2r\cos(\theta-\varphi)+r^2}\mathrm{d}\theta\\&\leq\frac{2M}{2\pi A}(2\pi-4\delta)(1-r^2)\\&=\frac{2M}{\pi A}(\pi-2\delta)(1-r^2).\end{align*}   \tag*{(9.9)}$$

当  $ r \rightarrow 1 $ 时，(9.9)式等号右端趋于零。即对任意的  $ \varepsilon > 0 $，有正数  $ \rho < 1 $，使当  $ 1 - \rho < r < 1 $ 时

<!-- page: 390 -->

$$ \frac{2M}{\pi A}(\pi-2\delta)(1-r^{2})<\varepsilon. $$ 

从(9.8)和(9.9)式看到，当 $ 1-\rho<r<1,\vert\varphi-\theta_{0}\vert<\delta $时，即对图9.1中用斜线标出的那个区域内所有的点z来说，就都有：

 $$ \begin{align*}&\left|\frac{1}{2\pi}\int_{0}^{2\pi}\left[u(\zeta)-u(\zeta_{0})\right]\frac{1-r^{2}}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta\right.\\&\leqslant\left|\frac{1-r^{2}}{2\pi}\int_{\theta_{0}-2\delta}^{\theta_{0}+2\delta}\frac{u(\zeta)-u(\zeta_{0})}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta\right|+\\&\quad\left|\frac{1-r^{2}}{2\pi}\int_{\theta_{0}+2\delta}^{2\pi+\theta_{0}-2\delta}\frac{u(\zeta)-u(\zeta_{0})}{1-2r\cos(\theta-\varphi)+r^{2}}\mathrm{d}\theta\right|\\&<\varepsilon+\varepsilon=2\varepsilon.\end{align*} $$ 

由  $ \varepsilon $ 的任意性, 知道 (9.7) 是真的.

4. 上半平面内狄利克雷问题的解 为了求出在实轴上取已知值而在上半平面内调和的那个函数  $ u(z) $ 在点 z 处之值，我们作出一个把上半平面  $ \operatorname{Im}\zeta>0 $ 共形映射成单位圆  $ |\omega|<1 $ 的分式线性变换

<div style="text-align: center;"><img src="images/p0390_img_in_image_box_3242_2736_3993_3764.jpg" alt="图9.1" width="16%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图9.1</div> </div>


$$  \omega=\frac{\zeta-z}{\zeta-\overline{z}}.   \tag*{(9.10)}$$

因为这时点 z 被变成  $ \omega = 0 $，所以根据平均值定理，有

$$  U(0)=\frac{1}{2\pi}\int_{0}^{2\pi}U(\omega)\mathrm{d}\tau.   \tag*{(9.11)}$$

其中  $ u[\zeta(\omega)] = U(\omega) $，而  $ \tau $ 是单位圆周上点的辐角：

$$  \mathrm{e}^{\mathrm{i}\tau}=\frac{t-z}{t-\overline{z}}.   \tag*{(9.12)}$$

这里 t 在实轴  $ \mathrm{Im}\zeta=0 $ 上，因为(9.10)把实轴  $ \mathrm{Im}\zeta=0 $ 变成单位圆周  $ |\omega|=1 $.

在(9.12)这个等式两端微分,我们得到

 $$ \mathrm{e}^{\mathrm{i}\tau}\mathrm{d}\tau=\frac{2y}{\left(t-\bar{z}\right)^{2}}\mathrm{d}t\qquad\left(z=x+\mathrm{i}y\right). $$

<!-- page: 391 -->

因此便有

 $$ \mathrm{d}\tau=\frac{2y\mathrm{d}t}{(t-z)(t-\overline{z})}=\frac{2y\mathrm{d}t}{(t-x)^{2}+y^{2}}. $$ 

将(9.11)代回到原来的变数上去,结果我们便得出了 $ \uwave{\text{对于上半平}} $面的泊松积分公式:

$$  u\left(z\right)=\frac{1}{\pi}\int_{-\infty}^{+\infty}u\left(t\right)\cdot\frac{y\mathrm{d}t}{\left(t-x\right)^{2}+\dot{y}^{2}}.   \tag*{(9.13)}$$

同样，在一定条件下(例如，设  $ u(t) $ 是有界函数等)，我们可以证明(9.13)是上半平面上狄利克雷问题的解.

例 9.1 积出 (9.13) 式中的积分, 我们可得到一个在上半平面内的调和函数  $ u(z) $. 今设  $ u(t) $ 在实轴的一段  $ (\alpha, \beta) $ 上等于 1, 而在实轴的其余部分上等于 0, 则得

 $$ \begin{aligned}u\left(z\right)&=\frac{1}{\pi}\int_{a}^{\beta}\frac{y\mathrm{d}t}{\left(t-x\right)^{2}+y^{2}}\\&=\frac{1}{\pi}\left(\operatorname{a r c}\tan\frac{\beta-x}{y}-\operatorname{a r c}\tan\frac{\alpha-x}{y}\right)^{\textcircled{1}}.\end{aligned} $$ 

例 9.2 设有一个很长的圆柱面是用很薄的导体做成的. 这柱面被过它的轴的平面分为两半, 一半的电位保持为  $ V_{0} $, 另一半接地. 现在要求出柱体内任一点的电位.

由于柱体是很长的,所以内部的电位是只与 x, y 有关的函数  $ V(x, y) $. 可设圆柱的半径为 1. 为求电位函数  $ V(x, y) $, 可把问题化成如下的边值问题, 即狄利克雷问题:

 $ V(x,y) $为单位圆内的调和函数，即

$$  \begin{aligned}&\Delta V=\frac{\partial^{2}V}{\partial x^{2}}+\frac{\partial^{2}V}{\partial y^{2}}=0, 在 x^{2}+y^{2}<1 内 \\&V(x,y)=V_{0}, 在 x^{2}+y^{2}=1 上且 y<0\\&V(x,y)=0, 在 x^{2}+y^{2}=1 上且 y\geqslant0\end{aligned}   \tag*{(9.14)}$$

<!-- page: 392 -->

为解此题，今作分式线性变换

 $$ \omega=\mathrm{i}\frac{1-z}{1+z}, $$ 

它将单位圆  $ |z| < 1 $ 共形映射成上半平面  $ \mathrm{Im} w > 0 $，使  $ -1 \to \infty $， $ 1 \to 0 $， $ i \to 1 $，其边界对应是：下半圆周对应于负半实轴；上半圆周对应于正半实轴（如图 9.2）.

<div style="text-align: center;"><img src="images/p0392_img_in_image_box_468_1805_3988_3158.jpg" alt="图9.2" width="79%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图9.2</div> </div>


经变换后的狄利克雷问题是：

 $ V^{*} $  $ (u,v) $ 为上半平面内的调和函数，即

$$  \left.\begin{array}{l}{\Delta V^{*}=0(\operatorname{I m}w>0),}\\ {V^{*}\left(u,0\right)=0\left(u\geqslant0\right),}\\ {V^{*}\left(u,0\right)=V_{0}\left(u<0\right).}\end{array}\right\}   \tag*{(9.14)'}$$

易知，函数

 $$ V^{*}\left(u,v\right)=\frac{V_{0}}{\pi}\arg w $$ 

恰是(9.14)的解.为回答原来的问题,我们应当将解答的 w 平面形式回到 z 平面上,写成 x,y 的函数.为此,先注意

 $$ \arg w=\operatorname{I m}\{\ln w\}, $$ 

故最终的答案是：

<!-- page: 393 -->

$$ \begin{align*}V(x,y)&=\frac{V_{0}}{\pi}\mathrm{Im}\left\{\ln\left(\mathrm{i}\frac{1-z}{1+z}\right)\right\}\\&=\frac{V_{0}}{\pi}\arg\left\{\mathrm{i}\frac{1-z}{1+z}\right\}\\&=\left\{\begin{array}{ll}\frac{V_{0}}{\pi}\arctan\left(\frac{1-x^{2}-y^{2}}{2y}\right),&y>0,\\\frac{V_{0}}{2},&y=0,\end{array}\right.\\\frac{V_{0}}{\pi}\left[\pi+\arctan\left(\frac{1-x^{2}-y^{2}}{2y}\right)\right],&y<0.\end{align*} $$ 

## 第九章习题

(一)

1 设(1)  $ u(x,y) $ 为区域 D 内的调和函数；(2) 圆  $ \left|z-a\right|<R $ 全含于 D. 求证：当  $ z=a+re^{i\theta}, r<R $ 时，

 $$ \begin{align*}u\left(\boldsymbol{r},\boldsymbol{\theta}\right)&=\mathrm{Re}f(a+r\mathrm{e}^{\mathrm{i}\theta})\\&=\frac{a_{0}}{2}+\sum_{n=1}^{\infty}r^{n}\left(a_{n}\cos n\theta+b_{n}\sin n\theta\right),\end{align*} $$ 

且展式是惟一的.

2 如果 u(z) 在 z 平面内是有界的调和函数, 试证 u(z) 恒等于常数.

3 设  $ f(z) $ 为一整函数且不恒等于一常数， $ u(x,y)=\operatorname{Re}f(z) $，则对于任一实数 a，必有平面上的点  $ (x_{0},y_{0}) $ 使  $ u(x_{0},y_{0})=a $.

4 设(1)  $ u(x,y) $ 是区域 D 内的调和函数；(2) 圆 K 全含于 D,  $ u(x,y) $ 在 K 内恒等于一常数 a. 求证  $ u(x,y) $ 在 D 内恒等于 a.

5 设(1)  $ u(x,y) $ 为区域 D 内的调和函数；

(2) $ (x_{0},y_{0})\in D,u(x_{0},y_{0})=a; $

(3) U 是  $ (x_{0}, y_{0}) $ 的一个邻域,  $ U \subseteq D $,

求证: U 内有无穷多个点,  $ u(x, y) $ 在其上的值都是 a.

6 试求在单位圆 K 内调和、在闭圆  $ \overline{K} $ 上（除去其上两点  $ \alpha, \beta $ 外）连续

<!-- page: 394 -->

$$  八 $$ 

的函数，这个函数在圆弧 $ \alpha\beta $上取值1，在单位圆周的其余部分上取值0.

 $$ \left( 二 \right) $$ 

1 试用调和函数的平均值定理证明：

 $$ \int_{0}^{\pi}\ln(1-2r\cos\theta+r^{2})\mathrm{d}\theta=0, $$ 

其中 -1 < r < 1.

提示 当  $ 0 \leq r < 1 $ 时，令  $ z = r e^{i\theta} $，考虑  $ \mathrm{Ln}(1 - z) $ 在  $ |z| < 1 $ 内的一个单值解析分支  $ \ln(1 - z) $。于是  $ u(z) = \mathrm{Re}[\ln(1 - z)] $ 在  $ |z| < 1 $ 内调和。且有  $ u(0) = \mathrm{Re}[\ln 1] = 0 $。再利用第二章习题（一）21 的结果；当  $ -1 \leq r < 0 $ 时，可考虑  $ \mathrm{Ln}(1 + z) $ 在  $ |z| < 1 $ 内的一个单值解析分支  $ \ln(1 + z) $，再作类似于上段的讨论，即可得到证明。

2 如果两个二元实函数  $ u_{1}(x,y) $ 与  $ u_{2}(x,y) $ 在区域 D 内为调和，在闭域  $ \overline{D} $ 上连续，且在 D 的所有边界点处有

 $$ u_{1}\left(x,y\right)=u_{2}\left(x,y\right), $$ 

试证: 在 D 内恒有

 $$ u_{1}\left(x,y\right)=u_{2}\left(x,y\right). $$ 

提示 考虑  $ u(x,y)=u_{1}(x,y)-u_{2}(x,y) $.

3 设二元实函数  $ u(x, y) $ 是在  $ 0 < |z| < \rho $ ( $ < +\infty $) 内的有界调和函数. 试证: 适当定义  $ u(0,0) $ 后,  $ u(x,y) $ 是在  $ |z| < \rho $ 内的调和函数.

<!-- page: 395 -->

# 本书第一版荣获第一届国家教委 高等学校优秀教材二等奖

ISBN 7-04-012943-4

<div style="text-align: center;"><img src="images/p0395_img_in_image_box_460_4855_1507_5616.jpg" alt="Image" width="23%" /></div>


9"787040"129434">

定价：18.70元
