# 数学物理方法（第四版）[十二五国家级规划教材] (姚端正 周国全 贾俊基)

> 源文件：`数学物理方法（第四版）[十二五国家级规划教材] (姚端正 周国全 贾俊基) (z-library.sk, 1lib.sk, z-lib.sk).pdf_by_PaddleOCR-VL-1.6.json`
> 共 377 页，由 PaddleOCR-VL-1.6 从 PDF 转出。
> 页码锚点格式 `<!-- page: N -->`，N 为 PDF 页码（从 1 起）。
> 图片位于同级的 `images/`，已本地化。

## 章节索引

### 第一篇 复变函数论（第 10 页）
- 第一章 解析函数 — 第 21 页
- 第二章 解析函数积分 — 第 48 页
- 第三章 复变函数级数 — 第 64 页
- 第四章 解析延拓 $ \Gamma $ 函数 B 函数 — 第 86 页
- 第五章 留数理论 — 第 95 页

### 第二篇 数学物理方程（第 114 页）
- 第六章 定解问题 — 第 115 页
- 第七章 行波法 — 第 128 页
- 第八章 分离变量法 — 第 148 页
- 第九章 积分变换法 — 第 176 页
- 第十章 格林函数法 — 第 201 页

### 第三篇 特殊函数（第 229 页）
- 第十一章 勒让德多项式 — 第 230 页
- 第十二章 贝塞尔函数 — 第 249 页
- 第十三章 施图姆-刘维尔理论 — 第 273 页

### $ ^{*} $第四篇 近似方法及现代内容（第 281 页）
- 第十四章 变分法 — 第 282 页
- 第十五章 非线性方程 — 第 300 页
- 第十六章 积分方程 — 第 319 页
- 第十七章 小波变换 — 第 333 页


---

<!-- page: 1 -->

# 国家精品课程配套教材 国家级精品资源共享课配套教材

# 数学物理方法

（第四版） 姚端正 周国全 贾俊基 编著

<div style="text-align: center;"><img src="images/p0001_img_in_image_box_0_635_958_1242.jpg" alt="Image" width="99%" /></div>


P 科学出版社

<!-- page: 2 -->

“十二五”普通高等教育本科国家级规划教材

数学物理方法

（第四版）

姚端正 周国全 贾俊基 编著

科学出版社

北京

<!-- page: 3 -->

#### 内容简介

本书是“十二五”普通高等教育本科国家级规划教材，也是国家精品课程、国家级精品资源共享课配套教材。

作者本着去粗取精、更新拓宽的思想科学地组织内容。全书密切结合物理实例，特别注重与后续课程的联系，并增加了一般传统教材中所没有的非线性方程、积分方程、分步傅里叶变换及小波变换等内容。全书分为复变函数论（第一篇）、数学物理方程（第二篇）、特殊函数（第三篇）和近似方法及现代内容（第四篇）四个部分。在每章后都有小结，每小节后都附有习题，习题中包含具有一定深度、难度和挑战度的题，以培养学生分析问题、解决问题的能力和创新能力。为了方便读者，每章后都有以二维码形式链接的授课课件及习题分析与讨论，书末附有习题参考答案。

本书可作为高等院校物理专业和相关专业本科生的教材，也可供相关专业的研究生、教师和科技人员参考使用。

图书在版编目(CIP)数据

数学物理方法/姚端正，周国全，贾俊基编著.—4版.—北京：科学出版社，2020.8

“十二五”普通高等教育本科国家级规划教材

ISBN 978-7-03-065651-3

Ⅰ. ①数… Ⅱ. ①姚…②周…③贾… Ⅲ. 数学物理方法-高等学校-教材 Ⅳ. O411.1

中国版本图书馆 CIP 数据核字（2020）第120637号

责任编辑：窦京涛 / 责任校对：杨聪敏

责任印制：张伟 / 封面设计：华路天然工作室

##### 科学出版社出版

北京东黄城根北街16号

邮政编码：100717

http://www.sciencep.com

北京建宏印刷有限公司 印刷

科学出版社发行 各地新华书店经销

关

1992年8月第一版开本：720×1000 B5

1997年7月第二版印张：241/4

2010年3月第三版字数：489000

2020年8月第四版2020年8月第十三次印刷

定价：59.00元

（如有印装质量问题，我社负责调换）

<!-- page: 4 -->

### 第四版前言

本人所编数学物理方法第三版面世业已十年。然而，“欲穷千里目，更上一层楼”，一本好的教材，必须通过在教学实践中的不断检验、千锤百炼才能造就。为此在保留了原教材特色的前提下，第四版对其内容和体系做了如下修改：

（1）为了使教材既能与时俱进，具有高阶性、创新性和挑战度，又能适应当前普遍存在的学时偏少的需要，我们改变了原教材体系，将大纲要求的最基本、必讲的内容连贯性地集中放在前三篇，增加了第四篇——近似方法及现代内容，并将原教材中的第十一章变分法、第十二章非线性方程、第十三章积分方程、经改写后的的小波变换以及新增加的现代内容一并汇入其中，以便使用该教材的学校可根据自身情况对第四篇内容或全讲或选讲，这样既能解决某些学校受学时限制的困扰，又不至降低教材质量.

（2）非线性方程是近代物理中常会遇到的方程，但大多非线性方程不能求得其解析解，为了使教材能与前沿学科接轨，在非线性方程一章增加了近些年来受广大学者青睐的“分步傅里叶变换法”这一方便的数值解法的内容，这对基础研究极为有用。

（3）对授课课件、部分章节中的措辞及注释内容进行了修改和补充.

（4）部分章节增加了有深度、难度和挑战度的习题，以进一步拓宽学生思路，增强其分析问题、解决问题的能力。

（5）增加了“附录Ⅰ.矢量微分算子与拉普拉斯算符”和“索引”两部分，以方便读者查阅.

还要指出的是，为了方便读者、节省篇幅，第四版将每章的授课课件、习题分析与讨论以及某些注释和证明过程以二维码链接的形式录入书中，这也是此版与前三版的一个较大差异和改进。

最后，感谢周国全老师、贾俊基老师加入到了第四版的改写工作中，感谢窦京涛编辑为本书出版所作的辛苦付出，感谢广大读者尤其是使用本教材的教师对本书的厚爱以及对本书所提出的宝贵意见和建议，感谢科学出版社高教数理分社社长昌盛和武汉大学熊贵光教授多年来对本人工作的支持与帮助。

姚端正

2019年6月于珞珈山

<!-- page: 5 -->

### 第三版前言

浮生却似冰底水，日夜东流人不知。不知不觉，本人的拙作《数学物理方法》一书已历经了20多年的使用历程。从讲义到出版问世，到再版；从荣获国家教委优秀教材二等奖，到荣获教育部科技进步二等奖，再到入选为普通高等教育“十一五”国家级规划教材；这一路过来，作为一个普通教师，本人心存太多的感慨和感激！我感谢李中辅教授、路见可教授和黄念宁教授在本书编写、修改过程中所作的有益讨论和指教；我感谢保宗悌教授、梁昆森教授、陆全康教授对本书的悉心评审、评阅，特别是老前辈梁昆森教授为第二版所写的序；我感谢广大读者尤其是使用本书的教师、学生对本书的厚爱；我感谢武汉大学教务部历年来对教学工作的重视、扶持；我也感谢科学出版社的昌盛编辑和窦京涛编辑为第三版的出版所付出的辛勤劳动。在第三版即将问世之际，我还要特别感谢金准智教授和熊贵光教授长期以来对本人工作的支持和帮助！我深知，没有大家的帮助和支持，本书不可能一步步地走到今天。

众所周知，数学物理方法是物理类专业的重要基础课，也是一门公认的难教、难学的理论课程。如何将难教、难学的课程变为易教、易学的课程，如何使数学物理方法教材的内容能适应21世纪科技发展的需要，这便是本人编写本书的主要宗旨。为此，第三版对第二版的内容大致作了如下更改：

1. 将全书的内容编排进行了调整，取消了原书的第四篇，而将其内容作为“非线性方程”、“积分方程”各一章并入第二篇。全书共含复变函数论、数学物理方程和特殊函数三篇，且为查找方便起见，将全书的16章不分篇地统一排序。

2. 受篇幅限制，删去了第二版中的部分章节，将其部分内容并入适当的章节或相关章节的习题中。如，删去了原书第二篇第二章行波法中的2.2节反射波，而将其内容作为习题并入习题7.1中；删去了原书第二篇第六章保角变换法，而将其中1.1节保角变换的主要内容作为新的一节（1.5节解析函数的几何性质）添加到第一篇中；删去了原书第二篇第七章复变函数法，而将其内容作为两个习题列入第二篇习题11.4中；删去了原书中的附录一（高斯方程和库默方程）、附录二（最陡下降法）、附录三（矢量公式和矢量定理），将高斯方程和库默方程的相关内容并入第三篇第十六章中，等等。

3. 对部分章节进行了改写. 如, 10.5 节含时的格林函数法, 13.2 节施密特-希尔伯特理论等.

4. 根据教育部对该课程的要求和近年来科技发展的需要，增加了部分章节或内容。如，2.3 节中含参量积分的内容，4.3 节 B 函数，5.4 节中的含对数函数的积分，9.5 节小波变换导引，等等。

<!-- page: 6 -->

需要说明的几个问题：

1. 本书可供讲授72～90学时（不含习题课）和讲授54～60学时（不含习题课）的两种需求者使用。对于讲授72学时（不含习题课）的使用者，若学时不够，建议可根据自身的情况或需求删去部分打*的节（而不是打*的章）。对于讲授54学时（不含习题课）的使用者，可直接删去打*的章。

2. 本书每小节后的大约一半的习题在其配套的《数学物理方法学习指导》（科学出版社，姚端正，2001年）中有详细解答和分析（为了培养学生分析问题、解决问题的能力，我们有意没有给出全部习题的解答）.

3. 为了方便读者，本书为读者提供了 PDF 格式的电子教案光盘（含习题课），并对以本书为教材的老师赠送可修改格式的授课用电子教案。需要指出的是，鉴于本课程应特别注重培养学生逻辑推理能力和分析问题、解决问题的能力，建议使用该教案的授课教师，一定要结合适当的板书推演过程，否则其教学效果将是不理想和不完善的。实际上本电子教案中有些章节已省去了不少推导、证明过程，而第十一章和第十三章，由于完全是通过板书推演来授课，则未录入电子教案。

“路漫漫其修远兮，吾将上下而求索！”尽管我衷心地希望本书能成为广大学习数理方法读者的良师益友，但由于受水平、时间和篇幅的限制，难免有疏漏和不妥之处，敬请专家和广大读者批评指正！

姚端正

2009年仲夏夜于珞珈山

<!-- page: 7 -->

### 第二版序言

多年来，姚端正和梁家宝两位先生先后相继为武汉大学物理类专业讲授“数学物理方法”课程。本书就是他们在长年教学实践的基础上编写出版的优秀教材。

作者十分注意数学与物理的结合，注意阐述有关物理背景和前景。这个特点对于物理类专业是很重要的。

非线性方程和积分方程对于物理学科的一些新进展很有用，但在同类教科书中却往往阙如。本书则将有关内容编为第四篇，体现出课程现代化之精神。

本书选材恰当，文字清晰，要言不繁。尽管增加了第四篇，全书篇幅并不大于同类教材，十分有利于在有限的学时内很好地完成数学物理方法的教学。

在 1995 年的优秀教材评选中，本书荣获国家教委第三届优秀教材二等奖，我以为正是实至名归。在本书再版之际，谨以此表示祝贺之忱。

<div style="text-align: center;"><img src="images/p0007_img_in_image_box_679_643_818_708.jpg" alt="Image" width="14%" /></div>


1996年丙子仲秋

<!-- page: 8 -->

### 第二版前言

本书第一版虽然荣幸获得了国家教委第三届优秀教材二等奖，但一本好的教材必须通过在教学实践中的千锤百炼，不断地充实、更新，才能满足读者和迅猛发展的科学技术的需要。故借此再版之机，我们对本书第一版的内容作了如下一些修改：

1. 对部分章、节的写法和内容作了些改动。如第二篇的 §3.5，§5.1，§5.5，§8.2；第三篇的 §2.3 等，以使本书能更紧密地结合物理学及相关课程的内容。

2. 在第四篇的非线性方程部分增加了“解析近似解和正则摄动法”一节，以满足近代物理学中解大量非线性方程的需要；在附录中增加了“矢量公式和矢量定理”的内容，以便读者学习本课程时查阅；在部分章节中增加了一些例题和习题，特别是将近些年来美国部分高校的研究生试题及 CUSPEA 考题中与本课程相关的内容分别录入到了相关章节的习题中，以进一步开拓学生视野，提高学生分析问题和解决问题的能力。

3. 删去了第三篇中与高等数学重复的“常微分方程的级数解法”的内容和附录中的“贝塞尔函数表”，仅将所需用到的结论和数据简述在相应章节的附注中.

4. 对习题中可作为公式和结论运用的题加上了公式编号；而对习题中的难题、超纲题打上了 * 标记.

5. 对书中和习题答案中的印刷错误进行了更正.

本书自1992年问世以来，得到校内外广大读者和专家的关心与支持，特别是武汉大学物理学93级“人才基地班”的同学，为本书的再版提供了许多宝贵的意见，武汉大学出版社为本书的再版给予了大力支持，在此一并表示衷心的感谢。

这次再版，尽管我们倾注了不少心血，但由于水平和时间的限制，错误或不妥之处在所难免，敬请读者批评指正。

编者

1996年暑期于珞珈山

<!-- page: 9 -->

### 第一版前言

本书是在多年来武汉大学物理类专业数学物理方法课程所用的自编教材和讲义的基础上修改而成的。其内容包括复变函数论、数学物理方程、特殊函数、积分方程和非线性方程简介四个部分。适合物理类专业和相应的专业教学使用。

数学物理方法是物理系基础理论课——四大力学之间的黏合剂，是解决物理学中各种具体问题的重要工具之一。为了编写出一本较为理想的数学物理方法教材，使之不仅局限于叙述知识，更主要的是引导学生去思考问题，使他们具有分析问题和解决问题的能力，在编写时我们注意了以下几点：

一、第二篇是以数学物理方程的各种解法为主线进行编写的。这样可使读者一目了然地了解数理方程一般有哪些解法，同时还便于读者将同一问题的不同解法进行对比，从而选择最佳方法来解决具体问题。

二、在每一小节的内容后都编入了相当数量的习题（在附录中有参考答案），使读者能及时消化所学知识。在习题中，编入了一定量的能开拓学生知识面的内容。这样，既不挤占教材篇幅，又可使学生掌握更多知识。

三、每一章后都附有小结，使学生对整章内容融会贯通，加强知识的条理性、系统性。小结的形式多采用表格或框图，以便于学生对比和加深印象。

四、考虑到物理类专业的特点，对有些定理或公式不是单从数学上进行推导，而是先从物理背景、物理前景方面进行阐述，使读者易于理解和接受。书中的内容、例题和习题也都尽量结合物理问题和物理实例。

五、随着学科的新进展，根据需要，将传统数学物理方法教科书中没有而对物理学又十分有用的某些积分方程和非线性方程的解法作为第四篇编入到了本书中。

六、为了教学的方便，将本课程用到的其他课程的部分定理、公式，编写到了本书相应章节的注释中。

七、书中打“*”的章节，若受学时限制，教师可只选讲，或放入习题课中讲解，也可不讲。

本书的出版，得到了武汉大学教务处、物理系、物理系基地班及出版社有关负责同志的大力支持。保宗悌教授在百忙中对本书进行了审阅；李中辅教授对本书的编写提出了一些宝贵的意见并作了有益的指教；龙理老师为本书核对了习题答案，在此一并表示衷心的感谢！

由于编者水平有限，再加之时间仓促，难免有不妥甚至谬误之处，敬请读者批评指正。

编者

1991年10月

<!-- page: 10 -->

## 目录

## 第一篇 复变函数论

第一章 解析函数……3    
1.1 复数及其运算……3    
习题1.1……6    
1.2 复变函数……7    
习题1.2……9    
1.3 微商及解析函数……10    
习题1.3……15    
1.4 初等解析函数……16    
习题1.4……22    
1.5 解析函数的几何性质……23    
习题1.5……28    
本章小结……29    
第二章 解析函数积分……30    
2.1 复变函数的积分……30    
习题2.1……32    
2.2 柯西定理……33    
习题2.2……38    
2.3 柯西积分公式……38    
习题2.3……44    
本章小结……45    
第三章 复变函数级数……46    
3.1 复级数……46    
3.2 幂级数……49    
习题3.2……51    
3.3 泰勒级数……51    
习题3.3……54    
3.4 洛朗级数……55    
习题3.4……60    
3.5 单值函数的孤立奇点……61    
习题3.5……65

<!-- page: 11 -->

本章小结 ..... 67    
第四章 解析延拓 Γ函数 B函数 ..... 68    
4.1 解析延拓 ..... 68    
习题4.1 ..... 70    
4.2 Γ函数 ..... 71    
习题4.2 ..... 73    
4.3 B函数 ..... 74    
习题4.3 ..... 75    
本章小结 ..... 76    
第五章 留数理论 ..... 77    
5.1 留数定理 ..... 77    
习题5.1 ..... 81    
5.2 利用留数理论计算实积分 ..... 82    
习题5.2 ..... 86    
5.3 物理问题中的几个积分 ..... 87    
习题5.3 ..... 90    
5.4 多值函数的积分 ..... 91    
习题5.4 ..... 93    
本章小结 ..... 95    
    
第二篇 数学物理方程    
第六章 定解问题 ..... 99    
6.1 引言 ..... 99    
6.2 三类数理方程的导出 ..... 101    
习题6.2 ..... 105    
6.3 定解条件 ..... 106    
习题6.3 ..... 110    
本章小结 ..... 111    
第七章 行波法 ..... 112    
7.1 无界弦的自由振动 达朗贝尔公式 ..... 112    
习题7.1 ..... 116    
7.2 无界弦的强迫振动 ..... 117    
习题7.2 ..... 121    
7.3 三维无界空间的自由振动 泊松公式 ..... 121    
习题7.3 ..... 127    
7.4 三维无界空间的受迫振动 推迟势 ..... 127    
本章小结 ..... 130

<!-- page: 12 -->

第八章 分离变量法……131    
8.1 有界弦的自由振动……131    
习题8.1……138    
8.2 非齐次方程 纯强迫振动……140    
习题8.2……143    
8.3 非齐次边界条件的处理……144    
习题8.3……148    
8.4 正交曲线坐标系中的分离变量法……148    
习题8.4……157    
本章小结……159    
第九章 积分变换法……160    
9.1 傅里叶变换……160    
习题9.1……167    
9.2 傅里叶变换法……169    
习题9.2……172    
9.3 拉普拉斯变换……173    
习题9.3……179    
9.4 拉普拉斯变换法……180    
习题9.4……182    
本章小结……184    
第十章 格林函数法……185    
10.1 δ函数……185    
习题10.1……188    
10.2 边值问题的格林函数法……189    
习题10.2……195    
10.3 稳恒问题的格林函数……195    
习题10.3……198    
10.4 电像法与狄氏格林函数……199    
习题10.4……204    
10.5 含时问题的格林函数法……205    
习题10.5……210    
本章小结……211    
第三篇 特殊函数    
第十一章 勒让德多项式……215    
11.1 勒让德多项式……215

<!-- page: 13 -->

11.2 勒让德多项式的性质……220      
习题11.2 ……226      
11.3 连带勒让德函数与球函数……227      
习题11.3 ……232      
本章小结……233      
第十二章 贝塞尔函数……234      
12.1 贝塞尔函数……234      
习题12.1 ……239      
12.2 贝塞尔函数的性质……239      
习题12.2 ……245      
12.3 其他柱函数……246      
习题12.3 ……253      
本章小结……256      
第十三章 施图姆-刘维尔理论……258      
13.1 施图姆-刘维尔本征值问题……258      
习题13.1 ……261      
13.2 高斯方程和库默尔方程……262      
本篇主要特殊函数性质小结……265      
* 第四篇 近似方法及现代内容      
第十四章 变分法……269      
14.1 泛函和泛函的极值……269      
习题14.1 ……277      
14.2 用变分法解数理方程……278      
习题14.2 ……285      
本章小结……286      
第十五章 非线性方程……287      
15.1 非线性方程的某些初等解法……287      
习题15.1 ……292      
15.2 孤波和孤子……292      
习题15.2 ……297      
15.3 解析近似法之正则摄动法……298      
习题15.3 ……301      
15.4 数值解法之分步傅里叶变换法……301      
本章小结……305      
第十六章 积分方程……306      
16.1 积分方程的几种解法……306

<!-- page: 14 -->

习题16.1 ……312    
16.2 施密特-希尔伯特理论 ……313    
习题16.2 ……316    
16.3 维纳-霍普夫方法 ……316    
习题16.3 ……318    
本章小结……319    
第十七章 小波变换……320    
17.1 小波变换的由来……320    
17.2 小波变换……323    
习题参考答案……327    
参考文献……349    
附录……350    
Ⅰ. 矢量微分算子与拉普拉斯算符 ……350    
Ⅱ. 傅里叶变换简表……352    
Ⅲ. 拉普拉斯变换简表……353    
索引……355

<!-- page: 15 -->

## Contents

Part One Theory of Complex Variable Function    
    
Chapter 1 Analytic Function ..... 3    
1.1 Complex numbers and their operations ..... 3    
Problem 1.1 ..... 6    
1.2 Function of a complex variable ..... 7    
Problem 1.2 ..... 9    
1.3 Derivative and analytic function ..... 10    
Problem 1.3 ..... 15    
1.4 Elementary analytic functions ..... 16    
Problem 1.4 ..... 22    
1.5 Geometric properties of analytic functions ..... 23    
Problem 1.5 ..... 28    
Summary for chapter 1 ..... 29    
Chapter 2 The Integral of the Analytic Function ..... 30    
2.1 The integral of the variable function ..... 30    
Problem 2.1 ..... 32    
2.2 The Cauchy theorem ..... 33    
Problem 2.2 ..... 38    
2.3 Cauchy integral formula ..... 38    
Problem 2.3 ..... 44    
Summary for chapter 2 ..... 45    
Chapter 3 Series of Complex Variable Function ..... 46    
3.1 Complex series ..... 46    
3.2 Power series ..... 49    
Problem 3.2 ..... 51    
3.3 Taylor series ..... 51    
Problem 3.3 ..... 54    
3.4 Laurent series ..... 55    
Problem 3.4 ..... 60    
3.5 The isolated singularity of the single-valued function ..... 61

<!-- page: 16 -->

Problem 3.5 ..... 65    
Summary for chapter 3 ..... 67    
Chapter 4 Analytic Continuation $\Gamma$ Function B Function ..... 68    
4.1 Analytic continuation ..... 68    
Problem 4.1 ..... 70    
4.2 $\Gamma$ function ..... 71    
Problem 4.2 ..... 73    
4.3 B-function ..... 74    
Problem 4.3 ..... 75    
Summary for chapter 4 ..... 76    
Chapter 5 The Residue Theory ..... 77    
5.1 The Residue theorem ..... 77    
Problem 5.1 ..... 81    
5.2 Real integral calculated by the Residue theorem ..... 82    
Problem 5.2 ..... 86    
5.3 Several integrals in physical problems ..... 87    
Problem 5.3 ..... 90    
*5.4 Integrals of the multi-valued function ..... 91    
Problem 5.4 ..... 93    
Summary for chapter 5 ..... 95    
Part Two Equations of Mathematical Physics    
Chapter 6 Complete Mathematical Models ..... 99    
6.1 Introduction ..... 99    
6.2 Derivation for three type of equations of mathematical physics ..... 101    
Problem 6.2 ..... 105    
6.3 Boundary conditions and initial conditions ..... 106    
Problem 6.3 ..... 110    
Summary for chapter 6 ..... 111    
Chapter 7 Method of Traveling Waves ..... 112    
7.1 Solution for the free vibration of the unbounded string $D'$ Alembert formula ..... 112    
Problem 7.1 ..... 116    
7.2 Solution for the pure forced vibration of the unbounded string ..... 117    
Problem 7.2 ..... 121    
*7.3 The free vibration in three-dimensional unbounded space Poisson

<!-- page: 17 -->

formula ..... 121    
Problem 7.3 ..... 127    
*7.4 The forced vibration in three-dimensional unbounded space Retarded potentials ..... 127    
Summary for chapter 7 ..... 130    
Chapter 8 The Method of Separation of Variables ..... 131    
8.1 The free-vibration of the bounded string ..... 131    
Problem 8.1 ..... 138    
8.2 The non-homogeneous equation-the pure forced vibration ..... 140    
Problem 8.2 ..... 143    
8.3 The treatment of the non-homogeneous boundary conditions ..... 144    
Problem 8.3 ..... 148    
8.4 The separation of variables in the orthogonal curvilinear coordinates ..... 148    
Problem 8.4 ..... 157    
Summary for chapter 8 ..... 159    
Chapter 9 Integral Variable Method ..... 160    
9.1 Fourier transforms ..... 160    
Problem 9.1 ..... 167    
9.2 Fourier transform method ..... 169    
Problem 9.2 ..... 172    
9.3 Laplace transforms ..... 173    
Problem 9.3 ..... 179    
9.4 Laplace transform method ..... 180    
Problem 9.4 ..... 182    
Summary for chapter 9 ..... 184    
Chapter 10 Green's Function Method ..... 185    
10.1 $\delta$-function ..... 185    
Problem 10.1 ..... 188    
10.2 Boundary value problems solved by Green's function method ..... 189    
Problem 10.2 ..... 195    
10.3 Green's function for stable problem ..... 195    
Problem 10.3 ..... 198    
10.4 Electro-image method and Dirichlet Green's function ..... 199    
Problem 10.4 ..... 204

<!-- page: 18 -->

* 10.5 Time-related mathematical problems solved by Green's function    
method ..... 205    
Problem 10.5 ..... 210    
Summary for chapter 10 ..... 211    
Part Three Special Functions    
Chapter 11 Legendre Polynomials ..... 215    
11.1 Legendre polynomials ..... 215    
Problem 11.1 ..... 220    
11.2 The property of Legendre polynomials ..... 220    
Problem 11.2 ..... 226    
11.3 Associated Legendre function and spherical function ..... 227    
Problem 11.3 ..... 232    
Summary for chapter 11 ..... 233    
Chapter 12 Bessel functions ..... 234    
12.1 Bessel functions ..... 234    
Problem 12.1 ..... 239    
12.2 The property of Bessel functions ..... 239    
Problem 12.2 ..... 245    
* 12.3 Other Column Functions ..... 246    
Problem 12.3 ..... 253    
Summary for chapter 12 ..... 256    
Chapter 13 Sturm-Liouville Theory ..... 258    
13.1 Sturm-Liouville Eigenvalue problem ..... 258    
Problem 13.1 ..... 261    
* 13.2 Gauss equation and the Kummer equation ..... 262    
Summary for the properties of the principal special functions in part three ..... 265    
* Part Four Approximation Method and Modern Content    
Chapter 14 The Variational Method ..... 269    
14.1 Functionals and functional extreme ..... 269    
Problem 14.1 ..... 277    
14.2 Solving equations of mathematical physics by the variational method ..... 278    
Problem 14.2 ..... 285

<!-- page: 19 -->

Summary for chapter 14 ..... 286    
Chapter 15 Nonlinear Equations ..... 287    
15.1 Some Primary solution method for nonlinear equations ..... 287    
Problem 15.1 ..... 292    
15.2 Isolated wave and soliton ..... 292    
Problem 15.2 ..... 297    
15.3 The regular perturbation method in analytical approximation methods ..... 298    
Problem 15.3 ..... 301    
15.4 A step-by-step Fourier transform method for numerical approximate methods ..... 301    
Summary for chapter 15 ..... 305    
Chapter 16 Integral Equations ..... 306    
16.1 Several methods for solving integral equations ..... 306    
Problem 16.1 ..... 312    
16.2 Schmidt-Hilbert theory ..... 313    
Problem 16.2 ..... 316    
16.3 Wiener-Hopf method ..... 316    
Problem 16.3 ..... 318    
Summary for chapter 16 ..... 319    
Chapter 17 Wavelet transform ..... 320    
17.1 The origin of wavelet transform ..... 320    
17.2 Wavelet transform ..... 323    
Reference keys to the problems ..... 327    
Bibliography and references ..... 349    
Appendix ..... 350    
I. Vector Differential Operator and Laplace Operator ..... 350    
II. Summary table of Fourier transform ..... 352    
III. Summary table of Laplace transform ..... 353    
Index ..... 355

<!-- page: 20 -->

我没有试图直接解决某一物理问题，而只是试图寻找某种优美的数学.

——狄拉克

## 第一篇 复变函数论

复变函数论是实变函数论的推广与发展。它产生于18世纪，全面发展于19世纪，被誉为19世纪最独特的创造。当时的数学家们公论复变函数论是最丰饶的数学分支，并称之为19世纪的数学享受，赞之是抽象科学中最和谐的理论之一。复变函数论被广泛地应用于自然科学的众多领域，其内容主要包括解析函数理论、黎曼曲面理论、几何函数论、留数理论、广义函数等。本篇将分5章介绍物理学中常用到的以上理论中的相关内容。

<!-- page: 21 -->

复变函数的理论特别是其中的解析函数在物理学中有着广泛的应用。本章将建立复变函数的基本概念，并在此基础上引入解析函数；在以后各章将介绍解析函数的性质和应用。

### 1.1 复数及其运算

## 1. 复数的概念

一对有序的实数 $ (x,y) $定义为复数，通常表示为

$$  z=x+iy   \tag*{(1,1,1)}$$

式中 i 满足  $ i^{2} = -1 $，称为虚单位；而 x 和 y 都是实数，分别称为复数 z 的实部和虚部，常记为

 $$ x=Re z,\quad y=Im z $$ 

虚部为零的复数就可看作是实数，即  $ x + i0 = x $。因此，全体实数是全体复数的一部分。实部为零的复数称为纯虚数。两个复数相等，是指它们的实部和虚部分别相等，即

必须且只须

 $$ \begin{aligned}&x_{1}+i y_{1}=x_{2}+i y_{2}\\&x_{1}=x_{2},\quad y_{1}=y_{2}\\ \end{aligned} $$ 

复数  $ x + iy $ 和 x - iy 互称为共轭复数，常用  $ \bar{z} $ 表示 z 的共轭复数，于是

$$  \bar{z}=x-iy   \tag*{(1.1.2)}$$

## 2. 复数的几何表示

复数的几何表示对于了解复变函数理论中的一些概念，例如多值函数、解析延拓等，很有帮助，而在复变函数论的一个重要应用方面——保角变换，更是必须的。

复数  $ z = x + iy $ 可以用平面上的点表示（见图1.1）。在平面上作一直角坐标系，取横轴OX为实轴，单位为1，纵横OY为虚轴，单位为i，则复数 z 就可

<div style="text-align: center;"><img src="images/p0021_img_in_image_box_613_883_859_1145.jpg" alt="图1.1" width="25%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.1</div> </div>


以用横坐标等于x、纵坐标等于y的点表示。显然，对于每个复数，平面上有唯一的点与之相应；反过来，对于平面上的每一点，也有唯一的一个复数与之相对应。这也就是

<!-- page: 22 -->

说，复数全体与平面上的点有一一对应的关系.这样的平面称为复平面（或z平面）.

也可用从原点 O 到 z 点所引的向量  $ \overrightarrow{Oz} $ 表示复数  $ z = x + iy $ 。显然， $ \overrightarrow{Oz} $ 在实轴和虚轴上的投影分别表示  $ z = x + iy $ 的 x 和 y（图1.1）。若引入极坐标变量  $ (\rho, \varphi) $，则

 $$ x=\rho\cos\varphi,\quad y=\rho\sin\varphi $$ 

于是

$$  z=\rho\cos\varphi+i\rho\sin\varphi   \tag*{(1.1.3)}$$

或

$$  z=\rho\mathrm{e}^{\mathrm{i}\varphi}   \tag*{(1.1.4)}$$

(1,1,3)式和(1,1,4)式分别称为复数z的三角表示式和指数表示式.式中的 $ \rho $为向量 $ \overrightarrow{Oz} $的长度，称为复数z的模或绝对值，记作

$$  \rho=\mid z\mid=\sqrt{x^{2}+y^{2}}   \tag*{(1.1.5)}$$

而  $ \varphi $ 为向量  $ \overrightarrow{Oz} $ 与 x 轴的夹角，称为复数 z 的辐角，记作

$$  \varphi=\arg z,\qquad\tan\varphi=\frac{y}{x}   \tag*{(1.1.6)}$$

任一复数  $ z \neq 0 $ 有无穷多个辐角（例如  $ 30^{\circ}, 30^{\circ} + 2\pi, 30^{\circ} + 4\pi, \cdots $，均为同一向量的辐角），今以 argz 表示其中在  $ 2\pi $ 范围内变化的一个特定值，称之为辐角的主值，通常取

 $$ -\pi<\arg z\leqslant\pi $$ 

于是

$$  \mathrm{A r g}z=\arg z+2k\pi,\qquad k=0,\pm1,\pm2,\cdots   \tag*{(1.1.7)}$$

注意，当 z=0 时，其模为零，辐角无定义.

argz 与 Arctan  $ \frac{y}{x} $ 的主值  $ \arctan\frac{y}{x}\left(-\frac{\pi}{2}<\arctan\frac{y}{x}<\frac{\pi}{2}\right) $ 有如下关系：

$$   arg z=\left\{\begin{aligned}&\arctan\frac{y}{x},&z 在第Ⅰ象限 \\&\arctan\frac{y}{x}+\pi,&z 在第Ⅱ象限 \\&\arctan\frac{y}{x}-\pi,&z 在第Ⅲ象限 \\&\arctan\frac{y}{x},&z 在第Ⅳ象限 \end{aligned}\right.   \tag*{(1.1.8)}$$

例 1 已知流体在某点的速度 v = -1 - i，求其大小和方向.

解 大小： $ \left|v\right|=\sqrt{2} $

方向： $ \arg v = \arctan \frac{-1}{-1} - \pi = -\frac{3}{4}\pi $

注意，复数是没有大小的，因此以后在比较大小时只能用模来比较。

前面只是把模为有限的复数跟复数平面上的有限远点一一对应起来；在复

<!-- page: 23 -->

变函数理论中把无穷大也理解为复数平面上的一个“点”，称之为无限远点，并记为 $ \infty $，其模大于任何正数，辐角不定。显然，我们是难于用平面上的一个具体的点来描绘无限远点的，为此我们将引入复球面的概念。对于包括无限远点在内的复数的几何图像，也可用复球面来表示。如图1.2所示，把一个球放在复平面上，使其南极S与复平面相切于原点O，设复平面上的任意一点A与球的北极N的连线交球面于 $ A^{\prime} $点，于是，复



<div style="text-align: center;"><img src="images/p0023_img_in_image_box_517_181_857_371.jpg" alt="图1.2" width="35%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.2</div> </div>


数平面上的每一有限远点，都有球面上的点（除 N 以外）与之一一一对应（此对应关系称做测地投影）。若让 A 点以任何方式无限地远离原点 O，则相应的 A' 点将无限地趋近球面的北极 N，故可将 N 点看作无限远点的代表点，而整个球面就把无限远点包括在内。这样的球面称为复球面或黎曼（Riemann）球面。通常所指的复平面不包括无限远点。包括无限远点的复平面称为扩充了的复平面或全平面，它与复球面对应。复平面上只有一个无穷远点。

## 3. 复数的运算规则

由于实数是复数的特例，故在规定其运算方法时，既应使复数运算的法则施行于实数特例时，能够和实数运算的结果相符合，又应使复数的算术运算能够满足实数算术运算的一般规律（如加法遵守交换律与结合律；乘法遵守交换律、结合律与对加法的分配律等），为此我们规定：

（1）两复数  $ z_{1}=x_{1}+\mathrm{i}y_{1} $ 及  $ z_{2}=x_{2}+\mathrm{i}y_{2} $ 相加（减），可将它们的实部与实部，虚部与虚部分别相加（减），即

$$  z_{1}\pm z_{2}=(x_{1}\pm x_{2})+\mathrm{i}(y_{1}\pm y_{2})   \tag*{(1.1.9)}$$

（2）两复数  $ z_{1}=x_{1}+iy_{1} $ 及  $ z_{2}=x_{2}+iy_{2} $ 相乘，可按多项式乘法法则来进行，只需将结果中  $ i^{2} $ 换成 -1，即

$$  z_{1}\bullet z_{2}=(x_{1}x_{2}-y_{1}y_{2})+\mathrm{i}(x_{1}y_{2}+y_{1}x_{2})   \tag*{(1.1.10)}$$

（3）两复数  $ z_{1}=x_{1}+iy_{1} $ 及  $ z_{2}=x_{2}+iy_{2} $ 相除（除数 $ \neq0 $），可先把它写成分式的形式，然后分子分母同乘以分母的共轭复数，再进行化简，即

$$  \frac{z_{1}}{z_{2}}=\frac{x_{1}x_{2}+y_{1}y_{2}}{x_{2}^{2}+y_{2}^{2}}+\mathrm{i}\frac{y_{1}x_{2}-x_{1}y_{2}}{x_{2}^{2}+y_{2}^{2}},\quad z_{2}\neq0   \tag*{(1.1.11)}$$

由上述规定很容易证明

$$  \mathrm{e}^{\mathrm{i}\varphi_{1}}\bullet\mathrm{e}^{\mathrm{i}\varphi_{2}}\;=\;\mathrm{e}^{\mathrm{i}(\varphi_{1}+\varphi_{2})}   \tag*{(1.1.12)}$$

$$  \mathrm{e}^{\mathrm{i}\varphi_{1}}/\mathrm{e}^{\mathrm{i}\varphi_{2}}=\mathrm{e}^{\mathrm{i}(\varphi_{1}-\varphi_{2})}   \tag*{(1.1.13)}$$

故我们不难得到复数的乘、除、乘方和开方等运算的指数表示式

$$  z_{1}\bullet z_{2}=\rho_{1}\rho_{2}\mathrm{e}^{\mathrm{i}(\varphi_{1}+\varphi_{2})}   \tag*{（1.1.14）}$$

<!-- page: 24 -->

$$  \frac{z_{1}}{z_{2}}=\frac{\rho_{1}}{\rho_{2}}\mathrm{e}^{\mathrm{i}(\varphi_{1}-\varphi_{2})}   \tag*{(1.1.15)}$$

$$  z^{n}=\rho^{n}\mathrm{e}^{\mathrm{i}m\varphi},\qquad n=1,2,3,\cdots   \tag*{(1.1.16)}$$

$$  \sqrt[m]{z}=\sqrt[m]{\rho}\mathrm{e}^{\mathrm{i}\frac{\varphi}{m}}=\sqrt[m]{\rho}\mathrm{e}^{\mathrm{i}\frac{\arg z+2k\pi}{m}},\quad m=2,3,\cdots;k=0,\pm1,\pm2,\cdots   \tag*{(1.1.17)}$$

(1.1.17)式中的 k 本可取  $ 0, \pm1, \pm2, \cdots $，但实际上 k 只要取 0,1,…,m-1，就可得到  $ \sqrt[m]{z} $ 的 m 个不同的值，即， $ \arg(\sqrt[m]{z})=\frac{\arg z+2k\pi}{m}, k=0,1,2,\cdots,m-1 $。不难验证，k 取其他整数时所得到的  $ \sqrt[m]{z} $ 的值与这 m 个值相同.

例2 求 $ \sqrt[3]{-8} $之值.

解 因 -8 = 8e^{in}, 所以

 $$ \sqrt[3]{-8}=\sqrt[3]{8}\mathrm{e}^{\mathrm{i}\frac{\pi+2k\pi}{3}},\quad k=0,1,2 $$ 

当 k=0 时， $ \sqrt[3]{-8}=\sqrt[3]{8}\mathrm{e}^{\mathrm{i}\frac{\pi}{3}}=1+\mathrm{i}\sqrt{3} $;

当 k=1 时， $ \sqrt[3]{-8}=\sqrt[3]{8}\mathrm{e}^{\mathrm{i}\pi}=-2 $

当 k=2 时， $ \sqrt[3]{-8}=\sqrt[3]{8}\mathrm{e}^{\frac{5\pi}{3}}=1-\mathrm{i}\sqrt{3} $

注 ① 当然，矢量的起点可以不在原点；也就是说长度和方向都相同的矢量表示同一个矢量。

#### 习题1.1

1. 用复变量表示：

（1）上半平面；（2）左半平面；（3）半圆（包括边界）；（4）扇形（不要边界）.

2. 求出下列关系的几何位置：

(1) $ \left|z-a\right|=\left|z-b\right| $，a 和 b 为复常数；（2） $ \left|z\right|+\operatorname{Re}z\leq1 $；

(3)

 $$ \operatorname{Re}\frac{1}{z}=2;\quad(4)\quad\left|z-\frac{a}{2}\right|+\left|z+\frac{a}{2}\right|=c,\quad a>0,c>0. $$ 

3. 试证明下列恒等式或关系式，并解释其几何意义：

 $$ |z_{1}+z_{2}|^{2}+|z_{1}-z_{2}|^{2}=2(|z_{1}|^{2}+|z_{2}|^{2}); $$ 

(1)

(2)

 $$ \left|z_{1}+z_{2}\right|\leqslant\left|z_{1}\right|+\left|z_{2}\right|; $$ 

(3)

$$  \left|z_{1}+z_{2}\right|\geqslant\left|z_{1}\right|-\left|z_{2}\right|；   \tag*{(1.1.20)}$$

(4)

$$  \mid z_{1}\mid-\mid z_{2}\mid\mid\leqslant\mid z_{1}-z_{2}\mid.   \tag*{(1.1.21)}$$

4. 求下列复数的实部、虚部、模与辐角主值：

(1)

 $$ 1-\cos\alpha+\sin\alpha,0<\alpha\leq\pi; $$ 

(2)

 $$ \frac{1-2\mathrm{i}}{3-4\mathrm{i}}-\frac{2-\mathrm{i}}{5\mathrm{i}}； $$ 

(3)

 $$ (\sqrt{3}+i)^{-3} $$ 

(4)

 $$ \mathrm{e}^{1+i}. $$ 

5. 证明棣摩弗(De Moivre)公式

$$  (\cos\theta+i\sin\theta)^{n}=\cos n\theta+i\sin n\theta   \tag*{(1,1,22)}$$

并用  $ \cos\theta $ 及  $ \sin\theta $ 表示  $ \cos n\theta $ 及  $ \sin n\theta $.

6. 计算下列数值：

(1)  $ \sqrt{1+i} $; (2)  $ (\sqrt{3}-i)^{5} $; (3)  $ \mathrm{Arg}(2-2i) $; (4)  $ (1+\sqrt{3}i)^{-10} $.

<!-- page: 25 -->

7. 求解方程

(1) $ z^{3}-1=0 $; (2) $ z^{2}-(2+3i)z-1+3i=0 $.

8. 设流体在点  $ z=1+2i $ 的流速为  $ v=\frac{3+i}{2-i} $，求其大小和方向.

9. 验证下列关系成立：

(1)  $ z \cdot \bar{z} = |z|^2 $,  $ \frac{z + \bar{z}}{2} = \mathrm{Re}z $,  $ \frac{z - \bar{z}}{2i} = \mathrm{Im}z $;

(2) 设  $ R(a,b,c,\cdots) $ 表示对于复数 a,b,c, $ \cdots $ 的任一有理运算，则  $ \overrightarrow{R(a,b,c\cdots)}=R(\overrightarrow{a},\overrightarrow{b},\overrightarrow{c},\cdots) $.

10. 写出下列曲线方程的复变量形式：

（1）双曲方程  $ x^{2}-y^{2}=1 $

（2）椭圆方程  $ \frac{x^{2}}{a^{2}}+\frac{y^{2}}{b^{2}}=1 $;

（3）圆的方程  $ (x-x_{0})^{2}+(y-y_{0})^{2}=R^{2} $

（4）直线方程  $ Ax+By+C=0 $

### 1.2 复变函数

## 1. 复变函数的概念

设 E 为复数平面的一点集（复数的集合），若按一定的规律，使 E 内每一复数 z 都有一个或多个的  $ w = u + \mathrm{i}v $ （u 和 v 为实数）与之相应，则称 w 为 z 的复变函数，定义域为 E，记作

 $$ w=f(z),\quad z\in E $$ 

若一个z只有一个w之值与之对应（例如 $ w=z^{2} $），则称w为z的单值函数。特别是若在E内至少存在不同的两点 $ z_{1} $及 $ z_{2} $，使 $ w=f(z_{1})=f(z_{2}) $，则称w在E内是多叶的（如 $ w=z^{2} $）；否则是单叶的（如 $ w=az+b,a\neq0 $）。

若一个 z 有多个 w 之值与之对应（例如  $ w=\sqrt{z} $），则称 w 为 z 的多值函数。因 z=x+iy，于是

$$  w=f(z)=u(x,y)+\mathrm{i}v(x,y)   \tag*{(1,2,1)}$$

这表明，一个复变函数无非是两个二元实变函数的有序组合，因而研究一个复变函数，也就是要研究两个实二元函数。

## 2. 区域的概念

在解析函数论中，函数的定义域不是一般的点集，而是满足一定特殊条件的点集——区域。为此，下面我们将引入区域及与之有关的一些概念。

（1）邻域：由不等式 $ \left|z-z_{0}\right|<\varepsilon $而确定的平面点集，称为定点 $ z_{0} $的 $ \varepsilon $-邻域.

（2）内点：若 $ z_{0} $有一个邻域全含于点集E内，则称 $ z_{0} $为点集E的内点。例如，若E为 $ |z|<1 $所确定的点集，则满足 $ |z|<1 $的所有点均为E的内点。

<!-- page: 26 -->

<div style="text-align: center;"><img src="images/p0026_img_in_image_box_100_144_412_491.jpg" alt="图1.3" width="32%" /></div>


（3）区域：具备下列性质的点集 $ \sigma $称为区域.

<div style="text-align: center;"><div style="text-align: center;">图1.3</div> </div>


① 全由内点组成.

② $ \sigma $ 中任意两点可用全在  $ \sigma $ 中的折线连接（图1.3）. 例如， $ \left|z\right|<1 $ 表示 z 平面上以原点为中心，1 为半径的圆形区域.

（4）外点：若 $ z_{0} $不属于区域 $ \sigma $且有一个邻域不含有 $ \sigma $的点，则称 $ z_{0} $为区域 $ \sigma $的外点。例如，满足 $ |z|>1 $的所有点都是区域 $ |z|<1 $的外点。

（5）界点：若 $ z_{0} $不属于区域 $ \sigma $，但以 $ z_{0} $为中心的无论多小的邻域内总有属于区域 $ \sigma $的点，则称 $ z_{0} $为 $ \sigma $的界点。例如，满足 $ |z|=1 $的所有点均为区域 $ \left|z\right|<1 $的界点。 $ \sigma $的全部界点称为 $ \sigma $的边界。若沿边界走，区域在左方，则走向称为边界的正向。



（6）闭区域：区域 $ \sigma $连同它的边界l称为闭区域，记为 $ \bar{\sigma}=\sigma+l $。例如， $ \left|z\right|\leqslant1 $表示以原点为中心、1为半径的闭圆（即圆形闭区域）。

（7）单连通区域和复连通区域：若在区域 $ \sigma $内作任何简单的闭曲线（除起点和终点外别无重点的连续曲线），其内的点都是属于 $ \sigma $的点，则称该区域 $ \sigma $为单连通区域（图1.4斜线部分）。不是单连通的区域就是复连通（或多连通）区域（图1.5斜线部分）。

<div style="text-align: center;"><img src="images/p0026_img_in_image_box_132_824_464_1004.jpg" alt="图1.4" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.4</div> </div>


<div style="text-align: center;"><img src="images/p0026_img_in_image_box_543_795_825_1003.jpg" alt="图1.5" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.5</div> </div>


## 3. 极限与连续性

设函数  $ w = f(z) $ 在  $ z_{0} $ 点的某邻域有定义（在  $ z_{0} $ 点不一定有定义），若对于任意给定的  $ \varepsilon > 0 $，总存在有  $ \delta > 0 $，使得当  $ 0 < |z - z_{0}| < \delta $ 时，就有  $ |f(z) - w_{0}| < \varepsilon (w_{0} $ 为一确定的复常数 $ ) $，则称  $ f(z) $ 当  $ z \to z_{0} $ 时以  $ w_{0} $ 为极限，并记为

$$  \lim_{z\to z_{0}}f(z)=w_{0}   \tag*{(1,2,2)}$$

<!-- page: 27 -->

应当注意的是，由于 z 是复平面上的变量，所以上式中  $ z \to z_{0} $ 必须是以任意的方式。与实函数类似，对于复变函数我们亦可证明下述结论：

（1）若极限存在必然唯一.

（2）若两个函数在某点有极限，则其和、差、积、商（分母的极限不能为0）在该点仍有极限，且其极限值等于他们各自极限值的和、差、积、商.

设  $ w = f(z) $ 在  $ z_{0} $ 点及其邻域有定义，并且当  $ z \to z_{0} $ 时，有

$$  \lim_{z\to z_{0}}f(z)=f(z_{0})   \tag*{(1,2,3)}$$

则称  $ f(z) $ 在  $ z_{0} $ 点连续. 在区域  $ \sigma $ 内各点均连续的函数称为在  $ \sigma $ 内的连续函数.

类似于实函数，对于复变函数我们亦可证明下述结论：

（1）若两函数在某点连续，则其和、差、积、商（分母不能为0）在该点仍连续.

（2）在某点连续的函数的复合函数在该点仍连续.

（3）若  $ f(x) $ 在闭区域  $ \bar{\sigma} $ 上连续，则

①  $ f(z) $ 在  $ \bar{\sigma} $ 上有界；

②  $ \left|f(z)\right| $ 在  $ \bar{\sigma} $ 上有最大值和最小值；

③  $ f(z) $ 在  $ \bar{\sigma} $ 上一致连续，即任给  $ \varepsilon>0 $，有与 z 无关的  $ \delta>0 $，使对  $ \bar{\sigma} $ 上满足  $ \left|z_{1}-z_{2}\right|<\delta $ 的任意两点  $ z_{1} $ 及  $ z_{2} $，均有  $ \left|f(z_{1})-f(z_{2})\right|<\varepsilon $.

不难证明函数  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $ 在  $ z_{0} $ 点连续的充分必要条件是，二元实函数  $ u(x,y) $ 和  $ v(x,y) $ 均在  $ z_{0} $ 点连续.

例 证  $ f(z)=\mathrm{e}^{\frac{1}{z}} $ 在原点不连续.

证因

 $$ \begin{aligned}&\lim_{\substack{z\to0}}\mathrm{e}^{\frac{1}{z}}=0\quad( 沿负实轴 ),\quad\lim_{\substack{z\to0}}\mathrm{e}^{\frac{1}{z}}=\infty\quad( 沿正实轴 )\end{aligned} $$ 

故  $ f(z) $ 在原点无确定的极限，从而在原点不连续.

#### 习题1.2

1. 求下列复变函数的实部与虚部：

(1)  $ w = \frac{z - 1}{z + 1} $; (2)  $ w = z^3 $.

2. 画出下列关系所表示的 z 点的轨迹的图形并确定它是不是区域：

(1)  $ \mathrm{Im}z>1 $ 且  $ |z|<2 $;

(2) $ |z-2i|=|z+2| $;

(3)  $ 0 < \arg(z-1) < \frac{\pi}{4} $ 且  $ 2 \leqslant \mathrm{Re}z \leqslant 3 $; (4)  $ \left|z-1+2i\right|=5 $.

3. 求下列复数序列的极限：

(1)  $ \frac{1+\sqrt{3}i}{5} $,  $ \left(\frac{1+\sqrt{3}i}{5}\right)^2 $,  $ \cdots\left(\frac{1+\sqrt{3}i}{5}\right)^n $,  $ \cdots $

(2)  $ 1, \frac{1}{2}i, -\frac{1}{3}, -\frac{1}{4}i, \frac{1}{5}, \frac{1}{6}i, -\frac{1}{7}, -\frac{1}{8}i\cdots $

4. 证明  $ f(z)=\frac{1}{2\mathrm{i}}\left(\frac{z}{\bar{z}}-\frac{\bar{z}}{z}\right) $ 在原点不连续.

<!-- page: 28 -->

### 1.3 微商及解析函数

## 1. 微商及微分

设  $ w = f(z) $ 是在 z 点及其邻域定义的单值函数，若

$$  \lim_{\Delta z\to0}\frac{\Delta f}{\Delta z}=\lim_{\Delta z\to0}\frac{f(z+\Delta z)-f(z)}{\Delta z}   \tag*{(1.3.1)}$$

在 z 点存在，并且是与  $ \Delta z \rightarrow 0 $ 的方式无关的有限值，则称  $ f(z) $ 在 z 点可导或可微，而称此极限值为  $ f(z) $ 在 z 点的导数，记为

$$  f^{\prime}(z)=\lim\limits_{\Delta z\to0}\frac{\Delta f}{\Delta z}   \tag*{(1.3.2)}$$

例1 证明  $ f(z)=z^{n} $ 在复平面上每点均可导，且

$$  (z^{n})^{\prime}=n z^{n-1}   \tag*{(1.3.3)}$$

证 因对于任意固定的 z 均有

 $$ \lim_{\Delta z\to0}\frac{(z+\Delta z)^{n}-z^{n}}{\Delta z}=\lim_{\Delta z\to0}\left[nz^{n-1}+\frac{n(n-1)}{2}z^{n-2}\Delta z+\cdots+(\Delta z)^{n-1}\right]=nz^{n-1} $$ 

例2 证明  $ f(z)=\bar{z} $ 在复平面上均不可微.

证 因

 $$ \lim_{\Delta z\to0}\frac{\overline{z+\Delta z}-\bar{z}}{\Delta z}=\lim_{\Delta z\to0}\frac{\overline{\Delta z}}{\Delta z} $$ 

而

 $$ \lim\limits_{\substack{\Delta x=0\\ \Delta y\to0}}\frac{\Delta\overline{z}}{\Delta z}=\lim\limits_{\Delta y\to0}\frac{-\Delta y}{\Delta y}=-1,\quad\lim\limits_{\substack{\Delta x\to0\\ \Delta y=0}}\frac{\overline{\Delta z}}{\Delta z}=\lim\limits_{\Delta x\to0}\frac{\Delta x}{\Delta x}=1 $$ 

类似于实变函数，我们记

$$  \mathrm{d}z=f^{\prime}(z)\mathrm{d}z\quad( 或 \mathrm{d}f=f^{\prime}(z)\mathrm{d}z)   \tag*{(1.3.4)}$$

称之为函数  $ w = f(z) $ 的微分。若用 dz 除 (1.3.4) 式两边，便得

$$  f^{\prime}(z)=\frac{\mathrm{d}z}{\mathrm{d}z}\quad\left( 或 f^{\prime}(z)=\frac{\mathrm{d}f}{\mathrm{d}z}\right)   \tag*{(1.3.5)}$$

即导数  $ f'(z) $ 等于函数的微分与自变量的微分之商. 故导数又称为微商.

由于复变函数的导数与微分的定义，形式上和数学分析中单元函数的相应定义一致，因此，微分学中所有的求导和微分法则，都可以推广到复变函数中来

 $$ \begin{aligned}&\left[f_{1}(z)\pm f_{2}(z)\right]^{\prime}=f_{1}^{\prime}(z)\pm f_{2}^{\prime}(z)\\&\left[f_{1}(z)\bullet f_{2}(z)\right]^{\prime}=f_{1}^{\prime}(z)\bullet f_{2}(z)+f_{1}(z)\bullet f_{2}^{\prime}(z)\\&\left[\frac{f_{1}(z)}{f_{2}(z)}\right]^{\prime}=\frac{f_{1}^{\prime}(z)\bullet f_{2}(z)-f_{1}(z)\bullet f_{2}^{\prime}(z)}{\left[f_{2}(z)\right]^{2}},\quad f_{2}(z)\neq0\\&\frac{\mathrm{d}g\left[f(z)\right]}{\mathrm{d}z}=\frac{\mathrm{d}g(\zeta)}{\mathrm{d}\zeta}\bullet\frac{\mathrm{d}f(z)}{\mathrm{d}z},\quad\zeta=f(z)\end{aligned} $$

<!-- page: 29 -->

$$ \frac{\mathrm{d}w}{\mathrm{d}z}=1\bigg/\frac{\mathrm{d}z}{\mathrm{d}w}\quad\left(\frac{\mathrm{d}z}{\mathrm{d}w}\neq0\right) $$ 

## 2. 柯西-黎曼条件

下面我们讨论函数可微的必要条件.

设  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $ 在一点  $ z=x+\mathrm{i}y $ 可微，则

$$  f^{\prime}(z)=\lim_{\Delta x\to0}\frac{\Delta f}{\Delta z}=\lim_{\Delta x\to0\atop\Delta v\to0}\frac{\Delta u+\mathrm{i}\Delta v}{\Delta x+\mathrm{i}\Delta y}   \tag*{(1.3.6)}$$

其中

 $$ \begin{aligned}\Delta u&=u(x+\Delta x,y+\Delta y)-u(x,y)\\\Delta v&=v(x+\Delta x,y+\Delta y)-v(x,y)\end{aligned} $$ 

因为  $ \Delta z $ 无论按什么方式趋于 0 时(1.3.6) 式总是成立的，现让  $ \Delta z $ 沿平行于实轴的方向趋于 0，则

$$  f^{\prime}(z)=\lim\limits_{\Delta x\to0\atop\Delta y=0}\frac{\Delta u+\mathrm{i}\Delta v}{\Delta x+\mathrm{i}\Delta y}=\frac{\partial u}{\partial x}+\mathrm{i}\frac{\partial v}{\partial x}   \tag*{(1.3.7)}$$

又让 $ \Delta z $沿平行于y轴的方向趋于0，则

$$  f^{\prime}(z)=\lim\limits_{\Delta x\to0\atop\Delta y\to0}\frac{\Delta u+\mathrm{i}\Delta v}{\Delta x+\mathrm{i}\Delta y}=-\mathrm{i}\frac{\partial u}{\partial y}+\frac{\partial v}{\partial y}   \tag*{(1.3.8)}$$

比较(1.3.8)式及(1.3.7)式得出

$$  \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\qquad\frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y}   \tag*{(1.3.9)}$$

(1.3.9)式称为柯西-黎曼(Cauchy-Riemann)条件（简记为C-R条件），它是在 $ w=f(z) $存在微商的条件下导出的，只是函数可导的必要条件，而不是充分条件，即具备这一条件的 $ f(z) $不一定可导。例如 $ f(z)=\sqrt{|xy|} $，即 $ u=\sqrt{|xy|} $，v=0，显然在z=0点是满足C-R条件的，但在z=0点却不可微。因为若让 $ \Delta z=\Delta r\mathrm{e}^{\mathrm{i}\varphi}\rightarrow0 $，则 $ \lim_{\Delta z\rightarrow0}\frac{\Delta f}{\Delta z}=\frac{\sqrt{\cos\varphi\cdot\sin\varphi}}{\mathrm{e}^{\mathrm{i}\varphi}} $之值将随 $ \varphi $不同而不同。

函数  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $ 在 z 点可导的充分条件是

(1) u, v 在 z 点有连续的一阶偏微商；

(2) u, v 在 z 点满足 C-R 条件.

今证明如下.

因 u, v 有连续的一阶偏导数. 故 u, v 的全微分存在, 即

 $$ \mathrm{d}u=\frac{\partial u}{\partial x}\mathrm{d}x+\frac{\partial u}{\partial y}\mathrm{d}y,\quad\mathrm{d}v=\frac{\partial v}{\partial x}\mathrm{d}x+\frac{\partial v}{\partial y}\mathrm{d}y $$ 

而

 $$ \mathrm{d}f=\mathrm{d}u+\mathrm{i}\mathrm{d}v=\Big(\frac{\partial u}{\partial x}+\mathrm{i}\frac{\partial v}{\partial x}\Big)\mathrm{d}x+\Big(\frac{\partial u}{\partial y}+\mathrm{i}\frac{\partial v}{\partial y}\Big)\mathrm{d}y $$

<!-- page: 30 -->

又由 C-R 条件有

 $$ \frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y},\quad\frac{\partial v}{\partial y}=\frac{\partial u}{\partial x} $$ 

则

 $$ \begin{aligned}\mathrm{d}f&=\left(\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}\right)\mathrm{d}x+\left(\frac{\partial u}{\partial y}+\mathrm{i}\frac{\partial u}{\partial x}\right)\mathrm{d}y\\&=\left(\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}\right)(\mathrm{d}x+\mathrm{i}\mathrm{d}y)\end{aligned} $$ 

于是

$$  \frac{\mathrm{d}f}{\mathrm{d}z}=\frac{\left(\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}\right)(\mathrm{d}x+\mathrm{i}\mathrm{d}y)}{\mathrm{d}x+\mathrm{i}\mathrm{d}y}=\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}   \tag*{(1.3.10)}$$

此式无论 $ \Delta z $以什么方式趋于零都存在，所以 $ f(z) $在z点可导.

(1.3.10)式可以作为计算复变函数微商的公式,结合C-R条件还可得到计算微商的其他三个公式

$$  \frac{\mathrm{d}f}{\mathrm{d}z}=\frac{\partial v}{\partial y}-\mathrm{i}\frac{\partial u}{\partial y}=\frac{\partial v}{\partial y}+\mathrm{i}\frac{\partial v}{\partial x}=\frac{\partial u}{\partial x}+\mathrm{i}\frac{\partial v}{\partial x}   \tag*{(1.3.11)}$$

## 3. 解析函数及其物理解释

如果函数  $ w=f(z) $ 在  $ z_{0} $ 点及其邻域均可导，则称  $ w=f(z) $ 在  $ z_{0} $ 点解析。如果函数  $ w=f(z) $ 在  $ z_{0} $ 点不解析，则  $ z_{0} $ 称为  $ w=f(z) $ 的奇点。如果函数  $ w=f(z) $ 在区域  $ \sigma $ 内处处可导，则称  $ f(z) $ 在区域  $ \sigma $ 内解析，或称  $ f(z) $ 为区域  $ \sigma $ 内的解析函数。

显然，由函数可导的必要条件与充分必要条件，我们不难推得函数解析的必要条件与充分必要条件.

例3 试证  $ f(z)=\mathrm{e}^{x}(\cos y+\mathrm{i}\sin y) $ 在复平面上解析，且  $ f'(z)=f(z) $.

证 因  $ u=e^{x}\cos y, v=e^{x}\sin y $ ，而  $ \frac{\partial u}{\partial x}=e^{x}\cos y, \frac{\partial u}{\partial y}=-e^{x}\sin y, \frac{\partial v}{\partial x}=e^{x}\sin y, \frac{\partial v}{\partial y}=e^{x}\cos y $ 均在复平面上处处连续，且满足 C-R 条件，所以  $ f(z) $ 在复平面上解析；且由 (1.3.11) 式有

 $$ f^{\prime}(z)=\mathrm{e}^{x}\mathrm{c o s}y+\mathrm{i}\mathrm{e}^{x}\mathrm{s i n}y=f(z) $$ 

由解析函数的定义和函数的求导法则可得：

（1）如果函数  $ f(z) $ 在区域  $ \sigma $ 中解析，则它在这个区域中是连续的.

（2）如果  $ f_{1}(z) $ 和  $ f_{2}(z) $ 是区域  $ \sigma $ 中的解析函数，则其和、差、积、商（商的情形要求分母在  $ \sigma $ 内不为零）也是该区域中的解析函数.

（3）如果函数  $ \zeta = f(z) $ 在区域  $ \sigma $ 内解析，而函数  $ w = g(\zeta) $ 在区域 G 内解析，若对于  $ \sigma $ 内的每一点 z，函数  $ f(z) $ 的值  $ \zeta $ 均属于 G，则函数  $ w = g[f(z)] $ 是区域  $ \sigma $ 上复变量 z 的一个解析函数.

（4）如果  $ w = f(z) $ 是区域  $ \sigma $ 上的一个解析函数，且在点  $ z_0 \in \sigma $ 的邻域中  $ |f'(z)| \neq 0 $，则在点  $ w_0 = f(z_0) \in G $ 的邻域中函数  $ f(z) $ 的值定义一个反函数  $ z = \varphi(w) $，它是复变

<!-- page: 31 -->

量 w 的解析函数. 于是我们有  $  f'(z_0) = \frac{1}{\varphi'(w_0)}  $.

我们已经知道解析函数的实部和虚部有 C-R 条件联系着，现在我们进一步阐明其实部和虚部的特性.为此，我们首先引入几个概念.

在区域  $ \sigma $ 中连续并有连续的一、二阶偏导数的实变函数  $ u(x,y) $，如果满足方程

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0 $$ 

则称  $ u(x,y) $ 为区域  $ \sigma $ 上的调和函数。方程  $ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0 $（或记作  $ \Delta u=0 $）称为二维拉普拉斯（Laplace）方程。而方程  $ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=-h(x,y) $ 和方程  $ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}+\lambda u=0 $ 分别称为二维泊松（Poisson）方程和二维亥姆霍兹（Helmhotz）方程。在物理学中，许多平面场，如稳定温度场、静电场、无旋流的速度场等，都满足这几个方程。

定理 1.1 解析函数的实部和虚部都是调和函数，且其梯度向量相互正交.

证 设  $ f(z)=u+iv $ 在区域  $ \sigma $ 上解析，于是在  $ \sigma $ 上 C-R 条件 (1.3.9) 成立。即

 $$ \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\quad\frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y} $$ 

而第二章将证明解析函数具有任意阶微商，因而此处 u 和 v 也有各阶偏微商，故有

 $$ \frac{\partial^{2}u}{\partial x^{2}}=\frac{\partial^{2}v}{\partial x\partial y},\quad\frac{\partial^{2}v}{\partial x\partial y}=-\frac{\partial^{2}u}{\partial y^{2}} $$ 

因此在 $ \sigma $上有

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=0 $$ 

同样可以证明在 $ \sigma $上有

$$  \frac{\partial^{2}v}{\partial x^{2}}+\frac{\partial^{2}v}{\partial y^{2}}=0   \tag*{(1.3.13)}$$

所以， $ u(x,y) $ 和  $ v(x,y) $ 都是区域  $ \sigma $ 上的调和函数.

而将 C-R 条件(1.3.9)式的两个等式对应相乘有

 $$ \begin{aligned}\frac{\partial u}{\partial x}\bullet\frac{\partial v}{\partial x}=&-\frac{\partial v}{\partial y}\bullet\frac{\partial u}{\partial y}\\\frac{\partial u}{\partial x}\bullet\frac{\partial v}{\partial x}+\frac{\partial u}{\partial y}\bullet\frac{\partial v}{\partial y}=&0\end{aligned} $$ 

即

$$  \nabla u\bullet\nabla v=0   \tag*{(1.3.14)}$$

亦即

这表明解析函数实部和虚部的梯度向量 $ \nabla u $与 $ \nabla v $正交.而 $ \nabla u $和 $ \nabla v $分别是曲线 $ u(x,y)= $常数与 $ v(x,y)= $常数的法向向量，这说明u=常数和v=常数是彼此互相正交的两曲线族.

由于解析函数的这一性质，解析函数的理论在平面场问题中有重要应用。现在以静电场为例来分析。既然实际的空间是三维的，静电场当然总是三维的。但如果电荷沿三维空间的某方向上分布是均匀的，我们取此方向为z方向，则电场和电势 $ \varphi(x, y) $都与空间坐标z无关，我们只要在xy平面上研究它就够了。这样的静电场叫作平

<!-- page: 32 -->

面静电场，它的电势  $ \varphi(x,y) $ 在 xy 平面的无源（即无电荷）区域中是满足二维拉普拉斯方程的. 即

$$  \frac{\partial^{2}\varphi}{\partial x^{2}}+\frac{\partial^{2}\varphi}{\partial y^{2}}=0   \tag*{(1.3.15)}$$

比较方程(1.3.12)[或(1.3.13)]与方程(1.3.15)可见，解析函数的实部（或虚部）可以解释为某平面静电场的势.

注意到平面静电场的等势线族  $ \varphi(x,y)= $ 常数与电场线族也是处处相互正交的，

<div style="text-align: center;"><img src="images/p0032_img_in_image_box_100_362_390_655.jpg" alt="图1.6" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.6</div> </div>


所以，如果我们将解析函数的实部  $ u(x,y) $ [或虚部  $ v(x,y) $] 解释为某平面静电场的势，那么  $ v(x,y) $ [或  $ u(x,y) $] 的等值线族就是该静电场的电场线族。正因为如此，人们常用一解析函数来描绘这一无源平面静电场，并称此解析函数为该平面静电场的复势。显然，同一平面静电场的复势可以相差一常数。

例4 考虑解析函数  $ f(z)=z^{2}=x^{2}-y^{2}+i2xy $，它对应什么样的平面静电场的复势？

解 如图1.6所示，实线族 $ u=x^{2}-y^{2}= $ 常数与虚线族 $ v=2xy= $ 常数在z平面互相正交. 如将其虚部v=2xy看作平面静电场的势，则等势线族和电场线族分别为2xy=常数和 $ x^{2}-y^{2}= $ 常数，这是以实轴和虚轴为截口的两块互相垂直的甚大的带电导体平面的静电场.



以上分析同样也适用于具有类似性质的其他平面标量场。一般而言，一既无源又无旋的平面矢量场，总可以构造一个解析函数，即复势与之对应。采用复势来研究平面矢量场，不但形式紧凑，而且可使计算大为简化。

由于解析函数的实部和虚部通过 C-R 条件联系着，因此，只要知道解析函数的实部（或虚部），就能求出相应的虚部（或实部）。具体可用以下两种方法来求。

（1）如果已知 u 求 v，可从全微分出发. 因

 $$ \begin{aligned}\mathrm{d}v&=\frac{\partial v}{\partial x}\mathrm{d}x+\frac{\partial v}{\partial y}\mathrm{d}y=-\frac{\partial u}{\partial y}\mathrm{d}x+\frac{\partial u}{\partial x}\mathrm{d}y\\&\quad v=\int-\frac{\partial u}{\partial y}\mathrm{d}x+\frac{\partial u}{\partial x}\mathrm{d}y+C\end{aligned} $$ 

故

（2）已知 u 求 v 还可由关系  $ \frac{\partial v}{\partial x} = \frac{\partial u}{\partial x} $，对 y 积分来求。因

$$  v=\int\frac{\partial v}{\partial y}\mathrm{d}y+\varphi(x)=\int\frac{\partial u}{\partial x}\mathrm{d}y+\varphi(x)   \tag*{(1.3.17)}$$

所以

$$  \frac{\partial v}{\partial x}=\frac{\partial}{\partial x}\int\frac{\partial u}{\partial x}\mathrm{d}y+\varphi^{\prime}(x)=-\frac{\partial u}{\partial y}   \tag*{(1.3.18)}$$

由(1.3.18)式可求得  $ \varphi(x) $，代入(1.3.17)式即可求得 v.

<!-- page: 33 -->

当然，由关系 $ \frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y} $两边对x积分类似于上述过程也可求得v.

例5 已知  $ u=x^{3}-3xy^{2} $，求 v.

解

 $$ \frac{\partial u}{\partial x}=3x^{2}-3y^{2},\quad\frac{\partial u}{\partial y}=-6xy $$ 

由（1.3.16）式有

 $$ \begin{aligned}v=&\int6xy\mathrm{d}x+(3x^{2}-3y^{2})\mathrm{d}y+C=\int\mathrm{d}(3x^{2}y-y^{3})+C\\=&3x^{2}y-y^{3}+C\end{aligned} $$ 

也可由(1.3.17)式和(1.3.18)式得

 $$ v=\int(3x^{2}-3y^{2})\mathrm{d}y+\varphi(x)=3x^{2}y-y^{3}+\varphi(x) $$ 

 $$ \frac{\partial v}{\partial x}=6xy+\varphi^{\prime}(x)=-\frac{\partial u}{\partial y}=6xy $$ 

所以

 $$ \varphi^{\prime}(x)=0,\quad\varphi(x)=C $$ 

于是

故得解析函数

 $$ v=3x^{2}y-y^{3}+C $$ 

 $$ \begin{aligned}f(z)&=u+\mathrm{i}v=x^{3}-3xy^{2}+\mathrm{i}(3x^{2}y-y^{3}+C)\\&=(x+\mathrm{i}y)^{3}+\mathrm{i}C=z^{3}+\mathrm{i}C\end{aligned} $$ 

像解析函数的实部和虚部这样的两个由 C-R 条件联系着的调和函数 u 与 v，称为共轭调和函数.

#### 习题1.3

1. 试推导极坐标形式下的 C-R 条件

$$  \frac{\partial u}{\partial\rho}=\frac{1}{\rho}\frac{\partial v}{\partial\varphi},\quad\frac{1}{\rho}\frac{\partial u}{\partial\varphi}=-\frac{\partial v}{\partial\rho}   \tag*{(1.3.19)}$$

2. 讨论下列函数的可微性和解析性：

 $$ \begin{aligned}&w=z^{2}；\\&w=\sqrt[5]{z^{3}}；\\ \end{aligned} $$ 

 $$ w=z\mathrm{R e}z; $$ 

 $$ w=|z|^{2}. $$ 

3. 若函数  $ f(z) $ 在区域  $ \sigma $ 上解析并满足下列条件之一，证明  $ f(z) $ 必为常数.

(1)  $ f'(z)=0 $;

(2) $ \overline{f(z)} $ 在  $ \sigma $ 上解析；

(3) $ |f(z)|= $ 常数；

(4)  $ \mathrm{Ref}(z)= $ 常数.

4. 已知解析函数的实部或虚部，求解析函数.

(1)  $ u = x^{2} - y^{2} + xy $,  $ f(i) = -1 + i $; (2)  $ u = 2(x - 1)y $,  $ f(2) = -i $;

 $$ v{\begin{array}{l}\frac{y}{x^{2}+y^{2}},f(2)=0;\end{array}}\quad(4)u=\ln\rho,f(1)=0. $$ 

5. 已知一平面静电场的电场线族是与实轴相切于原点的圆族，求等势线族，并求此电场的复势.

6. 已知一平面静电场的电场线簇是抛物线族  $ y^{2}=C^{2}+2Cx(C>0) $，求等势线簇，并求此电场的复势.

7.  $ xy^{2} $ 能否成为 z 的一个解析函数的实部？为什么？

<!-- page: 34 -->

8. 证明：如果  $  f(z)  $ 和  $ \varphi(z) $ 在  $ z_{0} $ 点解析， $  f(z_{0}) = \varphi(z_{0}) = 0  $， $ \varphi'(z_{0}) \neq 0 $，则  $ \lim_{z \to z_{0}} \frac{f(z)}{\varphi(z)} = \frac{f'(z_{0})}{\varphi'(z_{0})} $。即，对于解析函数而言，实函数中的洛必达(L'Hospital)法则仍成立。

### 1.4 初等解析函数

在这一节里将介绍一些简单的解析函数，如幂函数  $ z^n $，指数函数  $ e^z $，三角函数  $ \sin z $， $ \cos z $ 和双曲函数  $ \text{sh}z $， $ \text{ch}z $；还将介绍多值函数  $ \sqrt[n]{z} $， $ \text{Ln}z $， $ z^s $（ $ s \neq \text{整数} $）以及有关多值函数的一些基本概念，如支点、单值分支、支割线、黎曼面等。

## 1. 幂函数  $ w = z^{n} (n = 0, \pm 1, \pm 2, \cdots) $

由上一节的例1知道，当n=1,2,3, $ \cdots $时，幂函数 $ z^{n} $在复平面上处处可微。因此，当n是正整数（包括零）时， $ w=z^{n} $是复平面上的解析函数。当n=-1,-2,-3, $ \cdots $时，除了z=0这一点以外，导数 $ nz^{n-1} $也都处处存在并有确定值，故在n是负整数的情形下，幂函数 $ w=z^{n} $是除了z=0点以外的复平面上的解析函数，z=0是这函数的奇点。

由上所述解析函数的性质不难看出，多项式函数  $ w=P(z)=a_{0}+a_{1}z+a_{2}z^{2}+\cdots+a_{n}z^{n}(a_{n}\neq0) $ 也在复平面上解析；有理函数  $ w=\frac{P(z)}{Q(z)}=\frac{a_{0}+a_{1}z+a_{2}z^{2}+\cdots+a_{n}z^{n}}{b_{0}+b_{1}z+b_{2}z^{2}+\cdots+b_{m}z^{m}}(a_{n}, b_{m}\neq0) $ 在复平面上除使  $ Q(z)=0 $ 的点外解析.

## 2. 指数函数  $ w = e^{z} $

我们定义

$$  \mathrm{e}^{z}=\mathrm{e}^{x+\mathrm{i}y}=\mathrm{e}^{x}(\cos y+\mathrm{i}sin y)   \tag*{(1.4.1)}$$

并称它为指数函数（有时也用 expz 表示）。当 z 取实数 x 时，它就是实指数函数  $ e^{x} $

在上一节的例3中，曾证明了 $ f(z)=\mathrm{e}^{x}(\cos y+\mathrm{i}\sin y) $在复平面上解析，并且 $ f'(z)=f(z) $，所以指数函数 $ w=\mathrm{e}^{z} $在复平面上解析，并且

$$  \left(\mathrm{e}^{z}\right)^{\prime}=\mathrm{e}^{z}   \tag*{(1.4.2)}$$

易于证明，指数函数还有如下一些主要性质：

(1)  $ \mathrm{e}^{z_{1}} \cdot \mathrm{e}^{z_{2}} = \mathrm{e}^{z_{1} + z_{2}} $

(2)  $ \mathrm{e}^{z+i2k\pi}=\mathrm{e}^{z},\quad k=0,\pm1,\pm2,\cdots $

即  $ e^{z} $ 以  $ 2\pi i $ 为周期. 这是与实指数函数  $ e^{x} $ 的主要不同之点.

在(1.4.1)式中，如果令 $ z=\pm i\theta(\theta $为实数)则得我们所熟知的欧拉(Euler)公式

 $$ \mathrm{e}^{i\theta}=\cos\theta+\mathrm{i}\sin\theta,\quad\mathrm{e}^{-i\theta}=\cos\theta-\mathrm{i}\sin\theta $$ 

一般写成

$$  \sin\theta=\frac{\mathrm{e}^{\mathrm{i}\theta}-\mathrm{e}^{-\mathrm{i}\theta}}{2\mathrm{i}},\quad\cos\theta=\frac{\mathrm{e}^{\mathrm{i}\theta}+\mathrm{e}^{-\mathrm{i}\theta}}{2}   \tag*{(1,4,5)}$$

<!-- page: 35 -->

## 3. 三角函数

由(1.4.5)式我们类似地可定义正弦函数  $ \sin z $ 和余弦函数  $ \cos z $ 为

$$  \sin z=\frac{\mathrm{e}^{\mathrm{i}z}-\mathrm{e}^{-\mathrm{i}z}}{2\mathrm{i}},\quad\cos z=\frac{\mathrm{e}^{\mathrm{i}z}+\mathrm{e}^{-\mathrm{i}z}}{2}   \tag*{(1.4.6)}$$

它们是实数范围内正弦函数和余弦函数在复数范围内的推广.

由指数函数的解析性和求导公式可知道它们亦均在复平面解析，且

$$  (sinz)^{\prime}=cosz,\quad(cosz)^{\prime}=-sinz   \tag*{(1.4.7)}$$

sinz 和 cosz 还具有如下一些主要性质：

$$  (1)\sin(-z)=-\sin z,\cos(-z)=\cos z   \tag*{(1.4.8)}$$

(2)

$$  \sin^{2}z+\cos^{2}z=1   \tag*{(1.4.9)}$$

(3)

$$  \sin(z_{1}\pm z_{2})=\sin z_{1}\cos z_{2}\pm\cos z_{1}\sin z_{2}   \tag*{(1.4.10)}$$

$$  4)\cos(z_{1}\pm z_{2})=\cos z_{1}\cos z_{2}\mp\sin z_{1}\sin z_{2}   \tag*{(1.4.11)}$$

$$  \sin(z+2\pi)=\sin z,\cos(z+2\pi)=\cos z   \tag*{(1.4.12)}$$

 $$ (6)\sin z=0\  必须且只须 \ z=n\pi,n=0,\pm1,\pm2,\cdots $$ 

 $$ \cos z=0\  必须且只须 \ z=\left(n+\frac{1}{2}\right)\pi,\quad n=0,\pm1,\pm2,\cdots $$ 

(7) $ \left|\sin z\right| $和 $ \left|\cos z\right| $可大于任何正数（与实函数情形不同）.例如，当z=i时

 $$  cosi=\frac{e^{-1}+e}{2}=\frac{0.368+2.718}{2}=1.543>1 $$ 

事实上只要z的虚部y趋近无穷大， $ \left|\sin z\right| $和 $ \left|\cos z\right| $就趋于无穷大.

其他三角函数如  $ tanz $, cotz, secz, cscz 等，都可以仿照实函数关系来定义

$$  \tan z=\frac{\sin z}{\cos z},\quad\cot z=\frac{\cos z}{\sin z},\quad\sec z=\frac{1}{\cos z},\quad\csc z=\frac{1}{\sin z}   \tag*{(1.4.13)}$$

分别被称做正切、余切、正割、余割函数。它们的解析性和其他性质，也均可由 $ \sin z $和 $ \cos z $的解析性和其他性质推出。

## 4. 双曲函数

双曲正弦和双曲余弦的定义为

$$   shz=\frac{e^{z}-e^{-z}}{2},\quad chz=\frac{e^{z}+e^{-z}}{2}   \tag*{(1.4.14)}$$

类似于实函数定义

$$  \mathrm{t h}z=\frac{\mathrm{s h}z}{\mathrm{c h}z},\quad\mathrm{c o t h}z=\frac{\mathrm{c h}z}{\mathrm{s h}z},\quad\mathrm{s e c h}z=\frac{1}{\mathrm{c h}z},\quad\mathrm{c s c h}z=\frac{1}{\mathrm{s h}z}   \tag*{(1.4.15)}$$

分别称做双曲正切、双曲余切、双曲正割、双曲余割函数.

幂函数、指数函数、三角函数和双曲函数都是初等单值函数。下面介绍几种常见的初等多值函数。

<!-- page: 36 -->

## 5. 根式函数  $ w = \sqrt[n]{z} $

如果  $ z=w^{n}, n=2,3,\cdots $，则称 w 为 z 的根式函数，记为  $ w=\sqrt[n]{z} $。今以  $ w=\sqrt{z} $ 为例，来阐明有关多值函数的一些基本概念。

由  $ w=\sqrt{z} $，有  $ w^{2}=z $。令  $ w=\rho e^{\mathrm{i}\varphi} $， $ z=r e^{\mathrm{i}\theta} $，代入上式得： $ \rho^{2}e^{\mathrm{i}2\varphi}=r e^{\mathrm{i}\theta} $，于是  $ \rho^{2}=r $， $ 2\varphi=\theta+2k\pi $，所以

$$  \rho=\sqrt{r},\quad\varphi=\frac{\theta}{2}+k\pi,\quad k=0,\pm1,\pm2,\cdots   \tag*{(1.4.16)}$$

从这里可以看到，w 的模  $ \rho $ 与 z 的模 r 是一一对应的，而辐角则不然。对应于每个  $ \theta $ 值，有二个不同的  $ \varphi $ 值

$$  \varphi_{1}=\frac{\theta}{2},\quad\varphi_{2}=\frac{\theta}{2}+\pi   \tag*{(1.4.17)}$$

[相应于(1.4.16)式中 k=0,1]，从而给出两个不同的 w 值

$$  \begin{array}{r}{\begin{array}{l l}{\displaystyle w_{1}=\sqrt{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{2}},}&{\displaystyle w_{2}=\sqrt{r}\mathrm{e}^{\mathrm{i}\left(\frac{\theta}{2}+\pi\right)}}\\ \end{array}=-\sqrt{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{2}}}\end{array}   \tag*{(1.4.18)}$$

其他 k 值给出的 w 值只是这两个  $ \varphi $ 值的重复.

所以，函数  $ w=\sqrt{z} $ 是多值函数。其多值性表现在 w 的辐角与 z 的辐角的对应关系上。

若开始时在 z 平面选定一点  $  z(r, \theta)  $ 与  $  w_1 = \sqrt{r} e^{\frac{\theta}{2}}  $ 相对应，则当  $  z(r, \theta)  $ 沿着图 1.7 中其内含有 z=0 点的闭合曲线 C 连续变化，绕 z=0 点一圈回到原处时，Argz 的值由原来的  $ \theta $ 变为  $ \theta + 2\pi $，相应的 w 值由原来的  $ w_1 = \sqrt{r} e^{\frac{\theta}{2}} $ 变为  $ \sqrt{r} e^{\frac{\theta + 2\pi}{2}} = w_2 $。但如果  $  z(r, \theta)  $ 是沿图 1.7 中其内不包含原点的闭合曲线  $ C' $ 连续变化回到原处时，Argz 之值仍为  $ \theta $，因而相应的 w 值也不会改变，即仍为  $ w_1 = \sqrt{r} e^{\frac{\theta}{2}} $。



<div style="text-align: center;"><img src="images/p0036_img_in_image_box_98_693_429_1030.jpg" alt="图1.7" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.7</div> </div>


从上面分析看到，对于多值函数而言，存在某些特殊的点，当变量绕它转一圈回到原处时，对应的函数值不能还原（发生了变

化），这种点称为多值函数的支点 $ ^{①} $.

所以，z=0 是函数  $ w=\sqrt{z} $ 的支点。另外， $ z=\infty $ 也是  $ w=\sqrt{z} $ 的支点，因为如果令  $ z=\frac{1}{t} $，则有  $ w=\frac{1}{\sqrt{t}} $，当 t 绕 t=0 转一圈回到原处时，w 之值不还原，这个函数再没有其他支点了。因为在 z 平面上沿着任一条不包含原点在内部的闭曲线转一圈而回到原处时，其函数值都不会改变。

<!-- page: 37 -->

如果我们规定  $ -\pi<\theta\leqslant\pi $ ，则对应于  $ z=r\mathrm{e}^{\theta} $ 相应的有函数值  $ w_{1}=\sqrt{r}\mathrm{e}^{\frac{\theta}{2}} $ ；而对应于  $ z=r\mathrm{e}^{\mathrm{i}(\theta+2\pi)} $ 相应的有函数值  $ w_{2}=\sqrt{r}\mathrm{e}^{\mathrm{i}\left(\frac{\theta}{2}+\pi\right)} $ ，函数  $ w=\sqrt{z} $ 之值与自变量的取值实现了一一对应的关系。即对于多值函数而言，如果我们限制自变量 z 的变化范围，便可使得对于每一个自变量 z 值，都分别有唯一的一个确定的函数值与之相对应，亦即多值函数被划分成了若干个单值函数，我们称其中每一个单值函数为多值函数的一个单值分支。例如， $ w_{1}=\sqrt{r}\mathrm{e}^{\frac{\theta}{2}} $ 和  $ w_{2}=\sqrt{r}\mathrm{e}^{\mathrm{i}\left(\frac{\theta}{2}+\pi\right)} $，当  $ -\pi<\theta\leqslant\pi $ 时是  $ w=\sqrt{z} $ 的两个单值分支。

单值分支的划分，也可形象地用几何图形来描绘。如图1.8(a)所示，从0到∞沿负实轴将z(一)平面切割开，并规定切割的下缘 $ \arg z=-\pi $，上缘 $ \arg z=\pi $，则与这平面上的z值对应的函数值 $ w_1(z) $位于图1.8(c)所示的w平面的右半： $ -\frac{\pi}{2}<\arg w_1\leq\frac{\pi}{2} $，与切割下缘对应的是负虚轴，与上缘对应的是正虚轴。类似的如图1.8(b)所示，将z(二)平面也沿负实轴割开，但规定切割下缘是 $ \pi $，上缘是3 $ \pi $，因此与这平面上的z值对应的函数值 $ w_2(z) $位于图1.8(c)的左半平面： $ \frac{\pi}{2}<\arg w_2\leq\frac{3\pi}{2} $，与切割下缘对应的是正虚轴，与上缘对应的是负虚轴。对于 $ w=\sqrt{z} $的反函数 $ z=w^2 $来说，在w平面按图1.8(c)这样划出的区域，能使不同的w值对应于z平面的不同的z值，这也就是说 $ z=w^2 $分别在这两个区域 $ \left(-\frac{\pi}{2}<\arg w_1\leq\frac{\pi}{2},\frac{\pi}{2}<\arg w_2\leq\frac{3\pi}{2}\right) $上都是单叶函数，我们把这两个区域分别称做 $ z=w^2 $的单叶性区域。这样一来，当我们用 $ z=w^2 $的两个互不相交的单叶区域把w平面布满之后，便把多值函数 $ w=\sqrt{z} $的两个单值分支 $ w_1(z) $和 $ w_2(z) $分开表示出来，而每个单叶性区域是其一个单值分支的值域。

<div style="text-align: center;"><img src="images/p0037_img_in_image_box_141_848_333_1017.jpg" alt="(a)" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0037_img_in_image_box_379_849_571_1018.jpg" alt="(b)" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><img src="images/p0037_img_in_image_box_620_847_814_1025.jpg" alt="图1.8" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.8</div> </div>


<div style="text-align: center;"><div style="text-align: center;">(c)</div> </div>


我们称以上这种连接多值函数两支点间的割开 z 平面的线为支割线。它起着这样的作用：当 z 连续变化时，不得跨越支割线。这使得在割开的 z 平面上闭合曲线都不含支点于内，因此相应的函数值也只能在 w 平面上的一个单值分支内变化，而不会从一个单值分支跨越到另一个单值分支中去。这样，两个单值分支就完全分开了。当然，支割线并不必须是直线，只要能够起到把单值分支分开的作用即可。

<!-- page: 38 -->

应当注意，把一个多值函数划分为单值分支是有一定任意性的。例如，上述的 $ w=\sqrt{z} $，若规定 $ 0<\theta\leq2\pi $，则它的两个单值分支 $ \omega_{1}(z)=\sqrt{r}\mathrm{e}^{\mathrm{i}\frac{\theta}{2}} $和 $ \omega_{2}(z)=\sqrt{r}\mathrm{e}^{\mathrm{i}\left(\frac{\theta}{2}+\pi\right)} $就将分别位于w平面的上半平面和下半平面，如图1.9(c)所示。即

 $$ \begin{aligned}w_{1}(z):0<arg z\leqslant2\pi,\quad&0<arg w_{1}(z)\leqslant\pi\\w_{2}(z):2\pi<arg z\leqslant4\pi,\quad&\pi<arg w_{2}(z)\leqslant2\pi\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0038_img_in_image_box_135_317_328_489.jpg" alt="(a)" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><img src="images/p0038_img_in_image_box_381_318_576_521.jpg" alt="图1.9" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.9</div> </div>


<div style="text-align: center;"><img src="images/p0038_img_in_image_box_626_319_822_520.jpg" alt="图1.10" width="20%" /></div>


在图1.8和图1.9中，我们把根式 $ w=\sqrt{z} $的两个单值分支 $ w_{1}(z) $和 $ w_{2}(z) $的函数值与自变量z的对应关系分开表示出来了。这种对应关系也可以合并在一起表示。例如，将图1.9中 $ z(\text{一}) $平面支割线的上缘与 $ z(\text{二}) $平面中支割线的下缘连起来，并

<div style="text-align: center;"><img src="images/p0038_img_in_image_box_107_687_440_847.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.10</div> </div>


设想 z(二) 平面中支割线的上缘与 z(一) 平面中支割线的下缘也能连起来，构成如图 1.10 所示的这样一个交叉连接的两叶面。当 z 在 z(一) 平面上绕 z=0 转一圈后，它的轨迹将跨过连起来的支割线  $ \arg z = 2\pi $ 而进入 z(二) 平面；如果 z 点在 z(二) 平面继续再绕 z=0 点转一圈，它的轨迹将跨越

连起来的支割线  $ \arg z = 4\pi $ 和  $ \arg z = 0 $ 而回到 z(一) 平面。因此，这两叶互相粘合的复平面使函数  $ w = \sqrt{z} $ 的值与变量 z 的值一一对应。我们称这种使多值函数 w 的值与变量 z 的值一一对应的由若干叶复平面粘合而成的模型为黎曼面。



一般说来，一个多值函数的导数是不存在的，因为极限 $ \lim_{z\to z_0}\frac{f(z)-f(z_0)}{z-z_0} $之值与z趋近于 $ z_0 $的方式（例如绕过支点或者不绕过支点）有关，所以不能笼统地讨论其解析性。但如果在某一区域内能够把多值函数的各个单值分支划分开，则对于每一单值分支可以如前讨论其解析性。例如，若将z平面按图1.8所示方式割开，则函数 $ w=\sqrt{z} $与之相应的每一单值分支 $ w_1=\sqrt{r}e^{i\frac{\theta}{2}} $和 $ w_2=\sqrt{r}e^{i\left(\frac{\theta}{2}+\pi\right)} $都是解析的。因为在此二区域内，z无论怎么变动都不会绕过支点（多值函数的支点一定是函数的奇点，因为在支点的邻域内不能把各个单值划分开，导数也就不存在）。

<!-- page: 39 -->

## 6. 对数函数  $ w = \ln z $

若  $ z=e^{w} $，则称 w 为 z 的对数函数，并记为 w=Lnz。注意 z=0 时，Lnz 没有定义。令  $ w=u+i\upsilon $， $ z=r e^{i\theta} $，则由  $ z=e^{w} $ 得  $ r e^{i\theta}=e^{u}\cdot e^{i\upsilon} $，由此得

 $$ \mathrm{e}^{u}=r $$ 

即

$$  \begin{aligned}u&=\ln r=\ln|\;z|\quad&v=\theta+2k\pi,\quad k=0,\pm1,\pm2,\cdots\end{aligned}   \tag*{(1.4.19)}$$

于是

$$  \mathrm{L n}z=u+\mathrm{i}v=\ln\mid z\mid+\mathrm{i}(\theta+2k\pi),\quad k=0,\pm1,\pm2,\cdots   \tag*{(1.4.20)}$$

这说明对数函数  $ w = \ln z $ 是多值函数，其多值性表现在函数值 w 的虚部与自变数的辐角的对应关系上：对应于每一 z 值，有无穷多个 w 值，它们彼此的虚部相差  $ 2\pi $ 的整数倍.

对数函数仅有两个支点 0 与  $ \infty $。因为当 z 沿绕 z=0 点一周的曲线变化回到原出发点时，Argz 增加  $ 2\pi $，相应的函数值 w 的虚部也增加  $ 2\pi $，即发生了变化。令  $ z=\frac{1}{t} $，类似的可证明  $ \infty $ 也是 Lnz 的支点。

类似于对  $ w=\sqrt{z} $ 的讨论，从 0 到  $ \infty $ 作支割线即可得到 Lnz 在这些割破了的 z 平面上的无穷多个单值分支，记作

$$  \left(\ln z\right)_{k}=\ln\mid z\mid+\mathrm{i}(\theta+2k\pi),\quad k=0,\pm1,\pm2,\cdots   \tag*{(1.4.21)}$$

而通常将其中  $ \theta=\arg z,0<\arg z\leqslant2\pi $ 的那一支称做 Lnz 的主值支，记作

$$  \ln z=\ln\mid z\mid+\mathrm{iarg}z,\quad0<\arg z\leqslant2\pi   \tag*{(1.4.22)}$$

显然，对数函数 w=Lnz 的黎曼面由无穷多叶 z 平面叠合而成。与每一个 z 平面对应的 w 值，在 w 平面上构成一个与实轴平行的无穷长的宽度为  $ 2\pi $ 的带形区域（即  $ z=e^{w} $ 的单叶性区域）。

易于证明对数函数的每一单值分支都是解析函数，且

$$  \frac{\mathrm{d}}{\mathrm{d}z}(\ln z)_{k}=\frac{1}{z},\quad k=0,\pm1,\pm2,\cdots   \tag*{(1.4.23)}$$

也容易证明，对数函数  $ w = \ln z $，满足与实对数函数类似的运算规律

$$  \mathrm{Ln}(z_{1}\cdot z_{2})=\mathrm{Ln}z_{1}+\mathrm{Ln}z_{2}   \tag*{(1.4.24)}$$

$$  \mathrm{Ln}\Big(\frac{\mathcal{z}_{1}}{\mathcal{z}_{2}}\Big)=\mathrm{Ln}\mathcal{z}_{1}-\mathrm{Ln}\mathcal{z}_{2}   \tag*{(1.4.25)}$$

## 7. 一般幂函数

定义  $ z^{s}=\mathrm{e}^{s\mathrm{Ln}z} $ (s 为复常数) 为一般幂函数. 不难验证，当 s 取整数 n 或  $ \frac{1}{n} $ 时，它就是前面已讨论过的  $ z^{n} $ 及  $ \sqrt[n]{z} $. 一般幂函数对于不为零的复数 z 都有意义，由于 Lnz 的

<!-- page: 40 -->

多值性， $ z^{s} $ 除 s 为整数外是多值函数。其分支的方法与 Lnz 相同。在规定单分支后，是 z 的一个解析函数，导数为

$$  \frac{\mathrm{d}}{\mathrm{d}z}z^{s}=\frac{\mathrm{d}}{\mathrm{d}z}\mathrm{e}^{s\mathrm{Ln}z}=\mathrm{e}^{s\mathrm{Ln}z}\bullet s\bullet\frac{1}{z}=sz^{s-1}   \tag*{(1.4.26)}$$

## 8. 一般指数函数

定义  $ s^{z}=e^{z\ln s} $ (s 为复常数) 为一般指数函数. 显然， $ s^{z} $ 亦为多值函数.

注 ① 如果变量 z 绕支点转 n 周 (n 为自然数) 而回到原处，多值函数回复原值，我们就说这支点是 n-1 阶支点。阶数为有限的支点都称为代数支点，阶数为无限的支点称为超越支点。

#### 习题1.4

1. 证明(1.4.3)、(1.4.4)、(1.4.8)、(1.4.12)、(1.4.23)、(1.4.25)式.

2. 试证

 $$ (1)\ \sin(iz)=ishz,\cos(iz)=chz;\tag{1.4.27} $$ 

 $$ (2)\mathrm{~ch}^{2}z-\mathrm{sh}^{2}z=1;\tag{1.4.28} $$ 

 $$ (3)\mathrm{~c h}(z_{1}+z_{2})=\mathrm{c h}z_{1}\mathrm{~c h}z_{2}+\mathrm{s h}z_{1}\mathrm{~s h}z_{2}.\tag{1.4.29} $$ 

$$  3.\  若 \ z=x+iy, 试证   \tag*{（1.4.30）}$$

 $$ (1)\sin z=\sin x\mathrm{ch}y+\mathrm{i}\cos x\mathrm{sh}y; $$ 

(2)  $ \cos z = \cos x \cdot \sin x \cdot \sin y $ (1.4.31)

$$  (3)\mid\sin z\mid^{2}=\sin^{2}x+\operatorname{sh}^{2}y;   \tag*{（1.4.32）}$$

 $$ (4)\mid\cos z\mid^{2}=\cos^{2}x+\operatorname{sh}^{2}y.\tag{1.4.33} $$ 

4. 求证： $ \lim_{z\to0}\frac{\sin z}{z}=1 $

5. 若  $ z=\sin w $，则称 w 为 z 的反正弦函数，并记作  $ w=\operatorname{Arcsin} z $。类似地也可建立反余弦、反正切、反余切函数的概念。试讨论以上反三角函数的多值性。

## 6. 解方程

 $$ (1)\mathrm{~s h}z=0;\quad(2)\mathrm{e}^{z}=1+\mathrm{i}\sqrt{3};\quad(3)\mathrm{s i n}z=2;\quad(4)\mathrm{t a n}z=\frac{\mathrm{i}}{3}. $$ 

7. 判断下列函数是单值的还是多值的. 若是多值的，是几值？其支点是什么？

 $$ (1)z+\sqrt{z-1};\quad(2)\frac{1}{1+\ln z};\quad(3)\sqrt[3]{z^{2}-4}+\sqrt{z^{2}-1};\quad(4)\sqrt{\cos z}; $$ 

 $$ \mathrm{(5)}\frac{\sin\sqrt{z}}{\sqrt{z}};\quad\mathrm{(6)}\frac{\cos\sqrt{z}}{\sqrt{z}};\quad\mathrm{(7)L n s i n z};\quad\mathrm{(8)}\sqrt{\frac{z-1}{z-2}}. $$ 

8. 设  $ w=\sqrt[3]{z} $ 确定在沿负实轴割破了的 z 平面上，并且  $ w(i)=-i $，求  $ w(-i) $.

9. 当 z=0 时，规定多值函数  $ w=\sqrt{z^{2}-1}=i $ ，求  $ w(i) $ 之值.

## 10. 计算

(1) $ (1+i)^{i} $; (2) $ 5^{2+3i} $; (3) $ \cos5\varphi $; (4) $ \mathrm{Ln}(1+i) $.

11. 讨论下列关系是否成立：

 $$ \mathrm{L n}z+\mathrm{L n}z=2\mathrm{L n}z;\quad\mathrm{(2)}\mathrm{L n}z-\mathrm{L n}z=0. $$

<!-- page: 41 -->

### 1.5 解析函数的几何性质

用几何图形表示函数  $ w = f(z) $，将使我们对函数有直观的理解，特别是对于我们处理平面场问题，会有很大帮助。我们把复变函数理解为两个复平面上的点集间的对应（映射或变换）。具体地说，取两张复平面分别代表 z 平面和 w 平面，则复变函数  $ w = f(z) $ 给出了从 z 平面上的点集 E 到 w 平面上的点集 F 间的一个对应关系，与点  $ z \in E $ 对应的点  $ w = f(z) $ 称为 z 点的像点，而 z 点就称为  $ w = f(z) $ 的原像（图 1.11）。

<div style="text-align: center;"><img src="images/p0041_img_in_image_box_173_403_428_626.jpg" alt="图1.11" width="26%" /></div>


<div style="text-align: center;"><img src="images/p0041_img_in_image_box_438_403_784_620.jpg" alt="图1.12" width="36%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.11</div> </div>


例 1 问函数  $ w=z^{2} $ 将 z 平面的直线 y=x 变成了 w 平面的何种图形？

解

 $$ w=z^{2}=(x+\mathrm{i}y)(x+\mathrm{i}y)=x^{2}-y^{2}+\mathrm{i}2xy $$ 

所以

 $$ u=x^{2}-y^{2},\quad v=2xy $$ 

当 y=x 时

 $$ u=0,v=2x^{2}\geqslant0,\quad-\infty<x<\infty $$ 

故  $ w=z^{2} $ 将 z 平面的直线 y=x 变成了 w 平面上半虚轴（图 1.12）.

<div style="text-align: center;"><img src="images/p0041_img_in_image_box_192_878_767_1112.jpg" alt="Image" width="60%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.12</div> </div>


## 1. 单叶变换定理

但是，我们感兴趣的是 z 与 w 构成的一一对应的变换。即双向单值的关系。换而言之，我们需要从变换  $ w = f(z) = u(x, y) + \mathrm{i}v(x, y) $ 中，解出 x 和 y 作为 u 与 v 的单

<!-- page: 42 -->

值函数. 由高等数学的知识可知，允许这样做的条件是，该  $ w=u(x,y)+\mathrm{i}v(x,y) $ 的雅克比(Jacobi)行列式不等于零. 即

$$  \boldsymbol{J}=\begin{vmatrix}\frac{\partial u}{\partial x}&\frac{\partial u}{\partial y}\\ \frac{\partial v}{\partial x}&\frac{\partial v}{\partial x}\end{vmatrix}\neq0   \tag*{(1.5.1)}$$

设  $ w=f(z) $ 在区域  $ \sigma $ 中解析，则由 C-R 条件 (1.3.9) 式和解析函数的微商公式 (1.3.11) 式有，条件 (1.5.1) 式可改写为

$$  \begin{aligned}J&=\begin{vmatrix}\frac{\partial u}{\partial x}&\frac{\partial u}{\partial y}\\\frac{\partial v}{\partial x}&\frac{\partial v}{\partial y}\end{vmatrix}=\frac{\partial u}{\partial x}\frac{\partial v}{\partial y}-\frac{\partial v}{\partial x}\frac{\partial u}{\partial y}=\left(\frac{\partial u}{\partial x}\right)^{2}+\left(\frac{\partial u}{\partial y}\right)^{2}\\&=\left|\frac{\partial u}{\partial x}-\mathrm{i}\frac{\partial u}{\partial y}\right|^{2}=\mid f^{\prime}(z)\mid^{2}\neq0\end{aligned}   \tag*{(1.5.2)}$$

由此可见，若  $ w=f(z) $ 是区域  $ \sigma $ 中的解析函数，且  $ f^{\prime}(z)\neq0(z\in\sigma) $，则变换  $ w=f(z) $ 在区域  $ \sigma $ 上构成一一对应的变换，并称这变换为域  $ \sigma $ 上的单叶变换。

## 2. 导数的几何意义

设  $ w = f(z) $ 在  $ z_{0} $ 点解析，且  $ f'(z_{0}) \neq 0 $，则当  $ z_{0} $ 在 z 平面沿一曲线  $ l_{1} $ 运动到  $ z_{0} + \Delta z $ 点 [图 1.13(a)]，相应的  $ w_{0} $ 也将在 w 平面沿着一条相应的曲线  $ l_{1}^{\prime} $，运动到  $ w_{0} + \Delta w $ 点 [图 1.13(b)]，且

即

 $$ f^{\prime}(z_{0})=\lim_{\Delta z\to0}\frac{\Delta w}{\Delta z} $$ 

 $$ \begin{aligned}\mid f^{\prime}(z_{0})\mid\mathrm{e}^{\mathrm{iarg}f^{\prime}(z_{0})}&=\lim_{\Delta z\to0}\frac{\mid\Delta w\mid\mathrm{e}^{\mathrm{iarg}\Delta w}}{\mid\Delta z\mid\mathrm{e}^{\mathrm{iarg}\Delta z}}\\&=\lim_{\Delta z\to0}\left|\frac{\Delta w}{\Delta z}\right|\bullet\lim_{\Delta z\to0}\mathrm{e}^{\mathrm{i}(\arg\Delta z v-\arg\Delta z)}\end{aligned} $$ 

所以

$$  \mid f^{\prime}(z_{0})\mid=\lim_{\Delta z\to0}\left|\frac{\Delta\varpi}{\Delta z}\right|   \tag*{(1.5.3)}$$

$$  \arg f^{\prime}(z_{0})=\lim_{\Delta z\to0}(\arg\Delta w-\arg\Delta z)=\theta^{\prime}_{1}-\theta_{1}   \tag*{(1.5.4)}$$

注意到  $ \Delta z $ 和  $ \Delta w $ 分别是  $ z_0 $ 点到  $ z_0 + \Delta z $ 点和  $ w_0 $ 点到  $ w_0 + \Delta w $ 点的向量； $ |\Delta z| $ 和  $ |\Delta w| $ 分别是向量  $ \Delta z $ 和  $ \Delta w $ 的长度；而  $ \arg\Delta z $ 和  $ \arg\Delta w $ 分别是向量  $ \Delta z $ 和  $ \Delta w $ 的辐角。所以，当  $ \Delta z $ 沿  $ l_1 $ 趋于零时， $ \theta_1 = \lim_{\Delta x \to 0} \arg\Delta z $ 表示曲线  $ l_1 $ 在  $ z_0 $ 点的切线方向；相应的  $ \theta'_1 = \lim_{\Delta x \to 0} \arg\Delta w $ 表示曲线  $ l'_1 $ 在  $ w_0 $ 点的切线方向。故由 (1.5.4) 式可看出，导数的辐角  $ \arg f'(z_0) $ 为过  $ z_0 $ 点的曲线的切线经变换后的一个转动角，称做变换  $ w = f(z) $ 在  $ z_0 $ 点的旋转角。其值与  $ \theta_1 $ 即  $ z_0 $ 点的切线方向无关。因为尽管当  $ \theta_1 $ 改变

<!-- page: 43 -->

时  $ \theta_{1}^{\prime} $ 也随之而变，但它们的差值  $ \theta_{1}^{\prime}-\theta_{1}[=argf^{\prime}(z_{0})] $ 却保持不变。类似的由(1.5.3)式可看出，导数的模，为过  $ z_{0} $ 点的微线元  $ \mathrm{d}z=\lim_{\Delta x\to0}\Delta z $ 与经变换后的微线元  $ \mathrm{d}w=\lim_{\Delta x\to0}\Delta w^{\mathrm{①}} $ 的长度之比，称做变换 w=f(z) 在  $ z_{0} $ 点的长度伸缩比或放大系数。

<div style="text-align: center;"><img src="images/p0043_img_in_image_box_197_260_762_531.jpg" alt="图1.13" width="58%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.13</div> </div>


## 3. 保角变换

如图1.13所示，设过 $ z_{0} $点另有一条曲线 $ l_{2} $，它在 $ z_{0} $点的切线方向为 $ \theta_{2} $，则经过变换 $ w=f(z) $后在w平面相应的也有过 $ w_{0} $的另一条曲线 $ l_{2}^{\prime} $。设它在 $ w_{0} $点的切线方向为 $ \theta_{2}^{\prime} $，则由导数的几何意义知

又由前面(1.5.4)式有

所以

 $$ \begin{aligned}\theta_{2}^{\prime}-\theta_{2}&=\arg f^{\prime}(z_{0})\\\theta_{1}^{\prime}-\theta_{1}&=\arg f^{\prime}(z_{0})\\\theta_{2}^{\prime}-\theta_{2}&=\theta_{1}^{\prime}-\theta_{1}\\\theta_{2}^{\prime}-\theta_{1}^{\prime}&=\theta_{2}-\theta_{1}\end{aligned} $$ 

即

这说明曲线  $ l_{1} $ 和  $ l_{2} $ 在  $ z_{0} $ 点的夹角 $ \theta_{2}-\theta_{1} $，经变换后其大小和转向均未发生改变.

我们称这种使通过已知点的任意两条曲线间的夹角的大小及方向保持不变的变换  $ w=f(z) $，为该点的保角变换（或在该点是保角的）。若变换  $ w=f(z) $ 在一区域  $ \sigma $ 内各点均保角，则称它为该区域  $ \sigma $ 内的保角变换。

显然，解析函数在导数不为零的各点实现保角变换。

值得指出的是，有时需要讨论两条曲线在  $ z=\infty $ 处的交角的保角性. 在这种情形下，应当先作变换  $ z=\frac{1}{t} $，然后讨论经过这变换后的相应两条曲线在 t=0 点  $ (z=\infty $ 的相应点) 的交角的保角性 $ ^{③} $.

## 4. 保角变换的性质

我们指出，在保角变换下，二维拉氏方程、泊松方程和亥姆霍兹方程均具有不变性。

<!-- page: 44 -->

事实上，若  $ w = f(z) = \xi(x, y) + \mathrm{i}\eta(x, y) $ 在某区域  $ \sigma $ 内解析，且  $ w = f'(z) \neq 0 $，则由上可知， $ w = f(z) $ 在  $ \sigma $ 内实现保角变换。于是，实二元函数  $ u(x, y) $ 在此变换下变为  $ u(\xi, \eta) $ 且经此变换后有 $ ^{①} $

 $$ \begin{aligned}u_{x}&=u_{\xi}\xi_{x}+u_{\eta}\eta_{x},\quad u_{y}=u_{\xi}\xi_{y}+u_{\eta}\eta_{y}\\u_{xx}&=u_{\xi\xi}\xi_{x}^{2}+2u_{\xi\eta}\xi_{x}\eta_{x}+u_{\eta\eta}\eta_{x}^{2}+u_{\xi\xi x x}+u_{\eta}\eta_{xx}\\u_{yy}&=u_{\xi\xi}\xi_{y}^{2}+2u_{\xi\eta}\xi_{y}\eta_{y}+u_{\eta\eta}\eta_{y}^{2}+u_{\xi\xi y y}+u_{\eta}\eta_{yy}\\x_{xx}+u_{yy}&=u_{\xi\xi}(\xi_{x}^{2}+\xi_{y}^{2})+2u_{\xi\eta}(\xi_{x}\eta_{x}+\xi_{y}\eta_{y})+u_{\eta\eta}(\eta_{x}^{2}+\eta_{y}^{2})\\&\quad+u_{\xi}(\xi_{xx}+\xi_{yy})+u_{\eta}(\eta_{xx}+\eta_{yy})\end{aligned} $$ 

所以

而由 C-R 条件(1.3.9)式有

从而有

 $$ \begin{aligned}\xi_{x}&=\eta_{y},\quad\eta_{x}=-\xi_{y}\\\xi_{x}\eta_{x}+\xi_{y}\eta_{y}&=\xi_{x}\eta_{x}-\eta_{x}\xi_{x}=0\\\xi_{xx}+\xi_{yy}&=\eta_{xx}+\eta_{yy}=0\end{aligned} $$ 

更由(1.3.10)式和(1.3.11)式有

 $$ \xi_{x}^{2}+\xi_{y}^{2}=\eta_{x}^{2}+\eta_{y}^{2}=|\ f^{\prime}(z)|\ ^{2} $$ 

将这些结果一并代入(1.5.5)式便有

$$  u_{x x}+u_{y y}=(u_{\xi\xi}+u_{\eta\eta})|f^{\prime}(z)|^{2}   \tag*{(1.5.6)}$$

将（1.5.6）式代入拉普拉斯方程

$$  u_{xx}+u_{yy}=0   \tag*{(1.5.7)}$$

便有

 $$ (u_{\mathfrak{s}\mathfrak{s}}+u_{\mathfrak{m}})\mid f^{\prime}(z)\mid^{2}=0 $$ 

因为  $ f'(z) \neq 0 $，于是有

$$  u_{ 緹 }+u_{\eta\eta}=0   \tag*{(1.5.8)}$$

即拉普拉斯方程在保角变换下仍变为新坐标平面 w 中的拉普拉斯方程. 同样, 将 (1.5.6) 式代入泊松方程

$$  u_{x x}+u_{y y}=-h(x,y)   \tag*{(1.5.9)}$$

便有

$$  u_{\xi\xi}+u_{\eta\eta}=-h^{*}\left(\xi,\eta\right)   \tag*{（1.5.10）}$$

即泊松方程在保角变换下仍变为新坐标平面 w 中的泊松方程. 其中

$$  h^{*}\left(\xi,\eta\right)=\frac{h(x,y)}{\left|f^{\prime}(z)\right|^{2}}   \tag*{（1.5.11）}$$

类似的，我们也很易看出亥姆霍兹方程

$$  u_{xx}+u_{yy}+\lambda u=0   \tag*{（1.5.12）}$$

在保角变换  $ \omega = f(z) $ 下，将也仍变为亥姆霍兹方程

$$  u_{\mathfrak{s}\mathfrak{s}}+u_{\eta\eta}+\lambda^{*}u=0   \tag*{（1.5.13）}$$

其中

$$  \lambda^{*}=\frac{\lambda}{\mid f^{^{\prime}}(z)\mid^{2}}   \tag*{（1.5.14）}$$

<!-- page: 45 -->

保角变换的上述性质，使得保角变换在物理学的平面场问题中有着广泛的应用。因为以上三方程在保角变换下的不变性，实际上意味着满足以上三方程的平面场问题，在保角变换下的物理实质不变。这就使得我们有可能将一些边界形状复杂不易求解的平面场问题，通过选择某种适当的保角变换，化为边界形状简单的易求解的问题。

例 2 求两个具有相等电势  $ v_{0} $ 的互相垂直的很大的导电平板周围的等势面和电场线的分布.

解 由于问题的对称性，只需考虑如图 1.14(a) 所示 z 平面的第一象限情况. 为使边界形状简化，选变换

 $$ w=z^{2} $$ 

则图1.14(a)中的直角区域变成了图1.14(b)中w平面的上半平面，而在实轴 $ \eta=0 $上其电势为 $ v_{0} $.故由初等电磁学的知识知，在w平面其等势线为平行于实轴的直线，即 $ \eta= $常数；而电场线则是平行于虚轴的直线，即 $ \xi= $常数.回到z平面，由 $ w=z^{2} $有

 $$ \xi+\mathrm{i}\eta=(x+\mathrm{i}y)^{2}=x^{2}-y^{2}+\mathrm{i}2xy $$ 

所以等势线和电场线的方程分别为

 $$ \eta=2xy= 常数 $$ 

 $$ \xi=x^{2}-y^{2}= 常数 $$ 

这是 z 平面中的两族互相正交的双曲线，分别用实线和虚线在图 1.14(a) 中画出.

<div style="text-align: center;"><img src="images/p0045_img_in_image_box_184_751_771_1042.jpg" alt="图1.14" width="61%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.14</div> </div>


注 ① 由于解析函数的连续性，所以当  $ \Delta z \to 0 $ 时有  $ \Delta w \to 0 $.

② 曲线在某点的夹角，即指它们在该点的切线的夹角.

③因为在数学上定义曲线在无穷远点的交角为 $ \alpha $，就是指它们在倒数变换下的像曲线在原点的交角为 $ \alpha $。

④这里，引入了偏微商的另一种表示方法，即， $ u_{x}=\frac{\partial u}{\partial x} $， $ u_{xx}=\frac{\partial^{2}u}{\partial x^{2}} $，其他以此类推.

<!-- page: 46 -->

#### 习题1.5

1. w=z^{2} 将正方形 OACB(图 1.15) 变成什么图形?

2. 求  $ w=\frac{z-i}{z+i} $ 在 z=-1, z=i 的放大系数和转动角.

3. 函数  $ w=\frac{1}{z} $ 将 z 平面的下列曲线变成 w 平面上的什么曲线？

(1) $ x^{2}+y^{2}=4 $; (2)y=x;

(3) $ (x-1)^{2}+y^{2}=1 $; (4)x=1.

<div style="text-align: center;"><img src="images/p0046_img_in_image_box_649_228_857_423.jpg" alt="图1.15" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.15</div> </div>


4. 试讨论下列两对函数所构成的变换的特性（讨论其保角性和图形的变化情况）：

（1）幂函数  $ w=z^{n} $ 和根式函数  $ z=\sqrt[n]{w}\left(0<\arg z<\frac{2\pi}{n},n $ 为大于 1 的整数 $ \right) $;

(2) 指数函数  $ w = e^{z} $ 和对数函数  $ z = \ln w $ (0 < Imz < 2 $ \pi $).

 $ ^{*} $5. 求半无穷导体平面附近的电场分布（设导体上电势为  $ v_{0} $）.

6. 两块无穷大的金属板连成一块无穷大的板，连接处绝缘。设两部的电势分别为  $ v_{1} $ 和  $ v_{2} $，求板外的电势。

<!-- page: 47 -->

<div style="text-align: center;"><img src="images/p0047_img_in_image_box_109_349_172_414.jpg" alt="Image" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0047_img_in_image_box_109_481_172_547.jpg" alt="Image" width="6%" /></div>


本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>当\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n</td></tr></table>

<!-- page: 48 -->

## 第二章 解析函数积分

复积分是研究解析函数的工具。本章将在复积分的基础上建立表示解析函数积分的柯西（Cauchy）定理和柯西积分公式，它们是复变函数的基本理论和基本公式。

### 2.1 复变函数的积分

## 1. 复变函数积分的定义

复变函数的积分是复平面上的线积分，与实变函数积分类似，它也可以定义为和的极限.

设 l 是复数平面上的一条曲线，由 A 点到 B 点，在曲线上复变函数  $ f(z) $ 有定义。把曲线 l 任意分为 n 段，分点为  $ z_{0}=A, z_{1}, z_{2}, \cdots, z_{n}=B; \zeta_{k} $ 是  $ [z_{k-1}, z_{k}] $ 段上的任意

<div style="text-align: center;"><img src="images/p0048_img_in_image_box_101_669_375_948.jpg" alt="图2.1" width="28%" /></div>


一点(图2.1).作和数

<div style="text-align: center;"><div style="text-align: center;">图2.1</div> </div>


 $$ \begin{aligned}\sum_{k=1}^{n}f(\zeta_{k})(z_{k}-z_{k-1})&=\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k},\\ 其中 \Delta z_{k}&=z_{k}-z_{k-1}\end{aligned} $$ 

当 $n$ 无限地增大，使每一 $|\Delta z_k|$ 都趋于零时，如果这和数的极限存在，而且其值与各个 $\zeta_k$ 点的选取无关，则这极限值称为函数 $f(z)$ 沿曲线 $l$ 由 $A$ 到 $B$ 的积分，并记

$$  \int_{l}f(z)\mathrm{d}z=\lim_{\substack{n\to\infty\\ \max|\Delta z_{b}|\to0}}\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}   \tag*{(2.1.1)}$$

## 2. 复积分的存在条件及计算方法

若记  $ \zeta_{k}=\xi_{k}+\mathrm{i}\eta_{k},\Delta z_{k}=\Delta x_{k}+\mathrm{i}\Delta y_{k}\left(\xi_{k},\eta_{k},x_{k},y_{k}\right) $ 均为实数），则  $ f\left(\zeta_{k}\right)=u\left(\xi_{k},\eta_{k}\right)+\mathrm{i}v\left(\xi_{k},\eta_{k}\right)=u_{k}+\mathrm{i}v_{k} $ 。其中  $ u_{k}=u\left(\xi_{k},\eta_{k}\right),v_{k}=v\left(\xi_{k},\eta_{k}\right) $ 是实数。因而有

 $$ \begin{align*}\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}&=\sum_{k=1}^{n}(u_{k}+\mathrm{i}v_{k})(\Delta x_{k}+\mathrm{i}\Delta y_{k})\\&=\sum_{k=1}^{n}(u_{k}\Delta x_{k}-v_{k}\Delta y_{k})+\mathrm{i}\sum_{k=1}^{n}(v_{k}\Delta x_{k}+u_{k}\Delta y_{k})\end{align*} $$ 

如果上式右端两个和数的极限分别存在（当  $ n \to \infty, \max | \Delta z_k | \to 0 $ 时），由数学分析中

<!-- page: 49 -->

关于实线积分的知识知道，它们就是两个实线积分

$$  \int_{l}u\mathrm{d}x-v\mathrm{d}y,\qquad\int_{l}v\mathrm{d}x+u\mathrm{d}y   \tag*{(2.1.2)}$$

于是当和数  $ \sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k} $ 的极限存在时，有

$$  \int_{l}f(z)\mathrm{d}z=\int_{l}u\mathrm{d}x-v\mathrm{d}y+\mathrm{i}\int_{l}v\mathrm{d}x+u\mathrm{d}y   \tag*{(2.1.3)}$$

由此可见复积分 $ \int_{l}f(z)\mathrm{d}z $存在的条件，也就是(2.1.2)式中两个实线积分存在的条件.所以，只要 $ f(z) $在l上连续.曲线l分段光滑，复积分 $ \int_{l}f(z)\mathrm{d}z $就存在且由(2.1.3)式给出.

既然复积分是两实积分的组合，我们当然可以将复积分化为实积分来计算。

例1 计算 $ \int_{l}Rezdz $，其中l如图2.2所示分别为：(1)连接O点到2+i点的直线段；(2)连接O点到2再到2+i的折线.

解  $ \int_{l}Rez\mathrm{d}z=\int_{l}x(\mathrm{d}x+\mathrm{i}\mathrm{d}y) $

<div style="text-align: center;"><img src="images/p0049_img_in_image_box_600_510_858_704.jpg" alt="图2.2" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.2</div> </div>


（1）此时x=2y,y:0\rightarrow1，故

 $$ \begin{aligned}\int_{l}Re z\mathrm{d}z=&\int_{OA}x\left(\mathrm{d}x+\mathrm{i}\mathrm{d}y\right)\\ =&\int_{0}^{1}2y(2+\mathrm{i})\mathrm{d}y=2+\mathrm{i}\end{aligned} $$ 

（2）在 OB 上，y=0, x:0  $ \rightarrow $ 2；在 BA 上，x=2, y:0  $ \rightarrow $ 1。故

 $$ \begin{aligned}\int_{I}\mathrm{Re}z\mathrm{d}z=&\int_{OB}x\left(\mathrm{d}x+\mathrm{i}\mathrm{d}y\right)+\int_{BA}x\left(\mathrm{d}x+\mathrm{i}\mathrm{d}y\right)\\ =&\int_{0}^{2}x\mathrm{d}x+\mathrm{i}\int_{0}^{1}2\mathrm{d}y=2+2\mathrm{i}\end{aligned} $$ 

由此例看出，积分路径不同，积分的结果也不同.

例2 计算 $ \int_{l}z^{2}dz $，其中l是与上例相同的两条路径.

解  $ z^{2}=x^{2}-y^{2}+i2xy,u=x^{2}-y^{2},v=2xy $ ，故由(2.1.3)式有

 $$ \int_{l}z^{2}\mathrm{d}z=\int_{l}(x^{2}-y^{2})\mathrm{d}x-2xy\mathrm{d}y+\mathrm{i}\int_{l}2xy\mathrm{d}x+(x^{2}-y^{2})\mathrm{d}y $$ 

(1)

 $$ \int_{l}z^{2}\mathrm{d}z=\int_{0}^{1}\left[2(4y^{2}-y^{2})-4y^{2}\right]\mathrm{d}y+\mathrm{i}\int_{0}^{1}\left[8y^{2}+(4y^{2}-y^{2})\right]\mathrm{d}y=\frac{2}{3}+\frac{11}{3}\mathrm{i} $$ 

(2)

 $$ \begin{align*}\int_{I}z^{2}\mathrm{d}z=&\int_{OB}z^{2}\mathrm{d}z+\int_{BA}z^{2}\mathrm{d}z\\=&\int_{0}^{2}x^{2}\mathrm{d}x+\int_{0}^{1}(-4y)\mathrm{d}y+\mathrm{i}\int_{0}^{1}(4-y^{2})\mathrm{d}y=\frac{2}{3}+\frac{11}{3}\mathrm{i}\end{align*} $$

<!-- page: 50 -->

由此例看出，对于有些被积函数而言，尽管积分路径不同，但积分结果却是相同的。

下面再看一个结果可以作为公式记住的例子.

例3 试证

$$  \oint_{l}\frac{\mathrm{d}z}{(z-a)^{n}}=\left\{\begin{aligned}&2\pi i&(n=1)\\ &0&(n 是 \neq1 的整数 )\end{aligned}\right.   \tag*{(2.1.4)}$$

此处 l 是以 a 为中心 r 为半径的圆周.

证 在 l 上， $ z-a=re^{i\theta}(0<\theta\leqslant2\pi) $， $ \mathrm{d}z=\mathrm{i}re^{i\theta}\mathrm{d}\theta $

当n=1时有

 $$ \oint_{l}\frac{\mathrm{d}z}{z-a}=\int_{0}^{2\pi}\frac{\mathrm{i}r\mathrm{e}^{i\theta}}{r\mathrm{e}^{i\theta}}\mathrm{d}\theta=2\pi\mathrm{i} $$ 

当n为不等于1的整数时有

 $$ \oint_{l}\frac{\mathrm{d}z}{(z-a)^{n}}=\int_{0}^{2\pi}\frac{\mathrm{i}r\mathrm{e}^{\mathrm{i}\theta}}{r^{n}\mathrm{e}^{\mathrm{i}n\theta}}\mathrm{d}\theta=\frac{\mathrm{i}}{r^{n-1}}\int_{0}^{2\pi}\mathrm{e}^{-\mathrm{i}(n-1)\theta}\mathrm{d}\theta=0 $$ 

## 3. 复积分的性质

由复积分的定义，很容易证明复积分有与数学分析中的曲线积分类似的性质

(1)

 $$ \int_{l}\left[c_{1}f_{1}(z)+c_{2}f_{2}(z)\right]\mathrm{d}z=c_{1}\int_{l}f_{1}(z)\mathrm{d}z+c_{2}\int_{l}f_{2}(z)\mathrm{d}z(c_{1},c_{2} 为复 $$ 

(2)

 $$ \int_{l_{1}+l_{2}}f(z)\mathrm{d}z=\int_{l_{1}}f(z)\mathrm{d}z+\int_{l_{2}}f(z)\mathrm{d}z; $$ 

(3)

 $$ \int_{l_{A B}}f(z)\mathrm{d}z=-\int_{l_{B A}}f(z)\mathrm{d}z. $$ 

此外还有两个积分不等式，在对积分值作估计时是经常用到的

(1)

$$  \left|\int_{l}f(z)\mathrm{d}z\right|\leqslant\int_{l}\mid f(z)\mid\mathrm{d}s=\int_{l}\mid f(z)\mid\mid\mathrm{d}z\mid   \tag*{(2.1.5)}$$

其中  $ \mathrm{d}s=|\mathrm{d}z|=\sqrt{\mathrm{d}x^{2}+\mathrm{d}y^{2}} $，是曲线 l 的弧元.

证 由于  $ \left|\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}\right|\leqslant\sum_{k=1}^{n}\left|f(\zeta_{k})\right|\mid\Delta z_{k}\mid $，两边取极限即得(2.1.5)式.

(2) $ \left|\int_{l}f(z)dz\right|\leqslant MS $ (2.1.6)

其中M为 $ \left|f(z)\right| $在l上的一个上界，S为l的长度.

证 由于  $ \left|\sum_{k=1}^{n}f(\zeta_{k})\Delta z_{k}\right|\leqslant\sum_{k=1}^{n}\left|f(\zeta_{k})\right|\left|\Delta z_{k}\right|\leqslant M\sum_{k=1}^{n}\left|\Delta z_{k}\right| $，两边取极限即得(2.1.6)式.

#### 习题2.1

1. 计算积分 $ \int_{0}^{1+i}(x-y+ix^{2})dz $，积分路径是直线段.

2. 计算积分  $ \int_{-1}^{1} |z| \, dz $，积分路径是(1)直线段；(2)单位圆周的上半；(3)单位圆周的下半.

<!-- page: 51 -->

3. 利用积分不等式，证明

(1)  $ \left|\int_{-i}^{i}(x^{2}+iy^{2})dz\right|\leqslant2 $，积分路径是直线段；

(2) $ \left|\int_{-i}^{i}(x^{2}+iy^{2})dz\right|\leqslant\pi $，积分路径是连接-i到i的右半圆周.

4. 证明  $ \left|\int_{i}^{2+i}\frac{\mathrm{d}z}{z^{2}}\right|\leqslant2. $

5. 计算  $ I=\int_{l}\frac{\mathrm{d}z}{(z-a)^{n}} $，其中 n 为整数，l 为以 a 为中心，r 为半径的上半圆周.

### 2.2 柯西定理

由上一节的例子我们看到，有些复变函数的积分值不仅依赖于起点和终点，而且还与积分路径有关（如上节例1）；而有些复变函数的积分值却是只与积分路径的起点和终点有关（如上节例2）。函数  $ f(z) $ 究竟应该具备什么条件，才能保证  $ \int_{t} f(z) dz $ 所得值与路径无关呢？本节的柯西定理将讨论这一问题。

## 1. 单连通区域的柯西定理

设  $ f(z) $ 在单连通区域  $ \sigma $ 内解析，l 为  $ \sigma $ 内的任意一条分段光滑的曲线（图 2.3），则

$$  \oint_{l}f(z)\mathrm{d}z=0   \tag*{(2.2.1)}$$

证明这样的定理是比较困难的，1851年黎曼在附加条件“ $ f'(z) $在 $ \sigma $内连续”下得到一个如下的简单证明.

证 由(2.1.3)式

 $$ \oint_{l}f(z)\mathrm{d}z=\oint_{l}(u\mathrm{d}x-v\mathrm{d}y)+\mathrm{i}\oint_{l}(v\mathrm{d}x+u\mathrm{d}y) $$ 

设  $ f'(z) $ 在  $ \sigma $ 内连续，即  $ \frac{\partial u}{\partial x}, \frac{\partial u}{\partial y}, \frac{\partial v}{\partial x}, \frac{\partial v}{\partial y} $ 在  $ \sigma $ 内连续，则由数学分析中格林(Green)公式

<div style="text-align: center;"><img src="images/p0051_img_in_image_box_677_760_859_956.jpg" alt="图2.3" width="18%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.3</div> </div>


$$  \oint_{l}P(x,y)\mathrm{d}x+Q(x,y)\mathrm{d}y=\iint_{\sigma^{*}}\left(\frac{\partial Q}{\partial x}-\frac{\partial P}{\partial y}\right)\mathrm{d}\sigma   \tag*{(2.2.2)}$$

有

 $$ \oint_{l}f(z)\mathrm{d}z=\iint_{\sigma^{*}}\left(-\frac{\partial v}{\partial x}-\frac{\partial u}{\partial y}\right)\mathrm{d}\sigma+\mathrm{i}\iint_{\sigma^{*}}\left(\frac{\partial u}{\partial x}-\frac{\partial v}{\partial y}\right)\mathrm{d}\sigma $$ 

其中 $ \sigma^{*} $是以l为边界的单连通区域.又因为在 $ \sigma $内有

 $$ \frac{\partial u}{\partial x}=\frac{\partial v}{\partial y},\quad\frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y} $$ 

故得

 $$ \oint_{l}f(z)\mathrm{d}z=0 $$

<!-- page: 52 -->

在以上证明的过程中我们附加了条件“ $ f'(z) $在 $ \sigma $内连续”，是为了引用格林公式(2.2.2).但1900年古沙(Coursat)发明了新的证明方法，他勿需引用格林公式来证明柯西定理，因此“ $ f'(z) $在 $ \sigma $内连续”的条件在柯西定理中是可以去掉的.柯西定理的古沙证明法较长，这里从略.读者可参阅：参考书目[3]第四章§2.2，或Coursat-Hedrick-Dunkel，Function of a complex variable,1916.

## 2. 推论2.1

在单连通区域中解析的函数  $ f(z) $ 的积分值只依赖于起点与终点而与积分路线无关.

证 设  $ f(z) $ 在区域  $ \sigma $ 内解析， $ l_{1} $ 和  $ l_{2} $ 为  $ \sigma $ 内由 A 到 B 的任意两条分段光滑的

<div style="text-align: center;"><img src="images/p0052_img_in_image_box_98_468_326_675.jpg" alt="图2.4" width="23%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.4</div> </div>


 $$ \oint f(z)\mathrm{d}z=\int_{l_{1}}f(z)\mathrm{d}z-\int_{l_{2}}f(z)\mathrm{d}z=0 $$ 

所以

 $$ \int_{l_{1}}f(z)\mathrm{d}z=\int_{l_{2}}f(z)\mathrm{d}z $$ 

这就证明了推论.

根据这一结果，我们可以在一定范围内选择积分路径，使积分便于计算。

## 3. 不定积分 原函数

柯西定理已经回答了积分与路径无关的条件，这就是说，如果在单连通区域  $ \sigma $ 内  $ f(z) $ 解析，则沿  $ \sigma $ 内任一曲线 l（为叙述简单，今后我们所提到的曲线，一律指分段光滑的曲线）的积分  $ \int_{l} f(\zeta) \, \mathrm{d}\zeta $ 之值，只与其起点和终点有关。因此，当  $ z_{0} $ 固定，而令终点 z 为变点时，则不定积分  $ \int_{z_{0}}^{z} f(\zeta) \, \mathrm{d}\zeta $ 在  $ \sigma $ 内定义了一个单值函数

$$  F(z)=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta   \tag*{(2.2.3)}$$

称之为  $ f(z) $ 的不定积分.

定理2.1 设  $ f(z) $ 在单连通区域  $ \sigma $ 内解析，则由(2.2.3)式定义的函数  $ F(z) $ 在  $ \sigma $ 内解析，且  $ F'(z) = f(z) $.

证 在区域  $ \sigma $ 内的任一点 z 的邻域中取一点  $ z + \Delta z $，则由(2.2.3)式有

 $$ \frac{F(z+\Delta z)-F(z)}{\Delta z}=\frac{1}{\Delta z}\Big[\int_{z_{0}}^{z+\Delta z}f(\zeta)\mathrm{d}\zeta-\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta\Big] $$ 

由于右端积分与路径无关，故积分 $ \int_{z_{0}}^{z+\Delta z}f(\zeta)\mathrm{d}\zeta $的积分路径可以选成先由 $ z_{0} $到z与第二个积分相同的路径，再从z沿直线段到 $ z+\Delta z $（图2.5），于是有

<!-- page: 53 -->

$$ \frac{F(z+\Delta z)-F(z)}{\Delta z}=\frac{1}{\Delta z}\int_{z}^{z+\Delta z}f(\zeta)\mathrm{d}\zeta $$ 

又

 $$ f(z)=\frac{1}{\Delta z}\int_{z}^{z+\Delta z}f(z)\mathrm{d}\zeta $$ 

故有

 $$ \frac{F(z+\Delta z)-F(z)}{\Delta z}-f(z)=\frac{1}{\Delta z}\int_{z}^{z+\Delta z}[f(\zeta)-f(z)]\mathrm{d}\zeta $$ 

因  $ f(z) $ 是  $ \sigma $ 内的连续函数，故对于任意给定的  $ \varepsilon>0 $，可以找到  $ \delta>0 $，使当  $ \left|\zeta-z\right|<\delta $ 时  $ \left|f(\zeta)-f(z)\right|<\varepsilon $，

<div style="text-align: center;"><img src="images/p0053_img_in_image_box_612_140_860_383.jpg" alt="图2.5" width="25%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.5</div> </div>


而有

 $$ \left|\frac{F(z+\Delta z)-F(z)}{\Delta z}-f(z)\right|=\left|\frac{1}{\Delta z}\int_{z}^{z+\Delta z}[f(\zeta)-f(z)]\mathrm{d}\zeta\right|<\frac{1}{|\Delta z|}\int_{z}^{z+\Delta z}\varepsilon|\mathrm{d}\zeta|=\varepsilon $$ 

即

 $$ \lim_{\Delta z\to0}\frac{F(z+\Delta z)-F(z)}{\Delta z}=f(z) $$ 

亦即

 $$ F^{\prime}(z)=f(z)^{\textcircled{1}} $$ 

与数学分析一样，如果  $ \Phi'(z)=f(z) $，则称  $ \Phi(z) $ 为  $ f(z) $ 的一个原函数。因此，由不定积分（2.2.3）式所定义的函数  $ F(z) $ 就是被积函数  $ f(z) $ 的一个原函数。 $ f(z) $ 的原函数不是唯一的，但它们只差一个常数，即

$$  \Phi(z)=F(z)+C=\int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta+C   \tag*{(2.2.4)}$$

其中 C 为一个常数. 因为

 $$ \begin{aligned}&\Phi^{\prime}(z)=F^{\prime}(z)=f(z)\\ &\left[\Phi(z)-F(z)\right]^{\prime}=0\\ \end{aligned} $$ 

故

而有

 $$ \Phi(z)-F(z)=C,\quad 即 \quad\Phi(z)=F(z)+C $$ 

在(2.2.4)式中令 $ z=z_{0} $，得到 $ C=\Phi(z_{0}) $，所以

$$  \int_{z_{0}}^{z}f(\zeta)\mathrm{d}\zeta=\varPhi(z)-\varPhi(z_{0})   \tag*{(2.2.5)}$$

(2.2.5)式将计算解析函数的积分归结为寻找其原函数的问题.

例1 计算 $ \int_{0}^{2+i} z^{2} dz $.

解 函数  $ z^{2} $ 在复平面解析， $ \frac{z^{3}}{3} $ 是它的一个原函数，所以

 $$ \int_{0}^{2+i}z^{2}\mathrm{d}z=\frac{z^{3}}{3}\bigg|_{0}^{2+i}=\frac{2}{3}+\frac{11}{3}i $$ 

这样计算，当然比上一节中将它化为实积分沿任何一条路径计算都方便、简单得多。

例2 在区域 $ \sigma:0<\arg z<2\pi $上，计算 $ \int_{1}^{2}\frac{dz}{z} $

解 因为函数 $ \frac{1}{z} $在 $ \sigma $上解析，且其原函数为 $ \ln z $，故 $ \int_{1}^{2}\frac{1}{z}\mathrm{d}z=\ln2-\ln1=\ln2 $

<!-- page: 54 -->

## 4. 柯西定理的推广

单连通区域的柯西定理实际上指出了这样的事实：如果围线 l 及其内部均含于  $ f(z) $ 的解析区域中，则  $ \oint_{l} f(z) dz = 0 $。于是，我们可以推广柯西定理成下述的形式，以后我们将经常引用这种推广了的柯西定理：

设 l 为区域  $ \sigma $ 的边界围线，如果  $ f(z) $ 在区域  $ \sigma $ 内解析，且在  $ \bar{\sigma} = \sigma + l $ 上连续，则  $ \oint_{l} f(z) dz = 0 $.

因为  $  f(z)  $ 在 l 上连续，故积分  $ \int_{l} f(z) dz $ 存在。在 l 的内部作一围线  $ l^{*} $，由前述的柯西定理有  $ \oint_{l^{*}} f(z) dz = 0 $。而  $  f(z)  $ 在 l 上及其内部都是连续的，所以当  $ l^{*} $ 逼近于 l 时  $ \oint_{l^{*}} f(z) dz $ 的极限情况应就是  $ \oint_{l} f(z) dz $。这种想法为证明本定理提供了一个线索，但严格的证明比较麻烦，这里从略，读者可参看参考书目[3]第四章 §2.8。

## 5. 复通区域的柯西定理

由于我们所碰到的问题中的函数不一定在所讨论的区域中处处解析，可能有奇点，因此，我们常常需要作一些适当的围道把奇点挖掉而考虑所得到的有洞的复通区域的柯西定理：

设  $ L=l+\sum_{k=1}^{n}l_{k} $ 为复通区域  $ \sigma $ 的全部边界围线（图 2.6），若  $ f(z) $ 在  $ \sigma $ 内解析，在  $ \bar{\sigma}=\sigma+L $ 上连续，则有

$$  \oint_{l}f(z)\mathrm{d}z=\sum_{k=1}^{n}\oint_{l}f(z)\mathrm{d}z   \tag*{(2.2.6)}$$

其中，所有积分路线的走向都是逆时针方向的（以后均将逆时针走向记为 $ \oint $，而顺时针走向记为 $ \oint $）.

证 为简单起见，先考虑如图2.7所示仅由l和 $ l_{1} $两边界所组成的复通区域（即

<div style="text-align: center;"><img src="images/p0054_img_in_image_box_214_1023_404_1234.jpg" alt="图2.6" width="19%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.6</div> </div>


<div style="text-align: center;"><img src="images/p0054_img_in_image_box_524_1016_743_1236.jpg" alt="图2.7" width="22%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.7</div> </div>

<!-- page: 55 -->

$ L=l+l_{1}) $的情况.

作割线 AB，则复通区域化为了单连通区域。由单连通区域的柯西定理有

 $$ \oint_{L}f(z)\mathrm{d}z=\oint_{l}f(z)\mathrm{d}z+\int_{A}^{B}f(z)\mathrm{d}z+\oint_{l_{1}}f(z)\mathrm{d}z+\int_{B}^{A}f(z)\mathrm{d}z=0 $$ 

于是

 $$ \oint_{l}f(z)\mathrm{d}z+\oint_{l_{1}}f(z)\mathrm{d}z=0 $$ 

即

 $$ \oint_{l}f(z)\mathrm{d}z=\oint_{l_{1}}f(z)\mathrm{d}z $$ 

同法可证得，对于  $ L=l+\sum_{k=1}^{n}l_{k} $，有

 $$ \oint_{l}f(z)\mathrm{d}z=\sum_{k=1}^{n}\oint_{l_{k}}f(z)\mathrm{d}z $$ 

例3 计算 $ \oint_{l}\frac{dz}{(z-a)^{n}} $，其中n为整数，l为包围z=a的任一闭路径（图2.8）.

解 当  $ n \leqslant 0 $ 时， $ \frac{1}{(z-a)^{n}} $ 在 l 内及 l 上均解析，所以由柯西定理有

 $$ \oint_{l}\frac{\mathrm{d}z}{(z-a)^{n}}=0,\quad n\leqslant0 $$ 

<div style="text-align: center;"><img src="images/p0055_img_in_image_box_652_488_861_713.jpg" alt="图2.8" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.8</div> </div>


当n>0时，z=a 为 $ \frac{1}{\left(z-a\right)^{n}} $的奇点，在l内以a为圆心作一小圆 $ l_{e} $（含于l内），则由复通区域的柯西定理有

 $$ \oint_{l}\frac{\mathrm{d}z}{(z-a)^{n}}=\oint_{l_{z}}\frac{\mathrm{d}z}{(z-a)^{n}} $$ 

而由(2.1.4)式有

 $$ \oint_{l_{e}}\frac{\mathrm{d}z}{(z-a)^{n}}=\left\{\begin{matrix}2\pi\mathrm{i},&n=1\\ 0,&n\neq1\end{matrix}\right. $$ 

所以

<div style="text-align: center;"><img src="images/p0055_img_in_image_box_98_944_351_1190.jpg" alt="图2.9" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.9</div> </div>


$$  \oint_{l}\frac{\mathrm{d}z}{(z-a)^{n}}=\left\{\begin{aligned}&2\pi\mathrm{i},&&n=1\\ &0,&&n\neq1\text{ 且为整数 }\end{aligned}\right.   \tag*{(2.2.7)}$$

例4 计算 $ \oint_{l}\frac{dz}{z^{2}-1} $，l是圆周 $ \left|z\right|=a,a>2 $

(图2.9).

解  $ \frac{1}{z^{2}-1} $ 在 l 内有两个奇点  $ z=\pm1 $，故在 l 内可作小圆  $ l_{1} $ 和  $ l_{2} $，则由(2.2.6)式有

 $$ \oint_{l}\frac{\mathrm{d}z}{z^{2}-1}=\oint_{l_{1}}\frac{\mathrm{d}z}{z^{2}-1}+\oint_{l_{2}}\frac{\mathrm{d}z}{z^{2}-1} $$

<!-- page: 56 -->

又

 $$ \frac{1}{z^{2}-1}=\frac{1}{2}\Big(\frac{1}{z-1}-\frac{1}{z+1}\Big) $$ 

所以

 $$ \oint_{l_{1}}\frac{\mathrm{d}z}{z^{2}-1}=\frac{1}{2}\Big(\oint_{l_{1}}\frac{\mathrm{d}z}{z-1}-\oint_{l_{1}}\frac{\mathrm{d}z}{z+1}\Big)=\frac{1}{2}(2\pi\mathrm{i}-0)=\pi\mathrm{i} $$ 

同样可得

 $$ \oint_{t_{2}}\frac{\mathrm{d}z}{z^{2}-1}=-\pi\mathrm{i} $$ 

所以

 $$ \oint_{l}\frac{\mathrm{d}z}{z^{2}-1}=\pi\mathrm{i}-\pi\mathrm{i}=0 $$ 

注 ① 需要指出的是，在此处的证明中我们实际上只用到了(1) $ f(z) $有单连通区域 $ \sigma $上连续；(2) $ \int f(\zeta)d\zeta $沿区域 $ \sigma $上任意围线的积分为0这两个条件.因此只要满足这两个条件，上述定理的结论也正确.关于这一点，在2.3节中将会用到.

#### 习题2.2

1. 计算积分

(1)  $ \oint_{l}\frac{dz}{(z-a)(z-b)} $, l 是包围 a、b 两点的围线；

(2)  $ \oint_{l}\frac{2z^{2}-15z+30}{z^{3}-10z^{2}+32z-32}dz $, l 为圆  $ \left|z\right|=3 $.

2. 计算积分

(1)  $ \int_{-2}^{-2+i}(z+2)^2 dz $; (2)  $ \int_0^{\pi+2i}\cos\frac{z}{2} dz $; (3)  $ \int_1^{1+\frac{\pi}{2}i} z e^z dz $.

3. 由积分 $ \oint_{|z|=1}\frac{dz}{z+2} $之值证明

 $$ \int_{0}^{2\pi}\frac{1+2\cos\theta}{5+4\cos\theta}\mathrm{d}\theta=0 $$ 

### 2.3 柯西积分公式

## 1. 柯西公式

解析函数是一类具有特殊性质的复变函数。这种特殊性质的突出表现之一是，在函数的解析区域中，各处的函数值不是互相独立的，而是彼此联系着的。本节要介绍的柯西公式就给出了解析函数在解析区域内部的值和边界值之间的关系。

设 l 为区域  $ \sigma $ 的边界围线，若  $ f(z) $ 在区域  $ \sigma $ 内解析，在  $ \bar{\sigma} = \sigma + l $ 上连续，a 为  $ \sigma $ 内任意一点，则

$$  f(a)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(z)}{z-a}\mathrm{d}z   \tag*{(2.3.1)}$$

这就是柯西积分公式，简称为柯西公式。

<!-- page: 57 -->

证 函数  $ g(z)=\frac{f(z)}{z-a} $ 在  $ \sigma $ 内除 z=a 外均解析. 在  $ \sigma $ 内以 a 为圆心，充分小的  $ \rho $ 为半径作圆周  $ l_{\rho} $ (图 2.10)，则在以复围线  $ l+l_{\rho} $ 为边界的复通区域内，对函数  $ g(z) $ 可用复通区域的柯西定理

 $$ \oint_{l}\frac{f(z)}{z-a}\mathrm{d}z=\oint_{l_{\rho}}\frac{f(z)}{z-a}\mathrm{d}z $$ 

上式的成立，与右端 $ l_{\rho} $的半径 $ \rho $的取值无关。所以，我们只要适当选取 $ \rho $后就能证明上式的右端之值等于 $ 2\pi if(a) $，则(2.3.1)式便得证。

<div style="text-align: center;"><img src="images/p0057_img_in_image_box_668_149_859_374.jpg" alt="图2.10" width="19%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图2.10</div> </div>


 $$ \oint_{l_{_\rho}}\frac{f(z)}{z-a}\mathrm{d}z=\oint_{l_{_\rho}}\frac{f(z)-f(a)}{z-a}\mathrm{d}z+\oint_{l_{_\rho}}\frac{f(a)}{z-a}\mathrm{d}z $$ 

而

 $$ \oint_{l_{p}}\frac{f(a)}{z-a}\mathrm{d}z=f(a)\oint_{l_{p}}\frac{1}{z-a}\mathrm{d}z=2\pi\mathrm{i}f(a) $$ 

又由  $ f(z) $ 的连续性知，对于任意的  $ \varepsilon>0 $，存在  $ -\delta>0 $，使得当  $ |z-a|<\delta $ 即  $ \rho<\delta $ 时有

 $$ \mid f(z)-f(a)\mid<\varepsilon $$ 

所以，只要取  $ \rho\to0 $，便有

即

 $$ \begin{aligned}\left|\oint_{l_{p}}\frac{f(z)-f(a)}{z-a}\mathrm{d}z\right|&\leqslant\max_{( 在 l_{p} 上 )}\mid f(z)-f(a)\mid\bullet\frac{1}{\rho}\bullet2\pi\rho<2\pi\varepsilon\\\oint_{l_{p}}\frac{f(z)-f(a)}{z-a}\mathrm{d}z&=0\\\oint_{l}\frac{f(z)}{z-a}\mathrm{d}z&=2\pi\mathrm{i}f(a)\end{aligned} $$ 

故

即

 $$ \begin{aligned}&f(a)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(z)}{z-a}\mathrm{d}z\\ &\\&f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\\ \end{aligned} $$ 

更一般地

柯西公式(2.3.2)的意义在于：一个解析函数 $ f(z) $在区域 $ \sigma $内的值由它在该区域边界上的值 $ f(\zeta) $所确定。利用这个性质，考虑到解析函数和调和函数的关系，我们可以应用柯西公式(2.3.2)求解二维拉普拉斯方程的边值问题（见本书习题10.4中第4题）。

显然，柯西公式(2.3.2)对于复连通区域仍然成立.这时只要把l理解为区域全部边界的正向就行了.例如，对于图2.6中的情形有

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta+\frac{1}{2\pi\mathrm{i}}\sum_{k=1}^{n}\oint_{l_{k}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta   \tag*{(2.3.3)}$$

利用柯西公式(2.3.2)，可以计算某些围道积分. 注意 z 是被积函数在围道内的

<!-- page: 58 -->

奇点.

<div style="text-align: center;"><img src="images/p0058_img_in_image_box_99_172_325_465.jpg" alt="图2.11" width="23%" /></div>


例1 计算 $ \oint_{l}\frac{e^{z}dz}{z(z^{2}+1)} $，l为圆 $ \left|z-i\right|=\frac{1}{2} $

解  $ \frac{\mathrm{e}^{z}}{z(z^{2}+1)}=\frac{\mathrm{e}^{z}}{z(z+\mathrm{i})(z-\mathrm{i})} $ 被积函数的奇点为 z=0 和  $ z=\pm\mathrm{i} $，但在 l 内只有一个奇点 z=i（图 2.11），故有

<div style="text-align: center;"><div style="text-align: center;">图2.11</div> </div>


 $$ \begin{aligned}\oint_{l}\frac{\mathrm{e}^{z}}{z\left(z^{2}+1\right)}\mathrm{d}z=&\oint_{l}\frac{\frac{\mathrm{e}^{z}}{z\left(z+\mathrm{i}\right)}}{z-\mathrm{i}}\mathrm{d}z\\=&\left.2\pi\mathrm{i}\bullet\frac{\mathrm{e}^{z}}{z\left(z+\mathrm{i}\right)}\right|_{z=\mathrm{i}}\\=&\left.\pi(\sin1-\mathrm{i}\cos1)\right.\end{aligned} $$ 

## 2. 无界区域的柯西公式

设  $ f(z) $ 在闭合围道 l 外单值解析，在 l 上直到 l 外连续，并且当  $ z \to \infty $ 时， $ f(z) $ 一致趋于零（即任给一  $ \varepsilon > 0 $，就可找到一大数  $ R_{1} $，当  $ |z| > R_{1} $ 时，使得  $ \left|f(z)\right| < \varepsilon $，则有

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta   \tag*{(2.3.4)}$$

其中z为l外的任意一点.

证 以 z=0 为圆心，R 为半径作一足够大的圆  $ C_{R} $，将 l 和 z 点皆包含在其中。则当  $ R \to \infty $ 时，在  $ C_{R} $ 上有  $ \left|f(z)\right| < \varepsilon $。由(2.3.3)式有

 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{c_{R}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta+\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta $$ 

而

 $$ \left|\oint_{C_{R}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\right|\leqslant\oint_{C_{R}}\frac{\mid f(\zeta)\mid}{\mid\zeta-z\mid}\mid\mathrm{d}\zeta\mid<\frac{\varepsilon}{R-|z|}\cdot2\pi R\doteq2\pi\varepsilon $$ 

由于 $ \varepsilon $的任意性，所以此项趋于零，故有(2.3.4)式.

## 3. 柯西公式的几个推论

（1）解析函数的任意除导数 设 l 为区域  $ \sigma $ 的边界围线， $ f(z) $ 在  $ \sigma $ 内解析，在  $ \bar{\sigma} = \sigma + l $ 上连续，则在  $ \sigma $ 内  $ f(z) $ 的任何除导数  $ f^{(n)}(z) $ 均存在，并且

$$  f^{\left(n\right)}\left(z\right)=\frac{n!}{2\pi\mathrm{i}}\oint_{l}\frac{f\left(\zeta\right)}{\left(\zeta-z\right)^{n+1}}\mathrm{d}\zeta,\quad n=1,2,\cdots   \tag*{(2.3.5)}$$

证 容易看出，(2.3.5)式是柯西公式(2.3.2)形式地在积分号下对z求n次导数的结果. 因此，只需证明在积分号下对z求导是合法的即可. 由(2.3.2)式有

 $$ \frac{f(z+\Delta z)-f(z)}{\Delta z}=\frac{1}{2\pi\mathrm{i}}\bullet\frac{1}{\Delta z}\oint_{l}\left[\frac{f(\zeta)}{\zeta-z-\Delta z}-\frac{f(\zeta)}{\zeta-z}\right]\mathrm{d}\zeta $$

<!-- page: 59 -->

$$ =\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)}\mathrm{d}\zeta $$ 

故

 $$ \begin{aligned}&\left|\frac{f(z+\Delta z)-f(z)}{\Delta z}-\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta\right|\\=&\left|\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)}\mathrm{d}\zeta-\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta\right|\\=&\left|\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{\Delta z f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)^{2}}\mathrm{d}\zeta\right|\end{aligned} $$ 

因为  $ f(\zeta) $ 在  $ \bar{\sigma} $ 上连续，故在 l 上有  $ \left|f(\zeta)\right| \leqslant M $ (M 为常数). 设  $ d = \min|\zeta - z| $, S 为 l 的长度，则  $ |\zeta - z| \geqslant d $,  $ |\zeta - z - \Delta z| \geqslant |\zeta - z| - |\Delta z| > d - \frac{d}{2} = \frac{d}{2} $ (当  $ \Delta z $ 足够的小，例如  $ |\Delta z| < \frac{d}{2} $ 时)，因此

 $$ \left|\frac{1}{2\pi i}\oint_{l}\frac{\Delta z f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)^{2}}\mathrm{d}\zeta\right|\leqslant\frac{1}{2\pi}\oint_{l}\left|\frac{\Delta z\cdot f(\zeta)}{(\zeta-z-\Delta z)(\zeta-z)^{2}}\right|\mathrm{d}\zeta<\frac{|\Delta z|}{2\pi}\cdot\frac{MS}{d\frac{\zeta}{2}\cdot d\zeta} $$ 

取 $ \left|\Delta z\right|<\delta=\min\left(\frac{d}{2},\frac{\varepsilon}{MS/\pi d^{3}}\right) $，则

 $$ \lim_{\Delta z\to0}\frac{f(z+\Delta z)-f(z)}{\Delta z}=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta $$ 

即

 $$ f^{\prime}(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta $$ 

由数学归纳法并应用上述证 n=1 的情形类似的方法即可证得(2.3.5)式.

例2 计算 $ \oint_{l}\frac{e^{z}}{z^{n}}dz,n=0,\pm1,\pm2,\cdots $; l是圆 $ \left|z\right|=1 $.

解 若  $ n \leqslant 0 $，则由柯西定理有  $ \oint_{l} \frac{e^{z}}{z^{n}} dz = 0 $；若 n = 1，则由柯西公式有  $ \oint_{l} \frac{e^{z}}{z} dz = 2\pi i $；若 n > 1，则由（2.3.5）式有

 $$ \oint_{l}\frac{\mathrm{e}^{z}}{z^{n}}\mathrm{d}z=\frac{2\pi\mathrm{i}}{(n-1)!}\left.\frac{\mathrm{d}^{n-1}}{\mathrm{d}z^{n-1}}\mathrm{e}^{z}\right|_{z=0}=\frac{2\pi\mathrm{i}}{(n-1)!} $$ 

（2）柯西型积分和含参量的积分 由上面对于解析函数各阶导数均存在的证明过程我们看到，只要  $ f(z) $ 在 l 上连续，即使 l 不是闭合曲线，上面的证明也成立。因此可以推断，在（闭合或不闭合的）曲线 l 上连续的函数  $ \varphi(\zeta) $ 所构成的积分

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\int_{l}\frac{\varphi(\zeta)}{\zeta-z}\mathrm{d}\zeta   \tag*{(2.3.6)}$$

是不在曲线上的点的一个解析函数. 这样的积分称为柯西型积分.  $ f(z) $ 的导数可以通过在积分号下对 z 求导数得到

<!-- page: 60 -->

$$  f^{\left(p\right)}\left(z\right)=\frac{p!}{2\pi\mathrm{i}}\int_{l}\frac{\varphi\left(\zeta\right)\mathrm{d}\zeta}{\left(\zeta-z\right)^{p+1}}   \tag*{(2.3.7)}$$

对于积分曲线上的 z 点，积分(2.3.6)式在通常意义下不存在。因为积分变数  $ \zeta $ 要通过 z 点。关于这一问题的详细讨论，读者可参考文献[3]第四章 §3.7。

利用柯西型积分，就可以推导出含参量积分的解析性.

定理 2.2 设  $ f(t,z) $ 是 t 和 z 的连续函数， $ a \leqslant t \leqslant b, z \in \bar{\sigma} = \sigma + l $；对于  $ [a, b] $ 中的任何 t 值， $ f(t,z) $ 是  $ \bar{\sigma} $ 中的单值解析函数，则含参量的定积分所表示的函数

 $$ F(z)=\int_{a}^{b}f(t,z)\mathrm{d}t $$ 

是 $ \sigma $内的解析函数，而且

$$  F^{\prime}(z)=\int_{a}^{b}\frac{\partial f(t,z)}{\partial z}\mathrm{d}t   \tag*{(2.3.8)}$$

证 因为  $ f(z) $ 在  $ \bar{\sigma} $ 上解析，故对于  $ z \in \sigma $ 由柯西公式有

 $$ f(t,z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(t,\zeta)}{\zeta-z}\mathrm{d}\zeta $$ 

代入  $ F(z) $，并交换积分次序[因为  $ f(t,z) $ 连续]，得

 $$ F(z)=\frac{1}{2\pi\mathrm{i}}\int_{a}^{b}\mathrm{d}t\oint_{l}\frac{f(t,\zeta)}{\zeta-z}\mathrm{d}\zeta=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{1}{z-\zeta}\Big[\int_{a}^{b}f(t,\zeta)\mathrm{d}t\Big]\mathrm{d}\zeta $$ 

这是一个柯西型积分，由于  $ \int_{a}^{b}f(t,\zeta)dt $ 连续，故  $ F(z) $ 为  $ \sigma $ 内的解析函数，且

 $$ \begin{align*}F^{\prime}(z)&=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{1}{(\zeta-z)^{2}}\bigg[\int_{a}^{b}f(t,\zeta)\mathrm{d}t\bigg]\mathrm{d}\zeta\\&=\int_{a}^{b}\bigg[\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(t,\zeta)}{(\zeta-z)^{2}}\mathrm{d}\zeta\bigg]\mathrm{d}t=\int_{a}^{b}\frac{\partial f(t,z)}{\partial z}\mathrm{d}t\end{align*} $$ 

[以上结论也适用复变数 t 的积分  $ F(z)=\int_{t}f(t,z)dt $ 和无穷积分  $ F(z)=\int_{0}^{\infty}f(t,z)dt $ （要求  $ \int_{0}^{\infty}f(t,z)dt $ 在  $ \bar{\sigma} $ 中一致收敛）].

（3）柯西不等式 设 l 为以 z 为中心的圆  $ \left|\zeta-z\right|=R $， $ f(z) $ 在  $ \left|\zeta-z\right|<R $ 内解析，在  $ \left|\zeta-z\right|\leq R $ 上连续，且对于  $ \zeta\in l $ 有  $ \left|f(\zeta)\right|\leq M $，则

$$  \mid f^{\left(n\right)}\left(z\right)\mid\leqslant\frac{n!M}{R^{n}}   \tag*{(2.3.9)}$$

证 由(2.3.5)式有

 $$ \begin{align*}|\ f^{(n)}(z)\ |=&\frac{n!}{2\pi}\Big|\oint_{l}\frac{f(\zeta)}{(\zeta-z)^{n+1}}\mathrm{d}\zeta\Big|\leqslant\frac{n!}{2\pi}\oint_{l}\frac{|\ f(\zeta)\ |}{|\ \zeta-z\ |^{n+1}}|\ \mathrm{d}\zeta|\\\leqslant&\frac{n!M2\pi R}{2\pi R^{n+1}}=\frac{n!M}{R^{n}}\end{align*} $$ 

（4）刘维尔(Liouville)定理 设  $ f(z) $ 在复平面上解析，且当  $ z \to \infty $ 时有界： $ \left|f(z)\right| \leqslant $

<!-- page: 61 -->

$ M(M $ 为常数 $ ) $,则  $ f(z) $ 必为常数.

证 以复平面中任意一点 z 为圆心作圆周  $ \left|\zeta-z\right|=R $，则在闭圆  $ \left|\zeta-z\right|\leqslant R $ 中，因为  $ f(z) $ 连续，所以  $ f(z) $ 必有上界  $ M(R) $，且  $ M(R)\leqslant M $。故由柯西不等式 (2.3.9) 有

 $$ \mid f^{\prime}(z)\mid\leqslant\frac{M(R)}{R}\leqslant\frac{M}{R} $$ 

上式的成立应与 R 的取值无关，当  $ R \to \infty $ 有

 $$ \mid f^{\prime}(z)\mid=0 $$ 

即

 $$ f^{\prime}(z)=0 $$ 

所以  $ f(z) $ 必为常数.

（5）模数原理 若  $ f(z) $ 在区域  $ \sigma $ 中解析，在  $ \bar{\sigma} = \sigma + l $ 上连续，则  $ \left|f(z)\right| $ 只能在边界 l 上取得最大值.

证 对于函数 $ [f(z)]^n $ (n为正整数)应用柯西公式有

 $$ [f(z)]^{n}=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{\left[f(\zeta)\right]^{n}}{\zeta-z}\mathrm{d}\zeta $$ 

设  $ M = \max |f(\zeta)| $,  $ d = \min |\zeta - z| $, s 为 l 的全长，则

 $$ \mid\left[f(z)\right]^{n}\mid=\frac{1}{2\pi}\left|\oint\frac{\left[f(\zeta)\right]^{n}}{\zeta-z}\mathrm{d}\zeta\right|\leqslant\frac{M^{n}\bullet s}{2\pi d} $$ 

即

 $$ \mid f(z)\mid\leqslant M\bullet\left(\frac{s}{2\pi d}\right)^{1/n} $$ 

上式对于任意的 n 均应成立. 令  $ n \to \infty $，则因为  $ \lim_{n \to \infty} \left( \frac{s}{2\pi d} \right)^{1/n} = 1 $，所以有

 $$ \mid f(z)\mid\leqslant M $$ 

用更严格的方法可以证明（见参考文献[3]第五章§2.5），只有当 $ f(z) $为常数时，上式中的等号才成立.

（6）中值（平均值）定理 若  $ f(z) $ 在  $ \left|z-a\right|<R $ 内解析，在  $ \left|z-a\right|\leq R $ 上连续，则  $ f(z) $ 在圆心 a 的值等于它在圆周上的算术平均值. 即

$$  f(a)=\frac{1}{2\pi}\int_{0}^{2\pi}f(a+R\mathrm{e}^{\mathrm{i}\varphi})\mathrm{d}\varphi   \tag*{(2.3.10)}$$

证 由柯西公式有

 $$ f(a)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(z)}{z-a}\mathrm{d}z,\quad l\colon\mid z-a\mid=R $$ 

令  $ z-a=Re^{\mathrm{i}\varphi} $，则  $ \mathrm{d}z=\mathrm{i}Re^{\mathrm{i}\varphi}\mathrm{d}\varphi $，代入上式即得（2.3.10）式.

（7）摩勒纳(Morera)定理 设  $ f(z) $ 在区域  $ \sigma $ 内连续，且对  $ \sigma $ 内任意围线 l，都有  $ \oint_{l} f(z) dz = 0 $，则  $ f(z) $ 在  $ \sigma $ 内解析.

<!-- page: 62 -->

证 因为在  $ \sigma $ 内  $ f(z) $ 连续，且  $ \oint_{l} f(z) dz = 0 $，故根据上一节中的注释知， $ F(z) = \int_{z_0}^{z} f(\zeta) \, \mathrm{d}\zeta $ 在  $ \sigma $ 内解析，且  $ F'(z) = f(z) (z \in \sigma) $。又由本节关于解析函数任意阶导数的推论知  $ F''(z) = f'(z) (z \in \sigma) $ 存在，所以  $ f(z) $ 在  $ \sigma $ 内解析。

#### 习题2.3

1. 计算下列积分，其中 l 均为 |z| = 2.

(1)  $ \oint_{l} \frac{2z^{2}-z+1}{z-1} dz $; (2)  $ \oint_{l} \frac{\sin \frac{\pi}{4}z}{z^{2}-1} dz $; (3)  $ \oint_{l} \frac{z+2}{(z+1)z} dz $; (4)  $ \oint_{l} \frac{1}{z^{4}-1} dz $.

2. 计算积分  $ \int_{l}\frac{dz}{z^{2}+9} $，其中围道 l.

（1）包围3i，不包围-3i；（2）包围-3i，不包围3i；（3）包围 $ \pm3i $

3. 计算下列积分：

(1)  $ \oint_{l} \frac{\cos\pi z}{(z-1)^5} dz $; (2)  $ \oint_{l} \frac{e^z}{(z^2+1)^2} dz $; (3)  $ \oint_{l} \frac{z-\sin z}{z^6} dz $; (4)  $ \oint_{l} \frac{2z^2-z+1}{(z-1)^3} dz $.

其中  $ l: |z| = a, a > 1 $.

4. 已知  $ f(z)=\oint_{l}\frac{3\xi^{2}+7\xi+1}{\xi-z}d\xi $, l 为圆  $ \left|\xi\right|=3 $, 求  $ f'(1+i) $.

5. 求积分  $ \oint_{l} \frac{\mathrm{e}^{z}}{z} \mathrm{d}z (l: |z| = 1) $，从而证明

 $$ \int_{0}^{\pi}\mathrm{e}^{\cos\theta}\cos(\sin\theta)\mathrm{d}\theta=\pi $$ 

6. 计算积分 $ \frac{1}{2\pi i}\oint_{l}\frac{e^{z}}{z(1-z)^{3}}dz $，若

(1) z=0 在 l 内，z=1 在 l 外； (2) z=1 在 l 内，z=0 在 l 外； (3) z=0、z=1 均在 l 内.

7. 证明

 $$ \int_{0}^{2\pi}e^{\rho\cos\varphi}\cos(\rho\sin\varphi-n\varphi)d\varphi=\frac{2\pi\rho^{n}}{n!}(n 为自然数 ) $$ 

8. 证明：若  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $ 是上半平面的解析函数，且当  $ z\to\infty $ 时  $ f(z) $ 一致趋于零，则在上半平面中有

 $$ u(x,y)=\frac{y}{\pi}\int_{-\infty}^{\infty}\frac{u(\xi,0)}{(\xi-x)^{2}+y^{2}}\mathrm{d}\xi $$ 

 $$ v(x,y)=\frac{y}{\pi}\int_{-\infty}^{\infty}\frac{v(\xi,0)}{(\xi-x)^{2}+y^{2}}\mathrm{d}\xi $$ 

9. 设  $ u(t,x)=\frac{1}{\sqrt{1-2xt+t^{2}}} $，t 是复数，试证  $ \frac{\partial^{n}u(t,x)}{\partial t^{n}}\mid_{t=0}=\frac{1}{2^{n}}\frac{\mathrm{d}^{n}}{\mathrm{d}x^{n}}(x^{2}-1)^{n} $.

10. 设  $ u(x,t)=\mathrm{e}^{2tx-t^{2}} $, t 是复数，试证  $ \left.\frac{\partial^{n}u(x,t)}{\partial t^{n}}\right|_{t=0}=(-1)^{n}\mathrm{e}^{x^{2}}\frac{\mathrm{d}^{n}}{\mathrm{d}x^{n}}\mathrm{e}^{-x^{2}} $

<!-- page: 63 -->

本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>一、若  $ f(z) $ 在区域  $ \sigma $ 内解析,  $ \bar{\sigma}=\sigma+L $ 上连续,则\n $ \oint_{L}f(z)\mathrm{d}z=0 $,  $ L=l $\n $ \oint_{L}f(z)\mathrm{d}z=\sum_{k=1}^{n}\oint_{L_{k}}f(z)\mathrm{d}z $,  $ L=l+\sum_{k=1}^{n}l_{k} $\n $ \left\{\begin{array}{l}f(z)=\frac{1}{2\pi i}\oint_{L}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta,\\f(z)=\frac{1}{2\pi i}\left[\oint_{L}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta-\sum_{k=1}^{n}\oint_{L_{k}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta\right],L=l+\sum_{k=1}^{n}l_{k}\end{array}\right. $\n $ \left\{\begin{array}{l}f^{(n)}(z)=\frac{n!}{2\pi i}\oint_{L}\frac{f(\zeta)}{(\zeta-z)^{n+1}}\mathrm{d}\zeta\\模数原理: |f(z)| \leqslant M(M=\max|f(\zeta)|)\end{array}\right. $\n平均值定理:  $ f(a)=\frac{1}{2\pi}\int_{0}^{2\pi}f(a+R e^{i\varphi})\mathrm{d}\varphi $\n $ \left\{\begin{array}{l}(\bar{\sigma}: |z-a| \leqslant R)\\\mathrm{二} \cdot \left|\int_{L}f(z)\mathrm{d}z\right| \leqslant\int_{L}\left|f(z)\right| \cdot \mathrm{d}z $\n $ \left\{\begin{array}{l}M \cdot S\end{array}\right.\end{array}\right. $\n可用来估计积分之值.</td></tr></table>

<!-- page: 64 -->

级数也是研究解析函数的一个重要工具。我们将看到，一个函数的解析性与一个函数可否展开成幂级数的问题是等价的。这从另一个侧面提示了解析函数的本质，因此我们可以进一步地认识解析函数。

本章将讨论解析函数表示为幂级数的问题，对于某些和数学分析中平行的结论，往往叙述而不证明。

### 3.1 复级数

## 1. 复数项级数

每项均为复数的无穷级数

$$  f_{1}+f_{2}+\cdots+f_{k}+\cdots=\sum_{k=1}^{\infty}f_{k}   \tag*{(3.1.1)}$$

称为复数项级数，若它的部分和

$$  F_{n}=f_{1}+\cdots+f_{n},\quad n=1,2,\cdots   \tag*{(3.1.2)}$$

所构成的序列 $ \{F_{n}\} $收敛，即

 $$ \lim_{n\to\infty}F_{n}=F $$ 

有限，则称级数 $ \sum_{k=1}^{\infty}f_{k} $收敛于F，而称F为级数(3.1.1)的和；否则级数称为是发散的.

令  $ f_{k}=u_{k}+\mathrm{i}v_{k}, F=u+\mathrm{i}v $，则由  $ \lim_{n\to\infty}F_{n}=F $，有

 $$ \lim_{n\to\infty}[(u_{1}+\mathrm{i}v_{1})+(u_{2}+\mathrm{i}v_{2})+\cdots+(u_{n}+\mathrm{i}v_{n})]=u+\mathrm{i}v $$ 

即

 $$ \begin{aligned}&\lim_{n\to\infty}(u_{1}+u_{2}+\cdots+u_{n})=u\\&\lim_{n\to\infty}(v_{1}+v_{2}+\cdots+v_{n})=v\end{aligned} $$ 

由此可见，如果复级数  $ \sum_{k=1}^{\infty}f_{k} $ 收敛，则实级数  $ \sum_{k=1}^{\infty}u_{k} $ 和  $ \sum_{k=1}^{\infty}v_{k} $ 必分别收敛。反过来，如果  $ \sum_{k=1}^{\infty}u_{k} $ 和  $ \sum_{k=1}^{\infty}v_{k} $ 都收敛，则  $ \sum_{k=1}^{\infty}f_{k} $ 也收敛。这样，复级数的研究就归结为对实级数的研究。有关实数级数收敛问题的定理和性质在复数级数中仍然成立；有关实级数中绝对

<!-- page: 65 -->

收敛和一致收敛的概念、性质也可以推广到复数级数中来.

类似于实数级数，级数(3.1.1)式有收敛的充要条件——柯西收敛判据：任意给定 $ \varepsilon>0 $，存在正整数N，使当 $ n\geq N $时，有

$$  |F_{n+p}-F_{n}|=|f_{n+1}+f_{n+2}+\cdots+f_{n+p}|<\varepsilon,\quad p=1,2,\cdots   \tag*{(3.1.3)}$$

由(3.1.3)式，令 p=1，可得级数(3.1.1)式收敛的必要条件是

$$  \lim_{k\to\infty}f_{k}=0   \tag*{(3.1.4)}$$

如果  $ \sum_{k=1}^{\infty}|f_{k}| $ 收敛，则称  $ \sum_{k=1}^{\infty}f_{k} $ 绝对收敛。绝对收敛的级数必定是收敛的，因为  $ \left|f_{k+1}+f_{k+2}+\cdots+f_{k+p}\right|\leqslant\left|f_{k+1}\right|+\left|f_{k+2}\right|+\cdots+\left|f_{k+p}\right| $

绝对收敛的级数具有如下的主要性质和判别法：

（1）绝对收敛的级数，可任意交换其各项的次序，所得级数仍绝对收敛且其和不变.

（2）两个绝对收敛的级数可逐项相乘，所得级数仍绝对收敛.

（3）比值[或达朗贝尔(d'Alembert)]判别法 对于  $ \sum_{k=1}^{\infty} f_{k} $，若  $ \left|\frac{f_{k+1}}{f_{k}}\right| < \rho (\rho < 1 $ 且与 k 无关)，则级数  $ \sum_{k=1}^{\infty} f_{k} $ 绝对收敛。特别是，如果

$$  \lim_{k\to\infty}\left|\frac{f_{k+1}}{f_{k}}\right|=l   \tag*{(3.1.5)}$$

则当 l<1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 绝对收敛；当 l>1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 发散；当 l=1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 的敛散性需进一步检验.

（4）根式（或柯西）判别法 对于  $ \sum_{k=1}^{\infty} f_{k} $，若

$$  \lim_{k\to\infty}\sqrt[k]{\lceil f_{k}\rceil}=r   \tag*{(3.1.6)}$$

则当 r<1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 绝对收敛；当 r>1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 发散；当 r=1 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 的敛散性需进一步检验.

（5）高斯(Gauss)判别法 $ ^{①} $ 对于  $ \sum_{k=1}^{\infty}f_{k} $，设

$$  \frac{f_{k}}{f_{k+1}}=1+\frac{\mu}{k}+O\big(\frac{1}{k^{\lambda}}\big),\quad\lambda>1   \tag*{(3.1.7)}$$

则当  $ \mathrm{Re}\mu>1 $ 时，级数  $ \sum_{k=1}^{\infty}f_{k} $ 绝对收敛；当  $ \mathrm{Re}\mu\leqslant1 $ 时， $ \sum_{k=1}^{\infty}\left|f_{k}\right| $ 发散。式中  $ O\left(\frac{1}{k^{\lambda}}\right) $ 是量级的符号，表示数量级比  $ \frac{1}{k^{\lambda}} $ 更高的无穷小量， $ \mu $ 为复数。

<!-- page: 66 -->

## 2. 复变函数项级数

对于每项均为复变函数的复变函数项级数

$$  f_{1}(z)+\cdots+f_{k}(z)+\cdots=\sum_{k=1}^{\infty}f_{k}(z)   \tag*{(3.1.8)}$$

如果在区域  $ \sigma $ 上有一个函数  $ F(z) $，对任意给定的  $ \varepsilon > 0 $，存在与 z 无关的正整数 N，使当 n > N 时，对一切的  $ z \in \sigma $，均满足

$$  |F(z)-F_{n}(z)|<\varepsilon   \tag*{(3.1.9)}$$

则称级数(3.1.8)式在 $ \sigma $上一致收敛于 $ F(z) $.其中

$$  F_{n}(z)=\sum_{k=1}^{n}f_{k}(z)   \tag*{(3.1.10)}$$

级数(3.1.8)式在 $ \sigma $上一致收敛的充分必要条件是柯西一致收敛判据:任意给定 $ \varepsilon>0 $,存在与z无关的正整数N,使当 $ n>N $时,对一切 $ z\in\sigma $,均有

$$  f_{n+1}(z)+f_{n+2}(z)+\cdots+f_{n+p}(z)|<\varepsilon,\quad p=1,2,\cdots   \tag*{(3.1.11)}$$

一致收敛的级数具有如下的主要性质和判别法：

（1）连续性 若  $ f_{k}(z)(k=1,2,3,\cdots) $ 在区域  $ \sigma $ 内连续， $ \sum_{k=1}f_{k}(z) $ 在  $ \sigma $ 内一致收敛于  $ F(z) $，则和函数  $ F(z) $ 亦在  $ \sigma $ 内连续.

（2）逐项可积性 若  $ f_{k}(z)(k=1,2,3,\cdots) $ 在曲线 l 上连续，且  $ \sum_{k=1}^{\infty}f_{k}(z) $ 在曲线 l 上一致收敛于  $ F(z) $，则  $ \sum_{k=1}^{\infty}f_{k}(z) $ 沿 l 可以逐项积分，且

$$  \int_{l}F(z)\mathrm{d}z=\sum_{k=1}^{\infty}\int_{l}f_{k}(z)\mathrm{d}z   \tag*{(3.1.12)}$$

（3）逐项可导性——魏尔斯特拉斯(Weierstrass)定理 $ ^{②} $ 若级数 $ \sum_{k=1}^{n}f_{k}(z) $的各项均在区域 $ \sigma $内解析，且 $ \sum_{k=1}^{\infty}f_{k}(z) $在 $ \sigma $内的任一闭子域 $ \bar{\sigma}^{\prime} $上一致收敛于 $ F(z) $，则

 $ 1^{\circ}F(z)=\sum_{k=1}^{\infty}f_{k}(z) $ 在  $ \sigma $ 内解析；

 $ 2^{\circ} $ 在  $ \sigma $ 内级数可逐项求导至任意阶，且

$$  F^{\left(n\right)}\left(z\right)=\sum_{k=1}^{\infty}f_{k}^{\left(n\right)}\left(z\right)   \tag*{(3.1.13)}$$

（4）M判别法 若在区域  $ \sigma $ 内  $ \left|f_{k}(z)\right|\leqslant M_{k}(k=1,2,3,\cdots) $， $ M_{k} $ 是与 z 无关的正数，且  $ \sum_{k=1}^{\infty}M_{k} $ 收敛，则  $ \sum_{k=1}^{\infty}f_{k}(z) $ 在  $ \sigma $ 内绝对而且一致收敛.

注 ① 高斯判别法的证明见二维码.

②魏尔斯特拉斯定理的证明见二维码.

<div style="text-align: center;"><img src="images/p0066_img_in_image_box_523_1178_588_1241.jpg" alt="Image" width="6%" /></div>


高斯判别法的证明

<div style="text-align: center;"><img src="images/p0066_img_in_image_box_721_1178_785_1242.jpg" alt="Image" width="6%" /></div>


魏尔斯特拉斯定理的证明

<!-- page: 67 -->

### 3.2 幂级数

各项由幂函数组成的无穷级数，如

$$  \sum_{k=0}^{\infty}a_{k}(z-b)^{k}=a_{0}+a_{1}(z-b)+\cdots+a_{k}(z-b)^{k}+\cdots   \tag*{(3.2.1)}$$

称为以 b 为中心的幂级数. 其中  $ a_{0}, a_{1}, \cdots, a_{k}, \cdots $ 及 b 都是复常数.

## 1. 幂级数的收敛性

为了研究幂级数的收敛性，我们先引入如下的定理和推论：

阿贝尔(Abel)定理 若级数(3.2.1)在某点  $ z=z_{0} $ 收敛，则它在以 b 为圆心，以  $ \left|z_{0}-b\right| $ 为半径的圆内绝对收敛，而且在任何一个较小的闭圆  $ \left|z-b\right|\leqslant\rho\left(\rho<|z_{0}-b|\right) $ 上一致收敛.

证 由于级数(3.2.1)在 $ z_{0} $点收敛，故由(3.1.4)式有

 $$ \lim_{k\to\infty}a_{k}(z_{0}-b)^{k}=0 $$ 

所以存在一正数 h 使

 $$ |a_{k}(z_{0}-b)^{k}|<h,\quad k=0,1,2,\cdots $$ 

又

 $$ \begin{aligned}\mid a_{k}(z-b)^{k}\mid&=\left|a_{k}(z_{0}-b)^{k}\bullet\left(\frac{z-b}{z_{0}-b}\right)^{k}\right|\\&=\mid a_{k}(z_{0}-b)^{k}\mid\bullet\left|\frac{z-b}{z_{0}-b}\right|^{k}<h\frac{\rho^{k}}{\mid z_{0}-b\mid^{k}}\end{aligned} $$ 

而 $ \sum_{k=0}^{\infty}\frac{\rho^{k}}{|z_{0}-b|^{k}} $ 是一个收敛的常数项几何级数（因为 $ \frac{\rho}{|z_{0}-b|<1} $），由M判别法知，级数（3.2.1）式在 $ \left|z-b\right|\leqslant\rho(\rho<|z_{0}-b|) $中绝对而且一致收敛.

推论 3.1 若级数(3.2.1)式在某点  $ z=z_{1} $ 发散，则它在圆  $ \left|z-b\right|=\left|z_{1}-b\right| $ 的外面处处发散.

证 利用反证法，如果级数(3.2.1)式在圆 $ \left|z-b\right|=\left|z_{1}-b\right| $外的一点 $ z=z_{2} $收敛，则由阿贝尔定理级数将在圆 $ \left|z-b\right|=\left|z_{2}-b\right| $内收敛，这与题设级数在 $ z_{1} $点发散相矛盾.

## 2. 收敛圆及收敛圆半径

由阿贝尔定理及推论3.1不难看出，幂级数的收敛区域和发散区域是不可能相间的。因此，对于幂级数(3.2.1)式，必存在一以b为心， $ R(0 \leq R < \infty) $为半径的圆，在圆内级数绝对收敛（而且在较小的闭圆内一致收敛），而在圆外级数发散。这个圆称为该幂级数的收敛圆，而R称为它的收敛半径。

<!-- page: 68 -->

对于幂级数(3.2.1)式，由比值判别法易得到求它的收敛半径的公式. 因为

 $$ \lim_{k\to\infty}\left|\frac{f_{k+1}}{f_{k}}\right|=\lim_{k\to\infty}\left|\frac{a_{k+1}}{a_{k}}\right|\bullet\frac{\mid z-b\mid^{k+1}}{\mid z-b\mid^{k}}=\lim_{k\to\infty}\left|\frac{a_{k+1}}{a_{k}}\right|\bullet\mid z-b\mid $$ 

故

当 $ \lim_{k\to\infty}\left|\frac{a_{k+1}}{a_k}\right|\cdot|z-b|<1 $，即当 $ |z-b|<\lim_{k\to\infty}\left|\frac{a_k}{a_{k+1}}\right| $时，级数绝对收敛；

当 $ \lim_{k\to\infty}\left|\frac{a_{k+1}}{a_k}\right|\cdot|z-b|>1 $，即当 $ |z-b|>\lim_{k\to\infty}\left|\frac{a_k}{a_{k+1}}\right| $时，级数发散.

$$  R=\lim_{k\to\infty}\left|\frac{a_{k}}{a_{k+1}}\right|   \tag*{(3.2.2)}$$

例1 求级数  $ \sum_{k=0}^{\infty}z^{k} $， $ \sum_{k=1}^{\infty}\frac{z^{k}}{k} $， $ \sum_{k=1}^{\infty}\frac{z^{k}}{k^{2}} $ 的收敛半径，并讨论它们在收敛圆周上的敛散性.

解 由于对于这三个级数，均有 $ \lim_{k\to\infty}\left|\frac{a_k}{a_{k+1}}\right|=1 $，所以它们的收敛半径均为1。但在收敛圆周上它们的敛散性却各不一样：

 $ \sum_{k=0}^{\infty}z^{k} $，在 $ \mid z\mid=1 $上，由于一般项不趋于0，故处处发散.

 $ \sum_{k=1}^{\infty}\frac{z^{k}}{k} $，在z=1点，是调和级数，所以发散；在z=-1点，是交错级数，所以收敛.

 $ \sum_{k=1}^{\infty}\left|\frac{z^{k}}{k^{2}}\right| $，在 $ \left|z\right|=1 $上，是一p级数，所以 $ \sum_{k=1}^{\infty}\frac{z^{k}}{k^{2}} $处处绝对收敛，因而也处处收敛.

由复级数的根值判别法(3.1.6)式我们还可以得到求幂级数(3.2.1)式的收敛半径的另一公式

$$  R=\lim_{k\to\infty}\frac{1}{\sqrt[k]{\left|a_{k}\right|}}   \tag*{(3.2.3)}$$

例2 求级数  $ \sum_{n=0}^{\infty}\frac{1}{2^{2n}}z^{2n} $ 的收敛半径.

解  $ R=\frac{1}{\lim\limits_{n\to\infty}\left|\frac{1}{2^{2n}}\right|^{\frac{1}{2n}}}=2. $

## 3. 性质

由于幂级数(3.2.1)式的每一项 $ a_{k}(z-b)^{k} $都是z的解析函数，而且在其收敛圆内的任何一个闭区域内(3.2.1)式一致收敛，故由魏尔斯特拉斯定理知其和函数 $ f(z)=\sum_{k=0}^{\infty}a_{k}(z-b)^{k} $是收敛圆内的一个解析函数且可逐项求导至任意阶；由于幂级

<!-- page: 69 -->

数在收敛圆内绝对收敛，故具有绝对收敛级数所具有的一些性质（如可逐项相乘等）；由于幂级数在比收敛圆稍小的闭圆上一致收敛，故具有一致收敛的级数所具有的性质（如逐项积分等）。易于证明，通过逐项微分或积分后所得到的幂级数的收敛半径与原来级数的收敛半径相同。

#### 习题3.2

1. 确定下列级数的收敛半径：

(1)  $ \sum_{k=0}^{\infty}\frac{z^k}{k!} $; (2)  $ \sum_{k=1}^{\infty}\frac{k}{2^k}z^k $; (3)  $ \sum_{k=1}^{\infty}\frac{k!}{k^k}z^k $;

(4)  $ \sum_{k=0}^{\infty}(k+a^k)z^k $; (5)  $ \sum_{k=1}^{\infty}[2+(-1)^k]z^k $.

2.  $ \sum_{k=1}^{\infty}a_{k}z^{k} $ 的收敛半径为  $ R(0\leqslant R<\infty) $，确定下列级数的收敛半径：

(1)  $ \sum_{k=0}^{\infty}k^{n}a_{k}z^{k} $; (2)  $ \sum_{k=1}^{\infty}k^{k}a_{k}z^{k} $; (3)  $ \sum_{k=0}^{\infty}a_{k}^{n}z^{k} $.

3. 讨论幂级数在收敛圆周上的敛、散性：

(1)  $ \sum_{k=1}^{\infty}\frac{(-1)^k}{k}z^k $; (2)  $ \sum_{k=1}^{\infty}\frac{z^k!}{k^2} $.

4. 判断下列级数的收敛性及绝对收敛性：

(1)  $ \sum_{k=1}^{\infty} \frac{i^k}{\ln k} $; (2)  $ \sum_{k=1}^{\infty} \frac{i^k}{k} $.

### 3.3 泰勒级数

在上节曾提到，幂级数在其收敛圆内，代表一解析函数。反之，我们自然要问，解析函数是否能展开成一个幂级数？为此，我们学习泰勒（Taylor）展开定理。

## 1. 泰勒定理

设  $ f(z) $ 在圆域  $ \left|z-b\right|<R $ 内解析，则  $ f(z) $ 在该圆域内可展开为幂级数

$$  f(z)=\sum_{k=0}^{\infty}a_{k}(z-b)^{k}   \tag*{(3.3.1)}$$

称为泰勒级数（或泰勒展式）。其中系数

$$  a_{k}=\frac{1}{k!}f^{\left(k\right)}\left(b\right),\quad k=0,1,2,\cdots   \tag*{(3.3.2)}$$

称为泰勒系数. 且此展开是唯一的.

证 设 z 为圆  $ \left|z-b\right|=R $ 内的任一取定的点，则总有一个圆 l： $ \left|\zeta-b\right|=\rho(0<\rho<R) $，使 z 含在 l 内（见图 3.1）。由柯西公式有

<div style="text-align: center;"><img src="images/p0069_img_in_image_box_732_1059_859_1186.jpg" alt="图3.1" width="13%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图3.1</div> </div>

<!-- page: 70 -->

$$ f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta $$ 

其中  $ \zeta $ 是 l 上的变点. 利用几何级数恒等式

 $$ \frac{1}{1-q}=\sum_{k=0}^{\infty}q^{k},\quad\mid q\mid<1 $$ 

可将 $ \frac{1}{\zeta-z} $写成

 $$ \begin{aligned}\frac{1}{\zeta-z}=&\frac{1}{(\zeta-b)-(z-b)}=\frac{1}{\zeta-b}\frac{1}{1-\frac{z-b}{\zeta-b}}\\=&\frac{1}{\zeta-b}\sum_{k=0}^{\infty}\left(\frac{z-b}{\zeta-b}\right)^{k}\left(\because\left|\frac{z-b}{\zeta-b}\right|<1\right)\end{aligned} $$ 

级数  $ \sum_{k=0}^{\infty}\left(\frac{z-b}{\zeta-b}\right)^{k} $ 在 l 上是一致收敛的。所以乘上 l 上的有界函数  $ \frac{f(\zeta)}{\zeta-b} $ 后，仍在 l 上一致收敛，即

 $$ \frac{f(\zeta)}{\zeta-z}=\frac{f(\zeta)}{\zeta-b}\sum_{k=0}^{\infty}\left(\frac{z-b}{\zeta-b}\right)^{k}=\sum_{k=0}^{\infty}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\bullet(z-b)^{k} $$ 

在 l 上一致收敛. 故可在 l 上对它采用逐项积分, 而得

 $$ f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=\sum_{k=0}^{\infty}\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)\mathrm{d}\zeta}{(\zeta-b)^{k+1}}\bullet(z-b)^{k}=\sum_{k=0}^{\infty}a_{k}(z-b)^{k} $$ 

其中

$$  a_{k}=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)\mathrm{d}\zeta}{(\zeta-b)^{k+1}}   \tag*{(3.3.3)}$$

又由(2.3.5)式有

 $$ \frac{1}{2\pi i}\oint_{l}\frac{f(\zeta)\mathrm{d}\zeta}{(\zeta-b)^{k+1}}=\frac{f^{(k)}(b)}{k!} $$ 

故有

 $$ a_{k}=\frac{f^{\left(k\right)}\left(b\right)}{k!} $$ 

定理中的(3.3.1)和(3.3.2)式已得证. 现在证明此展开是唯一的，即在 b 的邻域  $ \left|z-b\right|<R $ 内， $ f(z) $ 的泰勒展开系数  $ a_{k} $ 是完全确定的. 为了证明这一点，设有两个泰勒级数代表同一个解析函数

 $$ \begin{aligned}f(z)=&a_{0}+a_{1}(z-b)+\cdots+a_{k}(z-b)^{k}+\cdots\\=&a_{0}^{\prime}+a_{1}^{\prime}(z-b)+\cdots+a_{k}^{\prime}(z-b)^{k}+\cdots\end{aligned} $$ 

令z=b，则有

 $$ a_{0}=a_{0}^{\prime}=f(b) $$ 

对(3.3.4)式求导，有

 $$ \begin{aligned}f^{\prime}(z)=&a_{1}+2a_{2}(z-b)+\cdots+ka_{k}(z-b)^{k-1}+\cdots\\=&a_{1}^{\prime}+2a_{2}^{\prime}(z-b)+\cdots+ka_{k}^{\prime}(z-b)^{k-1}+\cdots\end{aligned} $$ 

又令 z=b，得

<!-- page: 71 -->

$$ a_{1}=a_{1}^{\prime}=f^{\prime}(b) $$ 

仿此做下去，即可证明对于所有的  $ k(k=0,1,2,\cdots) $ 均有  $ a_{k}=a_{k}^{\prime} $，因此展开是唯一的.

## 2. 收敛范围

泰勒级数的收敛半径，当然可由幂级数的收敛半径公式(3.2.2)和(3.2.3)来求。用下面的方法，来确定泰勒级数的收敛范围，常常更为方便：

设 a 是  $ f(z) $ 的离开中心 b 最近的奇点，则  $ f(z) $ 的泰勒展开的收敛半径为

$$  \boldsymbol{R}=|\begin{array}{l}a-b\end{array}|   \tag*{(3.3.5)}$$

因为在圆  $ \left|z-b\right|=\left|a-b\right| $ 内， $ f(z) $ 处处解析，因此  $ f(z) $ 的泰勒展开 (3.3.1) 式的收敛半径不小于  $ \left|b-a\right| $；而 a 又是  $ f(z) $ 的奇点，故它的泰勒展开的收敛半径也不会大于  $ \left|a-b\right| $，因此收敛半径  $ R=\left|a-b\right| $。

## 3. 展开的方法

我们当然可以直接用泰勒展开定理将函数展开为泰勒级数.

例1 函数  $ f(z)=\mathrm{e}^{z} $，在复平面解析，故在复平面内任一点均可展开成泰勒级数，且由于  $ \infty $ 是它的奇点，故这些级数的收敛半径都是  $ \infty $。在 z=0 处， $ e^{z} $ 的泰勒系数为

 $$ \frac{1}{k!}\frac{\mathrm{d}^{k}}{\mathrm{d}z^{k}}\mathrm{e}^{z}\bigg|_{z=0}=\frac{1}{k!},\quad k=0,1,2,\cdots $$ 

于是  $ e^{z} $ 在 z=0 的泰勒展开为

$$  \mathrm{e}^{z}=1+z+\frac{z^{2}}{2!}+\cdots+\frac{z^{k}}{k!}+\cdots,\quad\mid z\mid<\infty   \tag*{(3.3.6)}$$

例2 函数 $ \frac{1}{1-z} $在z=0的邻域内是解析的，其唯一的奇点z=1，与z=0点的距离是1，在z=0点的k阶导数易算出为k！ $ (k=0,1,2,\cdots) $，故有

$$  \frac{1}{1-z}=1+z+z^{2}+\cdots+z^{k}+\cdots,\quad\mid z\mid<1   \tag*{(3.3.7)}$$

既然泰勒展开是唯一的，故我们当然可以用任何方便的办法来求一个函数的泰勒展开，而不一定要用（3.3.2）式去确定泰勒展开的系数了（从而可避免求导的麻烦）。我们常常借助于一些已知的级数展开式，通过种种手段来实现函数的泰勒展开。

例3 求  $ f(z)=\sin z $ 和  $ f(z)=\cos z $ 在 z=0 点的泰勒展开.

解 由正弦函数的定义和(3.3.6)式我们有

 $$ \sin z=\frac{\mathrm{e}^{\mathrm{i}z}-\mathrm{e}^{-\mathrm{i}z}}{2\mathrm{i}}=\frac{\sum\limits_{k=0}^{\infty}\frac{(\mathrm{i}z)^{k}}{k!}-\sum\limits_{k=0}^{\infty}\frac{(-\mathrm{i}z)^{k}}{k!}}{2\mathrm{i}} $$ 

所以

$$  \sin z=\sum_{k=0}^{\infty}\frac{(-1)^{k}z^{2k+1}}{(2k+1)!},\quad\mid z\mid<\infty   \tag*{(3.3.8)}$$

<!-- page: 72 -->

同样可得

$$  \cos z=\sum_{k=0}^{\infty}\frac{(-1)^{k}z^{2k}}{(2k)!},\quad\mid z\mid<\infty   \tag*{(3.3.9)}$$

(3.3.6)~(3.3.9)式应作为公式记住，以后经常会用到.

例4 求 $ \frac{1}{1-z^{2}} $在z=0的邻域内的泰勒展开.

解 可通过变量代换，再利用(3.3.7)式来展开. 令 $ t=z^{2} $，则

 $$ \frac{1}{1-z^{2}}=\frac{1}{1-t}=1+t+t^{2}+\cdots+t^{k}+\cdots,\quad\mid t\mid<1 $$ 

即

 $$ \frac{1}{1-z^{2}}=1+z^{2}+z^{4}+\cdots+z^{2k}+\cdots,\quad\mid z\mid<1 $$ 

也可以通过分项分式，再利用(3.3.7)式来展开

 $$ \begin{aligned}\frac{1}{1-z^{2}}=&\frac{1}{2}\Big(\frac{1}{1-z}+\frac{1}{1+z}\Big)\\=&\frac{1}{2}(1+z+z^{2}+z^{3}+\cdots)+\frac{1}{2}(1-z+z^{2}-z^{3}+\cdots)\\=&1+z^{2}+z^{4}+\cdots+z^{2k}+\cdots,\quad\mid z\mid<1\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0072_img_in_image_box_93_662_353_909.jpg" alt="图3.2" width="27%" /></div>


还可以用级数的乘法和(3.3.7)式来展开

 $$ \frac{1}{1-z^{2}}=\frac{1}{1-z}\bullet\frac{1}{1+z}=\sum_{k=0}^{\infty}z^{k}\bullet\sum_{n=0}^{\infty}(-1)^{n}z^{n} $$ 

<div style="text-align: center;"><div style="text-align: center;">图3.2</div> </div>


这两个级数在 $ |z|<1 $内绝对收敛，故可逐项相乘，如图3.2所示，我们可将乘后各次幂的系数排成对角线形式，则

 $$ \begin{aligned}\frac{1}{1-z^{2}}=&1+(1-1)z+(1-1+1)z^{2}\\&+(1-1+1-1)z^{3}+\cdots\\=&1+z^{2}+z^{4}+\cdots\end{aligned} $$ 

#### 习题3.3

1. 将下列函数在 z=0 点展开成幂级数，并指出其收敛范围：

(1) $ \frac{1}{(1-z)^{2}}; $ (2) $ \frac{1}{az+b} $ (a,b为复数, $ b\neq0 $); (3) $ e^{\frac{1}{1-z}}; $

(4)  $ \arctan z $; (5)  $ \frac{1}{1+z+z^{2}} $; (6)  $ \frac{\sin z}{1-z} $.

2. 将下列函数按(z-1)的幂展开，并指明其收敛范围：

(1)

(2)

 $$ \cos z； $$ 

 $$ \frac{z^{2}}{(z+1)^{2}}； $$ 

 $$ \frac{z}{z+2}; $$ 

(4)

 $$ \sin(2z-z^{2}) $$

<!-- page: 73 -->

3. 应用泰勒级数求下列积分：

（1）菲涅尔积分  $ s(z)=\int_{0}^{z}\sin z^{2}dz;c(z)=\int_{0}^{z}\cos z^{2}dz; $

（2）误差函数  $ \mathrm{erf}z=\frac{2}{\sqrt{\pi}}\int_{0}^{z}\mathrm{e}^{-\zeta^{2}}\mathrm{d}\zeta; $

（3）积分正弦  $ Siz=\int_{0}^{z}\frac{\sin z}{z}dz. $

4. 对于多值函数而言，在划分出单值分支后，可对各个单值分支像一个单值函数那样作泰勒展开。函数 $ (1+z)^{a} $ 在 a 不等于整数时是多值函数。试证明普遍的二项式定理

$$  (1+z)^{a}=1^{a}\bigg[1+\frac{\alpha}{1!}z+\frac{a(\alpha-1)}{2!}z^{2}+\frac{a(\alpha-1)(\alpha-2)}{3!}z^{3}+\cdots\bigg],\quad\mid z\mid<1   \tag*{(3.3.10)}$$

式中， $ \alpha $ 为任意复数； $ 1^{a}=(\mathrm{e}^{\mathrm{i}2k\pi})^{\alpha}=\mathrm{e}^{\mathrm{i}\alpha2k\pi}(k $ 为整数）.

5. 将  $ \ln(1+z) $ 在 z=0 的邻域内展开为泰勒级数.

6. 如果  $ f(z) $ 在解析区域  $ \sigma $ 内一点 a 的值为零。则称 a 为  $ f(z) $ 的零点。若  $ f(a)=f'(a)=\cdots=f^{(m-1)}(a)=0 $ 但  $ f^{(m)}(a)\neq0(m\geqslant1) $，则称 a 为  $ f(z) $ 的 m 级（阶）零点。试指出下列级数的零点 z=0 是几级（阶）零点。

(1)  $ z^{2}(e^{z^{2}}-1) $; (2)  $ 6\sin z^{3}+z^{3}(z^{6}-6) $.

7. 求和： $ s(z) = \sum_{n=1}^{\infty} z^n n^2 $， $ |z| < 1 $.

(1981年 CUSPEA 试题)

8. 求下列极数的和：

 $$ S=\sum_{n=2}^{\infty}\frac{\mathrm{e}^{\neg n}}{n^{2}-1},\quad t>0 $$ 

（加州理工学院研究生试题）

### 3.4 洛朗级数

由上节我们看出，用泰勒级数来表示圆形区域的解析函数是很方便的。但是，有些函数在我们所需讨论的区域中有奇点，特别是有时我们需讨论奇点邻域函数的性质，此时当然不能将函数表示成泰勒级数，而是另一种展开级数。本节将建立环域 $ r<|z-b|<R(0\leqslant r<R<\infty) $内解析的函数的级数表示——洛朗(Laurent)级数。

我们称具有正、负幂的幂级数

$$  \begin{aligned}\sum_{k=-\infty}^{\infty}C_{k}(z-b)^{k}=&\cdots+C_{-2}(z-b)^{-2}+C_{-1}(z-b)^{-1}\\&+C_{0}+C_{1}(z-b)+C_{2}(z-b)^{2}+\cdots\end{aligned}   \tag*{(3.4.1)}$$

为洛朗级数. 它是泰勒级数的推广.

## 1. 洛朗级数收敛性定理

洛朗级数(3.4.1)式在收敛环域 $ r<|z-b|<R $内的和函数是一解析函数，并在

<!-- page: 74 -->

任意较小的同心闭环域  $ r' \leqslant |z - b| \leqslant R'(r < r' < R' < R) $ 上一致收敛.

证 因为  $ \sum_{k=-\infty}^{\infty}C_{k}(z-b)^{k}=\sum_{k=0}^{\infty}C_{k}(z-b)^{k}+\sum_{k=1}^{\infty}C_{-k}(z-b)^{-k} $. 对于  $ \sum_{k=0}^{\infty}C_{k}(z-b)^{k} $ （称之为洛朗级数的正则部分），这正是 3.2 节中讨论过的幂级数. 设其收敛半径为 R，则在收敛圆的内部，即当  $ |z-b|<R $ 时，它的和函数是一解析函数，且在较小的闭圆  $ |z-b|\leq R'(R'<R) $ 上一致收敛.

对于 $ \sum_{k=1}^{\infty}C_{-k}(z-b)^{-k} $（称为洛朗级数的主要部分），令 $ \zeta=\frac{1}{z-b} $，则 $ \sum_{k=1}^{\infty}C_{-k}(z-b)^{-k}=\sum_{k=1}^{\infty}C_{-k}\zeta^{k} $。这亦是3.2节中讨论过的幂级数。设其收敛半径为 $ \frac{1}{r} $，则在收敛圆内即当 $ |\zeta|<\frac{1}{r} $时， $ \sum_{k=1}^{\infty}C_{-k}\zeta^{k} $的和函数是一解析函数，且在较小的闭圆 $ \left|\zeta\right|\leqslant\frac{1}{r^{\prime}}\left(\frac{1}{r^{\prime}}<\frac{1}{r}\right) $上一致收敛。也就是说， $ \sum_{k=1}^{\infty}C_{-k}(z-b)^{-k} $，当 $ |z-b|>r $时，其和函数是一解析函数，且在较大的闭圆 $ |z-b|\geqslant r^{\prime}>r $上一致收敛。

综上所述，仅当 r<R 时，级数  $ \sum_{k=0}^{\infty}C_{k}(z-b)^{k} $ 和  $ \sum_{k=1}^{\infty}C_{-k}(z-b)^{-k} $ 有共同的收敛区域  $ r<|z-b|<R $ 及共同的一致收敛的闭环域  $ r^{\prime}\leqslant|z-b|\leqslant R^{\prime} $. 故定理得证.

## 2. 洛朗定理

在环域  $ r<|z-b|<R $ 内解析的函数  $ f(z) $ 必可展开成洛朗级数

$$  f(z)=\sum_{k=-\infty}^{\infty}C_{k}(z-b)^{k}   \tag*{(3,4,2)}$$

其中

$$  C_{k}=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta   \tag*{(3.4.3)}$$

称为洛朗展开系数，l为圆周 $ \left|z-b\right|=\rho(r<r^{\prime}<\rho<R^{\prime}<R) $，且此展开是唯一的.

<div style="text-align: center;"><img src="images/p0074_img_in_image_box_98_943_331_1175.jpg" alt="图3.3" width="24%" /></div>


证 设 z 为  $ r<|z-b|<R $ 内的任意一取定的点，则总可作含于  $ r<|z-b|<R $ 内的两个圆

<div style="text-align: center;"><div style="text-align: center;">图3.3</div> </div>


 $$ \begin{aligned}&l_{1}:\mid\zeta-b\mid=R^{\prime},\quad R^{\prime}<R\\&l_{2}:\mid\zeta-b\mid=r^{\prime},\quad r^{\prime}>r\\ \end{aligned} $$ 

使得 z 含在环域  $ r' < |z - b| < R' $ 内（见图 3.3）。因为  $ f(z) $ 在闭环域  $ r' \leq |z - b| \leq R' $ 上解析，则由复通区域的柯西公式 (2.3.3) 式有

$$  f(z)=\frac{1}{2\pi\mathrm{i}}\oint_{l_{1}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta-\frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta   \tag*{(3.4.4)}$$

<!-- page: 75 -->

其中  $ \zeta $ 为  $ l_{1} $ 和  $ l_{2} $ 上的变点.

对于上式的第一个积分，类似于泰勒定理的证明过程，我们立即可得

$$  \frac{1}{2\pi\mathrm{i}}\oint_{l_{1}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=\sum_{k=0}^{\infty}\frac{1}{2\pi\mathrm{i}}\oint_{l_{1}}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta\bullet(z-b)^{k}   \tag*{(3.4.5)}$$

对于(3.4.4)式右边的第二个积分，由于

 $$ \begin{aligned}\frac{1}{\zeta-z}=&\frac{1}{\zeta-b-(z-b)}=-\frac{1}{z-b}\bullet\frac{1}{1-\frac{\zeta-b}{z-b}}\\=&-\frac{1}{z-b}\sum_{k=0}^{\infty}\left(\frac{\zeta-b}{z-b}\right)^{k}\quad\left( 因 \left|\frac{\zeta-b}{z-b}\right|<1\right)\end{aligned} $$ 

故类似于上一节的理由有

 $$ \frac{f(\zeta)}{\zeta-z}=-\frac{f(\zeta)}{z-b}\sum_{k=0}^{\infty}\left(\frac{\zeta-b}{z-b}\right)^{k} $$ 

在 $ l_{2} $上一致收敛.因而有

 $$ \frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=-\sum_{k=0}^{\infty}\frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{(\zeta-b)^{-k}}\mathrm{d}\zeta\bullet(z-b)^{-(k+1)} $$ 

令 $ -(k+1)=s $，则 k=-s-1，故

$$  \frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{\zeta-z}\mathrm{d}\zeta=-\sum_{s=-1}^{\infty}\frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{(\zeta-b)^{s+1}}\mathrm{d}\zeta\bullet(z-b)^{s}   \tag*{(3.4.6)}$$

将（3.4.5）、（3.4.6）式代入（3.4.4）式有

$$  \begin{align*}f(z)=&\sum_{k=0}^{\infty}\frac{1}{2\pi\mathrm{i}}\oint_{l_{1}}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta\bullet(z-b)^{k}\\&+\sum_{k=-\infty}^{-1}\frac{1}{2\pi\mathrm{i}}\oint_{l_{2}}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta\bullet(z-b)^{k}\end{align*}   \tag*{(3.4.7)}$$

又作圆  $ l: | \zeta - b | = \rho, r' < \rho < R' $，则由复通区域的柯西定理（2.2.6）式有

$$  \oint_{l_{1}}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta=\oint_{l}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta   \tag*{(3.4.8)}$$

$$  \oint_{l_{2}}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta=\oint_{l}\frac{f(\zeta)}{(\zeta-b)^{k+1}}\mathrm{d}\zeta   \tag*{(3,4,9)}$$

将（3.4.8）、（3.4.9）式代入（3.4.7）式便可得到定理中的（3.4.2）式和（3.4.3）式.

必须注意的是，尽管洛朗展开(3.4.2)式中含有 $ (z-b) $的负幂项，这些项当z=b时都是奇异的，但展开中心b点不一定是函数的奇点。事实上，洛朗定理也并未涉及展开中心b是否一定是函数的奇点的问题。关于这一点，在后面的例题2中我们也会看到。另外，尽管洛朗展开的系数公式(3.4.3)与泰勒展开的系数公式(3.3.3)的形式相同，但不论b是否是 $ f(z) $的奇点，都应有 $ C_{k}\neq\frac{f^{(k)}(b)}{k!} $。如果b是 $ f(z) $的奇点，则 $ f^{(k)}(b) $根本不存在；如果b不是 $ f(z) $的奇点， $ C_{k} $也不会等于 $ \frac{f^{(k)}(b)}{k!} $。因为(2.3.5)式

<!-- page: 76 -->

成立的条件是  $ f(z) $ 在 l 内解析，而 (3.4.3) 式中的  $ f(z) $ 在 l 内肯定有奇点（当然不一定是展开中心 b），否则也不需要考虑洛朗展开了.

下面我们证明上述的洛朗展开也是唯一的.

设  $ f(z) $ 在环  $ r<|z-b|<R $ 内还有另一展开式，即

 $$ f(z)=\sum_{k=-\infty}^{\infty}C_{k}(z-b)^{k}=\sum_{k=-\infty}^{\infty}C_{k}^{\prime}(z-b)^{k} $$ 

则由洛朗级数收敛定理知，此二级数在  $ l: |z-b|=\rho (r<\rho < R) $ 上一致收敛。它们分别乘上  $ (z-b)^n (n $ 为固定整数 $ 后仍然一致收敛，故可在  $ l $ 上逐项积分，即

 $$ \sum_{k=-\infty}^{\infty}C_{k}\oint_{l}(z-b)^{k+n}\mathrm{d}z=\sum_{k=-\infty}^{\infty}C_{k}^{\prime}\oint_{l}(z-b)^{k+n}\mathrm{d}z $$ 

对于上式，若  $ k+n \neq -1 $，即  $ k \neq -n - 1 $，则由(2.1.4)式有

 $$ \oint_{l}(z-b)^{k+n}\mathrm{d}z=0 $$ 

若  $ k+n=-1 $ ，即 k=-n-1 ，则

 $$ C_{-n-1}\oint\frac{1}{z-b}\mathrm{d}z=C_{-n-1}^{\prime}\oint\frac{1}{z-b}\mathrm{d}z $$ 

由(2.1.4)式有

 $$ C_{-n-1}2\pi\mathrm{i}=C^{\prime}_{-n-1}2\pi\mathrm{i} $$ 

即

 $$ C_{-n-1}=C^{\prime}_{-n-1} $$ 

而 n 是任意的整数，故有

 $$ C_{k}=C_{k}^{\prime},\quad k=0,\pm1,\pm2,\cdots $$ 

唯一性得证.（请大家思考，在这里，为什么我们不按证泰勒展开唯一性时所用的方法来证？）

## 3. 收敛范围

显然，设 a 和  $ a' $ 分别是函数  $ f(z) $ 的两个相邻的奇点，则洛朗级数  $ \sum_{k=-\infty}^{\infty} C_{k}(z-b)^{k} $ 必在环域  $ |a-b|<|z-b|<|a'-b| $ （设  $ |a'-b|>|a-b| $）内收敛.

## 4. 展开方法

从理论上说我们当然可直接利用展开公式(3.4.2)和(3.4.3)将函数进行洛朗展开。但由于洛朗展开的系数公式只有积分的形式，它的计算，往往是相当困难甚至是无法计算的。既然洛朗展开也是唯一的，除了个别情况我们直接利用展开定理将函数进行洛朗展开外（见例3），一般均可借助一些已知的级数展式，通过种种简便方法来进行洛朗展开。

例1 求函数 $ \frac{1}{z(z-1)} $在 $ 0<|z|<1 $和 $ 1<|z|<\infty $中的洛朗展开.

<!-- page: 77 -->

解（1）若  $ 0 < |z| < 1 $，则

 $$ \frac{1}{z(z-1)}=-\frac{1}{z}\bullet\frac{1}{1-z}=-\frac{1}{z}\sum_{k=0}^{\infty}z^{k}=-\sum_{k=0}^{\infty}z^{k-1}=-\frac{1}{z}-1-z-z^{2}-\cdots $$ 

(2) 若  $ 1 < |z| < \infty $，则

 $$ \begin{aligned}\frac{1}{z(z-1)}=&\frac{1}{z}\bullet\frac{1}{z\big(1-\frac{1}{z}\big)}=\frac{1}{z^{2}}\bullet\sum_{k=0}^{\infty}\Big(\frac{1}{z}\Big)^{k}\\=&\sum_{k=0}^{\infty}\frac{1}{z^{k+2}}=\frac{1}{z^{2}}+\frac{1}{z^{3}}+\frac{1}{z^{4}}+\cdots\end{aligned} $$ 

例2 将  $ f(z)=\frac{1}{(z-1)(z-2)} $ 在复平面中以 z=0 为中心进行洛朗展开.

解 在复平面中  $ f(z)=\frac{1}{(z-1)(z-2)}=\frac{1}{z-2}-\frac{1}{z-1} $ 仅有 z=1 和 z=2 两个奇点，故在复平面中以 z=0 为中心，可在以下三个区域进行洛朗展开：

(1) $ |z|<1 $,此时

 $$ f(z)=\frac{1}{1-z}-\frac{1}{2\left(1-\frac{z}{2}\right)}=\sum_{k=0}^{\infty}z^{k}-\frac{1}{2}\sum_{k=0}^{\infty}\left(\frac{z}{2}\right)^{k}=\sum_{k=0}^{\infty}\left(1-\frac{1}{2^{k+1}}\right)z^{k} $$ 

(2)  $ 1 < |z| < 2 $，此时

 $$ \frac{1}{z-1}=\frac{1}{z}\bullet\frac{1}{\left(1-\frac{1}{z}\right)}=\frac{1}{z}\sum_{k=0}^{\infty}\left(\frac{1}{z}\right)^{k}=\sum_{k=0}^{\infty}\frac{1}{z^{k+1}} $$ 

 $$ \frac{1}{z-2}=-\frac{1}{2}\frac{1}{1-\frac{z}{2}}=-\frac{1}{2}\sum_{k=0}^{\infty}\left(\frac{z}{2}\right)^{k}=-\sum_{k=0}^{\infty}\frac{z^{k}}{2^{k+1}} $$ 

所以

 $$ f(z)=\frac{1}{z-2}-\frac{1}{z-1}=-\sum_{k=0}^{\infty}\frac{z^k}{2^{k+1}}-\sum_{k=1}^{\infty}\frac{1}{z^k} $$ 

(3)  $ 2 < |z| $，此时

 $$ \frac{1}{z-1}=\frac{1}{z}\frac{1}{1-\frac{1}{z}}=\sum_{k=0}^{\infty}\frac{1}{z^{k+1}} $$ 

 $$ \frac{1}{z-2}=\frac{1}{z}\bullet\frac{1}{1-\frac{2}{z}}=\sum_{k=0}^{\infty}\frac{2^{k}}{z^{k+1}} $$ 

所以

 $$ f(z)=\frac{1}{z-2}-\frac{1}{z-1}=\sum_{k=1}^{\infty}\frac{2^{k-1}-1}{z^{k}} $$ 

由展开的结果看到本例的情况(1)是一个泰勒级数，这当然并不奇怪，因为在 $ \left|z\right|<1 $内，没有函数 $ f(z)=\frac{1}{(z-1)(z-2)} $的奇点.在情况(2)、(3)中，右边的展开式

<!-- page: 78 -->

在 z=0 点均有无穷项负幂，即 z=0 点对于展开式而言是奇点，但函数  $ f(z)=\frac{1}{(z-1)(z-2)} $ 在 z=0 点却是解析的，这正是前面我们让大家注意的展开中心不一定是函数的奇点的情况.

例3 试证

 $$ \mathrm{ch}\left(z+\frac{1}{z}\right)=C_{0}+\sum_{k=1}^{\infty}C_{k}\left(z^{k}+z^{-k}\right) $$ 

其中  $ C_{k}=\frac{1}{2\pi}\int_{0}^{2\pi}\cos k\varphi\mathrm{ch}(2\cos\varphi)\mathrm{d}\varphi $

证 因  $ w=z+\frac{1}{z} $ 在 z 平面上只有 z=0 一个奇点，而

 $$ \mathrm{ch}\ \mathrm{w}=1+\frac{\mathrm{w}^{2}}{2!}+\frac{\mathrm{w}^{4}}{4!}+\cdots $$ 

的收敛半径为 $ \infty $，故 $ \mathrm{ch}\left(z+\frac{1}{z}\right) $在z平面上也只有一个奇点z=0。故可将它在 $ 0<|z|<\infty $中展开为洛朗级数

 $$ \operatorname{ch}\left(z+\frac{1}{z}\right)=\sum_{k=-\infty}^{\infty}C_{k}z^{k} $$ 

其中

 $$ C_{k}=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{\mathrm{ch}(z+z^{-1})}{z^{k+1}}\mathrm{d}z $$ 

这里，l 表任意圆周  $ |z| = \rho > 0 $。取  $ \rho = 1 $，则在 l 上： $ z = e^{i\varphi}, 0 \leqslant \varphi \leqslant 2\pi $。故有

 $$ \begin{align*}\mathrm{C}_{k}=&\frac{1}{2\pi}\int_{0}^{2\pi}\mathrm{ch}(\mathrm{e}^{\mathrm{i}\varphi}+\mathrm{e}^{-\mathrm{i}\varphi})\mathrm{e}^{-\mathrm{i}k\varphi}\mathrm{d}\varphi\\=&\frac{1}{2\pi}\int_{0}^{2\pi}\mathrm{ch}(2\cos\varphi)\mathrm{c o s}k\varphi\mathrm{d}\varphi-\frac{\mathrm{i}}{2\pi}\int_{0}^{2\pi}\mathrm{ch}(2\cos\varphi)\mathrm{s i n}k\varphi\mathrm{d}\varphi\end{align*} $$ 

令  $ \varphi = \pi - \theta $，则右边第二个积分之值为零。故有

 $$ C_{k}=\frac{1}{2\pi}\int_{0}^{2\pi}\mathrm{ch}(2\cos\varphi)\cos k\varphi\mathrm{d}\varphi $$ 

所以

 $$ C_{k}=C_{\rightarrow k},\quad k=1,2,\cdots $$ 

故

 $$ \mathrm{ch}\left(z+\frac{1}{z}\right)=C_{0}+\sum_{k=1}^{\infty}C_{k}(z^{k}+z^{-k}) $$ 

#### 习题3.4

1. 将下列函数在指定环域内展开为洛朗级数：

 $$ (1)\frac{z+1}{z^{2}(z-1)},0<|z|<1,1<|z|<\infty;\qquad(2)\frac{z^{2}-2z+5}{(z-2)(z^{2}+1)},1<|z|<2; $$ 

(3)

 $$ \mathrm{e}^{z+\frac{1}{z}},0<|z|<+\infty; $$ 

 $$ \sin z\sin\frac{1}{z},0<|z|<∞. $$

<!-- page: 79 -->

2. 在给定点的（去心）邻域，将函数展开为洛朗级数，并确定展开式成立的区域.

(1) $ \frac{1}{(z^{2}+1)^{2}},z=i; $ (2) $ (z-1)^{2}\mathrm{e}^{\frac{1}{1-z}},z=1; $ (3) $ \frac{1}{(z-a)^{k}}(a\neq0,k $ 为自然数 $ ),z=0; $

(4) $ z^{2}e^{\frac{1}{z}},z=0; $ (5) $ \sin\frac{z}{1-z},z=1; $ (6) $ e^{\frac{1}{2}(z-\frac{a^{2}}{z})},z=0. $

3. 将函数 $ \frac{1}{(z-a)(z-b)}(0<|a|<|b|) $，在 z=0, z=a 的邻域内以及在圆环  $ \left|a\right|<\left|z\right|<\left|b\right| $ 内展开为洛朗级数.

4. 设  $ f(z) $ 在环域  $ 1-\varepsilon<|z|<1+\varepsilon $ 内解析， $ \varepsilon $ 为正数，证明在单位圆周上，其洛朗级数即为傅里叶级数.

5. 将函数  $  f(z) = \frac{1}{z(1-z)}  $ 在下列区域中展开为级数：

(1)  $ 0 < |z| < 1 $; (2)  $ |z| > 1 $; (3)  $ 0 < |z - 1| < 1 $; (4)  $ |z - 1| > 1 $;

(5) $ |z+1|<1 $; (6) $ 1<|z+1|<2 $; (7) $ |z+1|>2 $.

### 3.5 单值函数的孤立奇点

## 1. 函数的奇点

我们知道，函数的奇点是指函数的不解析之点。我们将函数的奇点分为孤立奇点和非孤立奇点两大类。

设单值函数  $ f(z) $ 在某点 b 不解析，而在 b 的某一去心邻域  $ 0<|z-b|<\varepsilon $ （即除去圆心 z=b 的某个圆）内解析，则称 z=b 是  $ f(z) $ 的一个孤立奇点。如，z=0 是函数  $ \frac{1}{z(z-1)} $ 的孤立奇点，因为当  $ 0<|z|<1 $ 时  $ \frac{1}{z(z-1)} $ 解析。同样，z=1 也是  $ \frac{1}{z(z-1)} $ 的一孤立奇点，因为当  $ 0<|z-1|<1 $ 时它也解析。

显然，函数在其孤立奇点的去心邻域（有时，也常常就称之为孤立奇点的邻域，而不用“去心”二字）是能展开成洛朗级数的. 如，当  $ 0<|z-1|<1 $ 时，有

 $$ \begin{aligned}f(z)&=\frac{1}{z(z-1)}=\frac{1}{z-1}\bullet\frac{1}{1-\left[-(z-1)\right]}\\&=\frac{1}{z-1}\sum_{k=0}^{\infty}(-1)^{k}(z-1)^{k}\\&=\sum_{k=0}^{\infty}(-1)^{k}(z-1)^{k-1}\\ \end{aligned} $$ 

若在 z=b 的无论多小邻域内，总有除 z=b 以外的奇点，则称 z=b 为  $ f(z) $ 的非孤立奇点。例如，z=0 就是函数  $ \left(\sin\frac{1}{z}\right)^{-1} $ 的非孤立奇点。因为这函数还有奇点  $ z=\frac{1}{n\pi} $，n=0， $ \pm1 $， $ \pm2 $， $ \cdots $。而只要 n 足够大， $ \frac{1}{n\pi} $ 可以任意接近于 0，即在 z=0 的无论多小的邻域内总可找到其他奇点。

<!-- page: 80 -->

对于函数的奇点特别是函数在其孤立奇点邻域内的性质的讨论，在许多问题中，如在留数理论中，在常微分方程的解析理论中等等，均有着十分重要的意义。本节我们将主要讨论单值函数（或多值函数的单值分支）的孤立奇点。

## 2. 孤立奇点的分类

单值函数的孤立奇点分为三类. 设 b 为  $ f(z) $ 的孤立奇点，则在 b 的去心邻域  $ 0 < |z - b| < R $ 中可将  $ f(z) $ 展开为洛朗级数

$$  f(z)=\sum_{k=-\infty}^{\infty}C_{k}(z-b)^{k}   \tag*{(3.5.1)}$$

由于洛朗级数的负幂部分表示奇点性质，故我们按(3.5.1)式其负幂部分的情况将之分为如下三类：

（1）若  $ f(z) $ 在 b 点的主要部分为零，即

$$  f(z)=C_{0}+C_{1}(z-b)+C_{2}(z-b)^{2}+\cdots,\quad0<|z-b|<R   \tag*{(3.5.2)}$$

则称 b 为  $ f(z) $ 的可去奇点. 如,  $ f(z)=\frac{\sin z}{z} $, 在 z=0 点该函数无确定值, 故 z=0 为该函数的奇点. 但

$$  \frac{\sin z}{z}=\frac{1}{z}\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}z^{2k+1}=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}z^{2k},\quad0<|z|<\infty   \tag*{(3.5.3)}$$

无负幂，故 z=0 是  $ f(z)=\frac{\sin z}{z} $ 的可去奇点.

对于(3.5.2)式有

$$  \lim_{z\to b}f(z)=C_{0}   \tag*{(3.5.4)}$$

因此，如果定义  $ f(b)=C_{0} $，则函数  $ f(z) $ 在 z=b 的奇异性就去掉了，而可以将之作为解析函数来看待（这亦是我们称 b 为可去奇点的由来）。如，对于  $ \frac{\sin z}{z} $ 若规定在 z=0 点  $ \frac{\sin z}{z} $ 之值为 1，则

 $$ f(z)=\left\{\begin{aligned}&\frac{\sin z}{z},&z\neq0\\ &1,&z=0\end{aligned}\right. $$ 

在 $ \left|z\right|<\infty $中解析，函数在z=0点的奇异性已去掉，而此时(3.5.3)式右边的级数在 $ \left|z\right|<\infty $中成立，代表去掉奇异性以后的级数.

可以证明，如果  $ f(z) $ 以 b 为可去奇点，则下列三条件的每一条都是 z=b 为  $ f(z) $ 的可去奇点的充分必要条件，它们可以互相推出：

 $ 1^{\circ}f(z) $在b点没有主要部分；

 $ 2^{\circ}\ \lim_{x\to h}f(z) $ 存在并且有限；

 $ 3^{\circ}f(z) $在b的某去心邻域内有界.

（2）若  $ f(z) $ 在 b 点的主要部分有有限项负幂，即

<!-- page: 81 -->

$$  f(z)=\frac{C_{-m}}{(z-b)^{m}}+\frac{C_{-(m-1)}}{(z-b)^{m-1}}+\cdots+\frac{C_{-1}}{z-b}+C_{0}+C_{1}(z-b)+\cdots   \tag*{(3.5.5)}$$

则称 b 为  $ f(z) $ 的 m 阶极点  $ (C_{-m} \neq 0) $. 如， $ f(z) = \frac{1}{z^{2}(z-1)} $，z = 0 为其奇点，且

 $$ \begin{aligned}\frac{1}{z^{2}(z-1)}=&\frac{-1}{z^{2}}\bullet\frac{1}{1-z}=\frac{-1}{z^{2}}\sum_{k=0}^{\infty}z^{k}\\=&-\left(\frac{1}{z^{2}}+\frac{1}{z}+1+z+\cdots\right),\quad0<|z|<1\end{aligned} $$ 

所以 z=0 是它的二阶极点. 又如， $ f(z)=\frac{1}{z-1} $，显然 z=1 是它的一阶极点. 一阶极点又称做单极点.

可以证明，如果  $ f(z) $ 以 b 为孤立奇点，则下列三条件每一条都是 z=b 为  $ f(z) $ 的 m 阶极点的充分必要条件，它们可以互相推出：

 $ 1^{\circ}f(z) $在b点的主要部分为 $ \frac{C_{-m}}{(z-b)^{m}}+\cdots+\frac{C_{-1}}{z-b}(C_{-m}\neq0) $;

 $ 2^{\circ}f(z) $ 在 b 的某去心邻域内能表示成  $ f(z)=\frac{\varphi(z)}{(z-b)^{m}} $，其中， $ \varphi(z) $ 在 b 的邻域内解析， $ \varphi(b)\neq0 $；

 $ 3^{\circ} g(z)=\frac{1}{f(z)} $ 以 b 为（可去奇点要作解析点看）m 阶零点.

以上三条，当然均可作为判断一个函数的 m 阶极点的充分必要条件. 而  $ \lim_{z\to b}f(z)=\infty $，则是 b 为函数  $ f(z) $ 的极点的充分必要条件.

（3）若  $ f(z) $ 在 b 点的主要部分有无限项负幂，即

$$  f(z)=\cdots+\frac{C_{-m}}{(z-b)^{m}}+\cdots+\frac{C_{-1}}{z-b}+C_{0}+C_{1}(z-b)+\cdots   \tag*{(3.5.6)}$$

则称 b 为  $ f(z) $ 的本性奇点. 如  $ \mathrm{e}^{\frac{1}{z}} $，当 z=0 时，其值不定，而

 $$ \mathrm{e}^{\frac{1}{z}}=1+\frac{1}{z}+\frac{1}{2!z^{2}}+\cdots,\quad0<|z|<\infty $$ 

有无限项负幂，故 z=0 为它的本性奇点.

从 b 为  $ f(z) $ 可去奇点的充分必要条件  $ \lim_{z\to b}f(z)= $ 有限值和 b 为  $ f(z) $ 的 m 阶极点的充分必要条件  $ \lim_{z\to b}f(z)=\infty $，用反证法我们立即可得到 b 为  $ f(z) $ 的本性奇点的充分必要条件是

 $$ \lim_{z\to b}f(z)\neq\left\{\begin{aligned}& 有限值 \\ &\infty\end{aligned}\right.,\quad 即 \lim_{z\to b}f(z) 不存在 $$ 

## 3. 无穷远点的性质

以上讨论的是奇点 z=b 为有限远点的情况. 现在讨论  $ z=\infty $ 的情况. 若存在一

<!-- page: 82 -->

正数 R，使  $ f(z) $ 在以 z=0 为圆心，R 为半径的圆外每一点  $ |z|>R $（包括  $ z=\infty $）都是可导的，则称  $ f(z) $ 在无穷远点的邻域内解析。如， $ f(z)=\frac{1}{z-1} $，当  $ |z|>1 $ 时， $ f(z) $ 处处解析，故它在无穷远点的邻域解析。

若以 z=0 为圆心，R 为半径作圆  $ \left|z\right|=R $，只要 R 足够大，在圆外，除无穷远点外  $ f(z) $ 别无奇点（即  $ f(z) $ 在  $ \infty $ 点的某去心邻域  $ R<|z|<\infty $ 中解析），则称无穷远点为  $ f(z) $ 的一个孤立奇点。如  $ \frac{\sin z}{z} $，当  $ |z|>0 $ 时， $ \frac{\sin z}{z} $ 除无穷远点外别无奇点，即它在  $ 0<|z|<\infty $ 中解析，故无穷远点是它的一个孤立奇点。

为了研究函数  $ f(z) $ 在无穷远点的性质，可作变换  $ z=\frac{1}{t} $，把  $ z=\infty $ 变为 t=0；函数  $ f(z)=f\left(\frac{1}{t}\right) $ 变为  $ \varphi(t) $，然后研究函数  $ \varphi(t) $ 在 t=0 的邻域的性质。若  $ \varphi(t) $ 在 t=0 的邻域  $ \left|t\right|<\delta $ 中解析，则  $ f(z) $ 在无穷远点的邻域  $ \left|z\right|>R=\frac{1}{\delta} $ 中解析；若  $ \varphi(t) $ 在  $ 0<|t|<\delta $ 中解析，即 t=0 为  $ \varphi(t) $ 的孤立奇点，则  $ f(z) $ 在  $ \frac{1}{\delta}=R,R<|z|<\infty $ 中解析，即  $ z=\infty $ 为  $ f(z) $ 的孤立奇点。

设  $ \varphi(t) $ 在 t=0 的去心邻域  $ 0<|t|<\delta $ 内的洛朗展开为

 $$ \begin{array}{r}{\varphi(t)=\cdots\frac{C_{-k}^{^{\prime}}}{t^{k}}+\cdots+\frac{C_{-1}^{^{\prime}}}{t}+C_{0}+C_{1}^{\prime}t+\cdots+C_{k}^{\prime}t^{k}+\cdots,\quad0<|t|<\delta}\end{array} $$ 

则  $ f(z) $ 在  $ z=\infty $ 的洛朗展开为

$$  \begin{aligned}f(z)=&\cdots+C_{-k}^{^{\prime}}z^{k}+\cdots+C_{-1}^{^{\prime}}z+C_{0}+\frac{C_{1}^{^{\prime}}}{z}+\cdots+\frac{C_{k}^{^{\prime}}}{z^{k}}+\cdots\\=&\cdots+C_{k}z^{k}+\cdots+C_{1}z+C_{0}+\frac{C_{-1}}{z}+\cdots+\frac{C_{-k}}{z^{k}}+\cdots\end{aligned}   \tag*{(3.5.7)}$$

其中

 $$ R<\mid z\mid<\infty,R=\frac{1}{\delta}；\ C_{±k}=C_{干k}^{\prime},k=1,2,\cdots $$ 

可见，将  $ f(z) $ 在无穷远点展开为洛朗级数，只要将  $ f(z) $ 在以 z=0 为中心以 R 为内半径 [R 为  $ f(z) $ 在有限区域中距 z=0 最远的一个奇点与 z=0 点间的距离] 的环域  $ R<|z|< \infty $ 展开即可 [若  $ f(z) $ 在有限区域中没有奇点，则这个展开就等于在  $ |z|< \infty $ 中的泰勒展开].

例 求  $ f(z)=\frac{\sin z}{z} $ 在孤立奇点无穷远点的洛朗展开.

 $$ f(z)=\frac{1}{z}\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}z^{2k+1}=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}z^{2k},\quad0<|z|<\infty $$ 

由于  $ f(z) $ 在  $ R<|z|< \infty $ 中的展开与  $ \varphi(t) $ 在  $ 0<|t|<\delta $ 中的展开相当，故我们当然可按照在有限区域中对孤立奇点的分类方法，将无穷远点为孤立奇点分为如下

<!-- page: 83 -->

三类：

（1）若  $ f(z) $ 在无穷远点的洛朗展开不含正幂，即

$$  f(z)=C_{0}+\frac{C_{-1}}{z}+\frac{C_{-2}}{z^{2}}+\cdots,\quad R<|z|<\infty   \tag*{(3.5.8)}$$

则称  $ z=\infty $ 为  $ f(z) $ 的可去奇点（作为解析点看）. 如， $ f(z)=z\sin\frac{1}{z} $， $ z=\infty $ 是它的可去奇点. 因为

 $$ z\sin\frac{1}{z}=z\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}\frac{1}{z^{2k+1}}=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(2k+1)!}\frac{1}{z^{2k}},\quad0<|z|<\infty $$ 

无正幂.

（2）若  $ f(z) $ 在无穷远点的洛朗展开有有限项正幂，即

$$  \begin{align*}f(z)=C_{m}z^{m}+C_{m-1}z^{m-1}+\cdots+C_{1}z+C_{0}+\frac{C_{-1}}{z}+\frac{C_{-2}}{z^{2}}+\cdots,\\C_{m}\neq0,\quad R<|z|<\infty\end{align*}   \tag*{(3.5.9)}$$

则称  $ z=\infty $ 为  $ f(z) $ 的 m 阶极点. 如 n 次多项式  $ P_{n}(z)=a_{n}z^{n}+a_{n-1}z^{n-1}+\cdots+a_{0}, z=\infty $ 是它的 n 阶极点.

（3）若  $ f(z) $ 在无穷远点的洛朗展开有无穷项正幂，即

$$  f(z)=\cdots+C_{k}z^{k}+\cdots+C_{1}z+C_{0}+\frac{C_{-1}}{z}+\frac{C_{-2}}{z^{2}}+\cdots,\quad R<|z|<\infty   \tag*{(3.5.10)}$$

则称  $ z=\infty $ 为  $ f(z) $ 的本性奇点. 如  $ f(z)=\mathrm{e}^{z}, z=\infty $ 是它的本性奇点, 因为

 $$ \mathrm{e}^{z}=1+\frac{z}{1!}+\frac{z^{2}}{2!}+\cdots,\quad\mid z\mid<\infty $$ 

有无限项正幂.

由上述分类标准可看出，我们亦可根据极限 $ \lim_{z\to\infty}f(z) $之值分别为有限、无限和不存在的三种不同情形，来判断 $ z=\infty $为 $ f(z) $的可去奇点、极点和本性奇点.

#### 习题3.5

1. 证明：如果 b 为  $ f(z) $ 的孤立奇点，则下列三条件的每一条都是 z=b 为  $ f(z) $ 的可去奇点的分必要条件，它们可以互相推出

(1)  $ f(z) $ 在 b 点没有主要部分；

(2) $ \lim_{x\to h}f(z) $存在并且有限；

(3)  $ f(z) $ 在 b 的充分小的邻域内有界.

2. 证明下列三种定义等价：点 b 为  $ f(z) $ 的 m 阶极点.

(1) 若  $ f(z) = \sum_{k = -m}^{\infty} C_{k}(z - b)^{k}, 0 < |z - b| < R, C_{-m} \neq 0; $

(2) 若  $ f(z)=\frac{\varphi(z)}{(z-b)^{m}} $,  $ \varphi(b)\neq0 $,  $ \varphi(z) $ 在  $ 0<|z-b|<R $ 中解析；

<!-- page: 84 -->

(3) 若  $ g(z)=\frac{1}{f(z)} $ 以 b 为 m 阶零点.

3. 证明下列三条中任意一条均是 $ \infty $为  $ f(z) $ 的 m 阶极点的充分必要条件：

(1)  $ f(z) $ 在  $ z = \infty $ 点的洛朗展开有 m 项正幂；

(2)  $ f(z) $ 在  $ z=\infty $ 的某邻域内（除  $ \infty $ 外）能表成  $ f(z)=z^{m}\varphi(z) $， $ \varphi(z) $ 在  $ z=\infty $ 的邻域内解析且  $ \varphi(\infty)\neq0 $；

(3)  $ g(z)=\frac{1}{f(z)} $ 以  $ \infty $ 为 m 阶零点.

4. 求出下列函数的奇点（包括  $ z = \infty $）。确定它们是哪一类的奇点（对于极点，要指出它们的阶）。

(1)  $ \frac{z-1}{z(z^2+4)^2} $; (2)  $ \frac{z^5}{(1-z)^2} $; (3)  $ \frac{1}{\sin z + \cos z} $; (4)  $ \frac{1-e^z}{1+e^z} $;

(5)  $ \tan^2 z $; (6)  $ z^2 $; (7)  $ \frac{z}{z+1} $; (8)  $ \frac{e^z}{1+z^2} $;

(9)  $ \frac{z^2+1}{e^z} $; (10)  $ ze^{\frac{1}{z}} $; (11)  $ \sin\left(\frac{1}{\sin\frac{1}{z}}\right) $; (12)  $ \frac{z^7}{(z^2-4)^2 \cos\frac{1}{z-2}} $.

5. 讨论下列多值函数的每一单值分支在给定点的性状. (对各个分支, 给定点是否解析, 或是否为奇点? 若为奇点, 是属哪一类?)

(1) $ \frac{z}{1+\sqrt{z-3}}, z=4; $

(2) $ \frac{1}{\sqrt{z}+\sqrt[3]{z}}, z=1; $

(3)  $ \cos\frac{1}{1+\sqrt{z}}, z=1; $

(4)  $ \frac{1}{(2+\sqrt{z})\sin(2-\sqrt{z})}, z=4. $

6.  $ f(z) $,  $ g(z) $ 分别以 z=b 为 m 阶及 n 阶极点，试问 z=b 为  $ f+g $,  $ f \cdot g $ 及  $ \frac{f}{g} $ 的什么样的点？

7. 下列函数在指定点的去心邻域内能否展为洛朗级数？

(1)  $ \cos\frac{1}{z}, z=0; $

(2)  $ \cos\frac{1}{z}, z=\infty; $

(3)  $ \sec\frac{1}{z-1}, z=1; $

(4)  $ \cot z, z=\infty. $

<!-- page: 85 -->

<div style="text-align: center;"><img src="images/p0085_img_in_image_box_86_341_149_405.jpg" alt="二、泰勒级数和洛朗级数" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0085_img_in_image_box_84_474_148_538.jpg" alt="Image" width="6%" /></div>


### 本章小结

本章授课课件 本章习题分析与讨论

<div style="text-align: center;"><div style="text-align: center;">二、泰勒级数和洛朗级数</div> </div>




<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>一、无穷级数</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{aligned}&amp;\sum_{k=1}^{\infty}f_{k}(f_{k}为复数)\\&amp;\sum_{k=1}^{\infty}f_{k}(z)\\&amp;\sum_{k=0}^{\infty}a_{k}(z-b)^{k}\end{aligned}\right. $</td><td style='text-align: center; word-wrap: break-word;'>除了实级数中，一致收敛级数的逐项可微性发展为魏尔斯特拉斯定理外，同类实级数的有关概念、定理与性质在此均适用.</td></tr></table>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>泰勒级数</td><td style='text-align: center; word-wrap: break-word;'>洛朗级数</td><td style='text-align: center; word-wrap: break-word;'>非孤立奇点</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>展开式</td><td style='text-align: center; word-wrap: break-word;'>$ f(z)=\sum_{k=0}^{\infty}a_k(z-b)^k $\n $ a_k=\frac{f^{(k)}(b)}{k!} $</td><td style='text-align: center; word-wrap: break-word;'>$ f(z)=\sum_{k=-\infty}^{\infty}C_k(z-b)^k $\n $ C_k=\frac{1}{2\pi i}\oint_S f(\zeta)\over(\zeta-b)^{k+1}d\zeta $</td><td style='text-align: center; word-wrap: break-word;'>三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n三、\n</td></tr></table>

<!-- page: 86 -->

解析延拓是解析函数论中的一个重要概念，在本章、下一章和以后多处均会用到； $ \Gamma $函数是数学物理中应用十分广泛的一种函数。本章将讨论解析延拓的基本原理和理论依据，并在此基础上讨论 $ \Gamma $函数、B函数。

### 4.1 解析延拓

## 1. 解析延拓

简单地说，解析延拓就是把在已知区域内解析的函数推广到更大的区域上去，或者说解析延拓就是将解析函数的定义域加以扩大。

利用泰勒级数进行解析延拓是普遍的方法. 考虑一个用幂级数定义的解析函数

$$  f_{1}(z)=\sum_{k=0}^{\infty}z^{k},\quad\mid z\mid<1   \tag*{(4.1.1)}$$

它的解析区域为 $ \sigma_{1} $:|z|<1，在|z|=1外级数是发散的。利用这级数可算出 $ f_{1}(z) $在|z|<1中任何一点的函数值及函数的各阶导数值。例如，在 $ z=\frac{1}{2} $这点，有

 $$ f_{1}\left(\frac{\mathrm{i}}{2}\right)=1+\frac{\mathrm{i}}{2}+\left(\frac{\mathrm{i}}{2}\right)^{2}+\cdots=\frac{1}{1-\frac{\mathrm{i}}{2}} $$ 

 $$ f_{1}^{\prime}\left(\frac{\mathrm{i}}{2}\right)=1+2\frac{\mathrm{i}}{2}+3\left(\frac{\mathrm{i}}{2}\right)^{2}+\cdots=\frac{1}{\left(1-\frac{\mathrm{i}}{2}\right)^{2}} $$ 

 $$ f_{1}^{(k)}\left(\frac{\mathrm{i}}{2}\right)=\frac{k!}{\left(1-\frac{\mathrm{i}}{2}\right)^{k+1}},\quad k=0,1,2,\cdots $$ 

由此得到  $ f_{1}(z) $ 在  $ z=\frac{i}{2} $ 的泰勒级数

 $$ \sum_{k=0}^{\infty}\frac{f_{1}^{(k)}\left(\frac{\mathrm{i}}{2}\right)}{k!}\left(z-\frac{\mathrm{i}}{2}\right)^{k}=\sum_{k=0}^{\infty}\frac{1}{\left(1-\frac{\mathrm{i}}{2}\right)^{k+1}}\left(z-\frac{\mathrm{i}}{2}\right)^{k} $$ 

记之为  $ f_{2}(z) $，即

<!-- page: 87 -->

$$  f_{2}(z)=\sum_{k=0}^{\infty}\frac{1}{\left(1-\frac{\mathrm{i}}{2}\right)^{k+1}}\left(z-\frac{\mathrm{i}}{2}\right)^{k}   \tag*{(4.1.2)}$$

它的收敛半径为  $ \left|1-\frac{i}{2}\right|=\frac{\sqrt{5}}{2} $，故其解析区域为  $ \sigma_{2} $ ：

 $ \left|z-\frac{i}{2}\right|<\frac{\sqrt{5}}{2} $，已越出了原来 $ f_{1}(z) $的解析区域 $ \left|z\right|<1 $

（见图4.1）。 $ f_{2}(z) $称为 $ f_{1}(z) $在区域 $ \left|z-\frac{1}{2}\right|<\frac{\sqrt{5}}{2} $内的解析延拓。

由上例看到，虽然解析函数  $ f_{1}(z) $ 和  $ f_{2}(z) $ 各有自己的有效范围  $ \left(|z|<1\right. $ 和  $ \left|z-\frac{\mathrm{i}}{2}\right|<\frac{\sqrt{5}}{2} $，但它们同时又有公共的有效范围（见图4.1中，两圆的公共部分 $ \sigma_{12} $）.

<div style="text-align: center;"><img src="images/p0087_img_in_image_box_639_237_857_471.jpg" alt="图4.1" width="22%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图4.1</div> </div>


一般地说，设已知一个函数  $ f_{1}(z) $ 在区域  $ \sigma_{1} $ 中解析，如果在与  $ \sigma_{1} $ 有重叠部分  $ \sigma_{12} $ （可以是一条线）的另一区域  $ \sigma_{2} $ 内，存在解析函数  $ f_{2}(z) $，且在  $ \sigma_{12} $ 中  $ f_{2}(z) \equiv f_{1}(z) $，则  $ f_{2}(z) $ 称为  $ f_{1}(z) $ 在  $ \sigma_{2} $ 中的解析延拓；同样， $ f_{1}(z) $ 也称为  $ f_{2}(z) $ 在  $ \sigma_{1} $ 中的解析延拓。

上例用函数的幂级数表达式作解析延拓，照那样做下去，将得到有不同收敛圆的许多幂级数，这些幂级数的全体代表一个解析函数  $ f(z) $，即

 $$ f(z)\equiv\left\{\begin{aligned}&f_{1}(z),z\in\sigma_{1}\\ &f_{2}(z),z\in\sigma_{2}\\ &f_{3}(z),z\in\sigma_{3}\\ &\cdots\cdots\end{aligned}\right. $$ 

或者说  $ f_{1}(z) $ 已解析延拓为解析函数  $ f(z) $，解析区域则从区域  $ \sigma_{1} $ 扩大为  $ \sigma = \sigma_{1} + \sigma_{2} + \sigma_{3} + \cdots $.

必须注意，上例中的延拓始终不能包含 z=1，因为在这点上级数（4.1.1）式总是发散的。事实上解析延拓也并非总能进行。例如函数

 $$ f(z)\equiv1+\sum_{k=1}^{\infty}z^{2^{k}} $$ 

它在圆域 $ \left|z\right|<1 $内收敛、解析，但这级数在 $ \left|z\right|=1 $上是处处发散的，在 $ \left|z\right|=1 $上处处是 $ f(z) $的奇点，因而解析延拓不能超过这圆周.

用泰勒展开进行解析延拓虽然是个普遍的方法，但具体计算较繁。通常总是采用一些特殊的方法，如用函数关系（见下节）、施瓦茨（Schwarz）反射原理（见本节习题）来进行解析延拓，可是要使这些做法有意义，必须首先证明解析延拓是唯一的。

<!-- page: 88 -->

## 2. 解析延拓的唯一性

我们所需要证明的是，如果  $ f_{2}^{\mathrm{I}}(z) $ 和  $ f_{2}^{\mathrm{II}}(z) $ 都是  $ f_{1}(z) $ 在  $ \sigma_{2} $ 中的解析延拓，则在  $ \sigma_{2} $ 中  $ f_{2}^{\mathrm{I}}(z) \equiv f_{2}^{\mathrm{II}}(z) $.

根据解析延拓的定义，既然  $ f_{2}^{\mathrm{I}}(z) $ 和  $ f_{2}^{\mathrm{II}}(z) $ 都是  $ f_{1}(z) $ 的解析延拓，那么在公共区域  $ \sigma_{12} $ 中它们都应该等于  $ f_{1}(z) $，即在  $ \sigma_{12} $ 中  $ f_{2}^{\mathrm{I}}(z) $ 和  $ f_{2}^{\mathrm{II}}(z) $ 相等，因此，所需要证明的论断可表述为解析函数的（内部）唯一性定理：

如果有两个在区域G中解析的函数 $ f^{\mathrm{I}}(z) $和 $ f^{\mathrm{II}}(z) $，已知它们在G的一个子区域g中恒等，则它们在整个G中也必恒等.

<div style="text-align: center;"><img src="images/p0088_img_in_image_box_98_431_325_718.jpg" alt="图4.2" width="23%" /></div>


证 令

 $$ F(z)\equiv f^{\mathrm{I}}\left(z\right)-f^{\mathrm{I I}}\left(z\right) $$ 

则可将上述唯一定理表述为：设  $ F(z) $ 在 G 内解析，且在 G 的子区域 g 中  $ F(z) \equiv 0 $，则在整个区域中有  $ F(z) \equiv 0 $。

<div style="text-align: center;"><div style="text-align: center;">图4.2</div> </div>


我们来证明后一论述. 取 g 的边界上的一点 b，如图4.2所示，取 b 的一个邻域，它的一部分  $ \alpha $ 属于 g，另一部分  $ \beta $ 不属于 g. 按照假定， $ F(z) $ 在 g 上处处等于零，在  $ \beta $ 上并非处处等于零（否则它就并入 g 中）. 以 b 为中心，把在 G 中解析的函数  $ F(z)=f^{1}(z)-f^{\parallel}(z) $ 展开为泰勒级数，设展开系数中第一个不为零的是  $ a_{m}(m $ 有限），则

 $$ F(z)=(z-b)^{m}\big[a_{m}+a_{m+1}(z-b)+\cdots\big],\quad a_{m}\neq0 $$ 

取z为与b紧邻而不等于b的值，于是 $ \left|z-b\right| $的值虽小，但不等于零，因而方括弧中的级数之和与 $ a_{m} $接近，即

 $$ a_{m}+a_{m+1}(z-b)+a_{m+2}(z-b)^{2}+\cdots\approx a_{m} $$ 

故  $ F(z)=(z-b)^{m}\left[a_{m}+a_{m+1}(z-b)+\cdots\right]\approx(z-b)^{m}a_{m}\neq0 $。这就是说， $ F(z) $ 在 b 的邻域（除 b 外）都不等于零，这与原假设  $ F(z) $ 在 g 上处处为零相矛盾，说明展开系数  $ a_{0}, a_{1}, \cdots, a_{k}, \cdots $ 必须都等于零。如果所有的系数都为零，则  $ F(z) $ 不仅在 g 内处处为零，而且在  $ \beta $ 上也处处为零。这就证明  $ F(z) $ 在区域  $ g+\beta $ 上等于零。重复同样的论证，不断扩大  $ F(z) $ 为零的区域，就可证明在整个区域 G 中  $ F(z) $ 恒等于零。因而，在  $ G $ 中  $ f^{1}(z) \equiv f^{1}(z) $，这就证明了解析延拓的唯一性。

必须注意，解析延拓的唯一性是复变函数所特有的重要性质，实变函数不可能有这样的性质.

解析延拓的唯一性为解析延拓提供了理论依据.

#### 习题4.1

1. 证明如果  $ f(z) $ 在区域 G 中解析，在 G 的一个子区域中等于零，则  $ f(z) $ 在整个 G 中等于零.

<!-- page: 89 -->

2. 证明级数  $ f(z)=\sum_{k=0}^{\infty}\left(\frac{1+z}{1-z}\right)^{k} $ 所定义的函数在左半平面内解析，并可解析延拓到除点 z=0 外的整个复平面.

3. 证明  $ \sum_{k=0}^{\infty}(az)^{k} $ 与  $ \sum_{k=0}^{\infty}(-1)^{k}\frac{(1-a)^{k}z^{k}}{(1-z)^{k+1}} $ 互为解析延拓 (a 是复常数).

提示：证明两者的解析区域具有公共部分。

4. 试求在圆域 $ \left|z\right|<1 $中的解析函数 $ f(z)=\sum_{k=0}^{\infty}\left(1-\frac{1}{2^{k+1}}\right)z^{k} $的解析延拓.

5. 证明施瓦茨反射原理：设  $ f(z) $ 在上半平面包括实轴上的一段是解析的，而且在这段实轴上  $ f(z) $ 取实数值，则  $ \overline{f(\bar{z})} $ 是  $ f(z) $ 在下半平面的解析延拓.

提示：设  $ f(z)=u(x,y)+\mathrm{i}v(x,y) $  $ (y\geqslant0) $，则  $ \overline{f(\overline{z})}=u(x,-y)-\mathrm{i}v(x,-y)=\xi(x,y)+\mathrm{i}\eta(x,y) $，然后用 C-R 条件证明.

### 4.2  $ \Gamma $ 函数

在数学分析中  $ \Gamma $ 函数定义为

$$  \Gamma(x)=\int_{0}^{\infty}\mathrm{e}^{-t}t^{x-1}\mathrm{d}t,\quad x>0   \tag*{(4.2.1)}$$

将x换成z，得

$$  \Gamma(z)=\int_{0}^{\infty}\mathrm{e}^{-t}t^{z-1}\mathrm{d}t^{\textcircled{1}},\quad\mathrm{R e}z>0   \tag*{(4.2.2)}$$

这积分又称为第二类欧拉(Euler)积分.  $ Re z > 0 $ 是这积分收敛的条件. 可以证明 $ ^{②} $，(4.2.2)式的积分在右半平面( $ Re z > 0 $)中代表一个解析函数.

## 1.  $ \Gamma $ 函数的基本性质

由(4.2.1)式出发，我们可以得到 $ \Gamma $函数的下列几个重要性质：

(1)

 $$ \Gamma(1)=1 $$ 

$$  \Gamma(z+1)=z\Gamma(z)   \tag*{(4.2.4)}$$

$$  \Gamma(n+1)=n!,n=0,1,2,\cdots   \tag*{（4.2.5）}$$

(3)

 $$ \Gamma(z)\Gamma(1-z)=\frac{\pi}{\sin\pi z} $$ 

$$  \Gamma\left(\frac{1}{2}\right)=\sqrt{\pi}   \tag*{(4.2.7)}$$

（4）

$$  \Gamma(2z)=2^{2z-1}\pi^{-\frac{1}{2}}\Gamma(z)\Gamma\Big(z+\frac{1}{2}\Big)   \tag*{(4.2.8)}$$

现在我们来证明这些性质.

证 由（4.2.2）式立即得

 $$ \Gamma(1)=\int_{0}^{\infty}\mathrm{e}^{-t}\mathrm{d}t=1 $$ 

这就在  $ Rez \geq 0 $ 中证明了(4.2.3)式.

<!-- page: 90 -->

将(4.2.2)式中z换成 $ z+1 $，然后分部求积分得

 $$ \Gamma(z+1)=\int_{0}^{\infty}\mathrm{e}^{-t}t^{z}\mathrm{d}t=-\left.\mathrm{e}^{-t}t^{z}\right|_{0}^{\infty}+z\int_{0}^{\infty}\mathrm{e}^{-t}t^{z-1}\mathrm{d}t=z\Gamma(z) $$ 

这就在  $ Rez>0 $ 中证明了(4.2.4)式.

取(4.2.4)式中 z 等于 n (n 为零或正整数) 便得 (4.2.5) 式.

下面分两步来证明(4.2.6)式.首先证明在实轴上一段0<x<1成立等式

$$  \Gamma(x)\Gamma(1-x)=\frac{\pi}{\sin\pi x}   \tag*{(4.2.9)}$$

当 0 < x < 1 时，由(4.2.1)式有

 $$ \begin{align*}\Gamma(x)\Gamma(1-x)&=\int_{0}^{\infty}\mathrm{e}^{-t}t^{x-1}\mathrm{d}t\bullet\int_{0}^{\infty}\mathrm{e}^{-s}s^{-x}\mathrm{d}s\\&=\int_{0}^{\infty}\int_{0}^{\infty}\mathrm{e}^{-(s+t)}\left(\frac{t}{s}\right)^{x}\frac{1}{t}\mathrm{d}s\mathrm{d}t\end{align*} $$ 

作变换

 $$ \xi=s+t,\qquad\eta=\frac{t}{s} $$ 

 $ \xi $ 和  $ \eta $ 都由 0 到  $ \infty $，相应雅可比 (Jacobi) 行列式为

 $$ \left|\frac{\partial(t,s)}{\partial(\xi,\eta)}\right|=\left|\frac{\partial(\xi,\eta)}{\partial(t,s)}\right|^{-1}=\frac{\xi}{(1+\eta)^{2}} $$ 

于是得

 $$ \begin{align*}\Gamma(x)\Gamma(1-x)&=\int_{0}^{\infty}\int_{0}^{\infty}\mathrm{e}^{-\xi}\eta^{x}\frac{1+\eta}{\xi\eta}\bigg|\frac{\partial(t,s)}{\partial(\xi,\eta)}\bigg|\mathrm{d}\xi\mathrm{d}\eta\\&=\int_{0}^{\infty}\mathrm{e}^{-\xi}\mathrm{d}\xi\int_{0}^{\infty}\frac{\eta^{\iota-1}}{1+\eta}\mathrm{d}\eta=\int_{0}^{\infty}\frac{\eta^{\iota-1}}{1+\eta}\mathrm{d}\eta=\frac{\pi}{\sin\pi x}\end{align*} $$ 

在最后一步中用了下一章（5.4.2）式的结果，这就证明了（4.2.9）式. 其次证明（4.2.6）式.

当 0 < Re z < 1 时，函数  $ \Gamma(z)\Gamma(1-z) $ 和  $ \frac{\pi}{\sin\pi z} $ 都是解析函数，而由(4.2.9)式知在定轴上一段 0 < x < 1 上该两函数相等，所以由上一节解析延拓的唯一性可知 (4.2.6) 式在 0 < Re z < 1 中成立.

在(4.2.6)式中取  $ z=\frac{1}{2} $ 便可得到(4.2.7)式.

请读者自己证明(4.2.8)式在 $ Re z>0 $中成立.

## 2.  $ \Gamma $ 函数是半纯函数

在有限区域中除极点外别无其他奇点的函数称为半纯函数. 下面我们证明  $ \Gamma(z) $ 是一个半纯函数.

我们知道(4.2.4)式的两边当 $ Re z>0 $时都是z的解析函数，但 $ \Gamma(z+1) $在更大一些的区域 $ Re z>-1 $中解析，故 $ \Gamma(z+1) $是 $ z\Gamma(z) $在区域 $ Re z>-1 $中的解析延拓.

<!-- page: 91 -->

这样就把  $ \Gamma(z)=\frac{\Gamma(z+1)}{z} $ 的定义域推广到  $ \mathrm{Re}z>-1 $ 中，在这区域中除了 z=0 是  $ \Gamma(z) $ 的一阶极点之外， $ \Gamma(z) $ 处处是解析的.

现在  $ \Gamma(z) $ 已是区域  $ Re z > -1 $ 中有定义的函数，故  $ \Gamma(z+1) $ 在区域  $ Re z > -2 $ 中有定义，而且除了 z = -1 这点以外处处是解析的，因此是  $ \mathrm{z}\Gamma(z) $ 在区域  $ Re z > -2 $ 中的解析延拓。在区域  $ Re z > -2 $ 中， $ \Gamma(z) = \frac{\Gamma(z+1)}{z} = \frac{\Gamma(z+2)}{z(z+1)} $ 有两个一阶极点，z = 0 和 z = -1。

由此类推，可以利用函数关系(4.2.4)式把 $ \Gamma(z) $延拓到全平面。在全平面上，除了z=0,-1,-2,\cdots,-n,\cdots $是一阶极点之外，函数 $ \Gamma(z) $处处是解析的，即 $ \Gamma(z) $是半纯函数。

最后要指出，上面我们虽然只推出了 $ \Gamma $函数的那些基本性质 $ [(4.2.3)\sim(4.2.8)式] $在各自的局部区域中成立，但由解析延拓的唯一性知，它们在全平面中，也均成立 $ ^{③} $.

注 ① 被积函数中  $ t^{z-1}=\mathrm{e}^{(z-1)\mathrm{Lnt}} $ 一般是多值函数，但通常约定在正实轴上  $ \arg t=0 $，即 t>0 时， $ t^{z-1}=\mathrm{e}^{(z-1)\mathrm{Lnt}} $ 中的 Lnt 取实数.

② B. H. 斯米尔诺夫著，叶彦谦译，高等数学教程第三卷第二分册，247页，1958，人民教育出版社.

③如，我们已推得(4.2.4)式： $ \Gamma(z+1)=z\Gamma(z) $ 在  $ \mathrm{Re}z>0 $ 中成立，但等式两边都是除了 z=-1,-2,\cdots $ 外在全平面解析的函数，故由解析延拓的唯一性知(4.2.4)式在全平面上除 z=-1,-2,\cdots 外仍成立。又 z=-1,-2,\cdots 这些点同时是  $ \Gamma(z+1) $ 和  $ z\Gamma(z) $ 的单极点，所以(4.2.4)式又可表示为  $ \frac{\varphi(z)}{(z-1)(z-2)\cdots(z-n)\cdots}=\frac{\psi(z)}{(z-1)(z-2)\cdots(z-n)\cdots} $，其中  $ \varphi(z) $ 和  $ \psi(z) $ 均在全平面解析，故再由解析延拓的唯一性知(4.2.4)式在全平面上成立。类似地可知(4.2.6)和(4.2.8)式亦均在全平面成立。

#### 习题4.2

1. 证明

(1)

 $$ (2n)!!=2^n\Gamma(n+1); $$ 

(2)

 $$ (1+\rho)(2+\rho)\cdots(n+\rho)=\frac{\Gamma(\rho+n+1)}{\Gamma(\rho+1)}; $$ 

(3)  $ \int_{0}^{1}(\ln\frac{1}{x})^{x-1}dx = \Gamma(z) $; (4)  $ \int_{0}^{\infty}e^{-r^{2}}r^{p}dr = \frac{1}{2}\Gamma\left(\frac{p+1}{2}\right) $.

2. 令  $ \psi(z)=\frac{\mathrm{d}\left[\mathrm{Ln}\Gamma(z)\right]}{\mathrm{d}z} $，试分别由（4.2.4）式和（4.2.6）式证明

 $$ \psi(z+1)=\frac{1}{z}+\psi(z) $$ 

 $$ \psi(1-z)=\psi(z)+\pi\mathrm{c o t}\pi z $$ 

3. 计算下列积分：

(1)

 $$ \int_{0}^{\infty}x^{3}\mathrm{e}^{-x}\mathrm{d}x; $$ 

(2)

 $$ \int_{0}^{\infty}x^{6}\mathrm{e}^{-2x}\mathrm{d}x； $$

<!-- page: 92 -->

(3)

 $$ \int_{0}^{\infty}x^{-\alpha}\sin x\mathrm{d}x,0<\alpha<2; $$ 

 $$ \int_{0}^{\infty}x^{-\alpha}\cos x\mathrm{d}x,0<\alpha<1; $$ 

(5)

 $$ \int_{0}^{\infty}x^{a-1}\mathrm{e}^{-x\cos\theta}\cos(x\sin\theta)\mathrm{d}x； $$ 

(6)

 $$ \int_{0}^{\infty}x^{\alpha-1}\mathrm{e}^{-x\cos\theta}\sin(x\sin\theta)\mathrm{d}x. $$ 

在(3)～(6)问中  $ \alpha>0,\quad-\frac{\pi}{2}<\theta<\frac{\pi}{2} $

4. 计算积分  $ I=\int_{-1}^{1}\frac{x^{2n}}{\sqrt{1-x^{2}}}dx $ 之值，n 是正整数.

5. 计算四维单位球的体积 V，其中

 $$ \begin{aligned}&x_{1}=r\sin\varphi_{2}\sin\varphi_{1}\cos\varphi,\quad x_{2}=r\sin\varphi_{2}\sin\varphi_{1}\sin\varphi\\&x_{3}=r\sin\varphi_{2}\cos\varphi_{1},\quad x_{4}=r\cos\varphi_{2}\\ \end{aligned} $$ 

提示: 计算具有坐标轴  $ x_{1}\cdots x_{n} $ 的 n 维球的体积, 可利用积分

 $$ \int_{-\infty}^{\infty}\mathrm{e}^{-(x_{1}^{2}+\cdots+x_{n}^{2})}\mathrm{d}v^{(n)}\;=\int_{0}^{\infty}\mathrm{e}^{-r^{2}}A r^{n-1}\mathrm{d}r\quad(A\mathrm{ 待定 }) $$ 

（芝加哥大学研究生试题）

###  $ ^{4.3} $ B 函数

我们定义

$$  \mathrm{B}(p,q)=\int_{0}^{1}t^{p-1}(1-t)^{q-1}\mathrm{d}t,\quad\mathrm{R e}p>0;\quad\mathrm{R e}q>0   \tag*{(4.3.1)}$$

为B函数，又称为第一类欧拉积分.积分中的被积函数通常是多值函数.若令 $ t=\sin^{2}\varphi $，则易于得到B函数的另一表达式

$$  \mathrm{B}(p,q)=2\int_{0}^{\frac{\pi}{2}}\sin^{2p-1}\varphi\cos^{2q-1}\varphi\mathrm{d}\varphi   \tag*{(4.3.2)}$$

我们将会看到 B 函数与  $ \Gamma $ 函数之间有如下重要关系：

$$   B(p,q)=\frac{\Gamma(p)\Gamma(q)}{\Gamma(p+q)}   \tag*{(4.3.3)}$$

证 当  $ Rep>0 $, Req>0 时，由  $ \Gamma $ 函数的定义 (4.2.2) 式有

 $$ \Gamma(p)=\int_{0}^{\infty}\mathrm{e}^{-t}t^{p-1}\mathrm{d}t,\quad\Gamma(q)=\int_{0}^{\infty}\mathrm{e}^{-t}t^{q-1}\mathrm{d}t $$ 

分别记上二式中的 t 为  $ x^{2} $ 和  $ y^{2} $，于是有

$$  \Gamma(p)=2\int_{0}^{\infty}\mathrm{e}^{-x^{2}}x^{2p-1}\mathrm{d}x   \tag*{(4.3.4)}$$

$$  \Gamma(q)=2\int_{0}^{\infty}\mathrm{e}^{-y^{2}}y^{2q-1}\mathrm{d}y   \tag*{（4.3.5）}$$

在(4.3.4)和(4.3.5)两式中又分别令  $ x=\rho\cos\varphi $ 和  $ y=\rho\sin\varphi $ ，于是得

 $$ \begin{align*}\Gamma(p)\Gamma(q)&=4\int_{0}^{\infty}\int_{0}^{\infty}\mathrm{e}^{-(x^{2}+y^{2})}x^{2p-1}y^{2q-1}\mathrm{d}x\mathrm{d}y\\&=4\int_{0}^{\infty}\int_{0}^{\frac{\pi}{2}}\mathrm{e}^{-\rho^{2}}(\rho\mathrm{c o s}\varphi)^{2p-1}(\rho\mathrm{s i n}\varphi)^{2q-1}\rho\mathrm{d}\rho\mathrm{d}\varphi\end{align*} $$

<!-- page: 93 -->

$$ \begin{aligned}&=4\int_{0}^{\infty}\mathrm{e}^{-\rho^{2}}\rho^{2(p+q)-1}\mathrm{d}\rho\int_{0}^{\frac{\pi}{2}}\cos^{2p-1}\varphi\sin^{2q-1}\varphi\mathrm{d}\varphi\\&=\Gamma(p+q)\mathrm{B}(p,q)\end{aligned} $$ 

最后的结果是通过将上式的倒数第二步与(4.3.4)式和(4.3.2)式对比而得到的.这就证明了(4.3.3)式.

显然，利用(4.3.3)式和Γ函数的解析性，可将B函数从 $ Re p>0, Re q>0 $解析延拓到除了p=0,-1,-2, $ \cdots $;q=0,-1,-2, $ \cdots $外的整个p平面和q平面.

由 B 函数的定义式(4.3.1)或另一表达式(4.3.2)，立即可证得 B 函数的对称关系

$$   B(p,q)=B(q,p)   \tag*{(4.3.6)}$$

#### 习题4.3

1. 利用(4.3.3)式和(4.3.1)式，证明Γ函数的倍乘公式(4.2.8)式

 $$ \Gamma(2z)=2^{2z-1}\pi^{-\frac{1}{2}}\Gamma(z)\Gamma\Big(z+\frac{1}{2}\Big) $$ 

提示：在证明过程中作变量代换  $ t=\frac{1-\sqrt{\xi}}{2} $，并利用  $ \Gamma\left(\frac{1}{2}\right)=\sqrt{\pi} $ 的关系即可得.

2. 利用(4.3.3)式和(4.3.1)式，重证Γ函数的性质(4.2.6)式

 $$ \Gamma(z)\Gamma(1-z)=\frac{\pi}{\sin\pi z} $$ 

提示：在证明过程中作变量代换  $ x=\frac{t}{1-t} $

3. 计算下列积分：

(1) $ \int_{-1}^{1}(1-x^{2})^{n}dx; $

 $$ \int_{-1}^{1}(1-x)^{p}(1+x)^{q}\mathrm{d}x,\mathrm{R e}p>-1,\mathrm{R e}q>-1; $$ 

(3)  $ \int_{0}^{\frac{\pi}{2}}\tan^a\varphi\,d\varphi,\quad|\alpha|<1. $

4. 证明： $ \frac{\Gamma'(a)}{\Gamma(a)}=\lim_{b\to0}\left[\Gamma(b)-\mathrm{B}(a,b)\right] $

<!-- page: 94 -->

<div style="text-align: center;"><img src="images/p0094_img_in_image_box_193_490_257_555.jpg" alt="本章小结" width="6%" /></div>


本章授课课件

<div style="text-align: center;"><div style="text-align: center;">本章小结</div> </div>




<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>定 义</td><td style='text-align: center; word-wrap: break-word;'>性 质</td><td style='text-align: center; word-wrap: break-word;'>方 法</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>解析
延拓</td><td style='text-align: center; word-wrap: break-word;'>设  $ f_1(z)\in\sigma_1 $ 和  $ f_2(z)\in\sigma_2 $ 解析,  $ \sigma_{12}=\sigma_1\cap\sigma_2 $, 若  $ f_1(z)\equiv f_2(z) $ ,  $ f_2(z)\in\sigma_2 $ (或  $ \sigma_1 $) 中解析延拓,  $ f_1(z)\equiv f_2(z) $,  $ f_2(z)\in G $</td><td style='text-align: center; word-wrap: break-word;'>设  $ f_1(z) $ 和  $ f_2(z) $ 在区域 G 中解析, 若  $ f_1(z)\equiv f_2(z) $,  $ z\in G $,  $ g\in G $ 则</td><td style='text-align: center; word-wrap: break-word;'>1. 泰勒展开方法\n2. 函数关系式的方法\n3. 施瓦茨原理</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \Gamma $ 函
数</td><td style='text-align: center; word-wrap: break-word;'>$ \Gamma(z)=\int_{0}^{\infty}e^{-t^{z-1}}dt $,  $ \text{Re}z&gt;0 $</td><td style='text-align: center; word-wrap: break-word;'>1.  $ \Gamma(1)=1 $\n2.  $ \Gamma(z+1)=z\Gamma(z) $,  $ \Gamma(n+1)=n! $\n3.  $ \Gamma(z) $  $ \Gamma(1-z)=\frac{\pi}{\sin\pi z} $,  $ \Gamma\left(\frac{1}{2}\right)=\sqrt{\pi} $\n4.  $ \Gamma(2z)=2^{2z-1}\frac{1}{\sqrt{\pi}}\Gamma(z) $  $ \Gamma(z+\frac{1}{2}) $</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>B 函
数</td><td style='text-align: center; word-wrap: break-word;'>$ B(p,q)=\int_{0}^{1}t^{p-1}(1-t)^{q-1}dt $,  $ \text{Re}p&gt;0 $,  $ \text{Re}q&gt;0 $</td><td style='text-align: center; word-wrap: break-word;'>1.  $ B(p,q)=\frac{\Gamma(p)\Gamma(q)}{\Gamma(p+q)} $\n2.  $ B(p,q)=B(q,p) $</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

<!-- page: 95 -->

由第二章的学习，我们对复变函数的围道积分，已有了相当程度的了解. 我们知道，当  $ f(z) $ 在 l 内解析时，则由柯西定理(2.2.1)式有

 $$ \oint_{l}f(z)\mathrm{d}z=0 $$ 

当  $ f(z) $ 在 l 内有一阶极点时，则由柯西公式 (2.3.2) 式有

 $$ \oint_{l}f(z)\mathrm{d}z=\oint_{l}\frac{\varphi(z)}{z-a}\mathrm{d}z=2\pi\mathrm{i}\varphi(a) $$ 

当  $ f(z) $ 在 l 内有 n 阶极点时，则由解析函数的 n 阶导数公式有

 $$ \oint_{l}f(z)\mathrm{d}z=\oint_{l}\frac{\varphi(z)}{\left(z-a\right)^{n}}\mathrm{d}z=\frac{2\pi\mathrm{i}}{(n-1)!}\varphi^{(n-1)}(a) $$ 

其中，$\varphi(z)$ 在 $l$ 内解析。我们自然会想到，如果 $f(z)$ 在 $l$ 内有有限个孤立奇点（不一定是极点），围道积分 $\oint_{l} f(z) dz$ 的结果又会是怎样的呢？本章留数理论，将可回答我们的这一问题。我们已看到柯西定理和柯西公式等，只能解决围道内被积函数的奇点是极点型的围道积分问题。而从这一章的学习我们将会看到，留数理论不仅能解决奇点为极点，而且还能解决奇点为本性奇点的围道积分问题。它建立了解析函数的积分与函数的奇点的关系，并能用于计算一些实定积分。

### 5.1 留数定理

## 1. 留数定理

设  $ f(z) $ 在以曲线 l 围成的区域  $ \sigma $ 内除有有限个孤立奇点  $ b_{k}(k=1,2,\cdots,n) $ 外单值解析，在闭区域  $ \bar{\sigma} $ 上连续，则有

$$  \oint_{l}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{res}f(b_{k})   \tag*{(5.1.1)}$$

其中， $ \mathrm{res}f(b_{k}) $ 表示  $ f(z) $ 在孤立奇点  $ b_{k} $ 的某（去心）邻域内的洛朗展开的负一次幂  $ \frac{1}{z-b_{k}} $ 的系数，记作

$$   res f(b_{k})=C_{-1}   \tag*{(5.1.2)}$$

<!-- page: 96 -->

<div style="text-align: center;"><img src="images/p0096_img_in_image_box_97_138_313_354.jpg" alt="图5.1" width="22%" /></div>


称做  $ f(z) $ 在它的孤立奇点  $ b_{k} $ 处的留数 (residue). 上述定理被称为留数定理.

证 如图5.1所示，在l内分别以 $ b_{k} $为中心 $ R_{k} $为半径作小圆 $ l_{k}(k=1,2,\cdots,n) $，使 $ l_{k} $均含于l内又彼此互相隔离，则由复连通区域的柯西定理(2.2.6)式有

<div style="text-align: center;"><div style="text-align: center;">图5.1</div> </div>


$$  \oint_{l}f(z)\mathrm{d}z=\sum_{k=1}^{n}\oint_{l_{k}}f(z)\mathrm{d}z   \tag*{(5.1.3)}$$

今在孤立奇点  $ b_{1} $ 的去心邻域中将  $ f(z) $ 展开为洛朗级数

 $$ f(z)=\sum_{k=-\infty}^{\infty}C_{k}(z-b_{1})^{k},\quad0<|z-b_{1}|<R_{1} $$ 

则有

而由(2.1.4)式有

 $$ \begin{align*}\oint_{l_{1}}f(z)\mathrm{d}z&=\sum_{k=-\infty}^{\infty}C_{k}\oint_{l_{1}}(z-b_{1})^{k}\mathrm{d}z\\\oint_{l_{1}}(z-b_{1})^{k}\mathrm{d}z&=\begin{cases}2\pi\mathrm{i},&k=-1\\0,&k\neq-1\end{cases}\\\oint_{l_{1}}f(z)\mathrm{d}z&=C_{-1}\bullet2\pi\mathrm{i}=2\pi\mathrm{i}\mathrm{res}f(b_{1})\end{align*} $$ 

所以

其中

 $$  res f(b_{1})=C_{-1} $$ 

（这也是称 $ C_{-1} $为留数的来由，积分后仅留下系数 $ C_{-1} $）。类似地，我们可得

$$  \oint_{l_{k}}f(z)\mathrm{d}z=2\pi\mathrm{i}\mathrm{res}f(b_{k}),\quad k=2,3,\cdots,n   \tag*{(5.1.5)}$$

将（5.1.4）和（5.1.5）式代入（5.1.3）式有

 $$ \oint_{l}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{res}f(b_{k}) $$ 

由（5.1.4）和（5.1.5）式我们还可得

$$  \mathrm{res}f(b_{k})=\frac{1}{2\pi\mathrm{i}}\oint_{l_{k}}f(z)\mathrm{d}z,\quad k=1,2,\cdots,n   \tag*{（5.1.6）}$$

我们也常将此式作为留数的定义.

## 2. 无穷远点的留数

由(5.1.6)式我们看到，在 $ b_{k} $点，留数的定义是沿逆时针方向（即边界的正向）绕 $ b_{k} $一周的 $ f(z) $的一个围道积分，在围道 $ l_{k} $内，除 $ b_{k} $外别无 $ f(z) $的奇点。因此，类似地我们可定义无穷远点的留数为

$$  \mathrm{res}f(\infty)=\frac{1}{2\pi\mathrm{i}}\oint_{i}f(z)\mathrm{d}z   \tag*{(5.1.7)}$$

其中 l 是沿顺时针方向绕 z=0 一周的围道，且在围道外除  $ z=\infty $ 可能是奇点之外别无  $ f(z) $ 的奇点。这里积分的走向对于含  $ z=\infty $ 的区域说是正向。

<!-- page: 97 -->

今将  $ f(z) $ 在  $ z=\infty $ 的邻域中展开为洛朗级数

$$  f(z)=\sum_{k=-\infty}^{\infty}C_{k}z^{k},\quad R<|z|<\infty   \tag*{(5.1.8)}$$

则

 $$ \oint_{l}f(z)\mathrm{d}z=\sum_{k=-\infty}^{\infty}C_{k}\oint_{l}z^{k}\mathrm{d}z=C_{-1}\bullet2\pi\mathrm{i} $$ 

代入(5.1.7)式有

$$   res f(\infty)=-C_{-1}   \tag*{(5.1.9)}$$

应该注意的是，对于有限远点 b，如果它不是  $ f(z) $ 的奇点，则由(5.1.6)式知  $ \mathrm{res}f(b)=0 $。而对于  $ z=\infty $ 来说，即使它不是  $ f(z) $ 的奇点，只要展开式(5.1.8)式中  $ C_{-1} $ 不为 0， $ \mathrm{res}f(\infty) $ 就不等于零。

由(5.1.6)和(5.1.7)式立即可推得：全平面的留数之和为零.

## 3. 留数的计算方法

为了应用留数定理计算积分，必须掌握计算留数的方法，最基本的方法当然是由留数的定义来求留数。即在奇点的去心邻域将函数展开成洛朗级数，取其负一次幂的系数（对于 $ z=\infty $点要反号）。

例1 求  $ f(z)=\mathrm{e}^{\frac{1}{z}} $ 在本性奇点 z=0 处的留数.

解

 $$ \mathrm{e}^{\frac{1}{z}}=1+\frac{1}{z}+\frac{1}{2!}\cdot\frac{1}{z^{2}}+\cdots,\quad|z|>0 $$ 

故由留数的定义(5.1.2)式有

 $$  resf(0)=C_{-1}=1 $$ 

但上法并不常用，因为有时求洛朗级数比较麻烦，而应用上很重要的奇点是极点，对于极点可以导出如下的比较简单的计算留数的公式，而不必去求洛朗展开的负一次幂的系数.

设b为 $ f(z) $的n阶极点，则

$$  \mathrm{res}f(b)=\frac{1}{(n-1)!}\frac{\mathrm{d}^{n-1}}{\mathrm{d}z^{n-1}}\big[(z-b)^{n}f(z)\big]_{z=b}   \tag*{(5.1.10)}$$

特别是当 n=1 即 b 为  $ f(z) $ 的单极点时，有

$$  \mathrm{res}f(b)=\lim_{z\to b}[(z-b)f(z)]   \tag*{(5.1.11)}$$

证 因为 b 为  $ f(z) $ 的 n 阶极点，故由上一章 n 阶极点的充分必要条件有

 $$ f(z)=\frac{\varphi(z)}{(z-b)^{n}} $$ 

其中， $ \varphi(z) $ 在 b 点的邻域解析. 又由留数定义(5.1.6)式

 $$ \mathrm{res}f(b)=\frac{1}{2\pi\mathrm{i}}\oint_{l}f(z)\mathrm{d}z=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{\varphi(z)}{(z-b)^{n}}\mathrm{d}z $$ 

其中 l 为绕 b 一周的围道，故由解析函数的导数公式(2.3.5)有

<!-- page: 98 -->

$$ \begin{align*}\mathrm{res}f(b)&=\frac{1}{(n-1)!}\left.\frac{\mathrm{d}^{n-1}}{\mathrm{d}z^{n-1}}\varphi(z)\right|_{z=b}\\&=\frac{1}{(n-1)!}\left.\frac{\mathrm{d}^{n-1}}{\mathrm{d}z^{n-1}}\big[(z-b)^{n} f(z)\big]_{z=b}\right.\end{align*} $$ 

此即(5.1.10)式.若取n=1，则

 $$ \mathrm{res}f(b)=\frac{1}{0!}\frac{\mathrm{d}^{0}}{\mathrm{d}z^{0}}\big[(z-b)f(z)\big]_{z=b}=\lim_{z\to b}\big[(z-b)f(z)\big] $$ 

此即(5.1.11)式.

例2  $ f(z)=\frac{ze^{z}}{(z-a)^{3}} $ , 求  $ \operatorname{res}f(a) $.  $ (a \neq 0. $

解 z=a 为  $ f(z) $ 的三阶极点，故由(5.1.10)式有

 $$ \begin{aligned}\operatorname{res}f(a)&=\frac{1}{2!}\frac{\mathrm{d}^{2}}{\mathrm{d}z^{2}}\bigg[(z-a)^{3}\frac{z\mathrm{e}^{z}}{(z-a)^{3}}\bigg]_{z=a}\\&=\frac{1}{2}\mathrm{e}^{a}(2+a)\end{aligned} $$ 

例3  $ f(z)=\frac{1}{1+z^{2}} $，求  $ \mathrm{res}f(i) $.

解 i 为  $ f(z) $ 的单极点，故由(5.1.11)式有

 $$  res f(i)=\lim_{z\to i}(z-i)\bullet\frac{1}{(z-i)(z+i)}=\frac{1}{2i} $$ 

若  $ f(z)=\frac{\varphi(z)}{\psi(z)} $，其中  $ \varphi(z) $ 和  $ \psi(z) $ 均在 b 的邻域中解析，且  $ \varphi(b)\neq0 $，而 b 为  $ \psi(b) $ 的一阶零点（即  $ \psi(b)=0,\psi'(b)\neq0 $），则有

$$   resf(b)=\frac{\varphi(b)}{\psi^{^{\prime}}(b)}   \tag*{(5.1.12)}$$

证 因为 b 为  $ \psi(b) $ 的一阶零点，所以 b 为  $ f(z) $ 的一阶极点（见 3.5 节中 2. 孤立奇点的分类）。故有

 $$ \mathrm{res}f(b)=\lim_{z\to b}(z-b)\frac{\varphi(z)}{\psi(z)}=\lim_{z\to b}\frac{\left[(z-b)\varphi(z)\right]^{\prime}}{\psi^{^{\prime}}(z)}=\frac{\varphi(b)}{\psi^{^{\prime}}(b)} $$ 

例4  $ f(z)=\frac{\mathrm{e}^{iz}}{1+z^{2}} $ , 求  $ \mathrm{res}f(i) $.

解 设  $ \varphi(z)=\mathrm{e}^{\mathrm{i}z} $， $ \phi(z)=1+z^{2} $，故

 $$  res f(i)=\frac{e^{iz}}{2z}\bigg|_{z=i}=\frac{1}{2i e} $$ 

若知道了函数在各奇点处的留数，由留数定理 $ (5.1.1) $式，我们便可计算复变函数的围道积分.

例 5 计算积分

 $$ I=\oint_{|z|=1}\frac{\mathrm{d}z}{\varepsilon z^{2}+2z+\varepsilon},\quad0<\varepsilon<1 $$

<!-- page: 99 -->

解 被积函数的奇点为

 $$ z=\frac{-1\pm\sqrt{1-\epsilon^{2}}}{\epsilon} $$ 

在单位圆  $ |z|=1 $ 内的奇点为

 $$ z_{0}=\frac{-1+\sqrt{1-\varepsilon^{2}}}{\varepsilon} $$ 

是单极点. 于是  $ z_{0} $ 点留数为

 $$ \begin{align*}\mathrm{res}f(z_{0})&=\lim_{z\to z_{0}}\biggl[\biggl(z-\frac{-1+\sqrt{1-\varepsilon^{2}}}{\varepsilon}\biggr)\frac{1}{\varepsilon z^{2}+2z+\varepsilon}\biggr]\\&=\lim_{z\to z_{0}}\frac{1}{\varepsilon\biggl(z-\frac{-1-\sqrt{1-\varepsilon^{2}}}{\varepsilon}\biggr)}=\frac{1}{2\sqrt{1-\varepsilon^{2}}}\end{align*} $$ 

故

 $$ I=\oint_{|z|=1}\frac{\mathrm{d}z}{\varepsilon z^{2}+2z+\varepsilon}=2\pi i\mathrm{res}f(z_{0})=\frac{\pi\mathrm{i}}{\sqrt{1-\varepsilon^{2}}} $$ 

#### 习题5.1

1. 求下列函数在指定点处的留数：

 $$ \frac{z}{(z-1)(z+1)^{2}} $$ 

(2) $ e^{\frac{1}{z-1}} $，在z=1, $ \infty $;

 $$ z=\pm1,\infty; $$ 

(4) $ \frac{z}{\cos z} $，在 $ z=(2k+1)\frac{\pi}{2}(k=0,\pm1,\pm2,\cdots) $;

(5) $ e^{\frac{a}{2}}\left(z-\frac{1}{z}\right) $，在z=0；

2. 求下列函数在其孤立奇点和无穷远点（不是非孤立奇点）的留数：

(1) $ \frac{z^{2m}}{(1+z)^{m}} $(m为自然数)；(2) $ \frac{e^{z}}{z^{2}(z^{2}+9)} $；(3) $ \frac{\sin2z}{(z+1)^{3}} $；

(4) $ z^{3}\cos\frac{1}{z-2}; $ (5) $ \frac{z^{2}+1}{e^{z}}; $ (6) $ \cos\sqrt{\frac{1}{z}}. $

3. 计算下列围道积分：

3. 计算下列图道积分：

(1)  $ \oint_{l}\frac{dz}{z^{4}+1}, l: x^{2} + y^{2} = 2x; $

(2)  $ \oint_{l}\frac{zdz}{(z-1)(z-2)^{2}}, l: |z-2| = \frac{1}{2}; $

(3)  $ \oint_{l}\frac{dz}{(z-3)(z^{5}-1)} $, l: |z|=2;

(4)  $ \frac{1}{2\pi i}\oint_{l}\sin\frac{1}{z}dz $, l: |z|=r.

 $ ^{*} $4. 利用围道积分技术求级数值

 $$ \sum_{n=1}^{\infty}\frac{(-1)^{n}}{n^{4}}=\frac{-7\pi^{4}}{720} $$ 

提示：利用函数  $ 1/\sin\pi z $ 沿实轴，在  $ z=0,\pm1,\pm2,\cdots $ 处有极点的事实，选择适当的围道计算。（芝加哥大学研究生试题）

5. 求解函数  $ f(z)=\int_{c(x)}\Gamma(1+z)\Gamma(1-z)dz $ 的值，其中  $ c(x) $ 是从  $ -i\infty $ 到  $ +i\infty $，沿着  $ \mathrm{Re}(z)=x $ 的围道；x 在 -1 和 +1 之间.

（加州理工学院研究生试题）

<!-- page: 100 -->

### 5.2 利用留数理论计算实积分

在研究物理学的问题时，常常需要计算一些具体的实定积分。如，在研究阻尼振动时，将遇到狄利克雷(Dirichlet)积分 $ \int_{0}^{\infty}\frac{\sin x}{x}dx $；在研究光衍射时，将遇到菲涅耳(Fresnel)积分 $ \int_{0}^{\infty}\sin x^{2}dx $；在研究热传导时，将遇到积分 $ \int_{0}^{\infty}e^{-u^{2}}\cos bx dx(a>0,b= $实数)。这些积分，若用数学分析中计算定积分的方法来计算是相当麻烦有时甚至是不可能的。但是，若将之视为复围道积分中的一部分，而利用留数定理来计算，就会使计算变得简单得多。下面从几种典型类型的积分来说明用留数定理计算实定积分的方法。

## 1. 无穷积分  $ \int_{-\infty}^{\infty} f(x) dx $

若  $ f(z) $ 在实轴上无奇点，在上半平面除了有限个孤立奇点  $ b_{k}(k=1,2,\cdots,n) $ 外是处处解析的；在包括实轴在内的上半平面中，当  $ |z|\to\infty $ 时， $ zf(z) $ 一致趋于零（即，

<div style="text-align: center;"><img src="images/p0100_img_in_image_box_97_636_356_774.jpg" alt="图5.2" width="27%" /></div>


 $$ \forall\varepsilon>0,\exists R>0 $$ 

 $$ \left|z\right|>R $$ 

<div style="text-align: center;"><div style="text-align: center;">图5.2</div> </div>


 $$ \left|z\cdot f(z)\right|<\varepsilon) $$ 

$$  \int_{-\infty}^{\infty}f(x)\mathrm{d}x=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{res}f(b_{k})\mid_{\operatorname{Im}z>0}   \tag*{(5.2.1)}$$

证 考虑  $ f(z) $ 沿如图 5.2 所示围道 l 的积分，则由留数定理(5.1.1)式有

 $$ \oint_{l}f(z)\mathrm{d}z=\int_{-R}^{R}f(x)\mathrm{d}x+\int_{C_{R}}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k}\operatorname{res}f(b_{k})\mid_{l 内 } $$ 

其中  $ \sum_{k}\operatorname{res}f(b_{k})\mid_{l内} $ 表示  $ f(z) $ 在 l 内的孤立奇点处的留数的和. 故当  $ R\to\infty $ 时有

$$  \begin{align*}\lim_{R\to\infty}\int_{-R}^{R}f(x)\mathrm{d}x+\lim_{R\to\infty}\int_{C_R}f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}f(b_k)\mid_{\mathrm{Im}z>0}\end{align*}   \tag*{(5.2.2)}$$

其中  $ \sum_{k=1}^{n} \operatorname{res} f(b_k) \mid_{\operatorname{Im} z > 0} $ 表示  $ f(z) $ 在上半平面的孤立奇点处的留数和。注意无穷积分通常定义为下列极限 $ ^{①} $：

$$  \int_{-\infty}^{\infty}f(x)\mathrm{d}x=\lim\limits_{R_{1}\to\infty\atop R_{2}\to\infty}\int_{-R_{1}}^{R_{2}}f(x)\mathrm{d}x   \tag*{(5.2.3)}$$

显然，此处

$$  \lim_{R\to\infty}\int_{-R}^{R}f(x)\mathrm{d}x=\int_{-\infty}^{\infty}f(x)\mathrm{d}x   \tag*{(5.2.4)}$$

又由题设，当 $ \left|z\right|\rightarrow\infty $时， $ zf(z) $一致趋于0，故有

 $$ \lim_{R\to\infty}\left|\int_{C_{R}}f(z)\mathrm{d}z\right|\leqslant\liminf_{R\to\infty}\int_{C_{R}}\mid z f(z)\mid\frac{\mid\mathrm{d}z\mid}{\mid z\mid} $$

<!-- page: 101 -->

$$  \leqslant\lim_{R\to\infty}\max\mid z f(z)\mid\frac{\pi R}{R}=0   \tag*{(5.2.5)}$$

将（5.2.4）式与（5.2.5）式代入（5.2.2）式便得

 $$ \int_{-\infty}^{\infty}f(x)\mathrm{d}x=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{res}f(b_{k})\mid_{\operatorname{Im}z>0} $$ 

上面做法的精神是把所要计算的实积分看成实轴上的一段 $ (-R $到 $ R) $，补充一段 $ (C_{R}) $，使被积函数在这段上也无奇点，这样构成复平面上的一个围道，再用留数定理计算围道积分.应该注意的是，在补充一段时，应尽量使在这段路线上积分值比较易于计算，像上面(5.2.5)式那样，其值为0是再好不过的了.

例1 求积分  $ I=\int_{-\infty}^{\infty}\frac{\mathrm{d}x}{1+x^{2}} $ 之值.

解

 $$ f(z)=\frac{1}{1+z^{2}} $$ 

奇点为单极点  $ z=\pm i $，在上半平面只有孤立奇点 z=i，当  $ |z|\to\infty $ 时， $ zf(z) $ 一致趋于  $ 0(Imz\geqslant0) $，故由（5.2.1）式和（5.1.11）式有

 $$ I=2\pi i\mathrm{res}f(\mathrm{i})=2\pi\mathrm{i}\bullet\frac{1}{2\mathrm{i}}=\pi $$ 

思考：若  $ f(z) $ 在下半平面有有限个孤立奇点，则用留数定理计算无穷积分  $ \int_{-\infty}^{\infty} f(x) \, dx $ 的公式，应是怎样的？

2. 含有三角函数的无穷积分  $ \int_{0}^{\infty}f(x)\left\{\begin{aligned}&\cos px\\ &\sin px\end{aligned}\right\}\mathrm{d}x $

设  $ f(z) $ 在实轴上无奇点，在上半平面除了有限个孤立奇点  $ b_{k}(k=1,2,\cdots,n) $ 外是处处解析的；在包括实轴的上半平面  $ (0 \leqslant \arg z \leqslant \pi) $ 中，当  $ |z| \to \infty $ 时， $ f(z) $ 一致趋于 0，且 p > 0，则有

 $$ \int_{0}^{\infty}f(x)\cos p x\mathrm{d}x=\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}[f(b_{k})\mathrm{e}^{\mathrm{i}p b_{k}}]_{\mathrm{Im}z>0}\quad[f(x) 为偶函数 ]\quad(5.2.6) $$ 

$$  \int_{0}^{\infty}f(x)\sin p x\mathrm{d}x=\pi\sum_{k=1}^{n}\mathrm{res}\left[f(b_{k})\mathrm{e}^{\mathrm{i}\beta b_{k}}\right]_{\mathrm{Im}z>0}\quad\left[f(x) 为奇函数 \right]   \tag*{(5.2.7)}$$

其中  $ \sum_{k=1}^{n}\mathrm{res}[f(b_k)\mathrm{e}^{\mathrm{ip}b_k}]_{\mathrm{lm}z>0} $ 是函数  $ f(z)\mathrm{e}^{\mathrm{ip}z} $ 在上半平面的留数和.

证 若  $ f(x) $ 为偶函数，则

$$  \begin{align*}\int_{0}^{\infty}f(x)\cos p x\mathrm{d}x=&\int_{0}^{\infty}f(x)\frac{\mathrm{e}^{\mathrm{i}p x}+\mathrm{e}^{-\mathrm{i}p x}}{2}\mathrm{d}x\\=&\frac{1}{2}\Big[\int_{0}^{\infty}f(x)\mathrm{e}^{\mathrm{i}p x}\mathrm{d}x+\int_{-\infty}^{0}f(-x)\mathrm{e}^{\mathrm{i}p x}\mathrm{d}x\Big]\\=&\frac{1}{2}\int_{-\infty}^{\infty}f(x)\mathrm{e}^{\mathrm{i}p x}\mathrm{d}x\end{align*}   \tag*{(5.2.8)}$$

<!-- page: 102 -->

于是可仿照上面所讨论的无穷积分那样，考虑函数  $ f(z)\mathrm{e}^{\mathrm{i}z} $ 沿图 5.2 中的围道的积分

 $$ \begin{aligned}\oint_{l}f(z)\mathrm{e}^{\mathrm{i}pz}\mathrm{d}z=&\int_{-R}^{R}f(x)\mathrm{e}^{\mathrm{i}p x}\mathrm{d}x+\int_{C_{R}}f(z)\mathrm{e}^{\mathrm{i}p z}\mathrm{d}z\\ =&2\pi\mathrm{i}\sum_{k}\mathrm{res}\big[f(b_{k})\mathrm{e}^{\mathrm{i}p b_{k}}\big]_{l 内 }\end{aligned} $$ 

所以

$$  \int_{-\infty}^{\infty}f(x)\mathrm{e}^{\mathrm{i}px}\mathrm{d}x+\lim_{R\to\infty}\int_{C_{R}}f(z)\mathrm{e}^{\mathrm{i}pz}\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}\left[f(b_{k})\mathrm{e}^{\mathrm{i}pb_{k}}\right]_{\mathrm{Im}z>0}   \tag*{(5.2.9)}$$

而当 $ \left|z\right|\rightarrow\infty $时， $ f(z) $在包括实轴的上半平面中一致趋于0，p>0，故由若尔当引理②有

$$  \lim_{R\to\infty}\int_{C_{R}}f(z)\mathrm{e}^{\mathrm{i}pz}\mathrm{d}z=0   \tag*{(5.2.10)}$$

先将(5.2.10)式代入(5.2.9)式，再将(5.2.9)式代入(5.2.8)式即得到(5.2.6)式.

若  $ f(x) $ 为奇函数，则

$$  \int_{0}^{\infty}f(x)\sin p x\mathrm{d}x=\frac{1}{2\mathrm{i}}\int_{-\infty}^{\infty}f(x)\mathrm{e}^{\mathrm{i}p x}\mathrm{d}x   \tag*{（5.2.11）}$$

类似于上面的讨论便可得到(5.2.7)式.

例2 求积分  $ I=\int_{0}^{\infty}\frac{\cos x}{x^{2}+b^{2}}dx $ 之值  $ (b>0) $.

解  $ f(x)=\frac{1}{x^{2}+b^{2}} $ 是偶函数，p=1>0， $ f(z) $ 在上半平面中只有一个一阶极点 z=ib，且当  $ |z|\to\infty $ 时一致趋于零  $ (Im z\geqslant0) $，故由(5.2.6)式有

 $$ I=\pi i\mathrm{res}[f(z)\mathrm{e}^{\mathrm{i}z}]_{z=bi}=\pi\mathrm{i}\left.\frac{\mathrm{e}^{\mathrm{i}z}}{2z}\right|_{z=bi}=\frac{\pi}{2b}\mathrm{e}^{-b} $$ 

思考：若  $ p<0, f(z) $ 在下半平面  $ (-\pi\leq \arg z<0) $ 中满足 (5.2.6) 式和 (5.2.7) 式中的应用条件，其结果如何？

3. 三角函数有理式的积分  $ \int_{0}^{2\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta $

设  $ R(\cos\theta,\sin\theta) $ 为  $ \cos\theta,\sin\theta $ 的有理函数，且在  $ [0,2\pi] $ 上连续，则

$$  \int_{0}^{2\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta=2\pi\mathrm{i}\sum_{k=1}^{n}\operatorname{res}f(z)\mid_{|z|<1}   \tag*{（5.2.12）}$$

其中， $ f(z)=\frac{1}{\mathrm{i}z}R\left(\frac{z+z^{-1}}{2},\frac{z-z^{-1}}{2\mathrm{i}}\right) $;  $ \sum_{k=1}^{n}\operatorname{res}f(z)|_{|z|<1} $，表示 $ f(z) $在单位圆内所有奇点处的留数和.

证 令  $ z = e^{i\theta} $，则  $ \cos\theta = \frac{e^{i\theta} + e^{-i\theta}}{2} = \frac{z + z^{-1}}{2} $;  $ \sin\theta = \frac{e^{i\theta} - e^{-i\theta}}{2i} = \frac{z - z^{-1}}{2i} $;  $ \mathrm{d}z = \mathrm{i}z\mathrm{d}\theta $;  $ 0 \leqslant \theta \leqslant 2\pi $ 变成了单位圆  $ |z| = 1 $. 所以

 $$ \int_{0}^{2\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta=\oint_{|z|=1}\frac{1}{\mathrm{i}z}R\left(\frac{z+z^{-1}}{2},\frac{z-z^{-1}}{2\mathrm{i}}\right)\mathrm{d}z=\oint_{|z|=1}f(z)\mathrm{d}z $$

<!-- page: 103 -->

这里， $ f(z) $ 是 z 的一有理函数，且因为  $ R(\cos\theta,\sin\theta) $ 在  $ [0,2\pi] $ 上连续，故  $ f(z) $ 在  $ \{z\}=1 $ 上亦连续。若  $ f(z) $ 在  $ \{z\}=1 $ 内有 n 个孤立奇点，则由留数定理立即可得上述结论 (5.2.12) 式。

#### 例3 计算积分

 $$ I=\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{1+a\cos\theta},\quad\mid a\mid<1 $$ 

解 令  $ z = e^{i\theta} $，得

 $$ I=\frac{1}{\mathrm{i}}\oint_{|z|=1}\frac{1}{1+\frac{a}{2}\left(z+\frac{1}{z}\right)}\bullet\frac{\mathrm{d}z}{z}=\frac{2}{\mathrm{i}}\oint_{|z|=1}\frac{\mathrm{d}z}{a z^{2}+2z+a} $$ 

函数  $ az^{2}+2z+a $ 有两个一阶零点  $ z_{1}=-\frac{1}{a}+\sqrt{\frac{1}{a^{2}}-1} $， $ z_{2}=-\frac{1}{a}-\sqrt{\frac{1}{a^{2}}}-1 $。它们是被积函数的一阶极点。由于  $ |a|<1 $，故  $ |z_{2}|>1 $， $ |z_{1}|<1 $。即积分围道  $ |z|=1 $ 内只有一单极点  $ z_{1} $，由留数定理（5.1.1）式和单极点处的留数计算公式（5.1.11）有

 $$ I=\frac{2}{\mathrm{i}}\cdot2\pi\mathrm{i}\operatorname{res}\left[\frac{1}{az^{2}+2z+a},z_{1}\right]=\frac{4\pi}{a}\frac{1}{z_{1}-z_{2}}=\frac{2\pi}{\sqrt{1-a^{2}}} $$ 

注意，符号  $ \mathrm{res}[f(z), z_{1}] $ 是表示函数  $ f(z) $ 在  $ z_{1} $ 处的留数。我们应习惯使用各种表示方法。

我们可看出，上面做法的精神是，通过一个变量代换把实轴上的一段变为复平面中的一个闭合回路，从而好用留数定理计算积分.

注 ① 积分主值 在此，我们顺便介绍一下积分主值的概念。(5.2.3)式表示当上下限分别趋于∞时积分的极限值。但有时这样的极限不存在，而是当 $ R_{1}=R_{2}\rightarrow\infty $时极限存在。这后一极限值就称为积分主值，用

$$  P\int_{-\infty}^{\infty}f(x)\mathrm{d}x=\lim_{R\to\infty}\int_{-R}^{R}f(x)\mathrm{d}x   \tag*{(5.2.13)}$$

表示. 显然，如果(5.2.3)式的极限存在，则(5.2.13)的极限值也必定存在，而积分主值与通常意义下的无穷积分值一致；反过来则不一定.

对于有限区间 $ [a,b] $的情况，若 $ f(x) $在 $ [a,b] $内的 $ x_{0} $点无界，且极限 $ \lim_{\delta_{1}\to0}\delta_{1}\int_{a}^{x_{0}}\frac{d x}{f(x)}dx $和 $ \lim_{\delta_{2}\to0}\int_{x_{0}+\delta_{2}}^{b}f(x)dx $均存在，则

 $$ \int_{a}^{b}f(x)\mathrm{d}x\equiv\lim_{\delta_{1}\to0}\int_{a}^{x_{0}-\delta_{1}}f(x)\mathrm{d}x+\lim_{\delta_{2}\to0}\int_{x_{0}+\delta_{2}}^{b}f(x)\mathrm{d}x $$ 

若 $ \lim_{\delta_{1}\to0}\int_{a}^{x_{0}-\delta_{1}}f(x)\mathrm{d}x $ 和  $ \lim_{\delta_{2}\to0}\int_{x_{0}+\delta_{2}}^{b}f(x)\mathrm{d}x $ 均不存在，但  $ \lim_{\delta\to0}\left[\int_{a}^{x_{0}-\delta}f(x)\mathrm{d}x+\int_{x_{0}+\delta}^{b}f(x)\mathrm{d}x\right] $ 却存在，我们称这一极限为积分主值，并记作  $ P\int_{a}^{b}f(x)\mathrm{d}x $. 所以，引用积分主值，实际上是避开积分路径上奇点的方法. 如果原来的积分（如下节中的  $ \int_{0}^{\infty}\frac{\sin x}{x}\mathrm{d}x $ ) 在通常意义下存在，则其值与积分主值是一致的.

② 若尔当(Jordan)引理 设当|z|→∞时函数 f(z)在包括实轴的上半平面(0≤argz≤π)中一

<!-- page: 104 -->

致趋于零，则

$$  \lim_{R\to\infty}\int_{C_{R}}f(z)\mathrm{e}^{\mathrm{i}pz}\mathrm{d}z=0   \tag*{(5.2.14)}$$

其中，p>0； $ C_{R} $ 是以 z=0 为圆心，R 为半径的位于上半平面的半圆（图 5.2）.

思考：若 p<0，则若尔当引理应是怎样的？

③ 此积分在力学和量子力学中甚为重要，由它可以算出开普勒(Kepler)积分

<div style="text-align: center;"><img src="images/p0104_img_in_image_box_764_228_828_292.jpg" alt="图5.3" width="6%" /></div>


若尔当引理的证明

$$  I^{*}=\frac{1}{2\pi}\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{(1+\varepsilon\cos\theta)^{2}}=(1-\varepsilon^{2})^{-3/2}   \tag*{（5.2.16）}$$

因为只要在此例中以  $ \varepsilon/y $ 换  $ a(y > \varepsilon, |\varepsilon| < 1) $ 则得  $ \frac{1}{2\pi}\int_{0}^{2\pi}\frac{\mathrm{d}\theta}{(y + \varepsilon\cos\theta)} = \frac{1}{\sqrt{y^{2} - \varepsilon^{2}}} $. 两边对 y 求导再令 y = 1 即得上述结果.

#### 习题5.2

1. 计算下列积分：

 $$ \int_{-\infty}^{\infty}\frac{1+x^{2}}{1+x^{4}}\mathrm{d}x; $$ 

 $$ \int_{-\infty}^{\infty}\frac{\mathrm{e}^{i\pi k}}{k^{2}+\mu^{2}}\mathrm{d}k(r>0); $$ 

 $$ \int_{0}^{\infty}\frac{\cos ax}{1+x^{4}}\mathrm{d}x(a>0); $$ 

 $$ \int_{0}^{\infty}\frac{x}{x^{2}+a^{2}}\sin bx\mathrm{d}x(a>0,b>0). $$ 

2. 求下列积分：

(1) $ \int_{0}^{2\pi}\frac{1}{1-2b\cos\theta+b^{2}}\mathrm{d}\theta(\mid b\mid<1); $

(2) $ \int_{0}^{2\pi}\frac{1}{1+\cos^{2}\theta}\mathrm{d}\theta; $



(3) $ \int_{0}^{\frac{\pi}{2}}\frac{1}{a+\sin^{2}x}dx(a>0) $;

(4) $ \int_{0}^{\frac{\pi}{2}}\frac{1}{1+\cos^{2}x}dx. $

3. 证明： $ \int_{0}^{\infty}\frac{1}{1+x^{n}}\mathrm{d}x=\frac{\pi}{n}\frac{1}{\sin\frac{\pi}{n}}(n\geqslant2 $，整数).

提示：取如图5.3和图5.4所示围道，则在此围道内 $ f(z)=\frac{1}{1+z^{n}} $有一阶极点 $ \sqrt[n]{-1}=\mathrm{e}^{\mathrm{i}\frac{\pi}{n}} $

<div style="text-align: center;"><img src="images/p0104_img_in_image_box_184_916_461_1152.jpg" alt="图5.4" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.3</div> </div>


<div style="text-align: center;"><img src="images/p0104_img_in_image_box_490_962_774_1148.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.4</div> </div>


 $ ^{*} $4. 证明： $ \int_{0}^{\infty}t^{x-1}\cos tdt=\Gamma(x)\cos\frac{\pi}{2}x,\int_{0}^{\infty}t^{x-1}\sin tdt=\Gamma(x)\sin\frac{\pi}{2}x. $

<!-- page: 105 -->

$ ^{*} $5. 计算积分

(1) $ \int_{0}^{\infty}\frac{x}{\mathrm{e}^{x}-1}\mathrm{d}x; $ (2) $ \int_{0}^{\infty}\frac{x^{3}}{\mathrm{e}^{x}-1}\mathrm{d}x. $

提示：在选择适当围道计算以上积分时，可利用关系

 $$ \int_{0}^{\infty}\frac{x^{n}}{\mathrm{e}^{x}+1}\mathrm{d}x=(1-2^{-n})\int_{0}^{\infty}\frac{x^{n}}{\mathrm{e}^{x}-1}\mathrm{d}x,n>0 $$ 

 $ ^{*} $6. 计算积分

(1) $ \int_{-\infty}^{\infty}\frac{1}{\cosh x}dx; $ (2) $ \int_{-\infty}^{\infty}\frac{1}{\cosh^{3}x}dx. $

提示：可作变换  $ u = \sinh x $.

7. 求极限 $ \lim_{n\to\infty}\sqrt{n}\int_{-\infty}^{\infty}\frac{\mathrm{d}x}{(1+x^2)^n} $之值，其中n为正整数.

8. 计算积分  $ I = \int_{-\infty}^{\infty} \frac{\mathrm{e}^{ax}}{\cosh\pi x} \, \mathrm{d}x $,  $ |\alpha| < \pi $.

（加州理工学院研究生试题）

 $ ^{*} $9. 已知 $ \int_{-\infty}^{\infty}e^{-\alpha x^{2}}\,dx=\sqrt{\frac{\pi}{\alpha}} $，证明

(1)

 $$ \int_{-\infty}^{\infty}x^{2}\mathrm{e}^{-\alpha x^{2}}\mathrm{d}x=\frac{1}{2}\sqrt{\pi}\alpha^{-3/2};\int_{-\infty}^{\infty}x^{4}\mathrm{e}^{-\alpha x^{2}}\mathrm{d}x=\frac{3}{4}\sqrt{\pi}\alpha^{-5/2}； $$ 

(2) 若  $ \beta/\sqrt{\alpha}\ll1 $，且  $ \alpha $ 具有和  $ 1/\sqrt{\alpha} $ 相同的量级，则

 $$ \int_{-\alpha}^{\alpha}f(x)\mathrm{e}^{-\alpha(x^{2}+\beta x^{3})}\mathrm{d}x\approx\int_{-\alpha}^{\alpha}f(x)(1-q\beta x^{3})\mathrm{e}^{-\alpha x^{2}}\mathrm{d}x $$ 

(1983年 CUSPEA 试题)

*10. 计算积分  $ \int_{0}^{2\pi}\frac{1}{a+\cos\varphi}d\varphi $

（1）当a>1时；

（2）当 $ a=a_{0}+i\varepsilon $时，其中， $ 0<a_{0}<1,\varepsilon>0 $且 $ \varepsilon\to0,a_{0} $和 $ \varepsilon $均为实数；

（3）当a=-1时.

 $ ^{*} $11. 试计算

 $$ I=\int_{0}^{2\pi}\frac{b+a\cos\varphi}{a^{2}+b^{2}+2a b\cos\varphi}\mathrm{d}\varphi,\quad\mid a\mid\neq\mid b\mid $$ 

（4～7题和10、11题均为芝加哥大学研究生试题）

### 5.3 物理问题中的几个积分

1. 狄利克雷积分  $ \int_{0}^{\infty}\frac{\sin x}{x}dx $

这是  $ f(x)=\frac{1}{x} $ 在实轴上有奇点的积分，故我们在计算它时当然不能简单的应用（5.2.7）式。由（5.2.11）式有

 $$ \int_{0}^{\infty}\frac{\sin x}{x}\mathrm{d}x=\frac{1}{2\mathrm{i}}\int_{-\infty}^{\infty}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x $$

<!-- page: 106 -->

<div style="text-align: center;"><img src="images/p0106_img_in_image_box_98_140_405_289.jpg" alt="图5.5" width="32%" /></div>


故我们应考虑  $ F(z)=\frac{e^{iz}}{z} $ 沿如图 5.5 所示的路径的积分. 由留数定理（或柯西定理）有

<div style="text-align: center;"><div style="text-align: center;">图5.5</div> </div>


 $$ \begin{aligned}\oint_{l}F(z)\mathrm{d}z=&\int_{-R}^{-r}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x+\int_{C_{r}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z\\&+\int_{r}^{R}\frac{\mathrm{e}^{\mathrm{i}x}}{x}\mathrm{d}x+\int_{C_{R}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z=0\end{aligned} $$ 

而

 $$ \begin{aligned}\int_{-R}^{-r}\frac{\mathrm{e}^{ix}}{x}\mathrm{d}x+\int_{r}^{R}\frac{\mathrm{e}^{ix}}{x}\mathrm{d}x=&\int_{R}^{r}\frac{\mathrm{e}^{-ix}}{x}\mathrm{d}x+\int_{r}^{R}\frac{\mathrm{e}^{ix}}{x}\mathrm{d}x\\=&\int_{r}^{R}\frac{\mathrm{e}^{ix}-\mathrm{e}^{-ix}}{x}\mathrm{d}x=2\mathrm{i}\int_{r}^{R}\frac{\sin x}{x}\mathrm{d}x\end{aligned} $$ 

所以当  $ R \to \infty, r \to 0 $ 时有

$$  2\mathrm{i}\int_{0}^{\infty}\frac{\sin x}{x}\mathrm{d}x+\liminf_{r\to0}\int_{C_{r}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z+\liminf_{R\to\infty}\int_{C_{R}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z=0   \tag*{(5.3.1)}$$

由若尔当引理

 $$ \lim_{R\to\infty}\int_{C_{R}}\frac{\mathrm{e}^{\mathrm{i}z}}{z}\mathrm{d}z=0 $$ 

由小圆弧引理 $ ^{①} $

 $$ \liminf_{r\to0}\int_{C_{r}}\frac{\mathrm{e}^{\mathrm{i}\tau}}{z}\mathrm{d}z=-\pi\mathrm{i} $$ 

一并代入(5.3.1)式有

 $$ \int_{0}^{\infty}\frac{\sin x}{x}\mathrm{d}x=\frac{\pi}{2} $$ 

2. 菲涅耳积分  $ \int_{0}^{\infty}\left\{\begin{aligned}\sin x^{2}\\ \cos x^{2}\end{aligned}\right\}dx $

由5.2处理含三角函数的无穷积分的经验，自然会想到去考虑函数 $ e^{iz^{2}} $沿图5.2所示的围线l的积分，但很快发现该围道不适用，因为 $ \int_{C_{R}}e^{iz^{2}}dz $当 $ R\to\infty,\frac{\pi}{2}<\theta<\pi $时不收敛.经过摸索，选择l为图5.6中围线，则由柯西定理（或留数定理）有

<div style="text-align: center;"><img src="images/p0106_img_in_image_box_630_752_859_956.jpg" alt="图5.6" width="23%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.6</div> </div>


$$  \oint_{l}\mathrm{e}^{\mathrm{i}z^{2}}\mathrm{d}z=\int_{0}^{R}\mathrm{e}^{\mathrm{i}x^{2}}\mathrm{d}x+\int_{C_{R}}\mathrm{e}^{\mathrm{i}z^{2}}\mathrm{d}z+\mathrm{e}^{\mathrm{i}\frac{\pi}{4}}\int_{R}^{0}\mathrm{e}^{-r^{2}}\mathrm{d}r=0   \tag*{(5.3.3)}$$

在 $ C_{R} $上，令 $ z=Re^{i\frac{\theta}{2}} $，则

 $$ \begin{aligned}\left|\int_{C_{R}}\mathrm{e}^{\mathrm{i}z^{2}}\mathrm{d}z\right|&=\left|\frac{\mathrm{i}R}{2}\int_{0}^{\pi/2}\mathrm{e}^{\mathrm{i}R^{2}\left(\cos\theta+\mathrm{i}\sin\theta\right)}\mathrm{e}^{\mathrm{i}\frac{\theta}{2}}\mathrm{d}\theta\right|\\&\leqslant\frac{R}{2}\int_{0}^{\pi/2}\mathrm{e}^{-R^{2}\sin\theta}\mid\mathrm{d}\theta\mid\end{aligned} $$ 

而在 $ \left[0,\frac{\pi}{2}\right] $上，由5.2节注②中图5.3有

 $$ \sin\theta\geqslant\frac{2}{\pi}\theta $$

<!-- page: 107 -->

故

 $$ \left|\int_{C_{R}}\mathrm{e}^{\mathrm{i}z^{2}}\mathrm{d}z\right|\leqslant\frac{R}{2}\int_{0}^{\frac{\pi}{2}}\mathrm{e}^{-\frac{2R^{2}}{\pi}\theta}\mathrm{d}\theta=\frac{\pi}{4R}[1-\mathrm{e}^{-R^{2}}]\xrightarrow{R\to\infty}0 $$ 

X

 $$ \int_{R}^{0}\mathrm{e}^{-r^{2}}\mathrm{d}r\xlongequal{R\to\infty}-\int_{0}^{\infty}\mathrm{e}^{-r^{2}}\mathrm{d}r=-\frac{\sqrt{\pi}}{2} $$ 

令  $ R \to \infty $ 将以上结果代入(5.3.3)式得

 $$ \int_{0}^{\infty}\mathrm{e}^{\mathrm{i}x^{2}}\mathrm{d}x=\mathrm{e}^{\mathrm{i}\frac{\pi}{4}}\cdot\frac{\sqrt{\pi}}{2} $$ 

即

 $$ \begin{aligned}&\int_{0}^{\infty}\cos x^{2}+\mathrm{i}\int_{0}^{\infty}\sin x^{2}\mathrm{d}x=\left(\frac{1}{\sqrt{2}}+\mathrm{i}\frac{1}{\sqrt{2}}\right)\frac{\sqrt{\pi}}{2}\\ &\\ &\quad\int_{0}^{\infty}\cos x^{2}\mathrm{d}x=\int_{0}^{\infty}\sin x^{2}\mathrm{d}x=\frac{\sqrt{2\pi}}{4}\\ \end{aligned} $$ 

故有

3. 热传导问题中的积分  $ \int_{0}^{\infty}e^{-ur^{2}}\cos bx\,dx(a>0,b \text{ 是任意实数}) $

显然，这不能应用公式(5.2.6)来求，因为当 $ \left|z\right|\rightarrow\infty $时 $ e^{-\alpha z^{2}} $在半圆 $ C_{R} $上不一致趋于零。作如下变换

$$  \begin{align*}\int_{0}^{\infty}\mathrm{e}^{-ax^{2}}\cosh x\mathrm{d}x&=\int_{0}^{\infty}\mathrm{e}^{-ax^{2}}\frac{\mathrm{e}^{iyx}+\mathrm{e}^{-iyx}}{2}\mathrm{d}x=\frac{1}{2}\int_{-\infty}^{\infty}\mathrm{e}^{-ax^{2}-iyx}\mathrm{d}x\\&=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\int_{-\infty}^{\infty}\mathrm{e}^{-a\left(x+\frac{iy}{2a}\right)^{2}}\mathrm{d}x=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\int_{l_{1}^{\prime}}\mathrm{e}^{-ax^{2}}\mathrm{d}z\end{align*}   \tag*{（5.3.5）}$$

其中积分路线 $ l_{1}^{\prime} $是与实轴平行、相距为b/2a的由

 $ \mathrm{Re}z=x=-\infty $ 到  $ x=+\infty $ 的无限长直线. 考虑  $ e^{-az^{2}} $

沿如图5.7所示的回路积分，则

 $$ \begin{aligned}\oint_{l}\mathrm{e}^{-az^{2}}\mathrm{d}z=&\int_{l_{1}}\mathrm{e}^{-az^{2}}\mathrm{d}z+\int_{b/2a}^{0}\mathrm{e}^{-a(R+\mathrm{i}y)^{2}}\mathrm{d}(\mathrm{i}y)\\&+\int_{R}^{-R}\mathrm{e}^{-ax^{2}}\mathrm{d}x+\int_{0}^{b/2a}\mathrm{e}^{-a(-R+\mathrm{i}y)^{2}}\mathrm{d}(\mathrm{i}y)=0\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0107_img_in_image_box_585_754_860_961.jpg" alt="图5.7" width="28%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.7</div> </div>


其中， $ l_{1} $ 为从  $ \left(-R,\frac{b}{2a}\right) $ 到  $ \left(R,\frac{b}{2a}\right) $ 的直线段. 于是

 $$ \lim_{R\to\infty}\int_{l_{1}}\mathrm{e}^{-az^{2}}\mathrm{d}z=\int_{l_{1}^{\prime}}\mathrm{e}^{-az^{2}}\mathrm{d}z $$ 

 $$ \left|\int_{0}^{\frac{b}{2a}}\mathrm{e}^{-a(-R+\mathrm{i}y)^{2}}\mathrm{i}\mathrm{d}y\right|\leqslant\mathrm{e}^{-aR^{2}}\int_{0}^{\frac{b}{2a}}\mathrm{e}^{ay^{2}}\mathrm{d}y\xrightarrow{R\to\infty}0 $$ 

同理

 $$ \left|\int\limits_{b/2a}^{0}\mathrm{e}^{-u(R+\mathrm{i}y)^{2}}\mathrm{i}\mathrm{d}y\right|\xrightarrow{R\to\infty}0 $$ 

而

<!-- page: 108 -->

$$ \int_{R}^{-R}\mathrm{e}^{-ax^{2}}\mathrm{d}x\xlongequal{R\to\infty}-\int_{-\infty}^{\infty}\mathrm{e}^{-ax^{2}}\mathrm{d}x=-\frac{1}{\sqrt{a}}\int_{-\infty}^{\infty}\mathrm{e}^{-(\sqrt{a}x)^{2}}\mathrm{d}(\sqrt{a}x)=-\sqrt{\frac{\pi}{a}} $$ 

将这些结果一并代入(5.3.6)式得

 $$ \int_{t_{1}^{\prime}}\mathrm{e}^{-ax^{2}}\mathrm{d}z=\sqrt{\frac{\pi}{a}} $$ 

故由(5.3.5)式得

$$  \int_{0}^{\infty}\mathrm{e}^{-ax^{2}}\cos bx\mathrm{d}x=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\sqrt{\frac{\pi}{a}},\quad a>0   \tag*{(5.3.7)}$$

注 ① 小圆弧引理 设  $ f(z) $ 沿圆弧  $ C_{r}: z - a = r \mathrm{e}^{\mathrm{i}\theta} (\theta_{1} \leqslant \theta \leqslant \theta_{2}, r $ 充分小）上连续且  $ \lim_{r \to 0} [z - a f(z)] = \lambda (\lambda $ 为常数，包括 0) 在  $ C_{r} $ 上一致成立，则

$$  \liminf_{r\to0}\int_{C_{r}}f(z)\mathrm{d}z=\mathrm{i}(\theta_{2}-\theta_{1})\lambda   \tag*{（5.3.8）}$$

<div style="text-align: center;"><img src="images/p0108_img_in_image_box_97_443_327_595.jpg" alt="图5.8" width="24%" /></div>


特别是若 a 为  $ f(z) $ 的一阶极点，则

 $$ \liminf_{r\to0}\int_{C_{r}}f(z)\mathrm{d}z=\mathrm{i}(\theta_{2}-\theta_{1})\operatorname{res}f(a) $$ 

<div style="text-align: center;"><div style="text-align: center;">图5.8</div> </div>


或

$$  \liminf_{r\to0\atop C_{r}}f(z)\mathrm{d}z=\mathrm{i}(\theta_{2}-\theta_{1})\psi(a)   \tag*{（5.3.10）}$$

其中，积分沿逆时针方向进行（图5.8）， $ \psi(z)=(z-a)f(z) $在a的

邻域中解析，且 $ \psi(a)\neq0 $

思考1：若 a 是  $ f(z) $ 高于一阶的极点，(5.3.9) 和 (5.3.10) 式是否还成立？

思考2：你能用证明小弧引理类似的方法证明如下的大弧引理吗？

<div style="text-align: center;"><img src="images/p0108_img_in_image_box_764_654_829_717.jpg" alt="Image" width="6%" /></div>


② 大弧引理 设  $ f(z) $ 在圆弧  $ C_{R}: z = Re^{i\theta} (\theta_1 \leqslant \theta \leqslant \theta_2, R \to \infty) $ 上连续，且 小圆弧引理的证明  $ \lim_{R \to \infty} [zf(z)] = M $ 一致成立，则

$$  \lim_{R\to\infty}\int_{C_{R}}f(z)\mathrm{d}z=\mathrm{i}(\theta_{2}-\theta_{1})M   \tag*{（5.3.11）}$$

##### 习题5.3

1. 证明：若  $ f(z) $ 在实轴上有有限个一阶极点  $ a_{j}(j=1,2,\cdots,m) $，此外还满足 (5.2.1) 式成立的其他条件，则

$$  \int_{-\infty}^{\infty}f(x)\mathrm{d}x=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}f(b_{k})\mid_{\mathrm{Im}z>0}+\pi\mathrm{i}\sum_{j=1}^{m}\mathrm{res}f(a_{j})\mid_{\mathrm{Im}z=0}   \tag*{（5.3.12）}$$

2. 证明：若  $ f(z) $ 在实轴上有有限个一阶极点  $ a_{j}(j=1,2,\cdots,m) $，此外还满足公式(5.2.6)和(5.2.7)成立的其他条件，则

$$  \int_{-\infty}^{\infty}f(x)\mathrm{e}^{\mathrm{i}\beta x}\mathrm{d}x=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}\left[f(b_{k})\mathrm{e}^{\mathrm{i}\beta b_{k}}\right]_{\mathrm{Im}z>0}+\pi\mathrm{i}\sum_{j=1}^{m}\mathrm{res}\left[f(a_{j})\mathrm{e}^{\mathrm{i}\beta a_{j}}\right]_{\mathrm{Im}z=0}   \tag*{（5.3.13）}$$

于是有

$$  \begin{array}{r l r}&{}&{\int_{0}^{\infty}f(x)\mathrm{c o s}p x\mathrm{d}x=\pi\mathrm{i}\displaystyle\sum_{k=1}^{n}\mathrm{r e s}\bigl[f(b_{k})\mathrm{e}^{\mathrm{i}p b_{k}}\bigr]_{\mathrm{I m}z>0}+\frac{\pi}{2}\mathrm{i}\displaystyle\sum_{j=1}^{m}\mathrm{r e s}\bigl[f(a_{j})\mathrm{e}^{\mathrm{i}p a_{j}}\bigr]_{\mathrm{I m}z=0}}\\ &{}&{\big[f(-x)=f(x)\big]}\end{array}   \tag*{（5.3.14）}$$

$$  \begin{array}{r l r}&{}&{\int_{0}^{\infty}f(x)\sin p x\mathrm{d}x=\pi\displaystyle\sum_{k=1}^{n}\mathrm{r e s}\bigl[f(b_{k})\mathrm{e}^{\mathrm{i}\rho b_{k}}\bigr]_{\mathrm{I m}z>0}+\frac{\pi}{2}\displaystyle\sum_{j=1}^{m}\mathrm{r e s}\bigl[f(a_{j})\mathrm{e}^{\mathrm{i}\rho a_{j}}\bigr]_{\mathrm{I m}z=0}}\\ &{}&{\bigl[f(-x)=-f(x)\bigr]}\end{array}   \tag*{（5.3.15）}$$

<!-- page: 109 -->

3. 计算下列积分：

(1) $ \int_{-\infty}^{\infty}\frac{dx}{x^{4}-1}; $ (2) $ \int_{-\infty}^{\infty}\frac{dx}{x(x+1)(x^{2}+1)}. $

4. 计算下列积分：

(1) $ \int_{0}^{\infty}\frac{\sin x}{x(x^{2}+1)^{2}}\mathrm{d}x; $ (2) $ \int_{0}^{\infty}\frac{\sin x}{x(x^{2}+a^{2})}\mathrm{d}x,\quad a>0; $

(3) $ \int_{-\infty}^{\infty}\frac{\sin^{3}x}{x^{3}}dx; $ (4) $ \int_{0}^{\infty}\frac{\cos ax-\cosh x}{x^{2}}dx,\quad a\geqslant0,b\geqslant0; $

(5) $ \int_{-\infty}^{\infty}\frac{x\sin x}{x^{2}+4x+20}dx; $ (6) $ \int_{-\infty}^{\infty}\frac{x\cos x}{x^{2}+4x+20}dx. $

5. 计算下列积分：

(1)  $ \int_{-\infty}^{\infty}\frac{e^{ax}}{1+e^{x}}dx,\quad0<a<1; $

(2)  $ \int_{-\infty}^{\infty}\frac{e^{ax}-e^{bx}}{1-e^{x}}dx,\quad0<b<a<1; $

(3)  $ \int_{0}^{\infty}\frac{\sin x}{\sin x}dx; $

(4)  $ \int_{-\infty}^{\infty}\frac{\cos mx}{e^{x}+e^{-x}}dx. $

提示：对于(3)问，考虑 $ f(z)=\frac{e^{iz}}{shz} $沿如图5.9的闭路径上的积分.

 $$ \mathrm{e}^{ax}/\sinh(\pi x) $$ 

 $$ \int_{0}^{\infty}\frac{\sinh(\alpha x)}{\sinh(\pi x)}\mathrm{d}x=\frac{1}{2}\tan\frac{\alpha}{2},\quad\mid\alpha\mid<\pi $$ 

（第4题（3）问和6题为芝加哥大学研究生试题）

 $ ^{*} $7. 计算半径为 R 的四维球的体积 V，即计算积分

 $$ V=\int\mathrm{d}x_{1}\mathrm{d}x_{2}\mathrm{d}x_{3}\mathrm{d}x_{4} $$ 

 $$ 0\leqslant x_{1}^{2}+x_{2}^{2}+x_{3}^{2}+x_{4}^{2}\leqslant R^{2}. $$ 

<div style="text-align: center;"><img src="images/p0109_img_in_image_box_569_533_858_766.jpg" alt="图5.9" width="30%" /></div>


(1981年 CUSPEA 试题)

<div style="text-align: center;"><div style="text-align: center;">图5.9</div> </div>


###  $ ^{*} $5.4 多值函数的积分

被积函数是多值函数的情形，一定要适当割开平面，使其能分出单值解析分支，

<div style="text-align: center;"><img src="images/p0109_img_in_image_box_100_933_406_1230.jpg" alt="图5.10" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.10</div> </div>


才能应用柯西定理或留数定理来求出给定的积分值。下面我们将通过两个具体的例子，来了解如何计算多值函数的积分。

## 1. 欧拉积分  $ \int_{0}^{\infty}\frac{x^{\alpha-1}}{1+x}dx $ （ $ 0 < \alpha < 1 $）

其被积函数  $ f(z)=\frac{z^{a-1}}{1+z} $ 的支点为 0 和  $ \infty $.

从0点沿正实轴到 $ \infty $作支割线，则可划出单值分支.在 $ 0\leq\arg z\leq2\pi $所确定的单值分支中，考虑 $ f(z)=\frac{z^{a-1}}{1+z} $沿如图5.10所示的围道的积分，则在此围道内函数有单极点z=-1，故由

<!-- page: 110 -->

留数定理有

$$  \begin{aligned}\oint_{l}\frac{z^{a-1}}{1+z}\mathrm{d}z=&\int_{\varepsilon}^{R}\frac{x^{a-1}}{1+x}\mathrm{d}x+\int_{C_{R}}\frac{z^{a-1}}{1+z}\mathrm{d}z+\int_{R}^{\varepsilon}\frac{x^{a-1}\mathrm{e}^{\left[2\pi(a-1)\right]}}{1+x}\mathrm{d}x\\ &+\int_{C_{L}}\frac{z^{a-1}}{1+z}\mathrm{d}z=2\pi\mathrm{i}\mathrm{res}\Big[\frac{z^{a-1}}{1+z},-1\Big]\end{aligned}   \tag*{(5.4.1)}$$

因为

 $$ \begin{aligned}\int_{\varepsilon}^{R}\frac{x^{a-1}}{1+x}\mathrm{d}x&\xlongequal{R\to\infty}\int_{0}^{\infty}\frac{x^{a-1}}{1+x}\mathrm{d}x\\\left|\int_{C_{R}}\frac{z^{a-1}}{1+z}\mathrm{d}z\right|\leqslant\int_{C_{R}}\left|\frac{z^{a-1}}{1+z}\right|\bullet\mid\mathrm{d}z\mid\leqslant\frac{R^{a-1}}{R-1}\bullet2\pi R=\frac{2\pi R^{a}}{R-1}\xrightarrow{R\to\infty}0\\\int_{R}^{\varepsilon}\frac{x^{a-1}\mathrm{e}^{\mathrm{i}2\pi(a-1)}}{1+x}\mathrm{d}x=&-\mathrm{e}^{\mathrm{i}2\pi(a-1)}\int_{\varepsilon}^{R}\frac{x^{a-1}}{1+x}\mathrm{d}x\xlongequal{\varepsilon\to0}-\mathrm{e}^{\mathrm{i}2\pi(a-1)}\int_{0}^{\infty}\frac{x^{a-1}}{1+x}\mathrm{d}x\end{aligned} $$ 

在 $ C_{\varepsilon} $上， $ z=\varepsilon e^{i\theta} $（ $ \theta $由 $ 2\pi $到0），

 $$ \left|\left(z-0\right)\frac{z^{\alpha-1}}{1+z}\right|=\left|\varepsilon\mathrm{e}^{i\theta}\frac{\varepsilon^{\alpha-1}\mathrm{e}^{i\theta(a-1)}}{1+\varepsilon\mathrm{e}^{i\theta}}\right|\leqslant\varepsilon\bullet\frac{\varepsilon^{\alpha-1}}{1-\varepsilon}\xrightarrow{\varepsilon\rightarrow0}0 $$ 

故由上节小圆弧引理有

 $$ \int_{C_{\varepsilon}}\frac{z^{a-1}}{1+z}\mathrm{d}z\xrightarrow{\varepsilon\to0}0 $$ 

而

 $$ \mathrm{res}\Big[\frac{z^{a-1}}{1+z},-1\Big]=\lim_{z\to-1}(1+z)\frac{z^{a-1}}{1+z}=\mathrm{e}^{(a-1)\pi\mathrm{i}}=-\mathrm{e}^{a\pi\mathrm{i}} $$ 

把这些结果代入(5.4.1)式

 $$ [1-\mathrm{e}^{\mathrm{i}2\pi(a-1)}]\int_{0}^{\infty}\frac{x^{a-1}}{1+x}\mathrm{d}x=-2\pi\mathrm{i}\mathrm{e}^{a\pi\mathrm{i}} $$ 

所以

$$  \int_{0}^{\infty}\frac{x^{a-1}}{1+x}\mathrm{d}x=\frac{\pi}{\sin\alpha\pi}   \tag*{(5,4,2)}$$

2. 含对数函数的积分  $ \int_{0}^{\infty}\frac{\ln x}{(1+x^{2})^{2}}dx $

<div style="text-align: center;"><img src="images/p0110_img_in_image_box_97_944_401_1083.jpg" alt="图5.11" width="31%" /></div>


对数函数  $ \ln z $ 是一多值函数，其支点为 0 和  $ \infty $，因此，要计算如上的含对数函数的积分，需先连接 0 和  $ \infty $ 作支割线划出单值分支，然后在  $ 0 \leq \arg z \leq 2\pi $ 所确定的单值分支中计算此积分.

<div style="text-align: center;"><div style="text-align: center;">图5.11</div> </div>


考虑  $ f(z)=\frac{\ln z}{(1+z^{2})^{2}} $ 沿如图 5.11 所示的

围道积分，则在此围道内被积函数有唯一的二阶极点 z=i，于是由留数定理有

$$  \begin{aligned}&\int_{\epsilon}^{R}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x+\int_{\mathrm{C}_{R}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z+\int_{-R}^{\neg\epsilon}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x\\ &+\int_{\mathrm{C}_{r}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=2\pi\mathrm{i}\mathrm{res}f(\mathrm{i})\\ \end{aligned}   \tag*{(5.4.3)}$$

<!-- page: 111 -->

而当  $ R \to \infty, \varepsilon \to 0 $ 时有

 $$ \int_{\varepsilon}^{R}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x=\int_{0}^{\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x $$ 

 $$ \int_{-R}^{\neg\epsilon}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x=\int_{R}^{\epsilon}\frac{\ln(-x)}{(1+x^{2})^{2}}\mathrm{d}(-x)=\int_{0}^{\infty}\frac{\ln x+\mathrm{i}\pi}{(1+x^{2})^{2}}\mathrm{d}x $$ 

又因为 $ \lim_{z\to\infty}\frac{z\ln z}{(1+z^2)^2}=0,\lim_{z\to0}\frac{z\ln z}{(1+z^2)^2}=0 $，故由大弧引理（5.3.11）式和小弧引理（5.3.8）式，分别有

 $$ \lim_{R\to\infty}\int_{C_{R}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=0 $$ 

 $$ \lim_{\varepsilon\to0}\int_{C_{\varepsilon}}\frac{\ln z}{(1+z^{2})^{2}}\mathrm{d}z=0 $$ 

而

 $$ \mathrm{res}f(i)=\frac{\mathrm{d}}{\mathrm{d}z}\Big[(z-\mathrm{i})^{2}\left.\frac{\ln z}{(1+z^{2})^{2}}\right]\Big|_{z=i}=\frac{\pi+2\mathrm{i}}{8} $$ 

将上述结果代入(5.4.3)式得

 $$ 2\int_{0}^{\infty}\frac{\ln x}{(1+x^{2})^{2}}\mathrm{d}x+\mathrm{i}\pi\int_{0}^{\infty}\frac{1}{(1+x^{2})^{2}}\mathrm{d}x=-\frac{\pi}{2}+\frac{\pi^{2}}{4}\mathrm{i} $$ 

故有

$$  \int_{0}^{\infty}\frac{\ln x}{\left(1+x^{2}\right)^{2}}\mathrm{d}x=-\frac{\pi}{4}   \tag*{(5.4.4)}$$

$$  \int_{0}^{\infty}\frac{1}{(1+x^{2})^{2}}\mathrm{d}x=\frac{\pi}{4}   \tag*{(5.4.5)}$$

思考:可以选择如图5.10的围道来计算此积分吗?

#### 习题5.4

1. 计算下列积分：

(1)

 $$ \int_{0}^{\infty}\frac{\sqrt{x}\ln x}{\left(1+x\right)^{2}}\mathrm{d}x; $$ 

 $$ \int_{0}^{\infty}\frac{\sqrt{x}}{(1+x)^{2}}\mathrm{d}x. $$ 

提示：考虑 $ \int_{C}\frac{\sqrt{z}\ln z}{(1+z)^{2}}dz $，其中C如图5.12所示.

2. 计算下列积分：

(1) $ \int_{-1}^{1}\frac{\mathrm{d}x}{(x-2)\sqrt{1-x^{2}}} $

提示：从-1到1沿正实轴作支割线，在单值分支中考虑函数 $ \frac{1}{(z-2)\sqrt{(1-z^{2})}} $沿如图5.13所示路径的积分.

(2)

 $$ \int_{0}^{\infty}\frac{x^{a}}{(x^{2}+1)^{2}}\mathrm{d}x\quad(-1<\alpha<3)\text{；} $$ 

(3)

 $$ \int_{0}^{\infty}\frac{\ln x}{(x^{2}+1)^{2}}\mathrm{d}x； $$

<!-- page: 112 -->

(4)

 $$ \int_{0}^{\infty}\frac{\ln^{3}x}{(1+x)^{2}(1+x^{2})}\mathrm{d}x. $$ 

<div style="text-align: center;"><img src="images/p0112_img_in_image_box_163_204_443_469.jpg" alt="图5.12" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.12</div> </div>


<div style="text-align: center;"><img src="images/p0112_img_in_image_box_507_224_795_470.jpg" alt="图5.13" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图5.13</div> </div>


3. 计算积分

(1) $ \int_{0}^{\infty}\frac{\sin x}{\sqrt{x}}\mathrm{d}x; $ (2) $ \int_{0}^{\infty}\frac{\sin x^{2}}{x}\mathrm{d}x. $

 $ ^{*} $4. 计算梅林(Melin)变换型积分

 $$ \dot{I}=\int_{0}^{\infty}\frac{x^{1/2}}{1+x^{2}}\mathrm{d}x $$ 

（芝加哥大学研究生试题）

 $ ^{*} $5. 什么正数值 n 能使下列对数型积分有界？

 $$ I_{n}=\int_{0}^{\infty}\frac{\sqrt{x}\log x}{x^{n}+1}\mathrm{d}x $$ 

由变量代换或其他方法证明  $ I_{3}=0 $，并用围道积分计算  $ I_{2} $

（加州理工学院研究生试题）

<!-- page: 113 -->

### 本章小结

本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="4">可用来计算实积分</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{l $内的孤立奇点 $ \uparrow $ $ \operatorname*{lim}_{\varepsilon \to b_k}[(z-b_k)f(z)], b_k $ 为单极点 $ \frac{\operatorname{res}f(b_k)}{C_1}=C_1=\left\{\begin{array}{l}\frac{1}{(n-1)!}\frac{\mathrm{d}^{n-1}}{\mathrm{d}z^{n-1}}[(z-b_k)^n f(z)]=b_k, b_k $ 为  $ n $ 阶极点\\\oint_l f(z)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}f(b_k)\rightarrow\oint_l f(z)\mathrm{d}z=2\pi\mathrm{i}\mathrm{res}f(\infty),\mathrm{res}f(\infty)=-C_1\end{array}\right. $思想:将实积分与一复变函数围道积分联系起来.</td><td rowspan="2"></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>具体步骤 $ \left\{\begin{array}{l}1.\text{视}\int_{a}^{b}f(x)\mathrm{d}x\text{的}[a,b]\text{为复平面实轴上不含}f(x)\text{奇点的一段}l_1.\\2.\text{或补充一段(或几段)}l_2,\text{使}l_1+\sum_{k}l_k=\text{闭合回路}[(k=2,3,\cdots);\text{或作变数变换,使实轴上}[a,b]\text{变为复平面中闭合回路}l_2.\\3.\text{用留数定理计算}\oint_{l}f(z)\mathrm{d}z.\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>几类典型实积分</td><td rowspan="2">$ \left\{\begin{array}{l}1.\int_{-\infty}^{\infty}f(x)\mathrm{d}x=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}f(b_k)\vert_{\mathrm{Im}(z)&gt;0}+\pi\sum_{j=1}^{m}\mathrm{res}f(a_j)\vert_{\mathrm{Im}=0}\\2.\int_{0}^{\infty}f(x)\cos p x\mathrm{d}x=\pi\sum_{k=1}^{n}\mathrm{res}[f(b_k)\mathrm{e}^{ip b_k}]_{\mathrm{Im}(z)&gt;0}+\frac{\pi}{2}\sum_{j=1}^{m}\mathrm{res}[f(a_j)\mathrm{e}^{ip a_j}]_{\mathrm{Im}=0}\quad[p&gt;0,f(x)=f(-x)]\\3.\int_{0}^{\infty}f(x)\sin p x\mathrm{d}x=\pi\sum_{k=1}^{n}\mathrm{res}[f(b_k)\mathrm{e}^{ip b_k}]_{\mathrm{Im}(z)&gt;0}+\frac{\pi}{2}\sum_{j=1}^{m}\mathrm{res}[f(a_j)\mathrm{e}^{ip a_j}]_{\mathrm{Im}=0}\quad[p&gt;0,f(-x)=-f(x)]\\4.\int_{0}^{2\pi}R(\cos\theta,\sin\theta)\mathrm{d}\theta=\oint_{|z|=1}\frac{1}{i\tau}R\left(\frac{z+z^{-1}}{2},\frac{z-z^{-1}}{2i}\right)\mathrm{d}z=2\pi\mathrm{i}\sum_{k=1}^{n}\mathrm{res}f(b_k)\quad(|z|&lt;1\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>6.\int_{0}^{\infty}\cos x^2\mathrm{d}x=\int_{0}^{\infty}\sin x^2\mathrm{d}x=\frac{\sqrt{2\pi}}{4}\\7.\int_{0}^{\infty}\mathrm{e}^{-ax^2}\cos ax\mathrm{d}x=\frac{1}{2}\mathrm{e}^{-\frac{x^2}{4a}}\sqrt{\frac{\pi}{a}}\quad(a&gt;0)\\8.\int_{0}^{\infty}\frac{x^{n-1}}{1+x}\mathrm{d}x=\frac{\pi}{\sin\alpha}\quad(0&lt;\alpha&lt;1)</td></tr></table>

<!-- page: 114 -->

要想探求自然界的奥秘就得解微分方程。

——牛顿

## 第二篇 数学物理方程

数学物理方程主要是指从物理学及其他各门自然科学、技术科学中而产生的偏微分方程，有时也包括和此有关的积分方程、微分积分方程和常微分方程。本篇将用6章的篇幅着重讨论物理学中所涉二阶线性偏微分方程及其典型的求解方法。然而，随着现代科学技术的发展，非线性方程和积分方程也是众多物理问题不可回避的方程，故本篇的最后两章对这部分内容也作了简单介绍。

<!-- page: 115 -->

### 6.1 引 言

## 1. 数学物理方程

单从物理的角度而言，数学物理方程（简称数理方程）是指从物理问题中导出的反映客观物理量在各个地点、各个时刻之间相互制约关系的一些偏微分方程（有时也包括常微分方程和积分方程）。换而言之，它是物理过程的数学表达式。它所研究的范围十分广泛，从连续介质力学、传热学和电磁场理论，到等离子体物理、固体物理和非线性光学等；从线性问题到非线性问题。但传统的数学物理方程，却主要是指二阶线性偏微分方程。

传统的数理方程按照所代表的物理过程（或状态）一般可分为三类：

（1）描述振动和波动特征的波动方程

 $$ u_{t t}=a^{2}\Delta u+f $$ 

其中  $ u=u(x,y,z;t) $ 代表平衡时坐标为  $ (x,y,z) $ 的点在 t 时刻的位移（未知函数），a 是波传播的速度， $ f=f(x,y,z;t) $ 是与源有关的已知函数， $ \Delta $（或记作  $ \nabla^{2} $）是拉普拉斯（Laplace）算符（简称为拉氏算符） $ ^{①} $

 $$ \Delta\equiv\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

而

 $$ u_{tt}=\frac{\partial^{2}u}{\partial t^{2}} $$ 

（2）反映输运过程的扩散（或热传导）方程

 $$ u_{t}=D\Delta u+f $$ 

其中  $ u=u(x,y,z;t) $ 表示物质的浓度（或物体的温度），D 是扩散（或热传导）系数， $ f=f(x,y,z;t) $ 是与源有关的已知量， $ u_{t}=\frac{\partial u}{\partial t} $.

（3）描绘稳定过程（或状态）的泊松(Poisson)方程

 $$ \Delta u=-h $$ 

其中  $ u=u(x,y,z) $ 是表示稳定现象特征的物理量，如静电场中的电势等， $ h=h(x,y,z) $ 是与源有关的已知量.

这三类方程，其未知函数 u 的偏微商最高只有二阶，且 u 及其各阶偏微商都是以

<!-- page: 116 -->

线性的关系（即只有一次项）出现，故均属二阶线性偏微方程。在数学上，它们分别被称为双曲型方程，抛物型方程和椭圆型方程 $ ^{②} $。

## 2. 用数理方程研究物理问题的步骤

数理方程是以物理学与工程技术中的具体问题作为研究对象的，简单地说，它是把对物理问题的研究“翻译”为对数学问题的研究。为了使这个“翻译”及其研究工作做得既完整又准确，一般我们需经三个步骤。

（1）提出定解问题. 它包括泛定方程，即数理方程本身和定解条件，即确定具体问题的特解所需要的条件两方面. 同一类事物可用同一类方程描述，即泛定方程只是提供了解决问题的一般规律（同一类事物的共性），而定解条件提供了解决问题的具体条件（具体问题的个性），故它们总是同时提出，作为一个整体，称为定解问题. 它是根据物理学的规律和实验资料而提出的.

（2）求解. 提出了定解问题，实际上就完成了将物理问题“翻译”成数学语言的解释工作，下面紧接着面临的，当然应是对所提出的定解问题进行求解. 二阶线性偏微分方程的常用求解方法大致可归纳为如下几种：

① 行波法（或达朗贝尔解法）；

② 分离变量法；

③ 积分变换法；

④ 格林函数（或积分公式）法：

⑤ 变分法.

此外，对于有些具体问题，当我们无法得到其解析解（或不需要得到其解析解）时，还可采用近似方法求解。以上各解法，我们将在本篇以后各章中一一阐述。

（3）分析解答。作为用数理方程研究物理问题，仅仅求出了解答当然是不够的，还必须分析解的物理意义并论证解在数学上的存在性、唯一性和稳定性。至于物理意义，显然，不同的问题有不同的物理内涵。而存在性，是指验证所求得的解是否满足方程。唯一性，是指讨论在什么样的定解条件下，对于哪一函数类，方程的解是唯一的。通过对唯一性问题的研究，可以明确，对于一定的方程，需要多少个以及哪一些定解条件才能唯一地确定一个解。稳定性，是指讨论当定解条件有微小改变时，解是否也只有微小变化。若是，解就是稳定的。对于这个问题的讨论尤为重要，因为在把一个物理问题表成数学问题时，一般总会做一些简化或者理想化的假定，与真实情况有出入。研究了稳定性问题，就可以对于解的近似程度作出估计。

一个定解问题，若其解是存在、唯一而且是稳定的，就称为是适定的（即在物理上是适当而确定的）。

在本篇中，我们将主要介绍一些求解方法，而对于解的物理意义特别是解的适定性，我们只在适当的地方稍作讨论。

<!-- page: 117 -->

## 3. 数理方程的特点

从上面的介绍和分析我们看到，数理方程一方面紧密地、直接地联系着物理学中的许多问题，另一方面它又要广泛地运用数学中许多部门的成果，所以，它成为数学理论与物理学的实际问题之间的桥梁。我们在学习它时，要密切注意它的内容与物理学中各种有关现象的联系；要能熟练地掌握所讲述的解决问题的方法，并根据问题的性质来确定使用的方法；要灵活地把其他数学部门的知识运用到数理方程中来。

在这一篇的学习中，我们除了会经常用到数学分析中的许多基本内容外，还要用到复变函数论和泛函分析中的一些基本知识与方法。其他，如几何、代数、常微分方程的一些基本知识也常会用到。

注 ① 为清楚起见，有时也常将三维的拉普拉斯算符记作  $ \Delta_{3} $，而二维的记作  $ \Delta_{2} $，即

 $$ \Delta_{3}=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

 $$ \Delta_{2}=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}} $$ 

② 见参考文献 $ ^{[2]} $第179页.

### 6.2 三类数理方程的导出

由上一节的学习，我们已看到数理方程（即泛定方程）本身，在物理学的研究中起着重要的作用，那么，究竟如何从物理学的实际问题中导出数理方程呢？在这一节里，我们就将以几个具体的物理模型为例，来导出代表物理过程（或状态）的三类数理方程，从而掌握导出（或建立）数理方程的一般步骤（或规律）。

## 1. 弦的横振动方程

设有一根细长而柔软的弦线，紧绷于 A、B 两点之间，在平衡位置 AB 附近产生振幅极为微小的横振动，求这弦上各点的运动规律.

为了解决这个问题，如图 6.1 所示，我们就

将弦的平衡位置选在 x 轴上，并以  $ u(x, t) $ 表示

弦上 x 点在时刻 t 沿垂直于 x 轴方向的位移.



由于弦是细长的，这就意味着弦可看作是均匀的，其线密度  $ \rho(x,t) $ 将不随 x 变化。即  $ \rho(x,t)=\rho(t) $ 且任一小段的重量可忽略不计；由于弦紧绷于 A、B 两点之间，这说明弦中各相邻部分之间受有拉力即张力；由于弦是柔软的，这就意味着弦没有抗弯力，在放松的情况下，把它弯成任意

<div style="text-align: center;"><img src="images/p0117_img_in_image_box_566_960_858_1203.jpg" alt="图6.1" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.1</div> </div>

<!-- page: 118 -->

的形状它都保持不变，而紧绷以后，相邻小段之间的张力总是沿着弦线的切线方向；由于弦作微小横振动，故相邻两点沿振动方向的位移的差别很小，即 $ u_{x}=\frac{\partial u}{\partial x} $是小量，而 $ u_{x}^{2}\approx0 $.

现在，我们从弦中任意划出不包括端点(A、B)的一小段 $ \Delta x $，考虑这一小段与邻近部分的相互作用。在振动过程中这一小段 $ \Delta x $变成了弧 $ \widehat{M_{1}M_{2}} $，注意

 $$ \widehat{M_{1}M_{2}}=\int_{x}^{x+\Delta x}\sqrt{1+(u_{x})^{2}}\mathrm{d}x\approx\int_{x}^{x+\Delta x}\mathrm{d}x=\Delta x $$ 

即这一小段的长度在振动过程中可认为是不变的. 因此由胡克(Hooke)定律知张力和线密度也都不随 t 而变, 即  $ T(x, t) = T(x) $,  $ \rho(t) = \rho $ (常数). 我们来分析  $ \widehat{M_{1}M_{2}} $ 的受力情况, 如图 6.1 所示.

（1） $ M_{1} $ 点受有张力  $ T_{1} $，它在 y 轴方向的分力为  $ -T_{1}\sin\alpha_{1} $，在 x 轴方向的分力为  $ -T_{1}\cos\alpha_{1} $；

（2） $ M_{2} $ 点受有张力  $ T_{2} $，它在 y 轴方向的分力为  $ T_{2}\sin\alpha_{2} $，在 x 轴方向的分力为  $ T_{2}\cos\alpha_{2} $;

（3）设 $ \widehat{M}_{1}\widehat{M}_{2} $受有沿y轴方向的外力 $ F(x+\eta_{1}\Delta x,t)\Delta x $（注意， $ \widehat{M}_{1}\widehat{M}_{2}=\Delta x $）。其中 $ F(x,t) $表示单位长度所受的外力， $ 0<\eta_{1}\leq1 $

则由牛顿(Newton)第二定律有

 $$ \begin{array}{c}F(x+\eta_{1}\Delta x,t)\Delta x+T_{2}\sin\alpha_{2}-T_{1}\sin\alpha_{1}=(\rho\Delta x)u_{tt}(x+\eta_{2}\Delta x,t),\quad0<\eta_{2}\leqslant1\\ T_{2}\cos\alpha_{2}-T_{1}\cos\alpha_{1}=0\end{array} $$ 

注意到  $ \sin\alpha=\frac{\tan\alpha}{\sqrt{1+\tan^{2}\alpha}}=\frac{u_{x}}{\sqrt{1+u_{x}^{2}}}\approx u_{x} $，故有

 $$ \sin\alpha_{1}\approx u_{x}(x,t),\quad\sin\alpha_{2}\approx u_{x}(x+\Delta x,t) $$ 

 $$ \cos\alpha_{1}=\sqrt{1-\sin^{2}\alpha_{1}}\approx1,\quad\cos\alpha_{2}=\sqrt{1-\sin^{2}\alpha_{2}}\approx1 $$ 

从而有

 $$ T_{1}=T_{2}=T $$ 

于是

 $$ (\rho\Delta x)u_{tt}(x+\eta_{2}\Delta x,t)=F(x+\eta_{1}\Delta x,t)\Delta x+T[u_{x}(x+\Delta x,t)-u_{x}(x,t)] $$ 

 $$ u_{t t}(x+\eta_{2}\Delta x,t)=\frac{T}{\rho}\frac{u_{x}(x+\Delta x,t)-u_{x}(x,t)}{\Delta x}+\frac{F(x+\eta_{1}\Delta x,t)}{\rho} $$ 

对上式两边取极限（令  $ \Delta x \to 0 $）则得

$$  u_{t t}=a^{2}u_{x x}+f(x,t)   \tag*{(6.2.1)}$$

其中

$$  a^{2}=\frac{T}{\rho},\qquad f(x,t)=\frac{F(x,t)}{\rho}   \tag*{(6.2.2)}$$

此即弦的横振动方程. 若 f=0 ，即弦在振动过程中不受外力，则

$$  u_{t t}=a^{2}u_{x x}   \tag*{(6.2.3)}$$

它称为弦的自由振动方程.

<!-- page: 119 -->

对照上节所述，我们可看到弦的横振动方程是一维的波动方程。用类似的方法我们可推出杆的纵振动方程、理想传输线的电报方程也是这个方程；薄膜的横振动方程是二维的波动方程；而流体力学与声学方程是三维的波动方程。在此我们均不一一推导。

## 2. 热传导方程

设有一根横截面积为 A 的均匀细杆，沿杆长方向有温度差，其侧面绝热，考虑其热量传播的过程.

由于杆是均匀而又细的，所以在任何时刻，都可以把杆的横截面上的温度视为相同的；由于其侧面绝热，因此热量只会沿着杆长方向传导。所以，这是一个一维的热传导问题。

为方便起见，如图 6.2 所示，取杆与 x 轴重合，以  $ u(x, t) $ 表示杆上 x 点处 t 时刻的温度。现在，仿照上面导出弦振动方程一样，从杆的内部中划出一小段  $ \Delta x $，考察这一小段，在时间间隔  $ \Delta t $ 内热量流动的情况。



<div style="text-align: center;"><img src="images/p0119_img_in_image_box_545_495_857_551.jpg" alt="图6.2" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图6.2</div> </div>


设 c 为杆的比热容（单位物质升高单位温度所需热量，它与物质的材料有关）， $ \rho $ 为杆的密度，则

（1）在 $ \Delta t $时间内引起小段 $ \Delta x $温度升高，所需热量为

 $$ Q=c(\rho A\Delta x)\big[u(x,t+\Delta t)-u(x,t)\big] $$ 

故当  $ \Delta t \to 0 $ 时

 $$ Q\approx c\rho A u_{t}\Delta x\Delta t $$ 

而傅里叶(Fourier)实验定律告诉我们：当物体内有温度差存在时，热量由温度高处向温度低处流动，单位时间流过单位面积的热量 q (热流密度) 与温度的下降率成正比

$$  q=-k\frac{\partial u}{\partial n}   \tag*{(6.2.4)}$$

其中，k 为导热率（与物体的材料有关，且严格地说来也与温度有关，但若温度的改变范围不大，可视为与温度无关）； $ \frac{\partial u}{\partial n} $ 的方向，是所通过曲面的外法线方向；而负号表示由温度高处流向温度低处。故

（2）在  $ \Delta t $ 时间内沿 x 轴正向流入 x 处截面的热量为

 $$ Q_1(x)=-ku_x(x,t)A\Delta t $$ 

（3）在  $ \Delta t $ 时间内由  $ x + \Delta x $ 处的截面流出的热量为

 $$ Q_{2}(x+\Delta x)=-ku_{x}(x+\Delta x,t)A\Delta t $$ 

又设杆内有热源，其热源强度为  $ F(x,t) $ （单位时间内单位体积所放出的热量），则

（4）在  $ \Delta t $ 内，杆内热源在  $ \Delta x $ 段产生的热量为

<!-- page: 120 -->

$$ Q_{3}=F(x,t)(A\Delta x)\Delta t $$ 

根据能量守恒定律，流入 $ \Delta x $段的总热量与 $ \Delta x $段中热源产生的热量，应正好是 $ \Delta x $段温度升高所吸收的热量，即

 $$ Q=Q_{1}-Q_{2}+Q_{3} $$ 

故有

 $$ \begin{align*}c\rho A u_{t}\Delta x\Delta t=&-k u_{x}(x,t)A\Delta t+k u_{x}(x+\Delta x,t)A\Delta t+F A\Delta x\Delta t\\c\rho u_{t}=&\frac{k\big[u_{x}(x+\Delta x,t)-u_{x}(x,t)\big]}{\Lambda x}+F\end{align*} $$ 

令  $ \Delta x \to 0 $ 两边取极限

 $$ u_{t}=\frac{k}{c\rho}u_{x x}+\frac{F}{c\rho} $$ 

即

$$  u_{t}=D u_{x x}+f(x,t)   \tag*{（6.2.5）}$$

其中

$$  D=\frac{k}{c\rho},\quad f=\frac{F}{c\rho}   \tag*{(6.2.6)}$$

此即一维的热传导方程。用类似的方法可推出一维的扩散方程也是这个方程，当然也可推出三维的热传导（扩散）方程。

## 3. 泊松方程

设在充满了介电常数  $ \varepsilon $ 的介质区域中有体密度为  $ \rho(x,y,z) $ 的电荷，试研究这个区域中的静电场.

由于静电场中存在一势函数  $ V(x,y,z) $

$$  E=-{\nabla}V   \tag*{(6.2.7)}$$

其中 E 为电场强度。故要研究此问题，只需研究此区域中电势函数 V 所遵循的规律即可。在所要研究的区域中，任作一封闭曲面 S，围出一块空间区域  $ \tau $，则由电学中奥-高(Oersted-Gauss)定理有

 $$ \oint_{s}\boldsymbol{E}\cdot\mathrm{d}\boldsymbol{S}=\frac{1}{\varepsilon}\int_{\tau}\rho\mathrm{d}\tau $$ 

这里采用的是国际单位制. 又由数学中的高斯(Gauss)公式有

 $$ \oint_{s}\boldsymbol{E}\bullet\mathrm{d}\boldsymbol{S}=\int_{\tau}\nabla\bullet\boldsymbol{E}\mathrm{d}\tau $$ 

故有

 $$ \int_{\tau}\nabla\bullet E\mathrm{d}\tau=\frac{1}{\varepsilon}\int_{\tau}\rho\mathrm{d}\tau $$ 

由于 $ \tau $是任意的，因此

 $$ \nabla\bullet E=\frac{1}{\varepsilon}\rho $$ 

将（6.2.7）式代入上式即得

$$  \Delta V=-{\frac{1}{\varepsilon}}\rho^{ \textcircled{1} }   \tag*{(6.2.8)}$$

此即泊松方程（在真空中  $ \varepsilon = \varepsilon_{0} $）。若在我们所讨论的区域中无电荷，则（6.2.8）式变为

<!-- page: 121 -->

$$  \Delta V=0   \tag*{(6.2.9)}$$

此即拉普拉斯方程（简称为拉氏方程）。

不难看出，在三维（或二维）的热传导问题中，若达到了稳定状态，则热量将停止流动，各处温度不再变化，即 $ u_{t}=0 $。故此时热传导方程 $ u_{t}=D\Delta u+f $将变为 $ D\Delta u+f=0 $，即

 $$ \Delta u=-{\frac{f}{D}} $$ 

故稳定温度场亦满足泊松方程.

到此为止，我们已从三个实例出发推导出了物理上的三类典型方程，从以上推导过程我们看出，建立（导出）数理方程一般要经历以下三个步骤：

（1）从所研究的系统中划出一小部分，分析邻近部分与这一小部分的相互作用；

（2）根据物理学的规律（如前面所用的牛顿第二定律、能量守恒定律、奥-高定理等），以算式表达这个作用；

（3）化简、整理，即得数理方程.

当然，以上三类方程，并非能包揽物理中的一切问题，如，量子力学中的薛定谔（Schrödinger）方程

$$  \mathrm{i}\hbar\frac{\partial\psi}{\partial t}=-\frac{\hbar^{2}}{2\mu}\Delta\psi+U(r)\psi   \tag*{（6.2.10）}$$

其中，h 是普朗克(Planck)常量， $ \mu $ 是粒子质量， $ \psi(r,t) $ 是波函数， $ U(r) $ 是势函数；还有反映孤波问题的 KdV 方程

$$  u_{t}+\sigma u u_{x}+u_{x x x}=0   \tag*{(6.2.11)}$$

（其中， $ \sigma $ 为常数， $ u(x,t) $ 为位移）等，均不属这三类方程。我们将在本篇第十二章中介绍。

注 ① 高斯定理及微分算子的运算参见附录Ⅰ.

#### 习题6.2

1. 在弦的横振动问题中，若弦受到一与速度成正比的阻尼，试导出弦的阻力振动方程为

 $$ u_{t t}+c u_{t}=a^{2}u_{x x} $$ 

其中，c 是常数。又考虑回复力与弦的位移成正比时的情形，证明这时所得到的数理方程为

 $$ u_{t t}+c u_{t}+b u=a^{2}u_{x x} $$ 

其中 b 是常数. 此方程称为电报方程.

2. 试导出均匀细杆的纵振动方程

 $$ u_{t t}=a^{2}u_{x x}+f $$ 

其中  $ a^{2}=\frac{E}{\rho} $， $ f=\frac{F(x,t)}{\rho} $；E 为杨氏模量， $ \rho $ 为杆的密度，F 为单位长度的杆沿杆长方向所受的外力。

提示：应用胡克定律（应力  $ P = E \frac{\partial u}{\partial x} $）.

3. 在一维热传导方程  $ u_{t}=Du_{xx} $ 中，假设热量因杆的物质放射衰变（按指数规律）而有损失，证

<!-- page: 122 -->

明上述方程将变为

 $$ u_{t}=D u_{x x}-h\mathrm{e}^{-\omega t} $$ 

其中 h 和  $ \alpha $ 都是大于零的常数.

4. 试导出三维的热传导方程.

5. 设扩散物质的源强为  $ F(x,y,z;t) $ (单位体积内，在单位时间所产生的扩散物质)，试根据能斯特(Nernst)定律(通过介面  $ \mathrm{d}\sigma $ 流出的扩散物质为  $ -D\nabla u\cdot d\boldsymbol{\sigma} $) 和能量守恒定律导出扩散方程

 $$ u_{t}=D\Delta u+F $$ 

其中 D 为扩散系数.

6. 一长为 l 的匀质柔软轻绳，其一端固定在一竖直轴上。绳子以匀角速  $ \omega $ 转动，试导出此绳相对于水平线的横振动方程。

7. 一长为 l 的匀质柔软重绳，其上端固定在一竖直轴上，绳子和轴以匀角速  $ \omega $ 转动，试导出此绳在重力作用下相对于竖直轴的横振动方程.

8. 真空中电磁场的麦克斯韦(Maxwell)方程组的微分形式为

$$  \left\{\begin{aligned}&\nabla\bullet\boldsymbol{E}=0\\ &\nabla\times\boldsymbol{E}=-\frac{1}{c}\boldsymbol{H}_{t}\\ &\nabla\bullet\boldsymbol{H}=0\\ &\nabla\times\boldsymbol{H}=\frac{1}{c}\boldsymbol{E}_{t}\end{aligned}\right.   \tag*{(6.2.12)}$$

试由这一组方程，导出电磁波方程

$$  \begin{cases}E_{tt}=c^{2}\Delta E\\H_{tt}=c^{2}\Delta H\end{cases}   \tag*{（6.2.13）}$$

其中，E 和 H 分别为真空中的电场强度和磁场强度.

9. 试导出理想传输线的电报方程

$$  \begin{cases}V_{tt}=a^{2}V_{xx}\\I_{tt}=a^{2}I_{xx}\end{cases}   \tag*{（6.2.14）}$$

式中，V 和 I 分别是理想传输线上的电压、电流； $ a^{2}=\frac{1}{Cl} $；C 和 L 分别为单位长度上的电容和电感。

### 6.3 定解条件

## 1. 引入定解条件的必要性

从上一节对几个典型方程的推导我们看到，在推导方程时，我们总是选取物体内部不包含端点或者边界的一小部分来讨论其运动，从而导出方程。即，所得到的方程只反映物体内各部分的运动相互之间的联系。从物理的角度看，仅有方程还不足以确定物体的运动。因为物体的运动还与起始状态以及通过边界所受到的外界作用有关。另外，从数学的角度看，一个微分方程的通解中往往含有若干个任意常数或者任意函数，这就使得其解不能唯一确定。为了得到唯一确定的合理解，我们必须根据不同的

<!-- page: 123 -->

实际问题加上相应的条件来确定这些任意常数的数值和任意函数的形式。这些附加条件，就是初始条件和边界条件，统称它们为定解条件。

## 2. 初始条件

对于含有时间变量 t 的数理方程而言，其未知函数将随 t 不同而有不同的值，故必然要反映某一时刻的物理量与相邻时刻的同一物理量之间的关系，所以我们在求解这一类问题时，往往必须追溯到早先某个所谓“初始”时刻的状况，我们称物理过程初始状况的数学表达式为初始条件。

对于波动方程而言，初始条件给出的是初始位移

$$  u(x,y,z;t)\mid_{t=0}=\varphi(x,y,z)   \tag*{(6.3.1)}$$

和初始速度

$$  u_{t}(x,y,z;t)\mid_{t=0}=\psi(x,y,z)   \tag*{(6.3.2)}$$

其中  $ \varphi(x,y,z) $ 和  $ \psi(x,y,z) $ 是已知函数。如，一根长为 l 而两端固定的弦，用手把它的中点横向拨开距离 h（图 6.3），然后放手任其振动，则其初始条件为

 $$ \begin{aligned}&u(x,t)\mid_{t=0}=\left\{\begin{aligned}&(2h/l)x,&&0\leqslant x\leqslant l/2\\ &(2h/l)(l-x),&&l/2\leqslant x\leqslant l\end{aligned}\right.\\ &u_{t}(x,t)\mid_{t=0}=0\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0123_img_in_image_box_573_518_850_742.jpg" alt="图6.3" width="28%" /></div>


对于热传导（扩散）方程而言，初始条件给出的是初始温度（浓度）分布

<div style="text-align: center;"><div style="text-align: center;">图6.3</div> </div>


$$  u\mid_{t=0}=\varphi(x,y,z)   \tag*{(6.3.3)}$$

其中  $ \varphi(x,y,z) $ 为已知函数. 如，热传问题中若物体起始时刻处于零度，则初始条件为

 $$ u(x,y,z;t)\mid_{t=0}=0 $$ 

显然，从数学角度看，关于时间变量 t 的  $ n (n=1,2,\cdots) $ 阶方程，就需给出 n 个初始条件。因为必须对变量 t 积分 n 次，才能由  $ \frac{\partial^{n} u}{\partial t^{n}} $ 求得 u，这就会出现对于 t 而言的 n 个常数，故需给出 n 个条件才能确定这些常数。

对于泊松方程和拉普拉斯方程而言，当然根本不用提及初始条件，因为它们均不含有时间变量.

## 3. 边界条件

由于泛定方程中的未知函数均是空间位置的函数，这必然反映连续体的物理量在某一位置的取值与其相邻位置的取值之间的关系。这种关系延伸到被研究区域的边界，将与边界状况发生联系，即边界状况将通过逐点影响我们所要讨论的整个区域。所以，我们在求解方程时必须考虑边界状况。我们称物理过程边界状况的数学表

<!-- page: 124 -->

达式为边界条件. 边界条件主要有以下三类：

（1）第一类边界条件. 又称为狄利克雷条件. 它给出了未知函数在边界上的值. 即

$$  u\mid_{ 边 }=f(M,t)   \tag*{(6.3.4)}$$

其中，M代表区域边界上的变点， $ f(M,t) $是已知函数（下面也均一样）。如，杆的热传导问题，若在x=l处的一端温度为 $ T_{0}e^{-t} $，则

 $$ u\mid_{x=l}=T_{0}\mathrm{e}^{-t} $$ 

又如，长为 l 两端固定的弦的横振动问题，其边界条件为

 $$ u\mid_{x=0}=0,\quad u\mid_{x=l}=0 $$ 

（2）第二类边界条件. 又称为诺伊曼(Neumann)条件. 它给出了未知函数在边界上的法线方向的导数之值. 即

$$  u_{n}\mid_{ 边 }=f(M,t)   \tag*{（6.3.5）}$$

如，杆的导热问题，若已知在一端 x=l 处流入的热流密度为  $ \phi(t) $，则

而由(6.2.4)式有

故

 $$ \begin{aligned}-q\mid_{x=l}&=\psi(t)\\q=-ku_{x}\\ku_{x}\mid_{x=l}&=\psi(t)\\u_{x}\mid_{x=l}=\frac{1}{k}\psi(t)\end{aligned} $$ 

即

<div style="text-align: center;"><img src="images/p0124_img_in_image_box_96_701_366_841.jpg" alt="图6.4" width="28%" /></div>


又如，长为 l 的细杆的纵振问题，若一端受有外力，单位面积所受的力为  $ F(t) $（图 6.4），则在 x=l 端的边界条件为

<div style="text-align: center;"><div style="text-align: center;">图6.4</div> </div>


$$  u_{x}\mid_{x=l}=\frac{1}{E}F(t)^{\textcircled{1}}   \tag*{(6.3.6)}$$

其中 E 为杨氏模量. 若该端点是自由的, 即不受外力（外力 F=0）则

$$  u_{x}\mid_{x=l}=0   \tag*{(6.3.7)}$$

（3）第三类边界条件. 又称为混合边界条件. 它给出了未知函数和它的法线方向上的导数的线性组合在边界上的值. 即

$$  (u+hu_{n})\mid_{ 边 }=f(M,t)   \tag*{(6.3.8)}$$

其中，h 为常数。如，在杆的导热问题中，若某个端点 x=l 自由冷却，即这个端点与周围介质按牛顿冷却定律[物体冷却时放出的热量 -k $ \nabla u $ 与物体外界的温度差 $ (u|_{边}-u_0) $ 成正比，其中  $ u_0 $ 为周围介质的温度。]交换热量，则在这端点的边界条件为

 $$ -ku_{x}\mid_{x=l}=H(u\mid_{x=l}-u_{0}) $$ 

其中，H为常数.所以

 $$ (u+hu_{x})_{x=l}=u_{0} $$ 

其中  $ h=\frac{k}{H} $. 又如，杆的纵振动问题，若一端 x=l 与一个一端固定的弹簧相连（如

<!-- page: 125 -->

图6.5所示)，在杆的平衡位置弹簧的伸长（或压缩）为零，则弹簧力为 $ F(t)=-ku(l,t) $，其中，k为弹簧的劲度系数，参考(6.3.6)式，故在x=l端的边界条件为

 $$ (u_{x}+h u)\mid_{x=l}=0 $$ 

<div style="text-align: center;"><img src="images/p0125_img_in_image_box_572_139_859_297.jpg" alt="图6.5" width="29%" /></div>


其中, $ h=\frac{k}{E} $

<div style="text-align: center;"><div style="text-align: center;">图6.5</div> </div>


以上三类边界条件中，若 f=0，则分别称为第一、第二、第三类齐次边界条件.

当然，边界条件并不只限于以上三类，还有各式各样的边界条件，有时甚至是非线性的边界条件。比如，在热传导问题中有辐射条件

 $$ \left.-\frac{\partial u}{\partial n}\right|_{ 边 }=C(u^{4}\mid_{ 边 }-u_{0}^{4}) $$ 

其中 C 是一个常数， $ u_{0} $ 是外界的温度，u 和  $ u_{0} $ 都是绝对温标。

除了初始条件和边界条件外，有些具体的物理问题还需附加一些其他条件才能确定其解.

## 4. 其他条件

在研究具有不同介质的问题中，这时方程的数目增多，除了边界条件外，还需加上不同介质界面处的衔接条件。如，用两根不同质料的杆接成的一根杆的纵振动问题，在连接处位移相等，应力也相等，故在连接点  $ x=x_{0} $ 应满足下列衔接条件

$$  \left\{\begin{array}{l}\boldsymbol{u}_{1}\mid_{x=x_{0}}=\boldsymbol{u}_{2}\mid_{x=x_{0}}\\ \boldsymbol{E}_{1}\frac{\partial\boldsymbol{u}_{1}}{\partial x}\bigg|_{x=x_{0}}=\boldsymbol{E}_{2}\frac{\partial\boldsymbol{u}_{2}}{\partial x}\bigg|_{x=x_{0}}\end{array}\right.   \tag*{(6.3.10)}$$

其中， $ u_{1}=u_{1}(x,t) $ 和  $ u_{2}=u_{2}(x,t) $ 分别代表杆的两部分位移， $ E_{1} $ 和  $ E_{2} $ 分别为两部分的杨氏模量；在静电场问题里，在两种电介质的交界面 S 上，电势应当相等（连续），电势移矢量的法向分量也应当相等（连续），因而有衔接条件

$$  u_{1}\mid_{s}=u_{2}\mid_{s}   \tag*{(6.3.11)}$$

$$  \left.\varepsilon_{1}\frac{\partial u_{1}}{\partial n}\right|_{s}=\left.\varepsilon_{2}\frac{\partial u_{2}}{\partial n}\right|_{s}   \tag*{（6.3.12）}$$

其中  $ u_{1} $ 和  $ u_{2} $ 分别代表两种电介质的电势， $ \varepsilon_{1} $ 和  $ \varepsilon_{2} $ 则分别为两种电介质的介电常数. 设它们的电势移矢量分别为  $ D_{1} $ 和  $ D_{2} $，则由

 $$ D_{1n}\mid_{s}=D_{2n}\mid_{s} $$ 

和电动力学中关系式

 $$ \mathbf{D}=\varepsilon\mathbf{E}=-\varepsilon\nabla u $$ 

立即可得(6.3.12)式 $ (D_{1n} $ 和  $ D_{2n} $ 分别代表  $ D_{1} $ 和  $ D_{2} $ 的法向分量).

在某些情况下，出于物理上的合理性等原因，要求解为单值、有限，提出所谓自然边界条件。这些条件通常都不是要研究的问题直接明确给出的，而是根据解的特性要

<!-- page: 126 -->

求自然加上去的，故称为自然边界条件。如，欧拉方程

 $$ x^{2}y^{\prime \prime}+2xy^{\prime}-l(l+1)y=0\quad\quad(l=0,1,2,\cdots) $$ 

的通解是

 $$ y=A x^{l}+B x^{-(l+1)} $$ 

在区间 $ [0,a] $中，由于受在物理上要求解有限的条件限制，故有自然边界条件

 $$ y\mid_{x=0}\to 有限 $$ 

从而在 $ [0,a] $中其解应表示为

 $$ y=A x^{l} $$ 

## 5. 三类定解问题

我们知道，定解问题是由泛定方程和定解条件组成，而定解条件又主要是由初始条件和边界条件组成。但是，并非所有的定解问题中，都一定同时具有初始条件和边界条件。有些只有初始条件而无边界条件（如第七章要讲的“无界弦的自由振动”），我们称之为初值问题或柯西问题；有些只有边界条件而无初始条件（如，第九、十等章中均要涉及的狄氏问题），我们称之为边值问题；而有些既有初始条件又有边界条件（如，第八章要讨论的“有界弦的自由振动”），我们称之为混合问题。

注 ① 边界条件(6.3.6)的证明见二维码.

<div style="text-align: center;"><img src="images/p0126_img_in_image_box_751_612_816_674.jpg" alt="Image" width="6%" /></div>


#### 习题6.3

边界条件(6.3.6)的证明

1. 长为 l 两端固定的弦，作振幅极其微小的横振动，试写出其定解条件.

2. 半无限的理想传输线，一端加上正弦电压，试写出其定解问题.

3. 长为 l 的均匀杆，两端受拉力  $ F(t) $ 而作纵振动，写出边界条件.

4. 长为 l 的均匀杆，两端有恒定热流流入，其热流密度为  $ q_{0} $，试写出这个热传导问题的边界条件.

5. 弹簧原长为 l，一端固定，另一端被拉离平衡位置 b 而静止，放手任其振动，写出定解条件.

6. 长为 l 的弹性杆，两端受压，长度缩短为  $ l(1-2\varepsilon) $，放手后自由振动，试写出其初始条件；若一端受压缩短为  $ l(1-2\varepsilon) $，其初始条件又如何？

7. 一根长为 l 导热杆由两段构成，二段的热传导系数、比热、密度分别为  $ k_{1} $、 $ c_{1} $、 $ \rho_{1} $ 和  $ k_{2} $、 $ c_{2} $、 $ \rho_{2} $，初始温度是  $ u_{0} $，然后保持两端温度为零，试写出此热传导问题的定解问题.

8. 长为 l 的均匀弦，两端 x=0 和 x=l 固定，弦中张力为  $ T_{0} $，在 x=h 点，以横向力  $ F_{0} $ 拉弦，达到稳定后放手任其自由振动，写出初始条件.

 $ ^{*} $9. 长为 l 的弹性杆，上端牢牢固定，下端挂有重物 P，试推导它作纵振动时在下述情况下的边界条件：

（1）把杆在其下端所挂静止重物 P 的作用下的伸长状态（静力伸长）取作平衡位置.

（2）把杆的未伸长状态取作平衡位置（例如，就在初始时间，把重物下的支承移去而重物开始使杆伸长）.

<!-- page: 127 -->

<div style="text-align: center;"><img src="images/p0127_img_in_image_box_106_461_166_521.jpg" alt="Image" width="6%" /></div>


# 本章小结

本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="11">用数理方程研究物理问题</td><td rowspan="6">提出定解问题</td><td style='text-align: center; word-wrap: break-word;'>泛定方程</td><td style='text-align: center; word-wrap: break-word;'>波动方程: $ u_t = a^2 \Delta u + f $热传导(扩散)方程: $ u_t = D \Delta u + f $泊松方程: $ \Delta u = -h $振动过程: $ \left\{\begin{array}{l}u|_{t=0} = \varphi(x,y,z) \\ u_t|_{t=0} = \psi(x,y,z)\end{array}\right. $运输过程: $ u|_{t=0} = \varphi(x,y,z) $第一类边界条件: $ u|_{\text{边}} = f(M,t) $第二类边界条件: $ u_n|_{\text{边}} = f(M,t) $第三类边界条件: $ (u + hu_n)_|\text{边} = f(M,t) $</td></tr><tr><td rowspan="3">定解条件</td><td style='text-align: center; word-wrap: break-word;'>运动方程: $ \left\{\begin{array}{l}u_1|_{x=x_0} = u_2|_{x=x_0}\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第二类边界条件: $ u_t|_{\text{边}} = f(M,t) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第三类边界条件: $ (u + hu_n)_|_{\text{边}} = f(M,t) $</td></tr><tr><td rowspan="2">其他条件</td><td style='text-align: center; word-wrap: break-word;'>其他条件</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>周期性边界条件</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>行波法</td><td rowspan="3">积分变换法</td><td style='text-align: center; word-wrap: break-word;'>有限性边界条件</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>分离变量法</td><td style='text-align: center; word-wrap: break-word;'>周期性边界条件</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>格林函数法</td><td style='text-align: center; word-wrap: break-word;'>周期性边界条件</td></tr><tr><td rowspan="2">分析解答</td><td style='text-align: center; word-wrap: break-word;'>物理意义</td><td rowspan="2">[将在以后逐章学习]</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>存在唯一稳定</td></tr></table>

<!-- page: 128 -->

## 第七章 行波法

我们已经熟悉常微分方程的求解，一般是先求方程的通解，再用初始条件去确定通解中的任意常数而得到特解。因此我们也想仿照这个方法来求解偏微分方程的定解问题。即先求偏微分方程的通解，再用定解条件确定通解中的任意常数或函数。但是偏微分方程的通解不那么容易求，用定解条件确定函数往往更加困难。通过分析，我们发现这种方法主要适用于求解（无界区域的）齐次波动方程的定解问题。齐次波动方程反映介质一经扰动后在区域里不再受到外力的运动规律。如果问题的区域是整个空间，由初始扰动所引起的振动就会一往无前地传播出去，形成行（进）波。故我们把这种主要适用于求解这类行波问题的方法称为行波法。本章将介绍这种方法。

### 7.1 无界弦的自由振动 达朗贝尔公式

让我们考虑无界弦的自由振动，这个问题既简单明了又具有代表性。其定解问题为

$$  \{u_{t t}=a^{2}u_{x x}\}   \tag*{(7.1.1)}$$

$$  u(x,0)=\varphi(x),\quad-\infty<x<\infty   \tag*{(7.1.2)}$$

$$  \begin{array}{l l}{u_{t}(x,0)=\psi(x),}&{-\infty<x<\infty}\end{array}   \tag*{(7.1.3)}$$

其中  $ \varphi(x) $、 $ \psi(x) $ 为已知函数。在上一章所提出的弦的横振动问题中，如果弦没有受到任何外力作用，而且我们只研究其中的一小段，那么在不太长的时间里，两端的影响都来不及传到，不妨认为两端都不存在，弦是“无限长”的。于是可提出（7.1.1）～（7.1.3）式这样的定解问题。“无限长”杆的自由纵振动，“无限长”理想传输线上的电流、电压的变化均提出与之相同的定解问题。

## 1. 一维齐次波动方程的通解

为了用行波法求解这一问题，我们首先要求出方程(7.1.1)式的通解。由(7.1.1)式我们有

$$  \left(\frac{\partial}{\partial t}+a\frac{\partial}{\partial x}\right)\left(\frac{\partial}{\partial t}-a\frac{\partial}{\partial x}\right)u=0   \tag*{(7.1.4)}$$

因此，只要能找到两个微分算子 $ \frac{\partial}{\partial\xi} $和 $ \frac{\partial}{\partial\eta} $，使 $ \frac{\partial}{\partial\xi}=A\left(\frac{\partial}{\partial t}+a\frac{\partial}{\partial x}\right) $， $ \frac{\partial}{\partial\eta}=B\left(\frac{\partial}{\partial t}-a\frac{\partial}{\partial x}\right) $；A、B为常数，则方程(7.1.4)式就变为 $ u_{\xi\eta}=0 $，从而立即可求出其通解。为此，我们作变换 $ x=a(\xi+\eta) $， $ t=\xi-\eta $，此时有

 $$ \frac{\partial}{\partial\xi}=\frac{\partial}{\partial t}\frac{\partial t}{\partial\xi}+\frac{\partial}{\partial x}\frac{\partial x}{\partial\xi}=\frac{\partial}{\partial t}+a\frac{\partial}{\partial x} $$

<!-- page: 129 -->

$$ \frac{\partial}{\partial\eta}=\frac{\partial}{\partial t}\frac{\partial t}{\partial\eta}+\frac{\partial}{\partial x}\frac{\partial x}{\partial\eta}=-\left(\frac{\partial}{\partial t}-a\frac{\partial}{\partial x}\right) $$ 

于是方程(7.1.4)式变为

$$  u_{\xi\eta}=0   \tag*{(7.1.5)}$$

为了以后书写形式的简便和对称，我们也不妨将上述变换修改为  $ x=\frac{1}{2}(\xi+\eta) $， $ t=\frac{1}{2a}(\xi-\eta) $，即作变换

$$  \left\{\begin{array}{l}\xi=x+at\\\eta=x-at\end{array}\right.   \tag*{(7.1.6)}$$

此时，(7.1.5)式显然仍然成立.对于方程(7.1.5)式先对 $ \eta $求积分得

 $$ u_{\xi}=c(\xi) $$ 

其中， $ c(\xi) $为 $ \xi $的任意函数。将上式再对 $ \xi $求积分，得

 $$ u=\int c(\boldsymbol{\xi})\mathrm{d}\boldsymbol{\xi}=f_{1}(\boldsymbol{\xi})+f_{2}(\boldsymbol{\eta}) $$ 

其中  $ f_{1}(\xi) $、 $ f_{2}(\eta) $ 分别是  $ \xi $、 $ \eta $ 的任意函数。把变换 (7.1.6) 式代入上式，就得方程 (7.1.1) 式的通解

$$  u(x,t)=f_{1}(x+at)+f_{2}(x-at)   \tag*{(7.1.7)}$$

## 2. 达朗贝尔( $ D^{\prime}Alembert $)公式

下面我们利用初始条件(7.1.2)和(7.1.3)式来确定通解(7.1.7)式中的任意函数 $ f_{1} $和 $ f_{2} $.将(7.1.7)式代入(7.1.2)式，有

代入7.1.3式有

 $$ u(x,0)=f_{1}(x)+f_{2}(x)=\varphi(x) $$ 

 $$ u_{t}(x,0)=a f_{1}^{\prime}(x)-a f_{2}^{\prime}(x)=\psi(x) $$ 

即

 $$ f_{1}(x)-f_{2}(x)=\frac{1}{a}\int_{x_{0}}^{x}\psi(\alpha)\mathrm{d}\alpha+c $$ 

于是可求得

 $$ f_{1}(x)=\frac{1}{2}\varphi(x)+\frac{1}{2a}\int_{x_{0}}^{x}\psi(\alpha)\mathrm{d}\alpha+\frac{c}{2} $$ 

 $$ f_{2}(x)=\frac{1}{2}\varphi(x)-\frac{1}{2a}\int_{x_{0}}^{x}\psi(\alpha)\mathrm{d}\alpha-\frac{c}{2} $$ 

将求得的  $ f_{1}(x) $ 和  $ f_{2}(x) $ 中的 x 分别换成  $ x+at $ 和 x-at 后一并代入通解 (7.1.7) 式即得

$$  u(x,t)=\frac{1}{2}\left[\varphi(x+at)+\varphi(x-at)\right]+\frac{1}{2a}\int_{x-at}^{x+at}\psi(\alpha)\mathrm{d}\alpha   \tag*{(7.1.8)}$$

这就是达朗贝尔公式或称为达朗贝尔解. 它是无界弦的自由振动, 即定解问题  $ (7.1.1)\sim(7.1.3) $ 式的特解.

#### 例 1 求解初值问题

<!-- page: 130 -->

$$ \left\{\begin{aligned}u_{tt}&=a^{2}u_{xx}\\ u\mid_{t=0}&=\cos x,u_{t}\mid_{t=0}=2\end{aligned}\right. $$ 

解 此时  $ \varphi(x)=\cos x,\psi(x)=2 $ 故由达氏公式(7.1.8)式有

 $$ \begin{align*}u(x,t)&=\frac{1}{2}\big[\cos(x+at)+\cos(x-at)\big]+\frac{1}{2a}\int_{x-at}^{x+at}2\mathrm{d}\alpha\\&=\cos x\cos at+2t\end{align*} $$ 

## 3. 达朗贝尔解的适定性

易于验证，只要  $ \varphi $ 有直到二阶的连续导数， $ \psi $ 有一阶的连续导数，达朗贝尔解是满足方程(7.1.1)和初始条件(7.1.2)、(7.1.3)式的，即达朗贝尔解是存在的。又从求解的方法已看到，通解(7.1.7)式中的任意函数已由初始条件(7.1.2)、(7.1.3)式完全确定，故达朗贝尔解是唯一的。现在来证明达朗贝尔解的稳定性。设初始条件有两组，且它们相差很小，即

 $$ u\mid_{t=0}=\left\{\begin{aligned}&\varphi_{1}(x)\\ &\varphi_{2}(x)\end{aligned}\right.,\quad u_{t}\mid_{t=0}=\left\{\begin{aligned}&\psi_{1}(x)\\ &\psi_{2}(x)\end{aligned}\right. $$ 

 $$ \mid\varphi_{1}-\varphi_{2}\mid<\delta,\quad\mid\psi_{1}-\psi_{2}\mid<\delta $$ 

则由达朗贝尔公式(7.1.8)有

 $$ \begin{aligned}\mid u_{1}-u_{2}\mid\leqslant\frac{1}{2}\mid\varphi_{1}(x+at)-\varphi_{2}(x+at)\mid+\frac{1}{2}\mid\varphi_{1}(x-at)-\varphi_{2}(x-at)\mid\\+\frac{1}{2a}\int_{x-at}^{x+at}\mid\psi_{1}(\alpha)-\psi_{2}(\alpha)\mid\mathrm{d}\alpha<\frac{1}{2}\delta+\frac{1}{2}\delta+\frac{\delta}{2a}\int_{x-at}^{x+at}\mathrm{d}\alpha\end{aligned} $$ 

即

 $$ |u_{1}-u_{2}|<\delta(1+t) $$ 

所以，在有限的时间内，当初始条件有了微小改变时，其解也只有微小改变，即达朗贝尔解是稳定的。

综上所述，达朗贝尔解是适定的。

## 4. 达朗贝尔解的物理意义

为方便起见，我们先讨论初始条件只有初始位移的情况下达朗贝尔解的物理意义。此时(7.1.8)式给出

 $$ u(x,t)=\frac{1}{2}\big[\varphi(x+at)+\varphi(x-at)\big] $$ 

先看第二项，当 t=0 时，在 x=c 处观察者看到的波形为

 $$ \varphi(x-at)=\varphi(c-a\bullet0)=\varphi(c) $$ 

若观察者以速度 a 沿 x 轴的正向运动，则 t 时刻在 x = c + at 处，他所看到的波形为

 $$ \varphi(x-at)=\varphi(c+at-at)=\varphi(c) $$ 

由于 t 为任意时刻，这说明观察者在运动过程中随时可看到相同的波形  $ \varphi(c) $，可见，

<!-- page: 131 -->

波形和观察者一样，以速度a沿x轴正向传播。所以， $ \varphi(x-at) $ 代表以速度a沿x轴正向传播的波，称为正行波。而第一项的 $ \varphi(x+at) $则当然代表以速度a沿x轴负向传播的波，称为反行波。正行波和反行波的叠加（相加）就给出弦的位移。

再讨论只有初速度的情况. 此时(7.1.8)式给出

 $$ u(x,t)=\frac{1}{2a}\int_{x-at}^{x+at}\psi(\alpha)\mathrm{d}\alpha $$ 

设  $ \Psi(x) $ 为  $ \frac{\psi(x)}{2a} $ 的一个原函数，即

 $$ \Psi(x)=\frac{1}{2a}\int_{x_{0}}^{x}\psi(\alpha)\mathrm{d}\alpha $$ 

 $$ u(x,t)=\Psi(x+at)-\Psi(x-at) $$ 

则此时有

由此可见第一项也是反行波，第二项也是正行波，正、反行波的叠加（相减）给出弦的位移.

综上所述，达朗贝尔解表示正行波和反行波的叠加。

例2 设初速度  $ \psi(x) $ 为零，初位移为

 $$ \varphi(x)=\left\{\begin{aligned}&0,&x&<&-\alpha\\ &2+\frac{2x}{\alpha},&-\alpha&\leqslant&x\leqslant&0\\ &2-\frac{2x}{\alpha},&0&\leqslant&x\leqslant&\alpha\\ &0,&x&>\alpha\end{aligned}\right. $$ 

则此时达朗贝尔解（7.1.8）式给出了弦的位移为

 $$ u=\frac{1}{2}[\varphi(x+at)+\varphi(x-at)] $$ 

即初始位移(图7.1最下一图的实线)，它分为两半(该图虚线)，分别向左右两方以速度a移动(见图7.1中由下而上的各图中的虚线)，每经过时间间隔 $ \frac{\alpha}{4a} $，弦的位移由此二行波的和给出(见图7.1中由下而上的各图的实线).

由本节的学习我们看到，行波法的求解出发点，是基于波动现象的特点为背景的变量变换。它所采用的是与求解常微分方程一样的先

<div style="text-align: center;"><img src="images/p0131_img_in_image_box_542_607_860_1102.jpg" alt="图7.1" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.1</div> </div>


求通解，再用定解条件定特解的方法，故其思路上易于理解，且用之研究波动问题也很方便。但由于一般而言，偏微分方程的通解不易求，用定解条件定特解有时也十分困难，这就使得这种解法有相当大的局限性，我们一般只用它求解波动问题。

<!-- page: 132 -->

#### 习题7.1

1. 确定下列初值值问题的解：

(1)  $ u_{tt} - a^{2}u_{xx} = 0 $,  $ u(x,0) = 0 $,  $ u_{t}(x,0) = 1 $;

 $$ u_{t t}-a^{2}u_{x x}=0,\quad u(x,0)=\sin x,\quad u_{t}(x,0)=x^{2}; $$ 

(3)  $ u_{tt} - a^{2}u_{xx} = 0 $,  $ u(x,0) = x^{3} $,  $ u_{t}(x,0) = x $;

 $$ u_{t t}-a^{2}u_{x x}=0,\quad u(x,0)=\cos x,\quad u_{t}(x,0)=\mathrm{e}^{-1}. $$ 

2. 求解无界弦的自由振动，设弦的初始位移为  $ \varphi(x) $，初始速度为  $ -a\varphi'(x) $.

3. 求解弦振动方程的古沙问题

 $$ \left\{\begin{aligned}&u_{t t}=u_{x x}\\ &u(x,-x)=\varphi(x),\quad-\infty<x<\infty\\ &u(x,x)=\psi(x),\quad-\infty<x<\infty\end{aligned}\right. $$ 

4. 求解无限长理想传输线上电压和电流的传播情况. 设初始电压分布为 Acoskx，初始电流分布为  $ \sqrt{\frac{C}{L}}Acoskx $ (参考习题 6.2 第 9 题，注意  $ V_{x} = -LI_{t}, I_{x} = -CV_{t} $).

5. 细圆锥杆的纵振动的方程为

 $$ u_{t t}=a^{2}\left(u_{x x}+\frac{2}{x}u_{x}\right) $$ 

试求其通解.

提示：令  $ v(x,t)=xu(x,t) $

6. 试求出方程

 $$ \frac{\partial}{\partial x}\bigg[\left(1-\frac{x}{h}\right)^{2}\frac{\partial u}{\partial x}\bigg]=\frac{1}{a^{2}}\left(1-\frac{x}{h}\right)^{2}\frac{\partial^{2}u}{\partial t^{2}} $$ 

的通解.

 $$ u=\left[f_{1}(x-at)+f_{2}(x+at)\right]/(h-x) $$ 

其中，h 为已知常数， $ f_{1} $、 $ f_{2} $ 为充分光滑的任意函数。若

 $$ \left\{\begin{aligned}u(x,0)&=\varphi(x),&-\infty<x<\infty\\ u_{t}(x,0)&=\psi(x),&-\infty<x<\infty\end{aligned}\right. $$ 

求其特解.

提示：令  $ v(x,t)=(h-x)u(x,t) $.

7. 求下列偏微分方程的通解：

 $$ u_{x x}-2u_{x y}-3u_{y y}=0;\quad(2)u_{x x}-u_{x y}=0. $$ 

8. 解下列初值问题：

 $$ \left\{\begin{aligned}&u_{xx}+2u_{xy}-3u_{yy}=0\\ &u(x,0)=\sin x\\ &u_{y}(x,0)=x\end{aligned}\right. $$ 

9. 用行波法证明

 $$ \begin{cases}u_{tt}-a^{2}u_{xx}=0\\u(ct,t)=\varphi(t)\\u_{x}(ct,t)=\psi(t)\end{cases} $$

<!-- page: 133 -->

的解为

 $$ u=\frac{a+c}{2a}\varphi\left(\frac{a t+x}{a+c}\right)+\frac{a-c}{2a}\varphi\left(\frac{a t-x}{a-c}\right)+\frac{a^{2}-c^{2}}{2a}\int_{a t-x/a-c}^{a t+x/a+c}\psi(\xi)\mathrm{d}\xi,\quad c\neq\pm a $$ 

10. 试求一端固定的半无界弦的自由振动问题

 $$ \begin{cases}u_{tt}=a^{2}u_{xx}\\u(x,0)=\varphi(x),&0\leqslant x<\infty\\u_{t}(x,0)=\psi(x),&0\leqslant x<\infty\\u(0,t)=0,&t>0\end{cases} $$ 

并讨论其解所具有的物理意义.

11. 一根无限长的弦与 x 轴的正半轴重合，处于平衡状态中，左端位于原点，当 t > 0 时左端点作微小横振动  $ A \sin \omega t $，试求弦的振动规律.

12. 半无限长的杆，其端点受到纵向力  $ F(t)=A\sin\omega t $ 作用，求解杆的纵振动.

13. 平面偏振的平面光波沿 x 轴行进而垂直地投射于两种介质的分界面上. 入射光波的电场强度  $ E = E_{0} \sin \omega \left( t - \frac{n_{1}}{a} x \right) $，其中  $ n_{1} $ 是第一种介质的折射率，求反射光波和透射光波.

提示: 在分界面上, E 和  $ \frac{\partial E}{\partial x} $ 均连续.

### 7.2 无界弦的强迫振动

以上所讨论的只限于自由振动，其泛定方程均为齐次的。现在让我们来考虑无界弦或杆的纯强迫振动，即

$$  u_{t t}-a^{2}u_{x x}=f(x,t)   \tag*{(7.2.1)}$$

 $$ u\mid_{t=0}=0 $$ 

$$  u_{t}\mid_{t=0}=0   \tag*{(7.2.3)}$$

这时泛定方程是非齐次的。由前面的讨论我们想到，若能设法将方程的非齐次项消除掉（即将方程变为齐次方程），则便可利用7.1节中的达朗贝尔公式而得到此定解问题的解。为此，我们引入冲量原理。

## 1. 冲量原理

我们知道，(7.2.1)式中的  $ f(x,t)=\frac{\Gamma(x,t)}{\rho} $ 是单位质量的弦上所受的外力，这是一从时刻 t=0，一直延续到时刻 t 的持续作用力。由物理学中的叠加原理 $ ^{①} $，我们可将持续力  $ f(x,t) $ 所引起的振动[即定解问题(7.2.1)~(7.2.3)式的解]，视为一系列前后相继的瞬时力  $ f(x,\tau)(0\leqslant\tau\leqslant t) $ 所引起的振动  $ w(x,t;\tau) $ 的叠加。即

 $$ \begin{array}{r}{u(x,t)=\operatorname*{l i m}_{\Delta\tau\to0}\displaystyle\sum_{\tau=0}^{t}w(x,t;\tau)}\end{array} $$ 

现在，我们来分析瞬时力  $ f(x,\tau) $ 所引起的振动是怎样的。从物理的角度考虑，力对系统的作用对于时间的累积是给系统一定的冲量。我们考虑在短时间间隔  $ \Delta\tau $ 内

<!-- page: 134 -->

$ f(x,\tau) $ 对系统的作用，则  $ f(x,\tau)\Delta\tau $ 表示在  $ \Delta\tau $ 内的冲量。这个冲量使得系统的动量即系统的速度有一改变量[因为  $ f(x,t) $ 是单位质量弦所受外力，故动量在数值上等于速度]。若我们把在时间  $ \Delta\tau $ 内得到的速度改变量看成是在  $ t=\tau $ 时刻的一瞬间集中得到的，而在  $ \Delta\tau $ 的其余时间则认为没有冲量的作用，即没有外力的作用，则在  $ \Delta\tau $ 这段时间内，瞬时力  $ f(x,\tau) $ 所引起的振动的定解问题可表示为

 $$ \left\{\begin{aligned}&w_{t t}-a^{2}w_{x x}=0,\quad\tau<t<\tau+\Delta\tau\\ &w\mid_{t=\tau}=0\\ &w_{t}\mid_{t=\tau}=f(x,\tau)\Delta\tau\end{aligned}\right. $$ 

为了便于求解，设

 $$ w(x,t;\tau)=v(x,t;\tau)\triangle\tau $$ 

则有

 $$ v_{t t}-a^{2}v_{x x}=0 $$ 

$$  v\mid_{t=\tau}=0   \tag*{(7.2.5)}$$

$$  v_{t}\mid_{t=\tau}=f(x,\tau)   \tag*{(7.2.6)}$$

由上述分析可看出，欲求解纯强迫振动即定解问题(7.2.1)～(7.2.3)式，只要求解定解问题(7.2.4)～(7.2.6)式即可，而

 $$ u(x,t)=\lim_{\Delta\tau\to0}\sum_{\tau=0}^{t}w(x,t;\tau)=\lim_{\Delta\tau\to0}\sum_{\tau=0}^{t}v(x,t;\tau)\Delta\tau $$ 

即

$$  u(x,t)=\int_{0}^{t}v(x,t;\tau)\mathrm{d}\tau   \tag*{(7.2.7)}$$

以上这种用瞬时冲量的叠加代替持续作用力来解决定解问题(7.2.1)~(7.2.3)式的方法，称为冲量原理.

冲量原理的合理性，我们也可在数学上予以严格的证明。由（7.2.7）式有

 $$ \begin{aligned}&u_{t}=\int_{0}^{t}v_{t}\mathrm{d}\tau+v(x,t;\tau)\mid_{\tau=t}=\int_{0}^{t}v_{t}\mathrm{d}\tau^{\textcircled{2}}\\&u_{tt}=\int_{0}^{t}v_{tt}\mathrm{d}\tau+v_{t}\mid_{\tau=t}=\int_{0}^{t}v_{tt}\mathrm{d}\tau+f(x,t)\\&u_{xx}=\int_{0}^{t}v_{xx}\mathrm{d}\tau\\ \end{aligned} $$ 

代入方程(7.2.1)式和定解条件(7.2.2)、(7.2.3)式均满足.

## 2. 纯强迫振动的解

对于定解问题(7.2.4)～(7.2.6)式，令 $ T=t-\tau $，则有

 $$ \left\{\begin{array}{l}v_{T T}-a^{2}v_{x x}=0\\ v\mid_{T=0}=0\\ v_{T}\mid_{T=0}=f(x,\tau)\end{array}\right. $$ 

故由达朗贝尔公式(7.1.8)有

<!-- page: 135 -->

$$ v(x,t;\tau)=\frac{1}{2a}\int_{x-aT}^{x+aT}f(\alpha,\tau)\mathrm{d}\alpha=\frac{1}{2a}\int_{x-a(t-\tau)}^{x+a(t-\tau)}f(\alpha,\tau)\mathrm{d}\alpha $$ 

代入7.2.7式得

$$  u(x,t)=\frac{1}{2a}\int_{0}^{t}\int_{x-a(t-\tau)}^{x+a(t-\tau)}f(\alpha,\tau)\mathrm{d}\alpha\mathrm{d}\tau   \tag*{(7.2.8)}$$

此即纯强迫振动的解.

例 求解初值问题

 $$ \left\{\begin{array}{l}u_{t t}=u_{x x}+x\\ u(x,0)=0\\ u_{t}(x,0)=0\end{array}\right. $$ 

解 此处 a=1,  $ f(x,t)=x $, 故由(7.2.8)式有

 $$ \begin{align*}u(x,t)&=\frac{1}{2}\int_{0}^{t}\int_{x-(t-\tau)}^{x+(t-\tau)}\alpha\mathrm{d}\alpha\mathrm{d}\tau\\&=\frac{1}{4}\int_{0}^{t}\left\{\left[x+(t-\tau)\right]^{2}-\left[x-(t-\tau)\right]^{2}\right\}\mathrm{d}\tau\\&=\frac{1}{2}xt^{2}\end{align*} $$ 

## 3. 一般强迫振动

对于一般强迫振动，其定解问题为

$$  u_{t t}-a^{2}u_{x x}=f(x,t)   \tag*{(7.2.9)}$$

$$  u\mid_{t=0}=\varphi(x)   \tag*{(7.2.10)}$$

$$  u_{t}\mid_{t=0}=\psi(x)   \tag*{(7.2.11)}$$

由于泛定方程和定解条件都是线性的，故我们可以利用叠加原理来处理这一问题。

令

$$  u=u^{1}+u^{11}   \tag*{(7.2.12)}$$

并使  $ u^{1} $ 满足

$$  u_{tt}^{1}-a^{2}u_{xx}^{1}=0   \tag*{（7.2.13）}$$

$$  u^{\mathrm{I}}\mid_{t=0}=\varphi(x)   \tag*{(7.2.14)}$$

$$  u_{t}^{\mathrm{I}}\mid_{t=0}=\psi(x)   \tag*{（7.2.15）}$$

使 $ u^{||} $满足

$$  u_{t t}^{\mathbb{I}}-a^{2}u_{x x}^{\mathbb{I}}=f(x,t)   \tag*{(7.2.16)}$$

$$  u^{\mathbb{I}}\mid_{t=0}=0   \tag*{(7.2.17)}$$

$$  u_{t}^{\mathbb{I}}\mid_{t=0}=0   \tag*{（7.2.18）}$$

则(7.2.13)式加(7.2.16)式即为(7.2.9)式；(7.2.14)式加(7.2.17)式即为(7.2.10)式；(7.2.15)式加(7.2.18)式即为(7.2.11)式。故要求解定解问题(7.2.9)～(7.2.11)式只须求解定解问题(7.2.13)～(7.2.15)式和定解问题(7.2.16)～

<!-- page: 136 -->

(7.2.18)式即可. 定解问题(7.2.13)式～(7.2.15)式的解  $ u^{\mathrm{I}}(x,t) $ 可由达氏公式 (7.1.8) 给出；而定解问题 (7.2.16) 式～(7.2.18) 式的解  $ u^{\mathrm{II}}(x,t) $，由上面的 (7.2.8) 式给出. 故一般强迫振动的解为

$$  \begin{align*}u(x,t)=&u^{\mathrm{I}}+u^{\mathrm{II}}=\frac{1}{2}\big[\varphi(x+at)+\varphi(x-at)\big]\\&+\frac{1}{2a}\int_{x-at}^{x+at}\psi(\alpha)\mathrm{d}\alpha+\frac{1}{2a}\int_{0}^{t}\int_{x-a(t-\tau)}^{x+a(t-\tau)}f(\alpha,\tau)\mathrm{d}\alpha\mathrm{d}\tau\end{align*}   \tag*{(7.2.19)}$$

注 ①叠加原理 在物理学的研究中常常将几种不同原因的综合所产生的效果，用这些不同原因单独产生的效果（即假设其他原因不存在时，该原因所产生的效果）的累加来代替，这个原理称为叠加原理.

物理学中的叠加原理，在数理方法中具体反映在泛定方程和定解条件上，设L为线性微分算符，则线性微分方程和线性定解条件均可表示为

 $$ \mathbf{L}u=f $$ 

如， $ u_{tt}-a^{2}u_{xx}=0 $，即 $ \left(\frac{\partial^{2}}{\partial t^{2}}-a^{2}\frac{\partial^{2}}{\partial x^{2}}\right)u=0 $，亦即L_{u}=0。其中， $ L=\frac{\partial^{2}}{\partial t^{2}}-a^{2}\frac{\partial^{2}}{\partial x^{2}} $，f=0。又如， $ u_{t}|_{t=0}=0 $即 $ \frac{\partial}{\partial t}u(x,0)=0 $，亦即 $ Lu(x,0)=0 $，其中， $ L=\frac{\partial}{\partial t} $，f=0。易于证明：

（1）若  $ u_{i} $ 满足线性方程或线性定解条件

 $$ \mathbf{L}u_{i}=f_{i},\quad i=1,2,\cdots,n $$ 

则它们的线性组合  $ u=\sum_{i=1}^{n}c_{i}u_{i} $ 也必满足方程或定解条件，即

 $$ \mathbf{L}u=\sum_{i=1}^{n}c_{i}f_{i} $$ 

其中 $ c_{i} $为常数（下同）.

（2）若  $ u_{i} $ 满足线性方程或线性定解条件

 $$ \mathbf{L}u_{i}=f_{i},\quad i=1,2,\cdots,n,\cdots $$ 

且它们的线性组合  $ u=\sum_{i=1}^{\infty}c_{i}u_{i} $ 一致收敛，则 u 也满足方程或定解条件，即

 $$ \mathbf{L}u=\sum_{i=1}^{\infty}c_{i}f_{i} $$ 

（3）设 $ u(M,M_{0}) $满足线性方程或定解条件

 $$  Lu=f(M,M_{0}) $$ 

其中  $ M_{0} $ 为参数. 又假设  $ \boldsymbol{U}(\boldsymbol{M})=\int\boldsymbol{u}(\boldsymbol{M},\boldsymbol{M}_{0})\mathrm{d}\boldsymbol{M}_{0} $ 一致收敛，则  $ \boldsymbol{U}(\boldsymbol{M}) $ 也满足方程或定解条件，即

 $$ \mathbf{L}U=\int f(\boldsymbol{M},\boldsymbol{M}_{0})\mathrm{d}\boldsymbol{M}_{0} $$ 

由此看出，服从叠加原理的物理现象，所对应的泛定方程或定解条件应该是线性的。这是显然的，因为叠加就是累加，对于可列个是求和，不可列个是求积分；而只有线性方程（或定解条件）才满足可加性，这就是线性的定义。

由于物理上的很多问题都可以归结为线性方程或线性定解条件，这使得叠加原理在数理方法中应用很广，无论是本章还是以后各章都要用到它。特别是我们常常将数理方程的解表示为可列

<!-- page: 137 -->

个函数的叠加（即级数）或不可列个函数的叠加（即带参数的积分）的形式.

②这里，引用了含参变量积分的求导公式

 $$ \frac{\partial}{\partial t}\int_{x\neg_{at}}^{x+at}\psi(\alpha)\mathrm{d}\alpha=\int_{x\neg_{at}}^{x+at}\frac{\partial\psi}{\partial t}\mathrm{d}\alpha+\psi(x+at)\frac{\mathrm{d}(x+at)}{\mathrm{d}t}-\psi(x-at)\frac{\mathrm{d}(x-at)}{\mathrm{d}t} $$ 

##### 习题7.2

1. 求解下列定解问题：

(1)

 $$ \begin{cases}u_{tt}-a^{2}u_{xx}=x+at\\u(x,0)=0\\u_{t}(x,0)=0\end{cases}; $$ 

(2)

 $$ \left\{\begin{aligned}u_{xx}-u_{yy}&=8\\ u(x,0)&=0\\ u_{y}(x,0)&=0\end{aligned}\right., $$ 

2. 求解下列定解问题：

(1)

 $$ \left\{\begin{aligned}u_{tt}&=u_{xx}+t\sin x\\ u(x,0)&=0\\ u_{t}(x,0)&=\sin x\end{aligned}\right.; $$ 

(2)

 $$ \begin{cases}u_{xx}-u_{yy}=1\\u(x,0)=\sin x;\\u_{y}(x,0)=x\end{cases} $$ 

(3)

 $$ \begin{cases}u_{tt}-a^{2}u_{xx}=x\\u(x,0)=0\\u_{t}(x,0)=3\end{cases}; $$ 

(4)

 $$ \left\{\begin{aligned}u_{tt}&-a^{2}u_{xx}=x\mathrm{e}^{t}\\ u(x,0)&=\sin x\\ u_{t}(x,0)&=0\end{aligned}\right., $$ 

3. 设  $ v(x, y, t; \tau) $ 是初值问题

 $$ \left\{\begin{aligned}&v_{t t}=a^{2}(v_{x x}+v_{y y}),\quad t>\tau\geqslant0\\ &v\mid_{t=\tau}=0\\ &v_{t}\mid_{t=\tau}=f(x,y;\tau)\end{aligned}\right. $$ 

的解，证明

 $$ u(x,y,t)=\int_{0}^{t}v(x,y,t;\tau)\mathrm{d}\tau $$ 

是非齐次方程零值初值问题

 $$ \left\{\begin{array}{l}u_{t t}=a^{2}(u_{x x}+u_{y y})+f(x,y;t)\\ u\mid_{t=0}=0\\ u_{t}\mid_{t=0}=0\end{array}\right. $$ 

的解.

4. 试推导出二维非齐次波动方程初值问题

 $$ \left\{\begin{array}{l}u_{t t}=a^{2}(u_{x x}+u_{y y})+f(x,y;t),\quad-\infty<x,y<+\infty;t>0\\ u\mid_{t=0}=\varphi(x)\\ u_{t}\mid_{t=0}=\psi(x)\end{array}\right. $$ 

的解的表达式为

 $$ u(x,y,t)=\frac{1}{2\pi a}\left[\frac{\partial}{\partial t}\iint_{\sigma_{at}^{M}}^{}\frac{\varphi(\xi,\eta)\mathrm{d}\xi\mathrm{d}\eta}{\sqrt{(at)^{2}-(\xi-x)^{2}-(\eta-y)^{2}}}+\iint_{\sigma_{at}^{M}}^{}\frac{\varphi(\xi,\eta)\mathrm{d}\xi\mathrm{d}\eta}{\sqrt{(at)^{2}-(\xi-x)^{2}-(\eta-y)^{2}}}\right] $$ 

###  $ ^{*} $7.3 三维无界空间的自由振动 泊松公式

现在我们讨论三维空间的波动问题

<!-- page: 138 -->

$$  u_{t t}=a^{2}\triangle u   \tag*{(7.3.1)}$$

$$  u\mid_{t=0}=\varphi(M),\quad-\infty<x,y,z<\infty   \tag*{(7.3.2)}$$

$$  u_{t}\mid_{t=0}=\psi(M),\quad-\infty<x,y,z<\infty   \tag*{(7.3.3)}$$

其中 M 代表空间中任意一点。在 7.1 节中我们已比较详细的讨论过如何用行波法来求解一维的波动问题，因此我们自然想到，若能通过某种方法将三维的波动问题化为一维的波动问题，则便可借助于 7.1 节的结果或仿照 7.1 节的方法来求得三维波动问题的解。为此，我们引入平均值的方法。

## 1. 平均值法

我们引入函数

$$  \bar{u}(r,t)=\frac{1}{4\pi r^{2}}\iint_{S_{r}^{M_{0}}}u(M,t)\mathrm{d}s=\frac{1}{4\pi}\iint_{S_{r}^{M_{0}}}u(M,t)\mathrm{d}\Omega   \tag*{(7.3.4)}$$

称之为函数  $ u(M,t) $ 在以  $ M_{0} $ 为中心，r 为半径的球面  $ S_{r}^{M_{0}} $ 上的平均值。其中  $ \mathrm{d}\Omega=\frac{\mathrm{d}s}{r^{2}}=\sin\theta\mathrm{d}\theta\mathrm{d}\varphi $ 为立体角元。显然， $ \bar{u}(r,t) $ 只是独立变量 r 和 t 的函数。 $ M_{0} $ 是一个参量，而且很容易看出  $ \bar{u}(r,t) $ 和我们所要求的  $ u(M_{0},t_{0}) $ 有很紧密的联系



<div style="text-align: center;"><img src="images/p0138_img_in_image_box_97_599_423_890.jpg" alt="图7.2" width="34%" /></div>


 $$ u(M_{0},t_{0})=\lim_{r\to0}\bar{u}(r,t_{0}) $$ 

<div style="text-align: center;"><div style="text-align: center;">图7.2</div> </div>


因此，欲求波动方程(7.3.1)的解  $ u(M,t) $ 在任意一点  $ M_{0} $，任意时刻  $ t_{0} $ 的值  $ u(M_{0},t_{0}) $，只要先求  $ u(M,t) $ 在  $ t_{0} $ 时刻，以  $ M_{0} $ 为中心，r 为半径的球面  $ S_{r}^{M_{0}} $ 上的平均值，再令  $ r\to0 $ 即可。这种处理问题的方法称为平均值法。注意，如图7.2所示，这里各坐标变量之间的关系为

$$  \begin{aligned}&\left\{\begin{aligned}x&=x_{0}+r\sin\theta\cos\varphi\\y&=y_{0}+r\sin\theta\sin\varphi\\z&=z_{0}+r\cos\theta\end{aligned}\right.\\ &\frac{(x-x_{0})^{2}+(y-y_{0})^{2}+(z-z_{0})^{2}}{}\\ \end{aligned}   \tag*{(7.3.6)}$$

## 2. 三维齐次波动方程的通解

为了用平均值法求解三维的波动问题，我们对(7.3.1)式两边在球面 $ S_{r}^{M_{0}} $ 上积分并乘以常数因子 $ \frac{1}{4\pi} $，则得

 $$ \frac{1}{4\pi}\iint_{S_{r}^{M_{0}}}u_{u}\mathrm{d}\Omega=\frac{a^{2}}{4\pi}\iint_{S_{r}^{M_{0}}}\Delta u\mathrm{d}\Omega $$

<!-- page: 139 -->

即

 $$ \frac{\partial^{2}}{\partial t^{2}}\Big(\frac{1}{4\pi}\iint_{S_{r}^{M_{0}}}u\mathrm{d}\Omega\Big)=a^{2}\Delta\Big(\frac{1}{4\pi}\iint_{S_{r}^{M_{0}}}u\mathrm{d}\Omega\Big) $$ 

亦即

$$  \frac{\partial^{2}}{\partial t^{2}}\bar{u}(r,t)=a^{2}\Delta\bar{u}(r,t)   \tag*{(7.3.7)}$$

又因为在直角坐标系中

 $$ \Delta\bar{u}=\frac{\partial^{2}\bar{u}}{\partial x^{2}}+\frac{\partial^{2}\bar{u}}{\partial y^{2}}+\frac{\partial^{2}\bar{u}}{\partial z^{2}} $$ 

由变量 x 和 r 的关系 (7.3.6) 我们有

 $$ \begin{aligned}\frac{\partial\bar{u}}{\partial x}&=\frac{\partial\bar{u}}{\partial r}\frac{\partial r}{\partial x}\\&=\frac{\partial\bar{u}}{\partial r}\bullet\frac{\partial}{\partial x}\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}+(z-z_{0})^{2}}\\&=\frac{\partial\bar{u}}{\partial r}\bullet\frac{x-x_{0}}{r}\end{aligned} $$ 

所以

 $$ \begin{aligned}\frac{\partial^{2}\bar{u}}{\partial x^{2}}&=\frac{\partial}{\partial r}\Big(\frac{\partial\bar{u}}{\partial r}\bullet\frac{x-x_{0}}{r}\Big)\bullet\frac{\partial r}{\partial x}\\&=\frac{\partial\bar{u}}{\partial r}\frac{r^{2}-(x-x_{0})^{2}}{r^{3}}+\frac{\partial^{2}\bar{u}}{\partial r^{2}}\frac{(x-x_{0})^{2}}{r^{2}}\end{aligned} $$ 

类似的可得

 $$ \frac{\partial^{2}\bar{u}}{\partial y^{2}}=\frac{\partial\bar{u}}{\partial r}\frac{r^{2}-(y-y_{0})^{2}}{r^{3}}+\frac{\partial^{2}\bar{u}}{\partial r^{2}}\frac{(y-y_{0})^{2}}{r^{2}} $$ 

 $$ \frac{\partial^{2}\overline{u}}{\partial z^{2}}=\frac{\partial\overline{u}}{\partial r}\frac{r^{2}-(z-z_{0})^{2}}{r^{3}}+\frac{\partial^{2}\overline{u}}{\partial r^{2}}\frac{(z-z_{0})^{2}}{r^{2}} $$ 

故有

 $$ \begin{align*}\Delta\bar{u}&=\frac{\partial^{2}\bar{u}}{\partial x^{2}}+\frac{\partial^{2}\bar{u}}{\partial y^{2}}+\frac{\partial^{2}\bar{u}}{\partial z^{2}}=\frac{\partial\bar{u}}{\partial r}\frac{3r^{2}-r^{2}}{r^{3}}+\frac{\partial^{2}\bar{u}}{\partial r^{2}}\frac{r^{2}}{r^{2}}\\&=\frac{2}{r}\frac{\partial\bar{u}}{\partial r}+\frac{\partial^{2}\bar{u}}{\partial r^{2}}=\frac{1}{r}\frac{\partial^{2}}{\partial r^{2}}(r\bar{u})\end{align*} $$ 

代入7.3.7式得

即

 $$ \begin{aligned}\frac{\partial^{2}}{\partial t^{2}}\bar{u}&=\frac{a^{2}}{r}\frac{\partial^{2}}{\partial r^{2}}(r\bar{u})\\\frac{\partial^{2}}{\partial t^{2}}(r\bar{u})&=a^{2}\frac{\partial^{2}}{\partial r^{2}}(r\bar{u})\\v(r,t)&=r\bar{u}(r,t)\end{aligned} $$ 

令在上式中，

则得

 $$ v_{t t}=a^{2}v_{r r} $$ 

这与弦振动方程完全相似，由（7.1.7），其通解为

 $$ \begin{aligned}v(r,t)&=f_{1}(r+at)+f_{2}(r-at)\\\bar{u}(r,t)&=\frac{v(r,t)}{r}=\frac{f_{1}(r+at)+f_{2}(r-at)}{r}\end{aligned} $$ 

于是

<!-- page: 140 -->

注意到(7.3.8)式，立刻知

 $$ v(0,t)=0 $$ 

即

$$  f_{1}(at)+f_{2}(-at)=0   \tag*{(7.3.10)}$$

所以

 $$ \begin{aligned}u(M_{0},t_{0})&=\lim_{r\to0}\bar{u}(r,t_{0})=\lim_{r\to0}\frac{v(r,t_{0})}{r}\\&=\lim_{r\to0}\frac{f_{1}(r+at_{0})+f_{2}(r-at_{0})}{r}\\&=f_{1}^{\prime}(at_{0})+f_{2}^{\prime}(-at_{0})\\ \end{aligned} $$ 

此处最后一步用了洛必达法则. 而由(7.3.10)式有

 $$ f_{1}^{\prime}(at_{0})=f_{2}^{\prime}(-at_{0}) $$ 

故有

$$  u(M_{0},t_{0})=2f_{1}^{\prime}(at_{0})   \tag*{(7.3.11)}$$

此即波动方程(7.3.1)在任意时刻 $ t_{0} $，任意一点 $ M_{0} $处的解，其中 $ f_{1}^{\prime}(at_{0}) $为任意函数.

## 3. 泊松(Poisson)公式

为了得到方程(7.3.1)式满足初始条件(7.3.2)和(7.3.3)式的特解，我们需要用这两个初始条件来确定(7.3.11)式中的任意函数 $ f_{1}^{\prime}(at_{0}) $.为此，我们将(7.3.9)式两边乘以r后再分别对r和t求导

 $$ \begin{aligned}&\frac{\partial}{\partial r}(r\bar{u})=f_{1}^{\prime}(r+at)+f_{2}^{\prime}(r-at)\\&\frac{1}{a}\frac{\partial}{\partial t}(r\bar{u})=f_{1}^{\prime}(r+at)-f_{2}^{\prime}(r-at)\\ \end{aligned} $$ 

将此二式相加，并取 $ r=at_{0},t=0 $，则得

 $$ \begin{align*}2f_{1}^{\prime}(at_{0})=&\left[\frac{\partial}{\partial r}(r\bar{u})+\frac{1}{a}\frac{\partial}{\partial t}(r\bar{u})\right]_{r=at_{0}}\\=&\left[\frac{\partial}{\partial r}\Big(r\bullet\frac{1}{4\pi r^{2}}\iiint_{S_{r}^{M_{0}}}u\mathrm{d}s\Big)+\frac{1}{a}\frac{\partial}{\partial t}\Big(r\bullet\frac{1}{4\pi r^{2}}\iiint_{S_{r}^{M_{0}}}u\mathrm{d}s\Big)\right]_{r=at_{0}}\\=&\frac{1}{4\pi}\Big[\frac{\partial}{\partial r}\iiint_{S_{r}^{M_{0}}}\frac{u}{r}\mathrm{d}s+\frac{1}{a}\iiint_{S_{r}^{M_{0}}}\frac{u_{t}}{r}\mathrm{d}s\Big]_{r=at_{0}}\\=&\frac{1}{4\pi a}\Big[\frac{\partial}{\partial t_{0}}\iiint_{S_{at_{0}}^{M_{0}}}\frac{\varphi(M)}{at_{0}}\mathrm{d}s+\iiint_{S_{at_{0}}^{M_{0}}}\frac{\psi(M)}{at_{0}}\mathrm{d}s\Big]\end{align*} $$ 

将此结果代入(7.3.11)式，则得

 $$ u(M_{0},t_{0})=\frac{1}{4\pi a}\Big[\frac{\partial}{\partial t_{0}}\iint_{S_{a t_{0}}^{M_{0}}}\frac{\varphi(M)}{a t_{0}}\mathrm{d}s+\iint_{S_{a t_{0}}^{M_{0}}}\frac{\psi(M)}{a t_{0}}\mathrm{d}s\Big] $$ 

注意到  $ M_{0} $ 和  $ t_{0} $ 的任意性，故一般可写为

$$  u(M,t)=\frac{1}{4\pi a}\bigg[\frac{\partial}{\partial t}\iint_{S_{at}^{M}}\frac{\varphi(M^{\prime})}{at}\mathrm{d}s+\iint_{S_{at}^{M}}\frac{\psi(M^{\prime})}{at}\mathrm{d}s\bigg]   \tag*{(7.3.12)}$$

<!-- page: 141 -->

其中  $ M^{\prime} $ 表示以 M 为中心 at 为半径的球面  $ S_{at}^{M} $ 上的动点. (7.3.12) 式称为泊松公式，它给出了三维无界空间波动方程的初值问题的解.

泊松公式的物理意义很明显，它说明定解问题（7.3.1）～（7.3.3）式的解在M点

t 时刻之值，由以 M 为中心 at 为半径的球面  $ S_{at}^{M} $ 上的初始值而确定。显然，这是由于初值的影响是以速度 a 在时间 t 内从球面  $ S_{at}^{M} $ 上传播到 M 点的缘故。具体地来看，如图 7.3 所示，设初始扰动限于空间某个区域  $ T_{0} $，d 为 M 点到  $ T_{0} $ 的最近距离，D 为 M 点与  $ T_{0} $ 的最大距离，则

（1）当 at<d，即  $ t<\frac{d}{a} $ 时， $ S_{at}^{M} $ 与  $ T_{0} $ 不相交， $ \varphi(M^{\prime}) $ 和  $ \psi(M^{\prime}) $ 之值均为零，因而（7.3.12）式中的两个积分之值亦均为零，即  $ u(M,t)=0 $。这表示扰动的“前锋”尚未到达。

<div style="text-align: center;"><img src="images/p0141_img_in_image_box_645_304_861_491.jpg" alt="图7.3" width="22%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.3</div> </div>


（2）当 d<at<D，即 $ \frac{d}{a}<t<\frac{D}{a} $时， $ S_{at}^{M} $与 $ T_{0} $相交， $ \varphi(M^{\prime}) $、 $ \psi(M^{\prime}) $之值不为零，因而两积分之值亦不为零，即 $ u(M,t)\neq0 $，这表明扰动正在经过M点.

（3）当at>D，即 $ t>\frac{D}{a} $， $ S_{at}^{M} $与 $ T_{0} $也不相交，因而同样 $ u(M,t)=0 $，这表面扰动的“阵尾”已经过去了.

例1 设大气中有一个半径为1的球形薄膜，薄膜内的压强超过大气压的数值为 $ p_{0} $，假定该薄膜突然消失，将会在大气中激起三维波，试求球外任意位置的附加压强D.

解 如图 7.4 所示，设薄膜球球心到球外任意一点 M 的距离为 r，则其定解问题为



<div style="text-align: center;"><img src="images/p0141_img_in_image_box_98_818_328_985.jpg" alt="图7.4" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图7.4</div> </div>


 $$ \left\{\begin{aligned}&p_{_{t t}}-a^{2}\Delta p=0\\ &p\mid_{_{t=0}}=\left\{\begin{aligned}&p_{_{0}}&(r<1)\\ &0&(r>1)\end{aligned}\right.\\ &p_{_{t}}\mid_{_{t=0}}=0\end{aligned}\right. $$ 

当 r-1<at<r+1 时有

 $$ \begin{align*}\iint_{S_{at}^{M}}\frac{\varphi(M^{\prime})}{at}\mathrm{d}s=&\int_{0}^{2\pi}\mathrm{d}\varphi\int_{0}^{\theta_{0}}\frac{p_{_{0}}(at)^{2}\sin\theta\mathrm{d}\theta}{at}=2\pi p_{_{0}}at\left(1-\cos\theta_{0}\right)\\=&~2\pi p_{_{0}}at\left(1-\frac{r^{2}+a^{2}t^{2}-1}{2art}\right)\\=&-\frac{\pi p_{_{0}}}{r}[(r-at)^{2}-1]\end{align*} $$ 

注意  $ \psi(M^{\prime})=p_{t}|_{t=0}=0 $ 。故由泊松公式(7.3.12)式有

<!-- page: 142 -->

$$ \begin{align*}p(M,t)&=\frac{1}{4\pi a}\frac{\partial}{\partial t}\iint_{S_{at}^{M}}\frac{\varphi(M^{\prime})}{at}\mathrm{d}s\\&=\frac{1}{4\pi a}\frac{\partial}{\partial t}\Bigl(-\frac{\pi p_{0}}{r}\Bigr)\bigl[(r-at)^{2}-1\bigr]\\&=\frac{p_{0}}{2r}(r-at)\end{align*} $$ 

而当 at<r-1 和 at>r+1 时，由于  $ \varphi(M^{\prime}) $ 和  $ \psi(M^{\prime}) $ 均为零，故有  $ p(M,t)=0 $.

类似的，我们当然也可求得薄膜球内任意位置处的附加压强。

例2 求解定解问题 $ ^{①} $

 $$ \left\{\begin{aligned}&u_{t t}=a^{2}\Delta u\\ &u\mid_{t=0}=x^{3}+y^{2}z,\quad-\infty<x,y,z<\infty\\ &u_{t}\mid_{t=0}=0,\quad-\infty<x,y,z<\infty\\ \end{aligned}\right. $$ 

解  $ \varphi(M)=x^{3}+y^{2}z,\psi(M)=0 $. 注意到  $ M^{\prime} $ 和 M 的关系，则由(7.3.12)式有

 $$ \begin{aligned}u(M,t)&=\frac{1}{4\pi a}\frac{\partial}{\partial t}\iint_{S_{at}^{M}}\frac{\varphi(M^{\prime})}{at}\mathrm{d}s\\&=\frac{1}{4\pi a}\frac{\partial}{\partial t}\int_{0}^{2\pi}\int_{0}^{\pi}\frac{\varphi(x^{\prime},y^{\prime},z^{\prime})}{at}(at)^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\varphi\\&=\frac{1}{4\pi}\frac{\partial}{\partial t}\left\{t\int_{0}^{2\pi}\int_{0}^{\pi}[(x+at\sin\theta\cos\varphi)^{3}+(y+at\sin\theta\sin\varphi)^{2}(z+at\cos\theta)]\sin\theta\mathrm{d}\theta\mathrm{d}\varphi\right\}\\&=x^{3}+3a^{2}t^{2}x+zy^{2}+a^{2}t^{2}z\\ \end{aligned} $$ 

注 ① 由于本例初始条件的特殊性，本例也可使用叠加原理将之分解为两个一维波动问题的叠加后，再用达朗贝尔公式求解。即

另解 令

 $$ u=u^{\mathrm{I}}+u^{\mathrm{I I}} $$ 

使

 $$ \left\{\begin{aligned}&u_{t t}^{\mathrm{I}}=a^{2}u_{x x}^{\mathrm{I}}\\ &u^{\mathrm{I}}|_{t=0}=x^{3}\\ &u_{t}^{\mathrm{I}}|_{t=0}=0\end{aligned}\right.,\quad\left\{\begin{aligned}&u_{t t}^{\mathrm{I I}}=a^{2}u_{y y}^{\mathrm{I I}}\\ &u^{\mathrm{I I}}|_{t=0}=y^{2}z\\ &u_{t}^{\mathrm{I I}}|_{t=0}=0\end{aligned}\right. $$ 

则由达朗贝尔公式有

 $$ u^{1}=\frac{1}{2}\big[(x+at)^{3}+(x-at)^{3}\big]=x^{3}+3x(at)^{2} $$ 

 $$ u^{\parallel}=\frac{1}{2}[(y+at)^{2}z+(y-at)^{2}z]=z y^{2}+z(at)^{2} $$ 

于是

 $$ u(M,t)=u^{\mathrm{I}}+u^{\mathrm{I I}}=x^{3}+3a^{2}t^{2}x+z y^{2}+a^{2}t^{2}z $$ 

显然，这比直接用泊松公式求解要简单得多。

有些具有对称性的三维波动问题，也可视为一维问题而用达氏公式求解（见本节习题第2题）.

<!-- page: 143 -->

思考：初始条件  $ \varphi(M) $ 和  $ \psi(M) $ 为何种形式的函数时，能根据叠加原理将定解问题（7.3.1）式～（7.3.3）式分解为几个一维波动问题，再用达朗贝尔公式求解？为什么？[见姚端正等，大学物理，Vol.16, No.4(1997)18.]

#### 习题7.3

1. 一半径为 R 的球内含有气体，在初始时是静止的，在球内的初始压缩率为  $ s_{0} $，在球外为零。不论何时，压缩率与速度势的关系为  $ s=(1/c^{2})u_{t} $，并且速度势满足方程  $ u_{tt}=\Delta u $，试对所有的 t>0，确定压缩率 s。

2. 利用泊松积分公式求解下列定解问题

 $$ \left\{\begin{aligned}u_{t t}&=a^{2}(u_{x x}+u_{y y}+u_{z z})\\ u\mid_{t=0}&=0,\quad-\infty<x,y,z<\infty\\ u_{t}\mid_{t=0}&=x^{2}+y\mathfrak{Z},\quad-\infty<x,y,z<\infty\end{aligned}\right. $$ 

3. 证明球面问题

 $$ \begin{cases}u_{tt}=a^{2}(u_{xx}+u_{yy}+u_{zz}),&-\infty<x,y,z<\infty,t>0\\u\mid_{t=0}=\varphi(r),\quad r^{2}=x^{2}+y^{2}+z^{2}\\u_{t}\mid_{t=0}=\psi(r)\end{cases} $$ 

的解是

 $$ u(r,t)=\frac{(r-at)\varphi(r-at)+(r+at)\varphi(r+at)}{2r}+\frac{1}{2ar}\int_{r-at}^{r+at}\alpha\psi(\alpha)\mathrm{d}\alpha $$ 

4. 在泊松公式中，若将球面  $ S_{at}^{M} $ 上的积分代以 xy 平面上的圆  $ \sigma_{at}^{M} $ 上的积分，并注意球面  $ S_{at}^{M} $ 上下两半都投影于同一圆，便可导出二维空间的泊松公式。试导出二维空间的泊松公式

$$  \begin{align*}u(M,t)=u(x,y;t)=&\frac{1}{2\pi a}\Biggl[\frac{\partial}{\partial t}\iint_{\sigma_{at}^{M}}\frac{\varphi(\xi,\eta)\mathrm{d}\xi\mathrm{d}\eta}{\sqrt{(at)^{2}-(\xi-x)^{2}-(\eta-y)^{2}}}\\&+\iint_{\sigma_{at}^{M}}\frac{\psi(\xi,\eta)\mathrm{d}\xi\mathrm{d}\eta}{\sqrt{(at)^{2}-(\xi-x)^{2}-(\eta-y)^{2}}}\Biggr]\end{align*}   \tag*{(7.3.13)}$$

5. 利用二维泊松公式求解下列定解问题

 $$ \left\{\begin{aligned}&u_{tt}=a^{2}(u_{xx}+u_{yy})\\ &u(x,y,0)=x^{2}(x+y),&-\infty<x,y<\infty\\ &u_{t}(x,y,0)=0,&-\infty<x,y<\infty\end{aligned}\right. $$ 

思考：能否用注 $ ^{①} $提供的方法求解第2题和第5题？

###  $ ^{*} $7.4 三维无界空间的受迫振动 推迟势

现在，我们进一步讨论具有零值初始条件的有源空间波问题

$$  u_{t t}-a^{2}\Delta u=f(M,t)   \tag*{(7.4.1)}$$

$$  u\mid_{t=0}=0   \tag*{(7.4.2)}$$

$$  u_{t}\mid_{t=0}=0   \tag*{(7.4.3)}$$

<!-- page: 144 -->

## 1. 推迟势

欲求得这一定解问题的解，我们当然可仿照7.2节那样采用冲量原理，即先求出无源问题

$$  v_{t t}-a^{2}\Delta v=0   \tag*{(7,4,4)}$$

$$  v\mid_{t=\tau}=0   \tag*{(7.4.5)}$$

$$  v_{t}\mid_{t=\tau}=f(M,\tau)   \tag*{(7.4.6)}$$

的解  $ v(M,t;\tau) $，而定解问题（7.4.1）～（7.4.3）式的解为

$$  u(M,t)=\int_{0}^{t}v(M,t;\tau)\mathrm{d}\tau   \tag*{(7.4.7)}$$

由泊松公式(7.3.12)式，定解问题(7.4.4)～(7.4.6)式的解为

 $$ v(M,t;\tau)=\frac{1}{4\pi a}\iint_{S_{a(t-\tau)}^{M}}\frac{f(M^{\prime},\tau)}{a(t-\tau)}\mathrm{d}s $$ 

代入7.4.7式得

 $$ u(M,t)=\frac{1}{4\pi a}\int_{0}^{t}\iint_{S_{a(t-\tau)}^{M}}\frac{f(M^{\prime},\tau)}{a(t-\tau)}\mathrm{d}s\mathrm{d}\tau $$ 

引入变量代换

 $$ r=a(t-\tau) $$ 

则

 $$ \tau=t-\frac{r}{a} $$ 

 $$ \begin{align*}u(M,t)&=\frac{1}{4\pi a}\int_{at\rightarrow0}^{0}\iint_{S_{r}^{M}}\frac{f\left(M^{\prime},t-\frac{r}{a}\right)}{r}\mathrm{d}s\left(-\frac{\mathrm{d}r}{a}\right)\\&=\frac{1}{4\pi a^{2}}\int_{0}^{at}\iint_{S_{r}^{M}}\frac{f\left(M^{\prime},t-\frac{r}{a}\right)}{r}\mathrm{d}s\mathrm{d}r\\&=\frac{1}{4\pi a^{2}}\iiint_{T_{at}^{M}}\frac{f\left(M^{\prime},t-\frac{r}{a}\right)}{r}\mathrm{d}v\end{align*} $$ 

上式中  $ M^{\prime} $ 表示在以 M 为中心，at 为半径的球体  $ T_{at}^{M} $ 中的变点，积分在球体  $ T_{at}^{M} $ 中进行。若记

 $$ [\boldsymbol{f}]=f\big(M^{\prime},t-\frac{r}{a}\big) $$ 

则定解问题 $  (7.4.1) \sim (7.4.3)  $式的解为

$$  \begin{array}{r}{u(M,t)=\frac{1}{4\pi a^{2}}\iiint_{T_{a t}^{M}}\frac{\left[\boldsymbol{f}\right]}{r}\mathrm{d}\boldsymbol{v}}\end{array}   \tag*{(7.4.8)}$$

并称之为推迟势.

顺便提及，至于具有非零值初始条件的有源空间波，当然可仿照7.2节所述的那样用叠加原理来处理。

<!-- page: 145 -->

## 2. 推迟势的物理意义

由推迟势(7.4.8)式我们看到，欲求M点处t时刻的波动问题(7.4.1)～(7.4.3)式的解 $ u(M,t) $，必须把以M点为球心，at为半径的球体 $ T_{at}^{M} $内的源的影响都叠加起来。而且，源对M点在t时刻的影响，必须在比t早的时刻 $ \tau=t-\frac{r}{a} $发出，因为扰动以速度a传播必须历时 $ \frac{r}{a} $才能传到M点。换言之M点受到源的影响的时刻t，比源发出的时刻 $ t-\frac{r}{a} $迟了 $ \frac{r}{a} $，故称之为推迟势。

例 求解波动问题

 $$ \left\{\begin{aligned}&u_{t t}=a^{2}\Delta u+2(y-t)\\ &u\mid_{t=0}=0\\ &u_{t}\mid_{t=0}=x^{2}+y z\end{aligned}\right.,\quad-\infty<x,y,z<\infty $$ 

解 令  $ u = u^{I} + u^{II} $，使

 $$ \begin{cases}u_{tt}^{\mathrm{I}}=a^{2}\Delta u^{\mathrm{I}}\\u^{\mathrm{I}}\mid_{t=0}=0\\u_{t}^{\mathrm{I}}\mid_{t=0}=x^{2}+yz\end{cases},\quad\begin{cases}u_{tt}^{\mathrm{II}}=a^{2}\Delta u^{\mathrm{II}}+2(y-t)\\u^{\mathrm{II}}\mid_{t=0}=0\\u_{t}^{\mathrm{II}}\mid_{t=0}=0\end{cases} $$ 

则由泊松公式7.3.12式可求得

 $$ u^{I}\left(M,t\right)=x^{2}t+\frac{1}{3}a^{2}t^{3}+y z t $$ 

而由推迟势（7.4.8）式有

 $$ \begin{align*}u^{\parallel}\left(M,t\right)&=\frac{1}{4\pi a^{2}}\int_{0}^{at}\int_{0}^{2\pi}\int_{0}^{\pi}\frac{2\lfloor y+r\sin\theta\sin\varphi-\left(t-r/a\right)\rfloor}{r}\bullet r^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\varphi\mathrm{d}r\\&=yt^{2}-\frac{t^{3}}{3}\end{align*} $$ 

所以

 $$ u(M,t)=u^{\mathrm{I}}+u^{\mathrm{I I}}=t x^{2}+\frac{1}{3}a^{2}t^{3}+y t z+t^{2}y-\frac{1}{3}t^{3} $$

<!-- page: 146 -->

<div style="text-align: center;"><img src="images/p0146_img_in_image_box_174_482_238_547.jpg" alt="Image" width="6%" /></div>


本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="3">中心内容——用行波法求解无界区域的波动问题</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>定解问题</td><td style='text-align: center; word-wrap: break-word;'>定解问题</td><td style='text-align: center; word-wrap: break-word;'>求解方法 解答</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>当  $ u_y = u_z = 0 $ 时</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^u = a^2 \Delta u^u + f(M,t) \\ u_t^u |_{t=0} = 0 \\ u_t^u |_{t=0} = 0 \\ u_t^u = a^2 \Delta u^u \\ u_t^u |_{t=0} = \varphi(M) \\ u_t^u |_{t=0} = \psi(M)\end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^u = a^2 \Delta u^u + f(M,t) \\ u_t^u |_{t=0} = 0 \\ u_t^u |_{t=0} = \psi(M) \\ u_t^u = a^2 \Delta u^u \\ u_t^u |_{t=0} = \varphi(M) \\ u_t^u |_{t=0} = \psi(M)\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>当  $ u_x = u_z = 0 $ 时</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^x = a^2 u_x^u \\ u_t^x |_{t=0} = 0 \\ u_t^x |_{t=0} = \varphi(x) \\ u_t^x |_{t=0} = \psi(x)\end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^x = a^2 u_x^u \\ u_t^x |_{t=0} = 0 \\ u_t^x |_{t=0} = \psi(x) \\ u_t^x |_{t=0} = \varphi(x)\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>当  $ u_x = u_x + f(x,t) $</td><td style='text-align: center; word-wrap: break-word;'>$ u_t^x = a^2 u_x^u + f(x,t) $</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^x = a^2 u_x^u \\ u_t^x |_{t=0} = 0 \\ u_t^x |_{t=0} = \varphi(x)\end{array}\right. $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>当  $ u_x = u_x + f(x,t) + u_t^u $ 时</td><td style='text-align: center; word-wrap: break-word;'>$ u_t^x = a^2 u_x^u + f(x,t) $</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l}u_t^x =</td></tr></table>

<!-- page: 147 -->

在上一章中，我们已经说明，普遍地用行波法那样的先求通解，再用定解条件确定特解的方法来求解偏微分方程有很大的困难，因此，在解偏微分方程时，常常是直接求满足定解条件的特解。本章将学习的分离变量法就是直接求特解的一种方法，它是解数理方程的重要方法之一，适用于解大量的各种各样的定解问题，特别是在所研究问题的区域是矩形、柱面、球面等情况下，使用更为普遍。本章将主要讨论用分离变量法求解各种有界问题。

下面，我们首先以有界弦的自由振动为例来了解分离变量法的基本要领及解题步骤.

### 8.1 有界弦的自由振动

考虑长为 l 两端固定的弦的自由振动

 $$ u_{t t}=a^{2}u_{x x},\quad0<x<l,t>0 $$ 

$$  u\mid_{x=0}=0\Big\},\qquad t\geqslant0   \tag*{(8.1.2)}$$

 $$ u\mid_{x=l}=0\int^{\prime} $$ 

$$  \left.\begin{array}{l}u\mid_{t=0}=\varphi(x)\\ u_{t}\mid_{t=0}=\psi(x)\end{array}\right\}, 歩 0\leqslant x\leqslant l   \tag*{(8.1.3)}$$

由力学的知识我们知道，两端固定的弦的自由振动会形成驻波，这就启示我们尝试从驻波出发来解决这样的问题。

## 1. 分离变量

在力学中，驻波的表达式为

 $$ u(x,t)=2A\cos\frac{2\pi x}{\lambda}\cos2\pi\gamma t $$ 

这使我们自然想到，对于定解问题(8.1.1)式～(8.1.3)式可设其特解为

$$  u(x,t)=X(x)T(t)   \tag*{(8.1.4)}$$

其中  $ X(x) $ 和  $ T(t) $ 分别只是变量 x 和 t 的函数. 为了弄清楚定解问题 (8.1.1)~(8.1.3) 式究竟有什么样的驻波解, 应将 (8.1.4) 式分别代入方程和定解条件中.

将（8.1.4）式代入（8.1.1）式中得

<!-- page: 148 -->

$$ XT^{\prime \prime}=a^{2}X^{\prime \prime}T $$ 

即

 $$ \frac{T^{\prime \prime}}{a^{2}T}=\frac{X^{\prime \prime}}{X} $$ 

此式左边是 t 的函数，右边是 x 的函数，t 和 x 是两个独立变数，故只有两边都是常数时，此等式才能成立。令常数为  $ \mu $，则有

 $$ \frac{T^{\prime \prime}}{a^{2}T}=\frac{X^{\prime \prime}}{X}=\mu $$ 

即

$$  X^{\prime \prime}-\mu X=0   \tag*{(8.1.5)}$$

$$  T^{\prime \prime}-\mu a^{2}T=0   \tag*{(8.1.6)}$$

这样，求解偏微分方程（8.1.1）的问题，就化为了求解两个常微分方程（8.1.5）和（8.1.6）的问题。方程（8.1.5）和（8.1.6）总是有解的，问题是如何找到满足边界条件（8.1.2）和初始条件（8.1.3）的非零解。为此

将（8.1.4）式代入边界条件（8.1.2）式得

 $$ \left\{\begin{aligned}X(0)T(t)&=0\\ X(l)T(t)&=0\end{aligned}\right. $$ 

由于  $ T(t) $ 是 t 的任意函数，它不可能恒为零，故只可能有

$$  \left\{\begin{aligned}X(0)&=0\\ X(l)&=0\end{aligned}\right.   \tag*{(8.1.7)}$$

即，偏微分方程(8.1.1)式的边界条件(8.1.2)式，化为了常微分方程(8.1.5)式的边界条件(8.1.7)式.

将（8.1.4）式代入初始条件（8.1.3）式得

 $$ \left\{\begin{aligned}X(x)&T(0)=\varphi(x)\\ X(x)&T^{\prime}(0)=\psi(x)\end{aligned}\right. $$ 

由于  $ X(x) $ 是未知的，故显然，要想由此二式得到常微分方程（8.1.6）的初始条件  $ T(0) $ 和  $ T'(0) $，必须先求解出  $ X(x) $.

## 2. 本征值问题

让我们考虑定解问题

$$  \left\{\begin{array}{l}X^{\prime \prime}-\mu X=0\\ X(0)=0\\ X(l)=0\end{array}\right\}   \tag*{(8.1.7)}$$

在(8.1.5)式中， $ \mu $ 是常数，它不能任意取值，而只能在边界条件(8.1.7)式的限制下取某些特定的值，否则方程(8.1.5)将没有满足边界条件(8.1.7)式的非零解。这些特定的 $ \mu $值，称为方程(8.1.5)在边界条件(8.1.7)式下的本征值（或固有值）；相应于不同的 $ \mu $，方程(8.1.5)的非零解称为本征函数（或固有函数）。求本征值 $ \mu $和相应的本

<!-- page: 149 -->

征函数的问题称为本征值问题（固有值问题）.

现在我们来求解方程(8.1.5)、(8.1.7)所构成的本征值问题. $ \mu $ 的取值，无非有  $ \mu=0,\mu>0,\mu<0 $ 三种可能.

（1）若 $ \mu=0 $，则方程（8.1.5）的解为

 $$ X(x)=c_{1}x+c_{2} $$ 

其中  $ c_{1}, c_{2} $ 为任意常数（以下均同）. 代入边界条件（8.1.7）式解得  $ c_{2}=0, c_{1}=0 $ ，于是

 $$ X(x)\equiv0 $$ 

见 $ \mu $不能为零.

（2）若  $ \mu>0 $ ，则此时方程（8.1.5）的解为

 $$ X(x)=c_{1}\mathrm{e}^{\sqrt{\mu}x}+c_{2}\mathrm{e}^{-\sqrt{\mu}x} $$ 

代入边界条件(8.1.7)式得

 $$ \left\{\begin{aligned}&c_{1}+c_{2}=0\\ &c_{1}\mathrm{e}^{\sqrt{\mu}l}+c_{2}\mathrm{e}^{-\sqrt{\mu}l}=0\end{aligned}\right. $$ 

解得

 $$ c_{1}=0,\quad c_{2}=0 $$ 

于是

 $$ X(x)\equiv0 $$ 

可见 $ \mu $也不能大于零.

（3）若  $ \mu<0 $，记  $ \mu=-k^{2}(k $ 为实数），则方程（8.1.5）的解为

 $$ X(x)=c_{1}\mathrm{s i n}k x+c_{2}\mathrm{c o s}k x $$ 

由边界条件(8.1.7)式得

 $$ \left\{\begin{aligned}c_{2}&=0\\ c_{1}sinkl&=0\end{aligned}\right. $$ 

因为  $ c_{2}=0 $ ，故  $ c_{1} $ 不能为零，否则又将得到零值解。故上二式成立只可能是

 $$ \operatorname{sink}l=0 $$ 

这要求

 $$ kl=\pm n\pi,\quad n=0,1,2,\cdots $$ 

但 n 不能取零，否则 k=0，又将得到零值解；且  $ \pm n $ 给出的两个解只差一个正负号，即，是线性相关的，故

 $$ k=\frac{n\pi}{l},\quad n=1,2,3,\cdots $$ 

综上所述，由(8.1.5)式和(8.1.7)式所构成的本征值问题的本征值为

$$  \mu=-k^{2}=-\frac{n^{2}\pi^{2}}{l^{2}},\quad n=1,2,3,\cdots   \tag*{(8.1.8)}$$

其相应的本征函数即方程(8.1.5)的解为

$$  X_{n}(x)=c_{n}\sin\frac{n\pi}{l}x   \tag*{(8.1.9)}$$

其中， $ c_{n} $ 为任意常数.

<!-- page: 150 -->

## 3. 关于  $ T(t) $ 的方程的通解

将本征值  $ \mu = -\frac{n^{2}\pi^{2}}{l^{2}} $ 代入方程(8.1.6)得

 $$ T^{\prime \prime}(t)+\frac{a^{2}n^{2}\pi^{2}}{l^{2}}T(t)=0 $$ 

此方程的通解为

 $$ T_{n}(t)=A_{n}^{\prime}\cos\frac{n\pi a}{l}t+B_{n}^{\prime}\sin\frac{n\pi a}{l}t $$ 

其中  $ A_{n}^{\prime} $ 和  $ B_{n}^{\prime} $ 为任意常数. 故由(8.1.4)式得到，方程(8.1.1)满足边界条件(8.1.2)式的特解是

$$  u_{n}(x,t)=X_{n}(x)T_{n}(t)=\Big(A_{n}\cos\frac{n\pi a}{l}t+B_{n}\sin\frac{n\pi a}{l}t\Big)\sin\frac{n\pi x}{l},\quad n=1,2,3,\cdots   \tag*{(8.1.10)}$$

其中  $ A_{n}=A_{n}^{\prime}C_{n}, B_{n}=B_{n}^{\prime}C_{n} $ （8.1.10）式表示的特解有无穷多个，但一般说来，其中的任意一个并不一定能满足初始条件（8.1.3），因为当 t=0 时，

 $$ \left\{\begin{aligned}u_{n}(x,0)&=A_{n}\sin\frac{n\pi}{l}x\\ \left.\frac{\partial u_{n}}{\partial t}\right|_{t=0}&=B_{n}\frac{n\pi a}{l}\sin\frac{n\pi x}{l}\end{aligned}\right. $$ 

而初值  $ \varphi(x) $ 和  $ \psi(x) $ 是任意函数，因此这些特解  $ u_{n}(x,t) $ 中的任意一个，一般还不是问题的解.

## 4. 有界弦的自由振动的解

注意到方程（8.1.1）和边界条件（8.1.2）式均是线性的，故由叠加原理，把（8.1.10）式中所表示的特解叠加起来，得到的

$$  u(x,t)=\sum_{n=1}^{\infty}u_{n}(x,t)=\sum_{n=1}^{\infty}\left(A_{n}\cos\frac{n\pi a}{l}t+B_{n}\sin\frac{n\pi a}{l}t\right)\sin\frac{n\pi x}{l}   \tag*{(8.1.11)}$$

仍然是方程（8.1.1）满足边界条件（8.1.2）式的解。为使此解满足初始条件，将（8.1.11）式代入初始条件（8.1.3）式，则得

 $$ \left\{\begin{aligned}\varphi(x)&=\sum_{n=1}^{\infty}A_{n}\sin\frac{n\pi}{l}x\\ \psi(x)&=\sum_{n=1}^{\infty}B_{n}\frac{n\pi a}{l}\sin\frac{n\pi x}{l}\end{aligned}\right. $$ 

这恰好是  $ \varphi(x) $ 和  $ \psi(x) $ 的正弦展开 $ ^{①} $，于是

$$  \left\{\begin{array}{c}A_{n}=\frac{2}{l}\int_{0}^{l}\varphi(\alpha)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha\\ \end{array}\right.   \tag*{(8.1.12)}$$

$$  \left\{\begin{array}{c}B_{n}=\frac{2}{n\pi a}\int_{0}^{l}\psi(\alpha)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha\end{array}\right.   \tag*{(8.1.13)}$$

<!-- page: 151 -->

可见(8.1.11)式就是定解问题(8.1.1)~(8.1.3)式的解，其中系数  $ A_{n} $ 和  $ B_{n} $ 分别由(8.1.12)和(8.1.13)式给出。由傅里叶级数理论知，若在区间  $ [0, l] $ 中  $ \varphi(x) $ 有直到二阶的连续导数，分段连续的三阶导数； $ \psi(x) $ 有连续的一阶导数，分段连续的二阶导数，并且它们符合齐次边界条件，则系数由(8.1.12)式和(8.1.13)式给出的解(8.1.11)式存在 $ ^{②} $。

## 5. 解的物理意义

(8.1.10)式可重新改写为

 $$ u_{n}(x,t)=N_{n}\cos(\omega_{n} t-\delta_{n})\sin\frac{n\pi x}{l} $$ 

其中

 $$ N_{n}^{2}=A_{n}^{2}+B_{n}^{2},\quad\omega_{n}=\frac{n\pi a}{l},\quad\delta_{n}=\arctan\frac{B_{n}}{A_{n}} $$ 

可见  $ u_{n}(x,t) $ 代表一个驻波， $ N_{n}\sin\frac{n\pi}{l}x $ 代表弦上各点的振幅分布， $ \cos(\omega_{n}t-\delta_{n}) $ 是相位因子， $ \omega_{n} $ 是弦振动的固有频率（或本征频率）， $ \delta_{n} $ 是初相位。对于每一个 n，弦上各点都以相同的频率  $ \omega_{n} $，相同的初相位  $ \delta_{n} $ 振动。当  $ x_{m}=\frac{ml}{n}(m=0,1,\cdots,n) $ 时， $ \sin\frac{n\pi}{l}x_{m}=\sin m\pi=0 $，即这些点振幅为零，保持不动，称为节点（连同两端点在内节点共有  $ n+1 $ 个）；当  $ x_{k}=\frac{2k-1}{2n}l(k=1,2,\cdots,n) $ 时， $ \sin\frac{n\pi}{l}x_{k}=\sin\frac{2k-1}{2}\pi=\pm1 $，即这些点振幅为  $ \pm N_{n} $，达到最大值，称为腹点（有 n 个）。弦的振动  $ u(x,t)=\sum_{n=1}^{\infty}u_{n} $，表示一系列振幅不同、频率不同、相位不同的驻波的叠加。我们称 n=1 的驻波为基波；n=2 的驻波为二次谐波，以此类推。图 8.1 画出了 n=1,2,3 的驻波的形状，在节点处这些波看起来就好像没动一样，这亦正是我们称之为驻波的原因（驻是停止的意思）。



<div style="text-align: center;"><img src="images/p0151_img_in_chart_box_529_730_860_968.jpg" alt="图8.1" width="34%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图8.1</div> </div>


## 6. 分离变量法

由前文对于有界弦的自由振动的求解我们看到

（1）虽然我们是从驻波引出解题的线索，但是在整个求解过程中跟驻波并没有联系，因此这种解题方法完全可以推广应用于各种定解问题，如扩散问题、稳定场问题等。按照它的特点我们称之为分离变量法。其主要精神是：把未知函数按自变量（包括多个自变量的情况）的单元函数分开[如，令 $ u(x,t)=X(x)T(t) $]，从而将解偏微分方程的问题化为解常微分方程的问题。

<!-- page: 152 -->

（2）用分离变量法求解偏微分方程问题.一般要经历如下四项步骤：

① 对齐次方程和齐次边界条件分离变量；

② 解关于空间因子的常微方程的本征值问题；

③ 求其他常微分方程的解，与本征函数相乘，得到特解；

④叠加，由初始条件或非齐次边界条件（后者在求解狄氏问题时将涉及到，见本节例题）确定叠加系数，而最后得所求定解问题的解.

例 考察在矩形薄板内稳定状态的温度分布，板的两对边绝热，而其余的两边一边温度保持为零，另一边的温度由  $ f(x) $ 规定.

解 其定解问题可表示为

$$  u_{x x}+u_{y y}=0,\quad0<x<a,0<y<b   \tag*{(8.1.14)}$$

$$  u_{x}\mid_{x=0}=0\rbrack   \tag*{（8.1.15）}$$

 $$ u_{x}\mid_{x=a}=0 $$ 

$$  u\mid_{y=b}=0   \tag*{(8.1.16)}$$

令

$$  u\mid_{y=0}=f(x)   \tag*{(8.1.17)}$$

$$  u(x,y)=X(x)Y(y)   \tag*{(8.1.18)}$$

代入齐次方程(8.1.14)和齐次边界条件(8.1.15)、(8.1.16)式得

 $$ X^{\prime \prime}-\mu X=0 $$ 

 $$ Y^{\prime \prime}+\mu Y=0 $$ 

 $$ \left\{\begin{aligned}X^{\prime}(0)&=0\\ X^{\prime}(a)&=0\end{aligned}\right. $$ 

 $$ Y(b)=0 $$ 

解本征值问题

 $$ \left\{\begin{aligned}X^{\prime \prime}-\mu X&=0\\ X^{\prime}(0)&=0,\quad X^{\prime}(a)&=0\end{aligned}\right. $$ 

得

 $$ \mu=-\frac{n^{2}\pi^{2}}{a^{2}},\quad n=0,1,2,\cdots $$ 

 $$ X_{n}(x)=A_{n}\cos\frac{n\pi}{a}x $$ 

将  $ \mu = -\frac{n^{2}\pi^{2}}{a^{2}} $ 代入  $ Y(y) $ 的方程得

 $$ Y^{\prime \prime}-\frac{n^{2}\pi^{2}}{a^{2}}Y=0 $$ 

其通解为

 $$ Y(y)=\left\{\begin{aligned}&C_{0}y+D_{0},\quad n=0\\ &C\operatorname{ch}\frac{n\pi}{a}y+D\operatorname{sh}\frac{n\pi}{a}y=E\operatorname{sh}\frac{n\pi}{a}(y+F),\quad n\neq0\end{aligned}\right. $$ 

其中

<!-- page: 153 -->

$$ E=\sqrt{D^{2}-C^{2}},\quad F=\frac{a}{n\pi}\mathrm{a r c t a n h}\frac{C}{D} $$ 

由边界条件 $ Y(b)=0 $有

 $$ \left\{\begin{aligned}&C_{0}b+D_{0}=0,\quad n=0\\ &E\operatorname{sh}\frac{n\pi}{a}(b+F)=0,\quad n\neq0\end{aligned}\right. $$ 

故有

 $$ C_{0}=-\frac{D_{0}}{b},\quad F=-b\quad E\neq0 $$ 

因此

 $$ Y_{n}(y)=\left\{\begin{aligned}&D_{0}\frac{b-y}{b},&n=0\\ &E_{n}\operatorname{sh}\frac{n\pi}{a}(y-b),&n\neq0\end{aligned}\right. $$ 

而由(8.1.18)式有

 $$ \begin{aligned}u_{n}(x,y)&=X_{n}(x)Y_{n}(y)\\&=\left\{\begin{aligned}&\frac{a_{0}}{2}\frac{b-y}{b},&n&=0\\&a_{n}\cos\frac{n\pi}{a}x&sh\frac{n\pi}{a}(y-b),&n&\neq0\end{aligned}\right.\end{aligned} $$ 

其中, $ \frac{a_{0}}{2}=A_{0}D_{0},a_{n}=A_{n}E_{n} $，于是我们有

 $$ \begin{aligned}u(x,y)&=\sum_{n=0}^{\infty}u_{n}(x,y)\\&=\frac{a_{0}}{2}\frac{b-y}{b}+\sum_{n=1}^{\infty}a_{n}\cos\frac{n\pi x}{a}\mathrm{sh}\frac{n\pi}{a}(y-b)\end{aligned} $$ 

将之代入非齐次边界条件(8.1.17)式得

 $$ f(x)=\frac{a_{0}}{2}+\sum_{n=1}^{\infty}a_{n}\cos\frac{n\pi x}{a}\mathrm{sh}\left(-\frac{n\pi b}{a}\right) $$ 

故

 $$ a_{0}=\frac{2}{a}\int_{0}^{a}f(x)\mathrm{d}x $$ 

 $$ a_{n}=\frac{-2}{a\mathrm{~sh}\frac{n\pi b}{a}}\int_{0}^{a}f(x)\cos\frac{n\pi x}{a}\mathrm{d}x,\quad n=1,2,\cdots $$ 

于是此问题的解为

 $$ u(x,y)=\frac{b-y}{b}\frac{a_{0}}{2}+\sum_{n=1}^{\infty}a_{n}^{*}\ \frac{\operatorname{sh}\frac{n\pi}{a}(b-y)}{\operatorname{sh}\frac{n\pi b}{a}}\cos\frac{n\pi x}{a} $$ 

其中  $ a_{n}^{*} = \frac{2}{a}\int_{0}^{a} f(x) \cos \frac{n\pi x}{a} dx. $

<!-- page: 154 -->

注 ① 设以 2l 为周期的函数  $ f(x) $ 在  $ [-l, l] $ 上可以展开为三角级数

$$  f(x)=\frac{a_{0}}{2}+\sum_{n=1}^{\infty}\left(a_{n}\cos\frac{n\pi}{l}x+b_{n}\sin\frac{n\pi}{l}x\right)   \tag*{(8.1.19)}$$

则

$$  a_{n}=\frac{1}{l}\int_{-l}^{l}f(x)\cos\frac{n\pi}{l}x\mathrm{d}x,\quad n=0,1,\cdots   \tag*{(8.1.20)}$$

$$  b_{n}=\frac{1}{l}\int_{-l}^{l}f(x)\sin\frac{n\pi x}{l}\mathrm{d}x,\quad n=1,2,\cdots   \tag*{(8.1.21)}$$

若  $ f(x) $ 为奇函数，则

$$  f(x)=\sum_{n=1}^{\infty}b_{n}\sin\frac{n\pi x}{l}   \tag*{(8.1.22)}$$

其中

$$  b_{n}=\frac{2}{l}\int_{0}^{l}f(x)\sin\frac{n\pi}{l}x\mathrm{d}x,\quad n=1,2,\cdots   \tag*{(8.1.23)}$$

若  $ f(x) $ 为偶函数，则

$$  f(x)=\frac{a_0}{2}+\sum_{n=1}^{\infty}a_n\cos\frac{n\pi}{l}x   \tag*{(8.1.24)}$$

其中

$$  a_{n}=\frac{2}{l}\int_{0}^{l}f(x)\cos\frac{n\pi}{l}x\mathrm{d}x,\quad n=0,1,2,\cdots   \tag*{（8.1.25）}$$

②参见 B.H. 斯米尔诺夫，高等数学教程，第二卷 p157.

##### 习题8.1

1. 考察长为 l 的均匀细杆的导热问题. 若

（1）杆的两端温度保持零度；

（2）杆的两端均绝热；

（3）杆的一端为恒温零度，另一端绝热；

设杆的初始温度分布均为  $ \varphi(x) $；试用分离变量法求在这三种不同情况下的杆的导热问题的解，并注意其本征函数的差异。

2. 今有一弦，其两端被钉子钉紧作自由振动，其初位移为

 $$ \varphi(x)=\left\{\begin{aligned}&hx,&&0\leqslant x\leqslant1\\ &h(2-x),&&1\leqslant x\leqslant2\end{aligned}\right. $$ 

初速度为零，试求弦的振动（其中 h 为已知常数）.

3. 求下列定解问题：

(1)

 $$ \left\{\begin{aligned}&u_{t t}=a^{2}u_{x x},\quad0<x<\pi,t>0\\ &u(x,0)=3\sin x\\ &u_{t}(x,0)=0\\ &u(0,t)=u(\pi,t)=0\end{aligned}\right.,\quad0\leqslant x\leqslant\pi； $$ 

(2)

 $$ \left\{\begin{aligned}&u_{t t}-a^{2}u_{x x}=0,\quad0<x<\pi,t>0\\ &u(x,0)=x^{3}\\ &u_{t}\left(x,0\right)=0\\ &u(0,t)=u_{x}\left(\pi,t\right)=0\end{aligned}\right.,\quad0\leqslant x\leqslant\pi\quad; $$ 

 $$ \left\{\begin{aligned}&u_{t}=4u_{x x},\quad0<x<1,t>0\\ &u(x,0)=0,\quad0\leqslant x\leqslant1\\ &u(0,t)=u(1,t)=N_{0}\end{aligned}\right.; $$ 

(3)

 $$ \left\{\begin{aligned}u_{xx}+u_{yy}&=0,\quad0<x<1,0<y<1\\ u(x,0)&=x(x-1)\\ u(x,1)&=0\\ u(0,y)&=u(1,y)=0,\quad0\leqslant x\leqslant1\end{aligned}\right., $$ 

(4)

<!-- page: 155 -->

## 4. 求阻尼波动问题的解

 $$ \left\{\begin{aligned}&u_{u}+a u_{t}=c^{2}u_{x x},&0&<x<l,t>0\\ &u(x,0)=0&0&\leqslant x\leqslant l\\ &u_{t}(x,0)=g(x)&0&\leqslant x\leqslant l\\ &u(0,t)=u(l,t)=0,&t&\geqslant0\\ \end{aligned}\right. $$ 

5. 均匀细杆长为 l，在 x=0 端固定，而另一端受着一个沿杆长的方向的重力 Q，如果在开始一瞬间，突然停止这个力的作用，求杆的纵向振动.

6. 长为 2l 的均匀细杆，被作用在二端的压力压缩成  $ 2l(1-\varepsilon) $，在 t=0 时，把这个荷载移去，试证：若 x=0 是杆的中点，则在时刻 t，坐标为 x 的杆的截面位移  $ u(x,t) $ 由下式确定：

 $$ u(x,t)=\frac{8\varepsilon l}{\pi^{2}}\sum_{n=0}^{\infty}\frac{(-1)^{n+1}}{(2n+1)^{2}}\sin\frac{(2n+1)}{2l}\pi x\cos\frac{(2n+1)\pi a}{2l}t $$ 

7. 求下列高维波动问题的解：

 $$ \begin{cases}u_{tt}=a^{2}\Delta u,\quad0<x<1,0<y<1,0<z<1,t>0\\u(x,y,z;0)=\sin\pi x\sin\pi y\sin\pi z\\u_{t}(x,y,z;0)=0\\u(0,y,z;t)=u(1,y,z;t)=0\\u(x,0,z;t)=u(x,1,z;t)=0\\u(x,y,0;t)=u(x,y,1;t)=0\end{cases} $$ 

8. 长为 l 的柱形管，一端封闭，另一端开放，管外空气中含有某种气体，其浓度为  $ u_{0} $，向管内扩散，求该气体在管内的浓度.

9. 求解杆的横振动问题

 $$ \begin{cases}u_{tt}+a^{2}u_{xxxx}=0,0<x<l\\u\mid_{x=0}=u_{xx}\mid_{x=0}=0\\u\mid_{x=l}=u_{xx}\mid_{x=l}=0\\u\mid_{t=0}=\varphi(x)\\u_{t}\mid_{t=0}=\psi(x)\end{cases} $$ 

10. 边长为 b 的方形薄膜，边缘固定，开始时膜上各点的位移是  $ Axy(b-x)(b-y) $ (A 为常数)，求它从静止开始的自由振动情况.

11. 求量子力学中处于如下一维无限深势阱中粒子的状态：

 $$ \begin{cases}\mathrm{i}\hbar\frac{\partial}{\partial t}\psi(x,t)=-\frac{\hbar^{2}}{2\mu}\frac{\partial^{2}}{\partial x^{2}}\psi(x,t)\\\psi(-a,t)=\psi(a,t)=0\\\psi(x,0)=\frac{1}{\sqrt{a}}\sin\frac{\pi}{a}(x+a)\end{cases} $$ 

提示：令分离变量常数为 E，求得的  $ E_{n} $ 即为粒子能量.

12. 设有一由 x=0, y=0, z=0 和 x=a, y=b, z=c 六个面所围成的长方形盒，盒的 z=c 的面上的电势为  $ f(x, y) $，其余各个面的电势均为零，求盒内任一点处的电势。若盒的六个面上的电势均不为零，则该盒内的电势又该如何求？

<!-- page: 156 -->

13. 求解如下电报方程的定解问题：

 $$ \left\{\begin{aligned}&u_{u}-a^{2}u_{xx}+2bu_{t}+cu=0(0<x<l,t>0)\\ &u(x,0)=\varphi(x),u_{t}(x,0)=\psi(x)(0<x<l)\quad( 其中 ,b,c>0)\\ &u(0,t)=0,u(0,l)=0(t>0)\end{aligned}\right. $$ 

### 8.2 非齐次方程 纯强迫振动

现考虑有界弦（或杆）的纯强迫振动

$$  u_{t t}=a^{2}u_{x x}+f(x,t)   \tag*{(8.2.1)}$$

$$  u\mid_{x=0}=0\Big]   \tag*{(8.2.2)}$$

 $$ u\mid_{x=l}=0 $$ 

$$  \left.\begin{array}{l l}{u\mid_{t=0}=0}\\ {u_{t}\mid_{t=0}=0}\end{array}\right\}   \tag*{(8.2.3)}$$

由于方程中非齐次项  $ f(x,t) $ 的出现，所以，若直接以  $ u(x,t)=X(x)T(t) $ 代入方程，不能实现变量分离。由此，我们自然想到解非齐次线性常微分方程的常数变易法，类似地先考虑与非齐次方程（8.2.1）所对应的齐次问题。

## 1. 对应齐次问题的本征函数

定解问题(8.2.1)～(8.2.3)式所对应的齐次问题为

 $$ \left\{\begin{aligned}u_{tt}&=a^{2}u_{x x}\\ u&\mid_{x=0}=0\\ u&\mid_{x=l}=0\end{aligned}\right. $$ 

通过分离变量 $ \left[u(x,t)=X(x)T(t)\right] $后，得到的本征值问题为

 $$ \left\{\begin{aligned}X^{\prime \prime}-\mu X&=0\\ X(0)&=0,\quad X(l)&=0\end{aligned}\right. $$ 

由此解得本征函数为

 $$ X_{n}(x)=C_{n}\sin\frac{n\pi x}{l},\quad n=1,2,3,\cdots $$ 

## 2.  $ T_{n}(t) $ 的方程的解

仿照常数变易法，令

$$  u(x,t)=\sum_{n=1}^{\infty}T_{n}(t)\sin\frac{n\pi}{l}x   \tag*{(8.2.4)}$$

并将之代入方程(8.2.1)得

 $$ \sum_{n=1}^{\infty}\left[T_{n}^{\prime\prime}(t)+\left(\frac{an\pi}{l}\right)^{2}T_{n}(t)\right]\sin\frac{n\pi x}{l}=f(x,t) $$ 

此等式的左边是右边的函数  $ f(x,t) $ 对于变量 x 的傅里叶正弦展开，故由傅里叶级数

<!-- page: 157 -->

（简称傅氏级数）的系数公式（8.1.23）式有

$$  T_{n}^{\prime\prime}(t)+\left(\frac{a n\pi}{l}\right)^{2}T_{n}(t)=f_{n}(t)   \tag*{(8.2.5)}$$

其中

$$  f_{n}(t)=\frac{2}{l}\int_{0}^{l}f(\alpha,t)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha   \tag*{(8.2.6)}$$

又将(8.2.4)式代入初始条件(8.2.3)得

 $$ \begin{cases}\displaystyle\sum_{n=1}^{\infty}T_{n}(0)\sin\frac{n\pi}{l}x=0\\\displaystyle\sum_{n=1}^{\infty}T_{n}^{\prime}(0)\sin\frac{n\pi x}{l}=0\end{cases} $$ 

比较等式两边展开式的系数有

$$  \left\{\begin{aligned}T_{n}(0)&=0\\ T_{n}^{\prime}(0)&=0\end{aligned}\right.   \tag*{(8.2.7)}$$

由常微分方程的常数变易法 $ ^{①} $（或本篇9.3节例4）可求得关于常微分方程 $ T_{n}(t) $的定

解问题(8.2.5)和(8.2.7)式的解为

$$  T_{n}(t)=\frac{l}{n\pi a}\int_{0}^{t}f_{n}(\tau)\sin\frac{n\pi a}{l}(t-\tau)\mathrm{d}\tau   \tag*{(8.2.8)}$$

## 3. 有界弦(杆)的纯强迫振动的解

将（8.2.8）式代入（8.2.4）式得定解问题（8.2.1）～（8.2.2）式的解为

$$  u(x,t)=\sum_{n=1}^{\infty}\left[\frac{l}{n\pi a}\int_{0}^{t}f_{n}(\tau)\sin\frac{n\pi a}{l}(t-\tau)\mathrm{d}\tau\right]\sin\frac{n\pi}{l}x   \tag*{(8.2.9)}$$

其中  $ f_{n}(t) $ 由 (8.2.6) 式给出.

## 4. 本征函数法

以上求解非齐次方程的方法，显然也适用于求解带有其他齐次边界条件的各类非齐次方程，其主要步骤是

（1）用分离变量法求得对应的齐次问题（即对应的齐次方程连同齐次边界条件的本征函数.

（2）将未知函数  $ u(x,t) $ 或  $ u(x,y) $ 等按上面求得的本征函数展开，其展开系数为另一变量的函数，代入非齐次方程和初始条件（或另一变量的边界条件），得到关于时间因子的常微分方程的初值问题（或另一单元函数的常微分方程的边值问题），用常数变易法或拉氏变换法（见本篇第九章）可求得其解.

（3）将所求得的解代入未知函数的展开式中，即得到原定解问题的解. 这种分离变量的方法按其特点又叫本征函数（或固有函数）法.

#### 例 求解定解问题

<!-- page: 158 -->

$$  u_{t}-a^{2}u_{x}=A\sin\omega t   \tag*{(8.2.10)}$$

$$  u_{x}\mid_{x=0}=0,\quad u_{x}\mid_{x=l}=0   \tag*{(8.2.11)}$$

$$  u\mid_{t=0}=0   \tag*{(8.2.12)}$$

解 对应的齐次方程的本征值问题为

 $$ \left\{\begin{aligned}X^{\prime \prime}-\mu X&=0\\ X^{\prime}(0)&=0,\quad X^{\prime}(l)&=0\end{aligned}\right. $$ 

求解得本征函数

 $$ X_{n}(x)=C_{n}\cos\frac{n\pi}{l}x,\quad n=0,1,2,\cdots $$ 

令

$$  u=\sum_{n=0}^{\infty}T_{n}(t)\cos\frac{n\pi x}{l}   \tag*{(8.2.13)}$$

代入方程(8.2.10)和初始条件(8.2.12)式得

 $$ \left\{\begin{aligned}&\sum_{n=0}^{\infty}\Big[T_{n}^{\prime}(t)+\Big(\frac{n\pi a}{l}\Big)^{2}T_{n}(t)\Big]\cos\frac{n\pi x}{l}=A\sin\omega t\\ &\sum_{n=0}^{\infty}T_{n}(0)\cos\frac{n\pi x}{l}=0\end{aligned}\right. $$ 

比较等式两边傅里叶余弦展开的系数有

 $$ \left\{\begin{aligned}T_{0}^{\prime}(t)&=A\sin\omega t\\ T_{0}(0)&=0\end{aligned}\right.,\quad n=0 $$ 

 $$ \left\{\begin{aligned}T_{n}^{\prime}(t)+\left(\frac{n\pi a}{l}\right)^{2}T_{n}(t)&=0,\\ T_{n}(0)&=0\end{aligned}\right.,\quad n=1,2,3,\cdots $$ 

解之得

 $$ T_{_{0}}(t)=\frac{\mathrm{A}}{\omega}(1-\cos\omega t)\;;T_{_{n}}(t)=0,\quad n=1,2,3,\cdots $$ 

代入（8.2.13）式得到本定解问题的解为

 $$ u(x,t)=\frac{A}{\omega}(1-\cos\omega t) $$ 

不难看出用本征函数法求解非齐次方程的定解问题时，若初始条件（或另一变量的边界条件）是非零值（或非齐次）的，例如，若定解问题（8.2.1）式和（8.2.2）式带有非零值初始条件

 $$ \left\{\begin{aligned}u\mid_{t=0}&=\varphi(x)\\ u_{t}\mid_{t=0}&=\psi(x)\end{aligned}\right. $$ 

则当我们将展开式(8.2.4)代入方程(8.2.1)和上述非零值初始条件时，不仅会得到非齐次的常微分方程(8.2.5)，还会得到非零值的初始条件

<!-- page: 159 -->

$$ \left\{\begin{aligned}T_{n}(0)&=\frac{2}{l}\int_{0}^{l}\varphi(\alpha)\sin\frac{n\pi}{l}\alpha\mathrm{d}\alpha\\ T_{n}^{\prime}(0)&=\frac{2}{l}\int_{0}^{l}\psi(\alpha)\sin\frac{n\pi}{l}\alpha\mathrm{d}\alpha\end{aligned}\right. $$ 

我们固然可以直接求解这一常微分方程的初值问题，但不免增加求解的困难。对于这类问题，由于方程和定解条件都是线性的，故我们往往利用叠加原理，即令

 $$ u(x,t)=u^{\mathrm{I}}\left(x,t\right)+u^{\mathrm{II}}\left(x,t\right) $$ 

使  $ u^{I} $ 和  $ u^{II} $ 分别满足定解问题

 $$ \left\{\begin{aligned}u_{u}^{\mathrm{I}}&=a^{2}u_{x x}^{\mathrm{I}}\\ u^{\mathrm{I}}&\mid_{x=0}=0,u^{\mathrm{I}}\mid_{x=l}=0\\ u^{\mathrm{I}}&\mid_{t=0}=\varphi(x),u_{t}^{\mathrm{I}}\mid_{t=0}=\psi(x)\end{aligned}\right.\quad 和 \quad\left\{\begin{aligned}u_{t t}^{\mathrm{I I}}&=a^{2}u_{x x}^{\mathrm{I I}}+f(x,t)\\ u^{\mathrm{I I}}&\mid_{x=0}=0,u^{\mathrm{I I}}\mid_{x=l}=0\\ u^{\mathrm{I I}}&\mid_{t=0}=0,u_{t}^{\mathrm{I I}}\mid_{t=0}=0\end{aligned}\right. $$ 

于是，用8.1节和本节的方法，分别可求得 $ u^{1} $和 $ u^{2} $，从而可求得 $ u(x,t) $.

注 ① 由高等数学中的常数变易法知，对于二阶线性非齐次常微分方程

若对应的齐次方程

$$  \begin{aligned}y^{\prime \prime}(x)&+p(x)y^{\prime}(x)+q(x)y(x)=f(x)\\y^{\prime \prime}(x)&+p(x)y^{\prime}(x)+q(x)y(x)=0\end{aligned}   \tag*{(8.2.14)}$$

有通解

 $$ y(x)=c_{1}y_{1}(x)+c_{2}y_{2}(x) $$ 

其中  $ c_{1}, c_{2} $ 为常数，则非齐次方程（8.2.14）有特解

 $$ y(x)=c_{1}(x)y_{1}(x)+c_{2}(x)y_{2}(x) $$ 

其中  $ c_{1}(x) $ 和  $ c_{2}(x) $ 可由解方程组

 $$ \left\{\begin{aligned}&c_{1}^{\prime}(x)y_{1}(x)+c_{2}^{\prime}(x)y_{2}(x)=0\\ &c_{1}^{\prime}(x)y_{1}^{\prime}(x)+c_{2}^{\prime}(x)y_{2}^{\prime}(x)=f(x)\end{aligned}\right. $$ 

求得.

#### 习题8.2

1. 求解具有放射性衰变的热传导方程

 $$ u_{t}=a^{2}u_{x x}+A e^{-\beta x},\quad0<x<l,t>0 $$ 

已知边界条件为

 $$ u\mid_{x=0}=0,\quad u\mid_{x=l}=0 $$ 

初始条件为

 $$ u\mid_{t=0}=T_{0}( 常数 ) $$ 

2. 一长为 l 的均匀弦，弦上每一点受外力作用，其力密度为 bxt，若弦的二端是自由的，而初始位移为零，初始速度为  $ (l-x) $，试求弦的横振动.

3. 求解下列定解问题：

(1)

 $$ \begin{cases}u_{tt}=a^{2}u_{xx}+A x,\quad0<x<l,t>0\\u\left(x,0\right)=0,u_{t}\left(x,0\right)=0\\u\left(0,t\right)=0,u\left(l,t\right)=0\end{cases}; $$ 

(2)

 $$ \left\{\begin{aligned}&u_{t}-a^{2}u_{x x}=A\sin\omega t,\quad0<x<l,t>0\\ &u|_{x=0}=u_{x}|_{x=l}=0\\ &u|_{t=0}=0\end{aligned}\right.; $$ 

(3)

 $$ \left\{\begin{aligned}u_{x x}+u_{y y}=&A,\quad0<x<a,0<y<b\\ u\mid_{x=0}=&u\mid_{x=a}=0\\ u\mid_{y=0}=&u\mid_{y=b}=0\end{aligned}\right.; $$ 

(4)

 $$ \begin{cases}u_{tt}=a^{2}u_{xx}+A\mathrm{e}^{-t}\cos\frac{\pi}{2l}x\\u(x,0)=0,u_{t}(x,0)=0\\u_{x}(0,t)=0,u(l,t)=0\end{cases}. $$

<!-- page: 160 -->

4. 在第七章中我们曾用冲量原理在达朗贝尔公式的基础上求得了无界弦的纯强迫振动的解。试用冲量原理求出有界弦的纯强迫振动的解（8.2.9）式。

5. 均匀导线，每单位长的电阻为 r，通以恒定的电流 I，导线表面跟周围温度为零的介质进行热交换，试求导线上温度的变化。设初始温度和两端温度都为零，h 是热交换系数。

### 8.3 非齐次边界条件的处理

以上两节所讨论的问题，都基于边界条件是齐次的。但我们所遇到的实际问题，并非尽然，而往往是非齐次的边界条件更多。现以具有非齐次边界条件的有界弦的自由振动为例来研究这一问题。即

$$  u_{t t}-a^{2}u_{x x}=0   \tag*{(8.3.1)}$$

 $$ u\mid_{x=0}=g(t) $$ 

$$  u\mid_{x=l}=h(t)\Big\}   \tag*{(8.3.2)}$$

 $$ u\mid_{t=0}=\varphi(x) $$ 

$$  u_{t}\mid_{t=0}=\psi(x)\int   \tag*{(8.3.3)}$$

此时，对于边界条件(8.3.2)式将无法应用分离变量法，因为若将分离变数形式的解 $ u(x,t)=X(x)T(t) $代入(8.3.2)式，就会得到 $ X(0)=\frac{g(t)}{T(t)} $， $ X(l)=\frac{h(t)}{T(t)} $两个不能确定的值，即不能引出任何边界条件，所以首先必须把边界条件齐次化。

## 1. 边界条件的齐次化

为此，我们引入新的未知函数  $ v(x,t) $ 和辅助函数  $ w(x,t) $，令

$$  u(x,t)=v(x,t)+w(x,t)   \tag*{(8.3.4)}$$

若能找到函数  $ w(x,t) $，使它具备性质

$$  \begin{cases}w\mid_{x=0}=g(t)\\w\mid_{x=l}=h(t)\end{cases}   \tag*{(8.3.5)}$$

则新未知函数  $ v(x,t)=u(x,t)-w(x,t) $，便满足齐次边界条件

 $$ \left\{\begin{aligned}v&\mid_{x=0}=0\\ v&\mid_{x=l}=0\end{aligned}\right. $$ 

## 2. 辅助函数  $ w(x,t) $ 的选取

由此看来，问题的关键是寻找一个满足条件(8.3.5)式的函数 $ w(x,t) $. 实际上，对于任意固定的t，满足(8.3.5)式的 $ w(x,t) $所表示的是，过x-w平面上 $ [0,g(t)] $和 $ [l,h(t)] $两点的曲线. 这种曲线有很多条，最简单的是直线，令之为

 $$ w(x,t)=A(t)x+B(t) $$ 

其中， $ A(t) $ 和  $ B(t) $ 均为 t 的函数. 于是，由(8.3.5)式有

<!-- page: 161 -->

$$ \left\{\begin{aligned}&B(t)=g(t)\\ &A(t)l+B(t)=h(t)\end{aligned}\right. $$ 

从而求得

 $$ \left\{\begin{aligned}B(t)&=g(t)\\ A(t)&=\frac{h(t)-g(t)}{l}\end{aligned}\right. $$ 

故有

$$  \mathcal{w}(x,t)=\frac{h(t)-g(t)}{l}x+g(t)   \tag*{(8.3.6)}$$

这样一来，定解问题(8.3.1)～(8.3.3)式便转化为关于 $ v(x,t) $的定解问题

$$  v_{tt}-a^{2}v_{xx}=-\left(w_{tt}-a^{2}w_{xx}\right)   \tag*{(8.3.7)}$$

$$  v\mid_{x=0}=0\Big]   \tag*{(8.3.8)}$$

 $$ v\mid_{x=i}=0\big) $$ 

 $$ v\mid_{t=0}=\varphi(x)-w(x,0) $$ 

$$  v_{t}\mid_{t=0}=\psi(x)-w_{t}(x,0)   \tag*{(8.3.9)}$$

这正是上节我们介绍过的带有齐次边界条件的非齐次方程的定解问题，可用上节介绍过的本征函数法来求解.

例 1 研究一端固定，一端作周期运动  $ \sin\omega t $ 的弦振动.

解 其定解问题为

 $$ \begin{cases}u_{tt}-a^{2}u_{xx}=0,&0<x<l\\u(0,t)=0,u(l,t)=\sin\omega t&\\u(x,0)=u_{l}(x,0)=0,&0\leqslant x\leqslant l\end{cases} $$ 

令

 $$ u(x,t)=v(x,t)+w(x,t) $$ 

由（8.3.6）式选

 $$ w(x,t)=\frac{\sin\omega t}{l}x+0=\frac{x}{l}\sin\omega t $$ 

则(8.3.7)~(8.3.9)式变为

 $$ \begin{cases}v_{tt}-a^{2}v_{xx}=\frac{\omega^{2}}{l}x\sin\omega t\\v(0,t)=v(l,t)=0\\v(x,0)=0,\quad v_{t}(x,0)=-\frac{\omega}{l}x\end{cases} $$ 

又令  $ v(x,t)=v^{\mathrm{I}}(x,t)+v^{\mathrm{II}}(x,t) $，其中

 $$ \left\{\begin{aligned}&v_{t t}^{\mathrm{I}}-a^{2}v_{x x}^{\mathrm{I}}=0\\ &v^{\mathrm{I}}\left(0,t\right)=v^{\mathrm{I}}\left(l,t\right)=0\\ &v^{\mathrm{I}}\left(x,0\right)=0,\quad v_{t}^{\mathrm{I}}\left(x,0\right)=-\frac{\omega}{l}x\end{aligned}\right. $$

<!-- page: 162 -->

$$ \begin{cases}v_{tt}^{\mathbb{I}}-a^{2}v_{xx}^{\mathbb{I}}=\frac{\omega^{2}}{l}x\sin\omega t\\v^{\mathbb{I}}\left(0,t\right)=v^{\mathbb{I}}\left(l,t\right)=0\\v^{\mathbb{I}}\left(x,0\right)=v_{t}^{\mathbb{I}}\left(x,0\right)=0\end{cases} $$ 

记  $ \omega_{n}=\frac{n\pi}{l}a $ ，解之得

 $$ v^{\mathrm{I}}\left(x,t\right)=\sum_{n=1}^{\infty}\left(-1\right)^{n}\frac{2\omega l}{a\left(n\pi\right)^{2}}\sin\omega_{n}t\sin\frac{n\pi x}{l} $$ 

 $$ \begin{align*}v^{\parallel}\left(x,t\right)&=\sum_{n=1}^{\infty}(-1)^{n+1}\frac{\omega^{2}l}{a\left(n\pi\right)^{2}}\biggl[\frac{\sin\omega t+\sin\omega_{n}t}{\omega+\omega_{n}}-\frac{\sin\omega_{n}t-\sin\omega t}{\omega_{n}-\omega}\biggr]\sin\frac{n\pi}{l}x\\&=\sum_{n=1}^{\infty}(-1)^{n+1}\frac{2\omega^{2}l}{a\left(n\pi\right)^{2}}\frac{\omega\sin\omega_{n}t-\omega_{n}\sin\omega t}{\omega^{2}-\omega_{n}^{2}}\sin\frac{n\pi x}{l}\end{align*} $$ 

将  $ u(x,t) $ 按  $ \sin\frac{n\pi}{l}x $ 展开得

 $$ w(x,t)=\sum_{n=1}^{\infty}(-1)^{n+1}\frac{2}{n\pi}\sin\omega t\sin\frac{n\pi}{l}x $$ 

故立即可求得该问题的解  $ u(x,t) $ 为

 $$ u(x,t)=\sum_{n=1}^{\infty}\frac{(-1)^{n}2n\pi}{l^{2}(\omega^{2}-\omega_{n}^{2})}\sin\omega t\sin\frac{n\pi}{l}x-\sum_{n=1}^{\infty}\frac{(-1)^{n}2\omega}{al(\omega^{2}-\omega_{n}^{2})}\sin\omega_{n}t\sin\frac{n\pi}{l}x $$ 

## 3. 其他类非齐次边界条件的处理

以上处理非齐次边界条件的方法，也适用于附有其他非齐次边界条件的各类定解问题，但有时需选择  $ w(x,t) $ 为 x 的二次式，否则系数  $ A(t) $、 $ B(t) $ 无法确定。如，

 $$ \left\{\begin{aligned}&u_{t}-D u_{x x}=0\\ &u_{x}\mid_{x=0}=g(t),\quad u_{x}\mid_{x=l}=h(t)\end{aligned}\right. $$ 

为使边界条件齐次化，需选择  $  w(x,t)  $，使  $  \omega_{x}|_{x=0}=g(t), w_{x}|_{x=l}=h(l)  $. 此时若选  $  w=A(t)x+B(t)  $，则无法将边界条件代入来确定  $  A(t)  $、 $  B(t)  $. 但若选择

 $$ w=A(t)x^{2}+B(t)x+C(t) $$ 

则

 $$ \left\{\begin{aligned}w_{x}\mid_{x=0}&=2A(t)\bullet0+B(t)=g(t)\\ w_{x}\mid_{x=l}&=2A(t)\bullet l+B(t)=h(t)\end{aligned}\right. $$ 

由此得

 $$ \left\{\begin{aligned}A(t)&=\frac{h(t)-g(t)}{2l}\\ B(t)&=g(t)\end{aligned}\right. $$ 

至于  $ C(t) $，对边界条件不起作用，它是作为“机动函数”出现的，不妨取为零。

对于描绘稳定现象的定解问题，显然，不必要求（也不可能要求）所有的边界条件都是齐次的.

<!-- page: 163 -->

例2 研究如图8.2所示的半带形区域内的电势 $ u(x,y) $.已知边界x=0和y=0上的电势都是零，而边界x=a上的电势为 $ u_{0} $(常数).

解 其定解问题为

 $$ u_{xx}+u_{yy}=0,\quad0<x<a,0<y<\infty $$ 

$$  \left\{\begin{array}{l l}u\mid_{x=0}=0,u\mid_{x=a}=u_{0},&0\leqslant y<\infty\\ u\mid_{y=0}=0,&0\leqslant x\leqslant a\end{array}\right.   \tag*{(8.3.11)}$$

<div style="text-align: center;"><img src="images/p0163_img_in_image_box_635_145_858_385.jpg" alt="图8.2" width="23%" /></div>


为使关于变量 x 的边界条件齐次化，令

 $$ u(x,y)=v(x,y)+w(x,y) $$ 

<div style="text-align: center;"><div style="text-align: center;">图8.2</div> </div>


由（8.3.6）式，其中

 $$ w(x,y)=\frac{u_{0}}{a}x $$ 

于是  $ v(x,y) $ 的定解问题是

$$  v_{xx}+v_{yy}=0,\qquad0<x<a,0<y<\infty   \tag*{(8.3.13)}$$

$$  v\mid_{x=0}=0,v\mid_{x=a}=0,\quad0\leqslant y<\infty   \tag*{（8.3.14）}$$

$$  \left|\begin{array}{c}v\mid_{y=0}=-\frac{u_{0}}{a}x,\quad0\leqslant x\leqslant a\end{array}\right.   \tag*{（8.3.15）}$$

用分离变量法求得满足(8.3.13)式和(8.3.14)式的解为

 $$ v(x,y)=\sum_{n=1}^{\infty}(A_{n}\mathrm{e}^{\frac{n\pi x}{a}}+B_{n}\mathrm{e}^{-\frac{n\pi x}{a}})\sin\frac{n\pi x}{a} $$ 

其中  $ A_{n} $ 和  $ B_{n} $ 为待定常数. 又因为当  $ y \to \infty $ 时  $ u(x, y) $ 应是有限的（自然边界条件），即  $ v\big|_{v \to \infty} = $ 有限值 (8.3.16)

故由边界条件(8.3.15)式和(8.3.16)式可定出

 $$ A_{n}=0,B_{n}=(-1)^{n}\frac{2u_{0}}{n\pi},\quad n=1,2,3,\cdots $$ 

于是最后可得到原定解问题(8.3.10)～(8.3.12)式的解为

 $$ u(x,y)=\frac{u_{0}}{a}x+\frac{2u_{0}}{\pi}\sum_{n=1}^{\infty}\frac{(-1)^{n}}{n}\mathrm{e}^{-\frac{n\pi x}{a}}\sin\frac{n\pi x}{a} $$ 

还要指出，由于 w 的选取有一定的任意性，故选取不同的 w 所得到的解 u 在形式上可能很不相同，但根据解的唯一性可知这些解实质上是一样的。

综上所述，在用分离变量法解偏微分方程时，为了使边界条件实现变量分离，应使非齐次的边界条件齐次化。对于未知函数  $ u(x,t) $ 的定解问题，具体做法是：

（1）作变换  $ u(x,t)=v(x,t)+w(x,t) $;

（2）适当选取  $ w(x,t) $，使关于  $ v(x,t) $ 的边界条件齐次化，通常选  $ w(x,t) $ 为 x 的一次式

 $$ w(x,t)=A(t)x+B(t) $$ 

但当两个边界条件均为第二类时，需选择  $ w(x,t) $ 为 x 的二次式

 $$ w(x,t)=A(t)x^{2}+B(t)x+C(t) $$

<!-- page: 164 -->

其中 $ A(t) $， $ B(t) $和 $ C(t) $由 $ u(x,t) $的边界条件定.

（3）解关于  $ v(x,t) $ 的带有齐次边界条件的定解问题，从而最后可求得  $ u(x,t) $.

#### 习题8.3

1. 长为 l 而固定于 x=0 一端的均匀细杆，处于静止状态中，在 t=0 时，一个沿着杆长方向的力 Q（每单位面积上）加在杆的另一端上，求在 t>0 时，杆上各点的位移.

2. 有一长为 l，侧面绝热，而初始温度为  $ 0^{\circ}C $ 的均匀细杆，它的一端 x=l 处温度永远保持  $ 0^{\circ}C $，而另一端 x=0 处温度随时间直线上升，即  $ \left.u\right|_{x=0}=ct $ (c 是常数)，求 t>0 时，杆的温度分布.

3. 设弹簧一端固定，另一端在外力作用下作周期振动，此时定解问题为

 $$ \left\{\begin{aligned}&u_{t t}=a^{2}u_{x x},0<x<l\\ &u(x,0)=u_{t}(x,0)=0\\ &u(0,t)=0,u(l,t)=A\sin\omega t\end{aligned}\right. $$ 

试求解  $ u(x,t) $. 其中  $ \frac{\omega l}{\pi a} $ 不为正整数, a, l,  $ \omega $ 均为常数.

## 4. 求解定解问题

 $$ \left\{\begin{aligned}&u_{x x}+u_{y y}=f(x,y)\\ &u\mid_{x=0}=g(y),u\mid_{x=a}=h(y),\quad&0\leqslant y\leqslant b\\ &u_{y}\mid_{y=0}=\varphi(x),u_{y}\mid_{y=b}=\psi(x),\quad&0\leqslant x\leqslant a\end{aligned}\right. $$ 

5. 求解下列有源热传导的定解问题：

 $$ \begin{cases}u_{t}-a^{2}u_{xx}=\cos\frac{x}{2}\left(0<x<\pi,t>0\right)\\u(x,0)=xt\cos\frac{x}{2}\left(0\leqslant x\leqslant\pi\right)\\u_{x}\left(0,t\right)=1,u(\pi,t)=\pi(t>0)\end{cases} $$ 

### 8.4 正交曲线坐标系中的分离变量法

由前面的学习我们了解到，在用分离变量法求解数理方程时，不仅对于方程本身，而且对于边界条件，都要进行变量的分离。一般而言，能否应用分离变量法，除了与方程和边界条件本身的形式有关之外，还与采用什么样的坐标系有关，坐标系选择不当，变量就分不开。如，圆的狄氏问题（带有第一类边值条件的定解问题，称为狄利克雷问题，简称狄氏问题），其边界条件为  $ u\big|_{\rho=a}=0 $，其中 a 为圆的半径。现对这一边界条件进行变数分离，若选择直角坐标系，即  $ u=u(x,y) $，令  $ u(x,y)=X(x)Y(y) $，则由  $ |u|_{p=a}=0 $ 有  $ XY|\sqrt{x^{2}+y^{2}}=a=0 $，边界条件不可能按单变量分出来；但若选择极坐标，即  $ u=u(\rho,\varphi) $，令  $ u(\rho,\varphi)=R(\rho)\Phi(\varphi) $，则由  $ |u|_{p=a}=0 $ 有  $ R(a)\Phi(\varphi)=0 $，从而有  $ R(a)=0 $，边界条件分出来了。有时坐标系选择不当，即使变量分得开，也会使问题变得复杂。可见适当选择坐标系，对于分离变量法而言是相当重要的。

在这一部分我们将讨论在正交曲线坐标系，主要是柱坐标系和球坐标系中两个

<!-- page: 165 -->

重要方程的分离变量. 为此, 首先需引入正交曲线坐标系的概念.

## 1. 正交曲线坐标系

由三族互相正交的曲面而定义的坐标系称为正交曲线坐标系. 若以  $ q_{1}, q_{2}, q_{3} $ 表示正交曲线坐标，则它们与直角坐标的相互关系可表示为

 $$ \left\{\begin{aligned}x&=x(q_{1},q_{2},q_{3})\\ y&=y(q_{1},q_{2},q_{3}),\\ z&=z(q_{1},q_{2},q_{3})\end{aligned}\right.\quad\left\{\begin{aligned}q_{1}&=q_{1}(x,y,z)\\ q_{2}&=q_{2}(x,y,z)\\ q_{3}&=q_{3}(x,y,z)\end{aligned}\right. $$ 

如

（1）柱坐标 $ (\rho,\varphi,z) $

$$  \begin{cases}x=\rho\cos\varphi\\y=\rho\sin\varphi,\\z=z\end{cases}\begin{cases}\rho=\sqrt{x^{2}+y^{2}}\\\varphi=\arctan\frac{y}{x}\\z=z\end{cases}   \tag*{(8.4.1)}$$

其中， $ 0 \leqslant \rho < \infty, -\infty < \varphi < \infty, -\infty < z < \infty $（见图 8.3）.

（2）球坐标 $ (r,\theta,\varphi) $

$$  \begin{cases}x=r\sin\theta\cos\varphi\\y=r\sin\theta\sin\varphi,\\z=r\cos\theta\end{cases}\begin{cases}r=\sqrt{x^{2}+y^{2}+z^{2}}\\\theta=\arctan\frac{\sqrt{x^{2}+y^{2}}}{z}\\\varphi=\arctan\frac{y}{x}\end{cases}   \tag*{(8.4.2)}$$

其中， $ 0 \leqslant r < \infty, 0 \leqslant \theta \leqslant \pi, -\infty < \varphi < \infty $（见图 8.4）.

<div style="text-align: center;"><img src="images/p0165_img_in_image_box_155_842_400_1092.jpg" alt="图8.3" width="25%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图8.3</div> </div>


<div style="text-align: center;"><img src="images/p0165_img_in_image_box_498_847_801_1093.jpg" alt="图8.4" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图8.4</div> </div>


其他的正交曲线坐标还有不少，如抛物柱面坐标、椭球坐标等等，但我们经常用到的还是以上两种。

<!-- page: 166 -->

## 2. 如何选择坐标系

前面我们已提到在用分离变量法解题时，为了使变量分得开和问题易于求解，必须正确选择坐标系。一般而言，应当选择坐标系，使所讨论问题的边界与一个或几个坐标曲面的部分面重合。如，当边界面为半径为 a、高为 h 的圆柱面时，就应选择柱坐标  $ (\rho,\varphi,z) $，使其边界面与坐标面  $ \rho=a,z=0,z=h $ 的部分重合；若边界面是半径为 a 的球面，就应选择球坐标  $ (r,\theta,\varphi) $，使边界面与坐标面 r=a 重合；若边界面为生成角为  $ \theta_{1} $ 的圆锥面，也应选择球坐标，使边界面与坐标面  $ \theta=\theta_{1} $ 重合等等。

由于许多数理方程中都涉及函数的拉普拉斯量

$$  \Delta u=\frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}+\frac{\partial^{2}u}{\partial z^{2}}   \tag*{(8.4.3)}$$

故在此，有必要先导出常用的正交曲线坐标系中的  $ \Delta u $ 的表达式.

## 3. 正交曲线坐标系中的  $ \Delta u $

我们可以通过正交曲线坐标和直角坐标的关系，应用对复合函数求导的方法，来分别得到柱坐标、球坐标等正交曲线坐标系中的 $ \Delta u $的表达式.

由（8.4.1）式有

$$  \begin{aligned}\frac{\partial u}{\partial\rho}&=\frac{\partial u}{\partial x}\frac{\partial x}{\partial\rho}+\frac{\partial u}{\partial y}\frac{\partial y}{\partial\rho}\\&=\frac{\partial u}{\partial x}\cos\varphi+\frac{\partial u}{\partial y}\sin\varphi\end{aligned}   \tag*{(8.4.4)}$$

故

$$  \begin{aligned}\frac{\partial^{2}u}{\partial\rho^{2}}&=\Big(\frac{\partial^{2}u}{\partial x^{2}}\frac{\partial x}{\partial\rho}+\frac{\partial^{2}u}{\partial x\partial y}\frac{\partial y}{\partial\rho}\Big)\cos\varphi+\Big(\frac{\partial^{2}u}{\partial y\partial x}\frac{\partial x}{\partial\rho}+\frac{\partial^{2}u}{\partial y^{2}}\frac{\partial y}{\partial\rho}\Big)\sin\varphi\\&=\frac{\partial^{2}u}{\partial x^{2}}\cos^{2}\varphi+2\frac{\partial^{2}u}{\partial x\partial y}\sin\varphi\cos\varphi+\frac{\partial^{2}u}{\partial y^{2}}\sin^{2}\varphi\end{aligned}   \tag*{(8.4.5)}$$

类似可得

$$  \begin{aligned}\frac{\partial u}{\partial\varphi}=&-\rho\frac{\partial u}{\partial x}\mathrm{s i n}\varphi+\rho\frac{\partial u}{\partial y}\mathrm{c o s}\varphi\\\frac{\partial^{2}u}{\partial\varphi^{2}}=&\rho^{2}\frac{\partial^{2}u}{\partial x^{2}}\mathrm{s i n}^{2}\varphi-2\rho^{2}\frac{\partial^{2}u}{\partial x\partial y}\mathrm{s i n}\varphi\mathrm{c o s}\varphi+\rho^{2}\frac{\partial^{2}u}{\partial y^{2}}\mathrm{c o s}^{2}\varphi\\&-\rho\big(\frac{\partial u}{\partial x}\mathrm{c o s}\varphi+\frac{\partial u}{\partial y}\mathrm{s i n}\varphi\big)\end{aligned}   \tag*{(8.4.6)}$$

将(8.4.6)式两边乘以 $ \frac{1}{\rho^{2}} $，再与(8.4.5)式相加得

 $$ \frac{\partial^{2}u}{\partial\rho^{2}}+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}=\frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}-\frac{1}{\rho}\big(\frac{\partial u}{\partial x}\mathrm{c o s}\varphi+\frac{\partial u}{\partial y}\mathrm{s i n}\varphi\big) $$ 

上式两边分别加上 $ \frac{\partial^{2}u}{\partial z^{2}} $并将（8.4.4）式代入右边得

<!-- page: 167 -->

$$ \begin{array}{l}\frac{\partial^{2}u}{\partial\rho^{2}}+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}+\frac{\partial^{2}u}{\partial z^{2}}=\left(\frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}+\frac{\partial^{2}u}{\partial z^{2}}\right)-\frac{1}{\rho}\frac{\partial u}{\partial\rho}\end{array} $$ 

将（8.4.3）式代入上式右边移项即得

或

$$  \left.\begin{array}{l}\Delta u=\frac{\partial^{2}u}{\partial\rho^{2}}+\frac{1}{\rho}\frac{\partial u}{\partial\rho}+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}+\frac{\partial^{2}u}{\partial z^{2}}\\ \Delta u=\frac{1}{\rho}\frac{\partial}{\partial\rho}\Big(\rho\frac{\partial u}{\partial\rho}\Big)+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}+\frac{\partial^{2}u}{\partial z^{2}}\end{array}\right\}   \tag*{(8.4.7)}$$

此即在柱坐标中的  $ \Delta u $ 的表达式.

由于极坐标 $ (\rho,\varphi) $可看成是柱坐标 $ (\rho,\varphi,z) $当z=0的特例，故我们可立即得到极坐标中的 $ \Delta u $的表达式为

$$  \Delta u=\frac{1}{\rho}\frac{\partial}{\partial\rho}\big(\rho\frac{\partial u}{\partial\rho}\big)+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}   \tag*{(8.4.8)}$$

用类似的方法我们也易于推得球坐标中的  $ \Delta u $ 的表达式为

$$  \Delta u=\frac{1}{r^{2}}\frac{\partial}{\partial r}\Big(r^{2}\frac{\partial u}{\partial r}\Big)+\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}\Big(\sin\theta\frac{\partial u}{\partial\theta}\Big)+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}u}{\partial\varphi^{2}}   \tag*{(8.4.9)}$$

在三类数理方程中，如果我们把波动方程和热传导方程中的时间变数 t 的单元函数分离出来，即

令

$$  u(x,y,z;t)=T(t)v(x,y,z)   \tag*{(8.4.10)}$$

则齐次波动方程  $ u_{tt} - a^{2} \Delta u = 0 $ 就化为

即

 $$ \begin{aligned}&T^{\prime \prime}(t)v(x,y,z)-a^{2}T(t)\Delta v=0\\ &\quad\frac{T^{\prime \prime}}{a^{2}T}=\frac{\Delta v}{v}=-\lambda\\ \end{aligned} $$ 

其中 $ -\lambda $为任意常数.从而得到关于 $ T(t) $的一个常微分方程和关于 $ v(x,y,z) $的一个偏微分方程

$$  \begin{aligned}T^{\prime \prime}+a^{2}\lambda T&=0\\\Delta v+\lambda v&=0\end{aligned}   \tag*{(8.4.11)}$$

(8.4.11)式称为亥姆霍兹(Helmhotz)方程. 同样的，若将(8.4.10)式代入齐次热传导方程 $ u_{t}-D\Delta u=0 $，有

 $$ \begin{aligned}T^{\prime}+D\lambda T&=0\\\Delta v+\lambda v&=0\end{aligned} $$ 

也得到一个  $ T(t) $ 的常微分方程和  $ v(x,y,z) $ 的亥姆霍兹方程。而泊松方程的齐次方程是拉普拉斯方程。常系数常微分方程我们均会求解，因此，若欲用分离变量法来求解三类数理方程，必须对亥姆霍兹方程和拉普拉斯方程进行变量分离。

由于在直角坐标系中，无论是亥姆霍兹方程还是拉普拉斯方程，分离变量后得到的都是我们所熟悉的常系数常微分方程。故在此我们仅在柱、球坐标系中对此二方程进行变量分离。

<!-- page: 168 -->

## 4. 柱坐标系中亥姆霍兹方程的分离变量

将（8.4.11）式写成

$$  \Delta u+\lambda u=0   \tag*{(8.4.12)}$$

并将柱坐标中的  $ \Delta u $ 的表达式代入有

 $$ \frac{1}{\rho}\frac{\partial}{\partial\rho}\big(\rho\frac{\partial u}{\partial\rho}\big)+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}+\frac{\partial^{2}u}{\partial z^{2}}+\lambda u=0 $$ 

令

 $$ u(\rho,\varphi,z)=R(\rho)\Phi(\varphi)Z(z) $$ 

代入上式得

 $$ \frac{\Phi Z}{\rho}\frac{\mathrm{d}}{\mathrm{d}\rho}\big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\big)+\frac{R Z}{\rho^{2}}\frac{\mathrm{d}^{2}\Phi}{\mathrm{d}\varphi^{2}}+R\Phi\frac{\mathrm{d}^{2}Z}{\mathrm{d}z^{2}}+\lambda R\Phi Z=0 $$ 

两边用 $ \frac{1}{R\Phi Z} $遍乘并移项得

 $$ \frac{1}{\rho R}\frac{\mathrm{d}}{\mathrm{d}\rho}\big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\big)+\frac{1}{\rho^{2}\Phi}\frac{\mathrm{d}^{2}\Phi}{\mathrm{d}\varphi^{2}}+\lambda=-\frac{1}{Z}\frac{\mathrm{d}^{2}Z}{\mathrm{d}z^{2}} $$ 

上式的左边是 $ \rho $和 $ \varphi $的函数，与z无关；右边是z的函数，与 $ \rho $和 $ \varphi $无关，故要使这式成立，除非两边是同一个常数.设此常数为 $ \mu $，则

 $$ Z^{\prime\prime}+\mu Z=0 $$ 

 $$ \frac{1}{\rho R}\frac{\mathrm{d}}{\mathrm{d}\rho}\big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\big)+\frac{1}{\rho^{2}\Phi}\frac{\mathrm{d}^{2}\Phi}{\mathrm{d}\varphi^{2}}+\lambda-\mu=0 $$ 

对于后一方程，两边用  $ \rho^{2} $ 遍乘并移项得

 $$ \frac{\rho}{R}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)+\rho^{2}(\lambda-\mu)=-\frac{1}{\Phi}\frac{\mathrm{d}^{2}\Phi}{\mathrm{d}\varphi^{2}} $$ 

上式左边只是 $ \rho $的函数，右边只是 $ \varphi $的函数，故此式成立，除非两边等于同一常数，令之为 $ n^{2} $，并设 $ \lambda-\mu\geqslant0 $，记之为 $ k^{2}(k $为实数；若 $ \lambda-\mu<0 $，就记之为 $ -k^{2} $，这种情况以后讨论)，则有

 $$ \Phi^{\prime \prime}+n^{2}\Phi=0 $$ 

 $$ \frac{\rho}{R}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)+k^{2}\rho^{2}-n^{2}=0 $$ 

后一方程即

 $$ \rho^{2}R^{\prime \prime}+\rho R^{\prime}+(k^{2}\rho^{2}-n^{2})R=0 $$ 

综上所述，通过在柱坐标中分离变量，解偏微分方程（8.4.12）的问题，就化为了解三个常微分方程

$$  Z^{\prime \prime}+\mu Z=0   \tag*{(8.4.13)}$$

$$  \Phi^{\prime\prime}+n^{2}\Phi=0   \tag*{(8.4.14)}$$

$$  \rho^{2}R^{\prime \prime}+\rho R^{\prime}+(k^{2}\rho^{2}-n^{2})R=0   \tag*{（8.4.15）}$$

的问题. 其中  $ \mu $、 $ n^{2} $、 $ k^{2} $ 都是在分离变量过程中所引入的常数. 与弦的振动问题一样,

<!-- page: 169 -->

它们不能任意取值，而要根据边界条件取某些特定的值，分别称为方程（8.4.13）、（8.4.14）、（8.4.15）的本征值。实际上，由于受周期性的边界条件的限制，方程（8.4.14）中的本征值，只能取n=0,1,2，…（见本节例题）.

方程(8.4.13)和(8.4.14)是常系数常微分方程，其解易于得到. 方程(8.4.15)是变系数常微分方程，若作变换  $ x=k\rho, y(x)=R(\rho) $，则(8.4.15)式化为

$$  x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-n^{2})y=0^{①}   \tag*{(8.4.16)}$$

称之为 n 阶贝塞尔(Bessel)方程. 它的求解和解的性质将在第三篇特殊函数中讨论（见第三篇 12.1 节、12.2 节）.

注意到拉普拉斯方程（简称为拉氏方程）

 $$ \Delta u=0 $$ 

只不过是亥姆霍兹方程  $ \Delta u + \lambda u = 0 $ 当  $ \lambda = 0 $ 的特例，于是由上面的讨论我们立即可知柱坐标系中拉普拉斯方程分离变量后也会得到如下三个常微分方程：

 $$ \left\{\begin{aligned}&Z^{\prime \prime}+\mu Z=0\\ &\Phi^{\prime \prime}+n^{2}\Phi=0(n=0,1,2,\cdots)\\ &\rho^{2}R^{\prime \prime}+\rho R^{\prime}+(k^{2}\rho^{2}-n^{2})R=0\end{aligned}\right. $$ 

只不过其中  $ k^{2}=0-\mu=-\mu $ (设  $ -\mu \geqslant 0 $).

例 一个半径为 a 的薄圆盘，上下两面绝热. 若已知圆盘边缘的温度，求圆盘上稳定的温度分布.

解 由于圆盘的上下两面绝热，没有热量流动，且圆盘很薄，故可以化为二维问题来处理. 又因为无热源存在，故其温度分布  $ u(x,y) $ 应满足

$$  \left\{\begin{array}{l}\Delta u=0,\rho<a\\ u\mid_{\rho=a}=f(\varphi)\end{array}\right.   \tag*{(8.4.18)}$$

其中  $ f(\varphi) $ 为给定的函数. 将极坐标系中的  $ \Delta u $ 的表达式 (8.4.8) 代入 (8.4.17) 式得

$$  \frac{1}{\rho}\frac{\partial}{\partial\rho}\big(\rho\frac{\partial u}{\partial\rho}\big)+\frac{1}{\rho^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}=0   \tag*{(8.4.19)}$$

令

$$  u(\rho,\varphi)=R(\rho)\Phi(\varphi)   \tag*{(8.4.20)}$$

代入(8.4.19)式，按上面的步骤分离变量得

 $$ \left\{\begin{aligned}&\Phi^{\prime \prime}+n^{2}\Phi=0\\ &\frac{1}{\rho}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)-\frac{n^{2}}{\rho^{2}}R=0\end{aligned}\right. $$ 

至于边界条件(8.4.18)，由于是非齐次的，变数不能分离，但经过讨论我们却可确定n的取值及相应的本征函数.

在一般的物理问题中，函数  $  u(\rho, \varphi)  $ 是单值的，因此应有

 $$ u(\rho,\varphi+2\pi)=u(\rho,\varphi) $$ 

由（8.4.20）式，此即

<!-- page: 170 -->

$$ R(\rho)\Phi(\varphi+2\pi)=R(\rho)\Phi(\varphi) $$ 

也就是要求  $ \varphi $ 满足条件

 $$ \Phi(\varphi+2\pi)=\Phi(\varphi) $$ 

这就给关于 $ \Phi(\varphi) $的方程提出了定解条件，常称之为周期性的边界条件。故我们现在首先面临的是解本征值问题

$$  \left\{\begin{array}{l}\Phi^{\prime \prime}+n^{2}\Phi=0\\ \Phi(\varphi+2\pi)=\Phi(\varphi)\end{array}\right.   \tag*{(8.4.21)}$$

若 n=0，则(8.4.21)式的解为

 $$ \Phi(\varphi)=B_{0}\varphi+A_{0} $$ 

其中  $ A_{0} $、 $ B_{0} $ 为常数。由边界条件(8.4.22)有

 $$ B_{0}(\varphi+2\pi)+A_{0}=B_{0}\varphi+A_{0} $$ 

所以必须 $ B_{0}=0 $即

 $$ \Phi(\varphi)=A_{0} $$ 

若 $ n^{2}<0 $. 令 $ n^{2}=-\alpha^{2}(\alpha>0) $，则(8.4.21)式的通解为

 $$ \Phi(\varphi)=A\mathrm{e}^{\alpha\varphi}+B\mathrm{e}^{-\alpha\varphi} $$ 

由于实指数函数不是周期函数，显然它不满足(8.4.22)式，因此 $ n^{2} $不能取负值.

若 $ n^{2}>0 $，则(8.4.21)式的通解为

 $$ \Phi(\varphi)=A_{n}\cos n\varphi+B_{n}\sin n\varphi $$ 

将边界条件(8.4.22)代入得

 $$ A_{n}\cos n(\varphi+2\pi)+B_{n}\sin n(\varphi+2\pi)=A_{n}\cos n\varphi+B_{n}\sin n\varphi $$ 

所以，必须取  $ n=\pm1,\pm2,\cdots $ ，上式才能成立。但 n 取正整数和 n 取负整数时方程（8.4.21）的解是线性相关的，故只需取 n=1,2,\cdots

综上所述，本征值问题（8.4.21）～（8.4.22）式的本征值为

 $$ n^{2},\quad n=0,1,2,\cdots $$ 

相应的本征函数为

$$  \Phi_{n}(\varphi)=A_{n}\cos n\varphi+B_{n}\sin n\varphi   \tag*{(8.4.23)}$$

再求解关于  $ R(\rho) $ 的方程，即

 $$ \rho^{2}R^{\prime\prime}+\rho R^{\prime}-n^{2}R=0 $$ 

这是一欧拉型方程. 可以通过自变数变换  $ t=\ln\rho $ 将之化为常系数微分方程

 $$ \frac{\mathrm{d}^{2}R}{\mathrm{d}t^{2}}-n^{2}R=0 $$ 

解之得

$$  R_{n}(\rho)=\left\{\begin{aligned}&C_{0}+D_{0}t=C_{0}+D_{0}\ln\rho,&&n=0\\ &C_{n}\mathrm{e}^{n t}+D_{n}\mathrm{e}^{-n t}=C_{n}\rho^{n}+D_{n}\rho^{-n},&&n\geqslant1\end{aligned}\right.   \tag*{(8.4.24)}$$

但由于在 $ \rho=0 $处， $ \ln\rho $和 $ \rho^{-n}(n\geqslant1) $都是无穷大，考虑到在圆盘内，当 $ \rho\to0 $时，物理量（温度）为有限值的要求，故应取 $ D_{0}=0,D_{n}=0 $而只能有

$$  R_{n}(\rho)=C_{n}\rho^{n},\quad n=0,1,2,\cdots   \tag*{(8.4.25)}$$

<!-- page: 171 -->

这种限于取有界解的条件通常称之为有界性边界条件 $ ^{②} $.

将（8.4.23）式和（8.4.25）式代入（8.4.20）式得

 $$ u_{n}(\rho,\varphi)=R_{n}(\rho)\Phi_{n}(\varphi)=\rho^{n}(A_{n}\mathrm{c o s}n\varphi+B_{n}\mathrm{s i n}n\varphi),\quad n=0,1,2,\cdots $$ 

这里已将(8.4.25)式中的系数 $ C_{n} $，并入到了 $ A_{n} $和 $ B_{n} $中.于是，方程(8.4.17)的解为

$$  u(\rho,\varphi)=\sum_{n=0}^{\infty}\rho^{n}(A_{n}\cos n\varphi+B_{n}\sin n\varphi)   \tag*{（8.4.26）}$$

将边界条件(8.4.18)代入上式，有

 $$ f(\varphi)=\sum_{n=0}^{\infty}a^{n}(A_{n}\cos n\varphi+B_{n}\sin n\varphi) $$ 

故由傅里叶级数系数公式(8.1.20)式和(8.1.21)式有

$$  \left.\begin{array}{l}a_{0}=a^{0}A_{0}=\frac{1}{2\pi}\int_{-\pi}^{\pi}f(\psi)\mathrm{d}\psi\\ \alpha_{n}=a^{n}A_{n}=\frac{1}{\pi}\int_{-\pi}^{\pi}f(\psi)\cos n\psi\mathrm{d}\psi\\ \beta_{n}=a^{n}B_{n}=\frac{1}{\pi}\int_{-\pi}^{\pi}f(\psi)\sin n\psi\mathrm{d}\psi\end{array}\right\}\Bigg\}{n\geqslant1\}   \tag*{(8.4.27)}$$

代入（8.4.26）式，得定解问题（8.4.17）～（8.4.18）式的解为

$$  u(\rho,\varphi)=\sum_{n=0}^{\infty}\left(\frac{\rho}{a}\right)^{n}(\alpha_{n}\cos n\varphi+\beta_{n}\sin n\varphi)   \tag*{（8.4.28）}$$

其中  $ \alpha_{n}, \beta_{n} $ 由 (8.4.27) 式给出.

## 5. 球坐标系中亥姆霍兹方程的分离变量

把球坐标系中  $ \Delta u $ 的表达式(8.4.9)代入亥姆霍兹方程(8.4.12)得

 $$ \begin{aligned}\frac{1}{r^{2}}\frac{\partial}{\partial r}\Big(r^{2}\frac{\partial u}{\partial r}\Big)+&\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}\Big(\sin\theta\frac{\partial u}{\partial\theta}\Big)+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}u}{\partial\varphi^{2}}+\lambda u=0\\&u(r,\theta,\varphi)=R(r)\mathrm{v}(\theta,\varphi)^{ \circ  } \quad \end{aligned} $$ 

令

代入上方程，并将方程两边同乘以  $ r^{2}/Ry $，整理后得

 $$ \frac{1}{R}\frac{\mathrm{d}}{\mathrm{d}r}\Big(r^{2}\frac{\mathrm{d}R}{\mathrm{d}r}\Big)+k^{2}r^{2}=-\frac{1}{y}\Big[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}\Big(\sin\theta\frac{\partial y}{\partial\theta}\Big)+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}y}{\partial\varphi^{2}}\Big] $$ 

其中  $ k^{2}=\lambda $ 。由于 r, $ \theta,\varphi $ 均为独立自变量，故上式成立，除非等式左边和右边等于同一常数，令之为  $ l(l+1) $，则得

$$  r^{2}\frac{\mathrm{d}^{2}R}{\mathrm{d}r^{2}}+2r\frac{\mathrm{d}R}{\mathrm{d}r}+\left[k^{2}r^{2}-l(l+1)\right]R=0   \tag*{(8.4.29)}$$

$$  \frac{1}{\sin\theta}\frac{\partial}{\partial\theta}\Big(\sin\theta\frac{\partial y}{\partial\theta}\Big)+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}y}{\partial\varphi^{2}}+l(l+1)y=0   \tag*{(8.4.30)}$$

方程(8.4.30)称为球谐函数方程.再令

 $$ y(\theta,\varphi)=\Theta(\theta)\Phi(\varphi) $$

<!-- page: 172 -->

代入方程(8.4.30)，并将(8.4.30)式两边同乘以 $ 1/\Theta\Phi $ 后移项得

$$  \left\{\begin{array}{l}\Phi^{\prime \prime}+m^{2}\Phi=0,\quad m=0,1,2,\cdots\\ \frac{1}{\sin\theta}\frac{\mathrm{d}}{\mathrm{d}\theta}\Big(\sin\theta\frac{\mathrm{d}\Theta}{\mathrm{d}\theta}\Big)+\Big[l(l+1)-\frac{m^{2}}{\sin^{2}\theta}\Big]\Theta=0\end{array}\right.   \tag*{(8.4.32)}$$

于是，在球坐标系中求解亥姆霍兹方程（8.4.12）的问题，就化为了解三个常微分方程（8.4.29），（8.4.31）和（8.4.32）的问题.

与前一样，这些方程中的常数  $ m^{2} $、 $ l(l+1) $ 是在分离变量过程中引入的，不能任意取值，只能根据边界条件取某些特定的值即本征值。如，和上面例子中的情形一样，关于  $ \Phi $ 的方程中的常数  $ m^{2} $，由于受周期性的边界条件的限制，m 只能取 0,1,2,\cdots，其相应的本征函数当 m=0 时为 1，当  $ m\geqslant1 $ 时为  $ \cos m\varphi $ 和  $ \sin m\varphi $（它们是线性无关的） $ ^{④} $。

方程(8.4.29)和(8.4.32)是变系数的常微分方程. 对于方程(8.4.29)，作变换  $ x=kr,\frac{1}{\sqrt{x}}y(x)=R(r) $，则(8.4.29)化为

$$  x^{2}y^{\prime \prime}+xy^{\prime}+\left[x^{2}-\left(l+\frac{1}{2}\right)^{2}\right]y=0   \tag*{(8.4.33)}$$

与贝塞尔方程(8.4.16)的形式相似，称为球贝塞尔方程. 对于方程(8.4.32)，作变换 $ x=\cos\theta,y(x)=\Theta(\theta) $，则(8.4.32)化为

$$  (1-x^{2})y^{\prime \prime}-2xy^{\prime}+\left[l(l+1)-\frac{m^{2}}{1-x^{2}}\right]y=0   \tag*{(8.4.34)}$$

称之为连带勒让德（associated Legendre）方程.

方程（8.4.33）和（8.4.34）的求解和解的性质，均在第三篇中讨论（见第三篇12.1节和11.3节）.

与柱坐标系中的讨论类似，由于 $ \Delta u=0 $是 $ \Delta u+\lambda u=0 $当 $ \lambda=0 $的特例，故只要将(8.4.29)～(8.4.32)式中的 $ k^{2}=\lambda $用零代替，便立即可得球坐标中拉普拉斯方程分离变量后的三个常微分方程

$$  \Phi^{\prime \prime}+m^{2}\Phi=0,\quad m=0,1,2,\cdots   \tag*{（8.4.36）}$$

$$  \frac{1}{\sin\theta}\frac{\mathrm{d}}{\mathrm{d}\theta}\Big(\sin\theta\frac{\mathrm{d}\Theta}{\mathrm{d}\theta}\Big)+\Big[l(l+1)-\frac{m^{2}}{\sin^{2}\theta}\Big]\Theta=0   \tag*{（8.4.37）}$$

后两个方程和从  $ \Delta u + \lambda u = 0 $ 中分离出的完全一样；前一个方程仍为变系数方程，但它是我们所熟悉的欧拉方程.

综上所述，在正交曲线坐标系中分离变数时，一般说来，会得到一些特殊的变系数的常微分方程——贝塞尔方程和连带勒让德方程等。只有讨论了这些方程的解和本征值问题，才能在正交曲线坐标系中将分离变数法进行到底。

注 ① 令  $ x=k\rho, y=R(\rho) $，则  $ \frac{d}{d\rho}=\frac{d}{dx}\cdot\frac{dx}{d\rho}=k\frac{d}{dx};\frac{d^{2}}{d\rho^{2}}=\frac{d}{dx}\left(k\frac{d}{dx}\right)\cdot\frac{dx}{d\rho}=k^{2}\frac{d^{2}}{dx^{2}} $，故此时

<!-- page: 173 -->

(8.4.15)式化为： $ k^{2}\rho^{2}\frac{d^{2}y}{dx^{2}}+k\rho\frac{dy}{d\rho}+(k^{2}\rho^{2}-n^{2})y=0 $，即

 $$ x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-n^{2})y=0 $$ 

若  $ \lambda - \mu < 0 $，记  $ \lambda - \mu = -k^{2} $，则关于  $ R(\rho) $ 的方程为

$$  \rho^{2}R^{\prime\prime}+\rho R^{\prime}-(k^{2}\rho^{2}+n^{2})R=0   \tag*{(8.4.15)  ^{'} }$$

此时若作变换  $ x=k\rho, y=R(\rho) $，则(8.4.15) $ ^{\prime} $式化为

$$  x^{2}y^{\prime \prime}+xy^{\prime}-(x^{2}+n^{2})y=0   \tag*{(8.4.16)  ^{'} }$$

此式称为(n阶)虚宗量的贝塞尔方程. 我们将在第三篇 12.3 对它进行讨论.

②周期性边界条件和有界性边界条件又均称为自然边界条件.

③ 这里令  $ u(r,\theta,\varphi)=R(r)y(\theta,\varphi) $，而不是直接令  $ u(r,\theta,\varphi)=R(r)\Theta(\theta)\Phi(\varphi) $，是为了日后物理上的需要和讨论球函数的方便（见第三篇 11.3 节）.

④显然，这些本征函数也可用  $ \mathrm{e}^{\lim_{x\to0^{+}}(m=0,\pm1,\pm2,\cdots)} $ 来表示.

#### 习题8.4

1. 求解圆的狄氏问题

 $$ \begin{cases}\Delta_{2}u=0\\u\mid_{p=a}=A\cos\varphi\end{cases} $$ 

2. 求解扇形区域中的狄氏问题

 $$ \left\{\begin{aligned}&\Delta_{2}u=0,\quad\rho<a,\alpha<\varphi<\beta\\ &u\mid_{\varphi=a}=0,u\mid_{\varphi=\beta}=0\\ &u\mid_{\rho=a}=f(\varphi)\end{aligned}\right. $$ 

3. 求解泊松方程的狄氏问题

 $$ \begin{cases}\Delta_{2}u=-4,&\rho<a\\u\mid_{\rho=a}=0\end{cases} $$ 

提示：先找一个满足  $ u_{xx} + u_{yy} = -4 $ 的特解  $ u_{s} $

 $$ u(\rho,\varphi)=u_{s}+v(\rho,\varphi) $$ 

则

 $$ \begin{cases}\Delta_{2}v=0\\v\mid_{\rho=a}=-u_{s}\mid_{\rho=a}\end{cases} $$ 

4. 设有一个半径为 a 的“无限长”圆柱形接地导体，放置在均匀外电场  $ E_{0} $ 中，圆柱的轴线与  $ E_{0} $ 方向垂直，求电势分布.

5. 求圆环的狄氏问题

 $$ \left\{\begin{aligned}&\Delta u=0,\quad r_{2}<r<r_{1}\\ &u(r_{1},\theta)=\sin\theta\\ &u(r_{2},\theta)=0\end{aligned}\right. $$ 

6. 一无限长导体圆柱壳，半径为 a，把它充电到电势为

 $$ u=\left\{\begin{aligned}&u_{1},0<\varphi<\pi\\ &u_{2},\pi<\varphi<2\pi\end{aligned}\right. $$ 

求圆壳内的电势分布.

<!-- page: 174 -->

7. 解下列定解问题：

 $$ \left\{\begin{aligned}&\frac{1}{r}\frac{\partial}{\partial r}\Big(r\frac{\partial u}{\partial r}\Big)+\frac{1}{r^{2}}\frac{\partial^{2}u}{\partial\varphi^{2}}=0,\quad r<a\\ &\frac{\partial u}{\partial r}\bigg|_{r=a}=\varphi-\pi\end{aligned}\right. $$ 

8. 在环形区域 $ (a \leqslant \rho \leqslant b) $中，求解泊松方程的边值问题

 $$ \begin{cases}\Delta_{2}u=12(x^{2}-y^{2}),&a<\rho<b\\u\mid_{\rho=a}=0,\quad u_{\rho}\mid_{\rho=b}=0\end{cases} $$ 

提示: 先找满足  $ u_{xx} + u_{yy} = 12x^{2} - 12y^{2} $ 的特解  $ u_{s} $.

9. 半径为 a 的半圆形平板，其表面绝热，在板的周围边界上保持常温  $ u_{0} $，而在直径上保持常温  $ u_{1} $，求此半圆形平板在稳恒状态下的温度分布.

10. 半径为 a、表面熏黑了的均匀长圆柱，在温度为零度的空气中受着阳光照射。阳光垂直于柱轴，热流密度为 q，试求柱内稳定温度分布

 $$ \left\{\begin{aligned}&\Delta_{2}u=0\\ &(ku_{p}+Hu)_{p=a}=\left\{\begin{aligned}&q\sin\varphi,&0<\varphi<\pi\\ &0,&\pi<\varphi<2\pi\end{aligned}\right.\end{aligned}\right. $$ 

11. 将(8.5.18)式代入(8.5.19)式，证明当  $ \rho < a $ 时

 $$ u(\rho,\varphi)=\frac{a^{2}-\rho^{2}}{2\pi}\int_{0}^{2\pi}\frac{f(\psi)\mathrm{d}\psi}{\rho^{2}+a^{2}-2a\rho\cos(\psi-\varphi)} $$ 

此式称为泊松积分公式. 我们将在第10章格林函数法中导出.

12. 在球坐标系内，将下列氢原子的定态薛定谔方程

 $$ -\frac{\hbar^{2}}{2\mu}\Delta u(r,\theta,\varphi)-\frac{\mathrm{e}^{2}}{r}u(r,\theta,\varphi)=E u(r,\theta,\varphi) $$ 

分离变数为常微分方程. 其中  $ \mu $、h、e、E 为常数.

<!-- page: 175 -->

<div style="text-align: center;"><img src="images/p0175_img_in_image_box_96_497_157_560.jpg" alt="本章小结" width="6%" /></div>


<div style="text-align: center;"><div style="text-align: center;">本章小结</div> </div>


<div style="text-align: center;"><div style="text-align: center;">一、本章主要内容</div> </div>


本章授课课件 本章习题分析与讨论

<div style="text-align: center;"><img src="images/p0175_img_in_image_box_204_217_852_1203.jpg" alt="一、本章主要内容" width="67%" /></div>

<!-- page: 176 -->

在上一章中我们主要介绍了用分离变量法求解各种有界问题. 对于无界区域或半无界区域的问题, 采用求解数理方程的另一种常用方法——积分变换法, 比较方便, 所谓积分变换, 就是把某函数类 A 中的函数  $ f(x) $, 经过某种可逆的积分手续.

 $$ F(p)=\int k(x,p)f(x)\mathrm{d}x $$ 

变成另一函数类 B 中的函数  $ F(p) $,  $ F(p) $ 称为  $ f(x) $ 的像函数,  $ f(x) $ 称为像原函数, 而  $ k(x, p) $ 是 p 和 x 的已知函数, 称为积分变换的核. 在这种变换之下, 原来的偏微分方程可以减少自变量的个数, 直至变成常微分方程; 原来的常微分方程, 可以变成代数方程, 从而使在函数类 B 中的运算简化. 找出在 B 中的一个解, 再经过逆变换, 便得到原来要在 A 中所求的解.

积分变换的种类不少，如傅里叶变换（简称傅氏变换）、拉普拉斯变换（简称拉氏变换）、汉开尔（Hankel）变换、梅林（Mellin）变换等。本章将只介绍解数理方程时常用的傅氏变换和拉氏变换。

### 9.1 傅里叶变换

## 1. 傅里叶积分和傅里叶积分定理

由高等数学我们知道，一个以2l为周期的函数 $ f(x) $，若在区间 $ [-l,l] $上满足狄利克雷条件（即连续或有限个第一类间断点，并且只有有限个极值点），则在 $ [-l,l] $上可展开为傅氏级数（见8.1节注 $ ^{①} $）。

傅氏级数的复数形式 $ ^{①} $为

 $$ f(x)=\sum_{n=-\infty}^{\infty}c_{n}\mathrm{e}^{\mathrm{i}\omega_{n}x} $$ 

其中

 $$ \omega_{n}=\frac{n\pi}{l},\quad c_{n}=\frac{1}{2l}\int_{-l}^{l}f(\xi)\mathrm{e}^{-\mathrm{i}\omega_{n}\xi}\mathrm{d}\xi $$ 

因此， $ f(x) $也可表示为

$$  f(x)=\frac{1}{2l}\sum_{n=-\infty}^{\infty}\left[\int_{-l}^{l}f(\xi)\mathrm{e}^{-\mathrm{i}\omega_{n}\xi}\mathrm{d}\xi\right]\mathrm{e}^{\mathrm{i}\omega_{n}x}   \tag*{(9.1.1)}$$

由此看到，以2l为周期的函数，在自变数增长的过程中，函数值有规律的重复，自变数每增长一个周期2l，函数就重复变化一次。其中，参数 $ \omega_{n} $不连续地、跳跃地取下列

<!-- page: 177 -->

数值

 $$ \cdots-\frac{n\pi}{l},\cdots,-\frac{2\pi}{l},-\frac{\pi}{l},0,\frac{\pi}{l},\frac{2\pi}{l},\cdots,\frac{n\pi}{l},\cdots $$ 

其跃变间隔为

 $$ \Delta\omega_{n}=\pi/l $$ 

对于非周期函数而言，当然不具备以上这些特点，但我们自然想到，若将其看成周期趋于无穷大（即  $ 2l \to \infty $）的“周期函数”，则当然可仿照（9.1.1）式写出它的傅氏展开式，只是此时  $ \Delta\omega_{n} = \frac{\pi}{l} \to 0 $。这表明参数  $ \omega_{n} $ 变为  $ \omega $ 不再跃变，而是连续变化，即，非周期函数  $ f(x) $，可以表示为

 $$ \begin{align*}f(x)&=\lim_{l\to\infty}\sum_{n=-\infty}^{\infty}\bigg[\frac{1}{2l}\int_{-l}^{l}f(\xi)\mathrm{e}^{-\mathrm{i}\omega_{n}\xi}\mathrm{d}\xi\bigg]\mathrm{e}^{\mathrm{i}\omega_{n}x}\\&=\lim_{\Delta\omega_{n}\to0}\sum_{n=-\infty}^{\infty}\bigg[\frac{1}{2\pi}\int_{-\infty}^{\infty}f(\xi)\mathrm{e}^{-\mathrm{i}\omega_{n}\xi}\mathrm{d}\xi\bigg]\mathrm{e}^{\mathrm{i}\omega_{n}x}\Delta\omega_{n}\end{align*} $$ 

亦即

$$  f(x)=\frac{1}{2\pi}\int_{-\infty}^{\infty}\left[\int_{-\infty}^{\infty}f(\xi)\mathrm{e}^{-\mathrm{i}\omega\xi}\mathrm{d}\xi\right]\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega   \tag*{(9.1.2)}$$

(9.1.2)式称为函数 $ f(x) $的傅里叶积分(简称傅氏积分)公式.应该指出，上述推导是极不严格的.因为我们交换了极限过程与求和过程的次序.实际上，傅氏积分成立，需满足下述傅里叶积分定理：设 $ f(x) $在 $ (-\infty,\infty) $上有定义且

（1）在任一有限区间上满足狄利克雷条件：

（2）在无限区间 $ (-∞, ∞) $上绝对可积

 $$ \int_{-\infty}^{\infty}\mid f(x)\mid\mathrm{d}x<+\infty $$ 

则傅里叶积分公式

 $$ f(x)=\frac{1}{2\pi}\int_{-\infty}^{\infty}\left[\int_{-\infty}^{\infty}f(\xi)\mathrm{e}^{-\mathrm{i}\omega\xi}\mathrm{d}\xi\right]\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega $$ 

在  $ f(x) $ 的连续点 x 处成立，而在  $ f(x) $ 的第一类间断点  $ x_{0} $ 处，右边的积分应以  $ \frac{1}{2}[f(x_{0}+0)+f(x_{0}-0)] $ 代替.

此定理的证明，由于要用到较多的数学分析的知识，已超过本书范围，我们在此从略 $ ^{②} $.

类似地，我们可以写出三维形式的傅氏积分公式

$$  \begin{aligned}f(x,y,z)=&\left(\frac{1}{2\pi}\right)^{3}\iiint_{-\infty}^{\infty}\left[\iiint_{-\infty}^{\infty}f(\xi,\eta,\zeta)\mathrm{e}^{-\mathrm{i}(\omega_{1}\xi+\omega_{2}\eta+\omega_{3}\zeta)}\mathrm{d}\xi\mathrm{d}\eta\mathrm{d}\zeta\right]\\&\cdot\mathrm{e}^{\mathrm{i}(\omega_{1}x+\omega_{2}y+\omega_{3}z)}\mathrm{d}\omega_{1}\mathrm{d}\omega_{2}\mathrm{d}\omega_{3}\end{aligned}   \tag*{(9.1.3)}$$

## 2. 傅里叶变换

在傅氏积分公式（9.1.2）中令

<!-- page: 178 -->

$$  G(\omega)=\int_{-\infty}^{\infty}f(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x   \tag*{(9.1.4)}$$

则

$$  f(x)=\frac{1}{2\pi}\int_{-\infty}^{\infty}G(\omega)\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega   \tag*{(9.1.5)}$$

可见函数  $ f(x) $ 和  $ G(\omega) $ 可以通过积分相互表达。我们称 (9.1.4) 式为函数  $ f(x) $ 的傅里叶变换（简称傅氏变换），记作

$$  F[f(x)]=G(\omega)=\int_{-\infty}^{\infty}f(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x   \tag*{(9.1.6)}$$

 $ G(\omega) $ 又称为  $ f(x) $ 的像函数；而称 (9.1.5) 式为函数  $ G(\omega) $ 的傅里叶逆变换（简称傅氏逆变换或傅氏反演），记作

$$  F^{-1}\left[G(\omega)\right]=f(x)=\frac{1}{2\pi}\int_{-\infty}^{\infty}G(\omega)\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega   \tag*{(9.1.7)}$$

 $ f(x) $ 又称为  $ G(\omega) $ 的像原函数. 因此, 当  $ f(x) $ 满足傅氏积分定理的条件时, 傅氏积分公式就成为

$$  f(x)=F^{-1}\{F[f(x)]\}   \tag*{(9.1.8)}$$

这是傅氏变换和傅氏逆变换之间的一个重要关系.

易于看出，傅氏变换和逆变换的定义式(9.1.6)和(9.1.7)，其积分前的系数虽然各书的写法并不完全相同，但只要此二系数的乘积等于 $ \frac{1}{2\pi} $，(9.1.6)式和(9.1.7)式仍均是可以互相满足的，且两积分号内的指数因子 $ e^{-i\omega x} $和 $ e^{i\omega x} $也可以同时改为 $ e^{-i\omega x} $和 $ e^{-i\omega x} $.

在量子力学中，通常把  $ f(x) $ 记作  $ \psi(x) $，作为坐标表象的波函数，将  $ \omega $ 看作波数 k，而将 (9.1.6) 和 (9.1.7) 两式积分号前的系数分别写作  $ \frac{1}{\sqrt{2\pi}} $。由于  $ p = hk $  $ \left(h = \frac{h}{2\pi}, h $ 是普朗克常量  $ \right) $，则有  $ G(\omega) = G\left(\frac{p}{h}\right) $，记作  $ C(p) $，于是由 (9.1.5) 式和 (9.1.4) 式有

 $$ \psi(x)=\frac{1}{\sqrt{2\pi\hbar}}\int_{-\infty}^{\infty}C(p)\mathrm{e}^{\frac{\mathrm{i}}{\hbar}p x}\mathrm{d}p $$ 

 $$ C(p)=\frac{1}{\sqrt{2\pi\hbar}}\int_{-\infty}^{\infty}\psi(x)\mathrm{e}^{-\frac{i}{\hbar}p x}\mathrm{d}x $$ 

其中  $ C(p) $ 就是同一量子体系在动量表象中的波函数. 此二式表明了坐标表象与动量表象之间的波函数的变换关系（见量子力学有关知识）.

由傅氏变量和傅氏逆变换的定义(9.1.6)及(9.1.7)式可知，要求一个函数的傅氏变换（或傅氏逆变换），实际上是求一个含参数的广义积分.计算含参数的广义积分是一件比较困难的工作.但对于某些函数来说，还是比较容易计算的.

例1 指数衰减函数  $ f(t)=\left\{\begin{aligned}&0,&t<0\\ &\mathrm{e}^{-\beta t},&t\geqslant0\end{aligned}\right. $ 是无线电技术中常碰到的一个函数，求

<!-- page: 179 -->

它的傅氏变换和积分表达式. 其中  $ \beta>0 $.

解 由（9.1.6）式有

 $$ \begin{align*}F[f(t)]=G(\omega)=\int_{-\infty}^{\infty}f(t)\mathrm{e}^{-\mathrm{i}\omega t}\mathrm{d}t=\int_{0}^{\infty}\mathrm{e}^{-\beta t}\mathrm{e}^{-\mathrm{i}\omega t}\mathrm{d}t\\=\int_{0}^{\infty}\mathrm{e}^{-(\beta+\mathrm{i}\omega)t}\mathrm{d}t=\frac{1}{\beta+\mathrm{i}\omega}=\frac{\beta-\mathrm{i}\omega}{\beta^{2}+\omega^{2}}\end{align*} $$ 

而由(9.1.7)式有

 $$ \begin{align*}f(t)&=\frac{1}{2\pi}\int_{-\infty}^{\infty}G(\omega)\mathrm{e}^{\mathrm{i}\omega t}\mathrm{d}\omega\\&=\frac{1}{2\pi}\int_{-\infty}^{\infty}\frac{\beta-\mathrm{i}\omega}{\beta^{2}+\omega^{2}}\mathrm{e}^{\mathrm{i}\omega t}\mathrm{d}\omega=\frac{1}{2\pi}\int_{-\infty}^{\infty}\frac{\beta\cos\omega t+\omega\sin\omega t}{\beta^{2}+\omega^{2}}\mathrm{d}\omega\\&=\frac{1}{\pi}\int_{0}^{\infty}\frac{\beta\cos\omega t+\omega\sin\omega t}{\beta^{2}+\omega^{2}}\mathrm{d}\omega\end{align*} $$ 

此即函数  $ f(t) $ 的积分表达式. 由此我们还顺便得到一个含参变量 t 的积分公式

 $$ \int_{0}^{\infty}\frac{\beta\cos\omega t+\omega\sin\omega t}{\beta^{2}+\omega^{2}}\mathrm{d}\omega=f(t)\bullet\pi=\left\{\begin{aligned}&0,&&t<0\\ &\pi/2,&&t=0\\ &\pi\mathrm{e}^{-\beta t},&&t>0\end{aligned}\right. $$ 

常用函数的傅氏变换，已制成了表格以便查用.本书附录Ⅱ中，给出了傅氏变换简表.

类似地，在三维傅氏积分公式（9.1.3）的基础上可引入三维傅氏变换的定义.记

$$  \left\{\begin{aligned}&\boldsymbol{\omega}=\boldsymbol{e}_{1\omega_{1}}+\boldsymbol{e}_{2\omega_{2}}+\boldsymbol{e}_{3\omega_{3}}\\ &\boldsymbol{r}=\boldsymbol{e}_{1x}+\boldsymbol{e}_{2y}+\boldsymbol{e}_{3z}\\ &f(\boldsymbol{r})=f(x,y,z)\\ &\mathrm{d}\boldsymbol{r}=\mathrm{d}x\mathrm{d}y\mathrm{d}z,\quad\mathrm{d}\boldsymbol{\omega}=\mathrm{d}\omega_{1}\mathrm{d}\omega_{2}\mathrm{d}\omega_{3}\end{aligned}\right.   \tag*{(9.1.9)}$$

其中， $ e_{1}, e_{2}, e_{3} $ 为笛卡尔（Cartesian）坐标系中三个坐标轴的单位矢量。则（9.1.3）式变为

 $$ f(\boldsymbol{r})=\frac{1}{(2\pi)^{3}}\iiint_{-\infty}^{\infty}\left[\iiint_{-\infty}^{\infty}f(\boldsymbol{\xi},\boldsymbol{\eta},\boldsymbol{\zeta})\mathrm{e}^{-\mathrm{i}(\omega_{1}\boldsymbol{\xi}+\omega_{2}\boldsymbol{\eta}+\omega_{3}\boldsymbol{\zeta})}\mathrm{d}\xi\mathrm{d}\eta\mathrm{d}\zeta\right]\mathrm{e}^{\mathrm{i}\omega\cdot r}\mathrm{d}\omega $$ 

令

$$  G(\pmb{\omega})=\coprod_{-\infty}^{\infty}f(\pmb{r})\mathrm{e}^{-\mathrm{i}\pmb{\omega}\cdot\pmb{r}}\mathrm{d}\pmb{r}   \tag*{(9.1.10)}$$

则

$$  f(\boldsymbol{r})=\frac{1}{(2\pi)^{3}}\iiint_{-\infty}^{\infty}G(\pmb{\omega})\mathrm{e}^{\mathrm{i}\pmb{\omega}\cdot\boldsymbol{r}}\mathrm{d}\pmb{\omega}   \tag*{(9.1.11)}$$

我们称(9.1.10)式为三维函数  $ f(r) $ 的傅氏变换，记作

$$  F[f(\boldsymbol{r})]=G(\boldsymbol{\omega})=\iiint_{-\infty}^{\infty}f(\boldsymbol{r})\mathrm{e}^{-\mathrm{i}\omega\cdot r}\mathrm{d}\boldsymbol{r}   \tag*{(9.1.12)}$$

 $ G(\omega) $ 又称为  $ f(r) $ 的像函数，而称(9.1.11)式为三维函数  $ G(\omega) $ 的傅氏逆变换，记作

$$  F^{-1}\left[G\left(\pmb{\omega}\right)\right]=f(\pmb{r})=\frac{1}{\left(2\pi\right)^{3}}\iiint_{-\infty}^{\infty}G\left(\pmb{\omega}\right)\mathrm{e}^{\mathrm{i}\pmb{\omega}\cdot\pmb{r}}\mathrm{d}\pmb{\omega}   \tag*{(9.1.13)}$$

<!-- page: 180 -->

$ f(r) $ 又称为  $ G(\omega) $ 的像原函数.

## 3. 傅里叶变换的性质

下面我们介绍傅氏变换的几个基本性质. 设  $ F[f(x)] = G(\omega) $，且我们约定：当涉及一函数需要进行傅氏变换时，这个函数总是满足变换条件的.

（1）线性性质 若  $ \alpha,\beta $ 为任意常数，则对任意函数  $ f_{1} $ 和  $ f_{2} $ 有

$$  F[\alpha f_{_{1}}+\beta f_{_{2}}]=\alpha F[f_{_{1}}]+\beta F[f_{_{2}}]   \tag*{(9.1.14)}$$

证 由定义式(9.1.6)有

 $$ \begin{aligned}F[\alpha f_{_{1}}+\beta f_{_{2}}]=&\int_{-\infty}^{\infty}[\alpha f_{_{1}}(x)+\beta f_{_{2}}(x)]\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x\\ =&\alpha\int_{-\infty}^{\infty}f_{_{1}}(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x+\beta\int_{-\infty}^{\infty}f_{_{2}}(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x\\ =&\alpha F(f_{_{1}})+\beta F(f_{_{2}})\end{aligned} $$ 

（2）延迟性质（又称为频移性质）设 $ \omega_{0} $为任意常数，则

$$  F[\mathrm{e}^{\mathrm{i}\omega_{0}x}f(x)]=G(\omega-\omega_{0})   \tag*{(9.1.15)}$$

证 由定义式(9.1.6)有

 $$ \begin{aligned}F[\mathrm{e}^{\mathrm{i}\omega_{0}x}f(x)]&=\int_{-\infty}^{\infty}\mathrm{e}^{\mathrm{i}\omega_{0}x}f(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x\\&=\int_{-\infty}^{\infty}f(x)\mathrm{e}^{-\mathrm{i}(\omega-\omega_{0})x}\mathrm{d}x\\&=G(\omega-\omega_{0})\\ \end{aligned} $$ 

（3）位移性质 设  $ x_{0} $ 为任意常数，则

$$  F[f(x-x_{0})]=\mathrm{e}^{-\mathrm{i}\omega x_{0}}F[f(x)]   \tag*{(9.1.16)}$$

证 由定义式(9.1.6)有

 $$ \begin{align*}F\big[\boldsymbol{f}(x-x_{0})\big]&=\int_{-\infty}^{\infty}\boldsymbol{f}(x-x_{0})\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x\\&=\mathrm{e}^{-\mathrm{i}\omega x_{0}}\int_{-\infty}^{\infty}\boldsymbol{f}(x-x_{0})\mathrm{e}^{-\mathrm{i}\omega(x-x_{0})}\mathrm{d}(x-x_{0})\\&=\mathrm{e}^{-\mathrm{i}\omega x_{0}}\int_{-\infty}^{\infty}\boldsymbol{f}(x^{\prime})\mathrm{e}^{-\mathrm{i}\omega x^{\prime}}\mathrm{d}x^{\prime}\\&=\mathrm{e}^{-\mathrm{i}\omega x_{0}}F\big[\boldsymbol{f}(x)\big]\end{align*} $$ 

（4）相似性质 设 a 为不为零的常数，则

$$  F[f(ax)]=\frac{1}{\mid a\mid}G\Big(\frac{\omega}{a}\Big)   \tag*{(9.1.17)}$$

证 令  $ ax = x' $，则当 a > 0 时有

 $$ F[f(ax)]=\int_{-\infty}^{\infty}f(ax)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x=\int_{-\infty}^{\infty}f(x^{\prime})\mathrm{e}^{-\mathrm{i}\frac{\omega}{a}x^{\prime}}\mathrm{d}\frac{x^{\prime}}{a}=\frac{1}{a}G\left(\frac{\omega}{a}\right) $$

<!-- page: 181 -->

而当a<0时有

 $$ F[f(ax)]=\int_{-\infty}^{\infty}f(ax)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x=\int_{-\infty}^{-\infty}f(x^{\prime})\mathrm{e}^{-\mathrm{i}\frac{\omega}{a}x^{\prime}}\mathrm{d}\frac{x^{\prime}}{a}=-\frac{1}{a}G\left(\frac{\omega}{a}\right) $$ 

所以

 $$ F[f(ax)]=\frac{1}{\mid a\mid}G\Big(\frac{\omega}{a}\Big) $$ 

（5）微分性质 若当 $ \left|x\right|\rightarrow\infty $时， $ f(x)\rightarrow0 $， $ f^{(n-1)}(x)\rightarrow0 $（其中n=1,2, $ \cdots $），则

$$  \left.\begin{array}{r}F\left[f^{\prime}(x)\right]=\mathrm{i}\omega F\left[f(x)\right]\\ F\left[f^{\prime \prime}(x)\right]=\left(\mathrm{i}\omega\right)^{2}F\left[f(x)\right]\\ \cdots\cdots\\ F\left[f^{(n)}(x)\right]=\left(\mathrm{i}\omega\right)^{n} F\left[f(x)\right]\end{array}\right\}   \tag*{（9.1.18）}$$

证 由定义(9.1.6)式和分部积分法有

 $$ \begin{align*}F\big[f^{\prime}(x)\big]&=\int_{-\infty}^{\infty}f^{\prime}(x)\mathrm{e}^{-\mathrm{i}_{ax}x}\mathrm{d}x\\&=\big[f(x)\mathrm{e}^{-\mathrm{i}_{ax}x}\big]_{-\infty}^{\infty}-\int_{-\infty}^{\infty}f(x)(-\mathrm{i}\omega)\mathrm{e}^{-\mathrm{i}_{ax}x}\mathrm{d}x\end{align*} $$ 

因为当 $ \left|x\right|\rightarrow\infty $时， $ f(x)\rightarrow0 $，因此

 $$ F[f^{\prime}(x)]=\mathrm{i}\omega\int_{-\infty}^{\infty}f(x)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x=\mathrm{i}\omega F[f(x)] $$ 

又因为当 $ \left|x\right|\rightarrow\infty $时， $ f'(x)\rightarrow0 $，所以

 $$ F\big[f^{\prime \prime}(x)\big]=F\bigg[\frac{\mathrm{d}f^{\prime}(x)}{\mathrm{d}x}\bigg]=\mathrm{i}\omega F\big[f^{\prime}(x)\big]=(\mathrm{i}\omega)^{2}F\big[f(x)\big] $$ 

重复以上过程便可得（9.1.18）式.

（6）积分性质

$$  F\Big[\int_{x_{0}}^{x}f(\xi)\mathrm{d}\xi\Big]=\frac{1}{\mathrm{i}\omega}F\big[f(x)\big]   \tag*{(9.1.19)}$$

证 因为

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\int_{x_{0}}^{x}f(\xi)\mathrm{d}\xi=f(x) $$ 

所以

 $$ F\Big[\frac{\mathrm{d}}{\mathrm{d}x}\int_{x_{0}}^{x}f(\xi)\mathrm{d}\xi\Big]=F\big[f(x)\big] $$ 

又由微分性质(9.1.18)式有

 $$ F\Big[\frac{\mathrm{d}}{\mathrm{d}x}\int_{x_{0}}^{x}f(\xi)\mathrm{d}\xi\Big]=\mathrm{i}\omega F\Big[\int_{x_{0}}^{x}f(\xi)\mathrm{d}\xi\Big] $$ 

比较上面两式即得（9.1.19）式.

（7）卷积定理 已知函数  $ f_{1}(x) $ 和  $ f_{2}(x) $，则定义积分

 $$ \int_{-\infty}^{\infty}f_{1}(\xi)f_{2}(x-\xi)\mathrm{d}\xi $$

<!-- page: 182 -->

为函数  $ f_{1}(x) $ 与  $ f_{2}(x) $ 的卷积，记作  $ f_{1}(x) \cdot f_{2}(x) $，即

$$  f_{1}(x)*f_{2}(x)=\int_{-\infty}^{\infty}f_{1}(\xi)f_{2}(x-\xi)\mathrm{d}\xi   \tag*{(9.1.20)}$$

卷积运算“*”是一种函数间的运算，易于证明它与乘法相似，具有交换律、结合律与分配律，即

 $$ \begin{aligned}&f_{1}(x)*f_{2}(x)=f_{2}(x)*f_{1}(x)\\&\left[f_{1}(x)*f_{2}(x)\right]*f_{3}(x)=f_{1}(x)*\left[f_{2}(x)*f_{3}(x)\right]\\&f_{1}(x)*\left[f_{2}(x)+f_{3}(x)\right]=f_{1}(x)*f_{2}(x)+f_{1}(x)*f_{3}(x)\\ \end{aligned} $$ 

对于函数  $ f_{1}(x) $ 和  $ f_{2}(x) $ 有

$$  F\big[f_{1}(x)*f_{2}(x)\big]=F\big[f_{1}(x)\big]\bullet F\big[f_{2}(x)\big]   \tag*{(9.1.21)}$$

此即卷积定理.

证 由定义

 $$ F[f_{1}*f_{2}]=\int_{-\infty}^{\infty}\left[\int_{-\infty}^{\infty}f_{1}(\xi)f_{2}(x-\xi)\mathrm{d}\xi\right]\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x $$ 

由于  $ f_{1} $ 和  $ f_{2} $ 都是在  $ (-∞, ∞) $ 上绝对可积的，故积分可交换次序，因此

 $$ \begin{align*}F\big[f_{1}*f_{2}\big]=&\int_{-\infty}^{\infty}f_{1}(\xi)\bigg[\int_{-\infty}^{\infty}f_{2}(x-\xi)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x\bigg]\mathrm{d}\xi\\=&\int_{-\infty}^{\infty}f_{1}(\xi)\bullet\mathrm{e}^{-\mathrm{i}\omega\hat{\xi}}F\big[f_{2}\big]\mathrm{d}\xi=F\big[f_{1}\big]\bullet F\big[f_{2}\big]\end{align*} $$ 

#### （8）像函数的卷积定理

证

 $$ \begin{aligned}&F[f_{1}(x)\bullet f_{2}(x)]=\frac{1}{2\pi}F[f_{1}(x)]*F[f_{2}(x)]\\&\quad F[f_{1}(x)\bullet f_{2}(x)]\\&=\int_{-\infty}^{\infty}f_{1}(x)f_{2}(x)\mathrm{e}^{-\omega x}\mathrm{d}x\\&=\int_{-\infty}^{\infty}f_{1}(x)\bigg[\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{2}\left(\omega^{\prime}\right)\mathrm{e}^{\mathrm{i}\omega^{\prime}x}\mathrm{d}\omega^{\prime}\bigg]\mathrm{e}^{-\omega x}\mathrm{d}x\\&=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{2}\left(\omega^{\prime}\right)\bigg[\int_{-\infty}^{\infty}f_{1}(x)\mathrm{e}^{-\left(\omega-\omega^{\prime}\right)x}\mathrm{d}x\bigg]\mathrm{d}\omega^{\prime}\\&=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{2}\left(\omega^{\prime}\right)G_{1}\left(\omega-\omega^{\prime}\right)\mathrm{d}\omega^{\prime}\\&=\frac{1}{2\pi}G_{2}\left(\omega\right)*G_{1}\left(\omega\right)\\&=\frac{1}{2\pi}F[f_{1}(x)]*F[f_{2}(x)]\\ \end{aligned} $$ 

用类似的方法可以证明三维函数  $ f(r) $ 的傅氏变换亦具有上述的那些性质.

运用傅氏变换的线性性质、微分性质和积分性质，可以把线性常系数常微分方程化为代数方程，通过解代数方程与求傅氏逆变换，就可以得到此常微分方程的解。

例2 求解质量为1具有阻尼的(经典)谐振子的受迫振动方程

<!-- page: 183 -->

$$  \ddot{x}(t)+2\dot{\gamma}\dot{x}\left(t\right)+\omega_{0}^{2}x(t)=f(t)   \tag*{（9.1.23）}$$

其中  $ f(t) $ 是已知函数,  $ \gamma>0 $ 和  $ \omega_{0}^{2} $ 是常数.

解 记  $ F[x(t)]=\tilde{x}(\omega), F[f(t)]=\tilde{f}(\omega) $; 对方程中各项施行傅氏变换，则由线性性质(9.1.14)式和微分性质(9.1.18)式有

 $$ (\mathrm{i}\omega)^{2}\widetilde{x}(\omega)+2\mathrm{i}\omega\gamma\widetilde{x}(\omega)+\omega_{0}^{2}\widetilde{x}(\omega)=\widetilde{f}(\omega) $$ 

所以

 $$ \tilde{x}(\omega)=\frac{-\tilde{f}(\omega)}{\omega^{2}-2i\gamma\omega-\omega_{0}^{2}}=\tilde{f}(\omega)\bullet\frac{1}{(\sqrt{\omega_{0}^{2}-\gamma^{2}})^{2}-(\omega-\mathrm{i}\gamma)^{2}} $$ 

由查表和位移性质知

 $$ \frac{1}{(\sqrt{\omega_{0}^{2}-\gamma^{2}})^{2}-(\omega-\mathrm{i}\gamma)^{2}}=\frac{1}{\sqrt{\omega_{0}^{2}-\gamma^{2}}}F\big[\mathrm{e}^{-\gamma t}H(t)\sin\sqrt{\omega_{0}^{2}-\gamma^{2}}t\big] $$ 

其中

$$  H(t)=\left\{\begin{aligned}&0,&t<0\\ &1,&t>0\end{aligned}\right.   \tag*{(9.1.24)}$$

称为赫维赛德（Heaviside）单位函数或阶梯函数。它的更一般表示为

$$  H(t-a)=\left\{\begin{aligned}&0,&t<a\\ &1,&t>a\end{aligned}\right.   \tag*{（9.1.25）}$$

故

 $$ F\big[x(t)\big]=\frac{1}{\sqrt{\omega_{0}^{2}-\gamma^{2}}}F\big[f(t)\big]\bullet F\big[\mathrm{e}^{-\gamma t}H(t)\sin\sqrt{\omega_{0}^{2}-\gamma^{2}}t\big] $$ 

对上式两边取傅氏逆变换并应用卷积定理，立即可得所求受迫振动方程(9.1.23)的特解[记为 $ x_{s}(t) $，以示区别]为

 $$ x_{s}(t)=\frac{1}{\sqrt{\omega_{0}^{2}-\gamma^{2}}}\int_{-\infty}^{t}f(\tau)\mathrm{e}^{-\gamma(t-\tau)}\sin\big[\sqrt{\omega_{0}^{2}-\gamma^{2}}(t-\tau)\big]\mathrm{d}\tau $$ 

从而得(9.1.23)式的解为

 $$ x(t)=c_{1}x_{1}(t)+c_{2}x_{2}(t)+x_{s}(t) $$ 

其中

 $$ x_{1}(t)=\mathrm{e}^{-n}\sin\sqrt{\omega_{0}^{2}-\gamma^{2}}t\quad 和 \quad x_{2}(t)=\mathrm{e}^{-n}\cos\sqrt{\omega_{0}^{2}-\gamma^{2}}t $$ 

是(9.1.23)式所对应的齐次方程的线性独立解， $ c_{1} $ 和  $ c_{2} $ 是任意常数.

注 ① 傅里叶级数的复数形式证明见二维码.

②证明可参阅 B. H. 斯米尔诺夫. 高等数学教程，第二卷，第二分册，p. 456～459. 北京：高等教育出版社，1959.

<div style="text-align: center;"><img src="images/p0183_img_in_image_box_778_1008_844_1071.jpg" alt="Image" width="6%" /></div>


#### 习题9.1

傅里叶级数的

复数形式证明

1. 若  $ f(x) $ 满足傅氏积分定理的条件且为奇函数，试证

 $$ f(x)=\int_{0}^{\infty}b(\omega)\sin\omega x\mathrm{d}\omega $$

<!-- page: 184 -->

其中

 $$ b(\omega)=\frac{2}{\pi}\int_{0}^{\infty}f(x)\sin\omega x\mathrm{d}x $$ 

2. 求下列函数的傅氏变换：

(1) $ \frac{\sin ax}{x} $，a>0; (2) $ e^{-\eta x^{2}} $， $ \eta>0 $; (3) $ \sin \eta x^{2}, \cos \eta x^{2} $， $ \eta>0 $; (4) $ e^{-a|x|} $，a>0; (5) $ xe^{-ax^{2}} $，a>0.

3. 已知 $ \int_{-\infty}^{\infty}\frac{f(\xi)\mathrm{d}\xi}{(x-\xi)^{2}+a^{2}}=\frac{1}{x^{2}+b^{2}},0<a<b $，求未知函数 $ f(x) $.

4. 设  $ F[f(x)] = G(\omega), G^{(m)}(\omega) \mid_{\omega \to \pm \infty} = 0, m = 0, 1, \cdots, n-1 $，试证明像函数微分性质

$$  F\big[(-\mathrm{i}x)^{n}f(x)\big]=G^{(n)}\left(\omega\right),\quad n=1,2,\cdots   \tag*{(9.1.26)}$$

5. 试用傅氏变换的方法，求解量子力学中将会遇到的艾里（Airy）方程

 $$ u^{\prime \prime}(\xi)-\xi u(\xi)=0 $$ 

6. 设  $ F[f(x)] = G(\omega) $,  $ \int_{-\infty}^{\infty} G(\xi) \, \mathrm{d}\xi = 0 $，试证像函数的积分性质

$$  F\Big[\frac{1}{-\mathrm{i}x}f(x)\Big]=\int_{-\infty}^{\infty}G(\xi)\mathrm{d}\xi   \tag*{（9.1.27）}$$

7. 设  $ r = \sqrt{x^2 + y^2 + z^2} = |r| $,  $ \omega = \sqrt{\omega_1^2 + \omega_2^2 + \omega_3^2} = |\omega| $，证明

(1)  $  F\left[\frac{1}{r}\right] = \frac{4\pi}{\omega^2};  $

(2)  $  F\left[\frac{1}{r} e^{-\mu r}\right] = \frac{4\pi}{\omega^2 + \mu^2} (\mu > 0).  $

提示：(1) 可从右往左证，若从左往右证，则需先证(2)再取极限  $ \mu \to 0 $.

 $ ^{8} $. 试证傅里叶光学中的下列傅里叶变换关系式：

(1)  $  F[\operatorname{rect}(x)\operatorname{rect}(y)] = \operatorname{sinc}(f_x) \operatorname{sinc}(f_y)  $;

(2)  $  F[\Lambda(x)\Lambda(y)] = \mathrm{sinc}^2(f_x) \mathrm{sinc}^2(f_y).  $

其中

 $ f_{x}=\frac{\omega_{1}}{2\pi},f_{y}=\frac{\omega_{2}}{2\pi} $ 为频率；

rect(x)= $ \left\{\begin{aligned}&1,&|x|\leqslant\frac{1}{2}\\ &0,& 其他 \end{aligned}\right. $，为矩形函数；

 $$ \Lambda(x)=\begin{cases}1-\mid x\mid,&|x\mid\leqslant1\\0,& 其他 \end{cases}, 为三角函数； $$ 

 $ \sin c x=\frac{\sin \pi x}{\pi x} $，为 $ \sin c $函数.

9. 将  $ f(x)=\cos x^{2} $ 展开为傅氏积分.

（芝加哥大学研究生试题）

 $ ^{*} $10. 考虑受外力 g(t)作用的一个阻尼的简谐振子. 因此振子的运动由

 $$ \begin{array}{r}{\ddot{x}(t)+2a\dot{x}\left(t\right)+\omega_{0}^{2}x(t)=f(t),\qquad f(t)=g(t)/m}\end{array} $$ 

所给出. 考虑  $ \omega_{0} > a $ 的情形，这表示一个阻尼振子，且

 $$ f(t)=\begin{cases}f_{0},&\mid t\mid<\tau\\0,&\mid t\mid\geqslant\tau\end{cases} $$ 

求在三个区间  $ t<-\tau, t>\tau $ 和  $ |t|<\tau $ 中的  $ x(t) $，计算所有积分.

（加州理工学院研究生试题）

<!-- page: 185 -->

11. 设  $ F[f_{1}(x)] = G_{1}(\omega) $,  $ F[f_{2}(x)] = G_{2}(\omega) $,  $ F[f(x)] = G(\omega) $. 试证明乘积定理

$$  \int_{-\infty}^{\infty}f_{1}(x)f_{2}(x)\mathrm{d}x=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{1}^{*}\left(\omega\right)G_{2}\left(\omega\right)\mathrm{d}\omega=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{1}\left(\omega\right)G_{2}^{*}\left(\omega\right)\mathrm{d}\omega   \tag*{（9.1.28）}$$

和能量积分，即帕塞瓦尔(Parseval)等式

$$  \int_{-\infty}^{\infty}\left[f(x)\right]^{2}\mathrm{d}x=\int_{-\infty}^{\infty}\mid F(\omega)\mid^{2}\mathrm{d}\omega   \tag*{(9.1.29)}$$

其中， $ G_{1}^{*}(\omega) $， $ G_{2}^{*}(\omega) $ 分别为  $ G_{1}(\omega) $， $ G_{2}(\omega) $ 的共轭复数.

### 9.2 傅里叶变换法

对于无界区域的定解问题，傅里叶变换法是一种普遍适用的求解方法，其求解过程与解常微分方程大体相似。下面我们将通过几个具体的例子来了解如何用傅氏变换法来求解数学物理方程。

## 1. 波动问题

例 1 求解弦振动方程的初值问题

$$  \left\{u_{t t}=a^{2}u_{x x},\quad-\infty<x<\infty,t>0\right.   \tag*{(9.2.1)}$$

$$  \left\{\begin{aligned}u(x,0)&=\varphi(x)\\ u_{t}(x,0)&=0\end{aligned}\right\},\quad-\infty<x<\infty   \tag*{(9.2.2)}$$

解 视 t 为参数，对（9.2.1）、（9.2.2）和（9.2.3）式的两端均进行傅氏变换，并记

 $$ F[u(x,t)]=\int_{-\infty}^{\infty}u(x,t)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x=\tilde{u}(\omega,t),\quad F[\varphi(x)]=\tilde{\varphi}(\omega) $$ 

则有

 $$ \begin{cases}\frac{\mathrm{d}^{2}\tilde{u}}{\mathrm{d}t^{2}}=-a^{2}\omega^{2}\tilde{u}\\\tilde{u}(\omega,0)=\tilde{\varphi}(\omega)\\\tilde{u}_{t}(\omega,0)=0\end{cases} $$ 

这是带参数 $ \omega $的变量t的二阶常微分方程的初值问题，解之得

 $$ \tilde{u}(\omega,t)=\tilde{\varphi}(\omega)\cos{a\omega t} $$ 

于是由逆变换公式(9.1.7)，得定解问题(9.2.1)～(9.2.3)式的解为

 $$ \begin{align*}u(x,t)&=F^{-1}\big[\tilde{u}(\omega,t)\big]=F^{-1}\big[\tilde{\varphi}(\omega)\cos\omega t\big]\\&=\frac{1}{2\pi}\int_{-\infty}^{\infty}\tilde{\varphi}(\omega)\cos\omega t\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega\\&=\frac{1}{4\pi}\int_{-\infty}^{\infty}\tilde{\varphi}(\omega)\big[\mathrm{e}^{\mathrm{i}\omega(x+at)}+\mathrm{e}^{\mathrm{i}\omega(x-at)}\big]\mathrm{d}\omega\\&=\frac{1}{2}\big[\varphi(x+at)+\varphi(x-at)\big]\end{align*} $$ 

这与用达朗贝尔公式所得到的结果一致. 最后一步应用了位移性质.

<!-- page: 186 -->

## 2. 输运问题

例2 求无界杆的热传导问题

$$  \int u_{t}=a^{2}u_{x x}+f(x,t),\quad-\infty<x<\infty,t>0   \tag*{(9.2.4)}$$

$$  \mathcal{N}_{u}(x,0)=\varphi(x),\qquad\quad-\infty<x<\infty   \tag*{（9.2.5）}$$

解 对(9.2.4)式和(9.2.5)式两端以 x 为变量分别进行傅氏变换，并记

 $$ F[u(x,t)]=\tilde{u}(\omega,t),\quad F[\varphi(x)]=\tilde{\varphi}(\omega),\quad F[f(x,t)]=\tilde{f}(\omega,t) $$ 

则有

 $$ \left\{\begin{aligned}&\frac{\mathrm{d}\tilde{u}}{\mathrm{d}t}=-a^{2}\omega^{2}\tilde{u}+\tilde{f}(\omega,t)\\ &\tilde{u}(\omega,0)=\tilde{\varphi}(\omega)\end{aligned}\right. $$ 

这是带参数 $ \omega $关于变量t的一阶常微分方程的初值问题，解之得

 $$ \tilde{u}(\omega,t)=\tilde{\varphi}(\omega)\mathrm{e}^{-a^{2}\omega^{2}t}+\int_{0}^{t}\tilde{f}(\omega,\tau)\mathrm{e}^{-a^{2}\omega^{2}(t-\tau)}\mathrm{d}\tau $$ 

于是，由逆变换得（9.2.4）式和（9.2.5）式的解应为

 $$ \begin{align*}u(x,t)=&F^{-1}\big[\tilde{u}(\omega,t)\big]\\=&F^{-1}\big[\tilde{\varphi}(\omega)\mathrm{e}^{-\alpha^{2}\omega^{2}t}\big]+F^{-1}\bigg[\int_{0}^{t}\widetilde{f}(\omega,\tau)\mathrm{e}^{-\alpha^{2}\omega^{2}(t-\tau)}\mathrm{d}\tau\bigg]\\=&F^{-1}\big[F\big[\varphi(x)\big]\bullet F\big[F^{-1}(\mathrm{e}^{-\alpha^{2}\omega^{2}t})\big]\big]\\&+\int_{\varsigma}^{t}F^{-1}\big[F\big[f(x,\tau)\big]\bullet F\big[F^{-1}\big[\mathrm{e}^{-\alpha^{2}\omega^{2}(t-\tau)}\big]\big]\big]\mathrm{d}\tau\end{align*} $$ 

故由卷积性质(9.1.21)有

 $$ u(x,t)=\varphi(x)*F^{-1}(\mathrm{e}^{-a^{2}\omega^{2}t})+\int_{0}^{t}f(x,\tau)*F^{-1}[\mathrm{e}^{-a^{2}\omega^{2}(t-\tau)}]\mathrm{d}\tau $$ 

而由逆变换公式(9.1.7)式得

$$  \begin{aligned}F^{-1}(\mathrm{e}^{-a^{2}\omega^{2}t})&=\frac{1}{2\pi}\int_{-\infty}^{\infty}\mathrm{e}^{-a^{2}\omega^{2}t}\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega\\&=\frac{1}{2\pi}\int_{-\infty}^{\infty}\mathrm{e}^{-a^{2}\omega^{2}t}(\cos\omega x+\mathrm{i}\sin\omega x)\mathrm{d}\omega\\&=\frac{1}{\pi}\int_{0}^{\infty}\mathrm{e}^{-a^{2}\omega^{2}t}\cos\omega x\mathrm{d}\omega\\&=\frac{1}{2a\sqrt{\pi t}}\mathrm{e}^{-\frac{x^{2}}{4a^{2}t}}\end{aligned}   \tag*{(9.2.6)}$$

最后一步利用了第一篇的积分公式(5.3.7)式

 $$ \int_{0}^{\infty}\mathrm{e}^{-a x^{2}}\cos b x\mathrm{d}x=\frac{1}{2}\mathrm{e}^{-\frac{b^{2}}{4a}}\sqrt{\frac{\pi}{a}},\quad a>0 $$ 

于是

 $$ u(x,t)=\varphi(x)*\frac{1}{2a\sqrt{\pi t}}\mathrm{e}^{-\frac{x^2}{4a^2t}}+\int_{0}^{t}f(x,\tau)*\frac{1}{2a\sqrt{\pi(t-\tau)}}\mathrm{e}^{-\frac{x^2}{4a^2(t-\tau)}}\mathrm{d}\tau $$

<!-- page: 187 -->

$$  \mathrm{e}^{-\frac{1}{2a\sqrt{\pi t}}\int_{-\infty}^{\infty}\varphi(\xi)\mathrm{e}^{-\frac{(x-\xi)^2}{4a^2t}}\mathrm{d}\xi}+\frac{1}{2a\sqrt{\pi}}\mathrm{e}^{-\frac{f(\xi,\tau)}{\sqrt{t-\tau}}}\mathrm{d}\xi\mathrm{d}\tau   \tag*{(9.2.7)}$$

由此例我们看到，用傅氏变换解方程时不必像分离变量法那样区分齐次方程和非齐次方程，都是按同样的步骤解。

例3 已知某种微粒在空间的浓度分布为  $ \varphi(r) $，求解 t>0 时浓度的变化.

解 其定解问题为

$$  u_{t}-a^{2}\Delta u=0   \tag*{(9.2.8)}$$

$$  u\mid_{t=0}=\varphi(\boldsymbol{r})   \tag*{(9.2.9)}$$

将上述定解问题就空间变量  $ r(x,y,z) $ 作三维傅氏变换，并记

 $$ F[u(\boldsymbol{r},t)]=\iiint_{-\infty}^{\infty}u(\boldsymbol{r},t)\mathrm{e}^{-\mathrm{i}\omega\cdot r}\mathrm{d}\boldsymbol{r}=\tilde{u}(\boldsymbol{\omega},t) $$ 

 $$ F[\varphi(\boldsymbol{r})]=\tilde{\varphi}(\boldsymbol{\omega}),\quad\omega=\sqrt{\omega_{1}^{2}+\omega_{2}^{2}+\omega_{3}^{2}}=|\boldsymbol{\omega}| $$ 

则运用微分性质有

 $$ \left\{\begin{aligned}&\frac{\mathrm{d}\tilde{u}}{\mathrm{d}t}+a^{2}\omega^{2}\tilde{u}=0\\ &\tilde{u}(\pmb{\omega},0)=\tilde{\varphi}(\pmb{\omega})\end{aligned}\right. $$ 

解之得

 $$ \tilde{u}(\pmb{\omega},t)=\tilde{\varphi}(\pmb{\omega})\mathrm{e}^{-a^{2}\omega^{2}t} $$ 

由三维函数的傅氏逆变换公式 $ (9.1.13) $有

 $$ \begin{aligned}F^{-1}[\mathrm{e}^{-a^{2}\omega^{2}t}]&=\frac{1}{(2\pi)^{3}}\iiint_{-\infty}^{\infty}\mathrm{e}^{-a^{2}\omega^{2}t}\mathrm{e}^{\mathrm{i}\omega r}\mathrm{d}\omega\\&=\frac{1}{(2\pi)^{3}}\iiint_{-\infty}^{\infty}\mathrm{e}^{-a^{2}(\omega_{1}^{2}+\omega_{2}^{2}+\omega_{3}^{2})t}\mathrm{e}^{\mathrm{i}(\omega_{1}x+\omega_{2}y+\omega_{3}z)}\mathrm{d}\omega_{1}\mathrm{d}\omega_{2}\mathrm{d}\omega_{3}\\&=\frac{1}{8a^{3}(\pi t)^{3/2}}\mathrm{e}^{-\frac{x^{2}+y^{2}+z^{2}}{4a^{2}t}}\\ \end{aligned} $$ 

此处重复用了(9.2.6)式的结果三次. 故由逆变换公式和卷积定理有

$$  \begin{align*}u(\boldsymbol{r},t)&=F^{-1}\big[\tilde{u}(\boldsymbol{\omega},t)\big]=F^{-1}\big[\tilde{\varphi}(\boldsymbol{\omega})\mathrm{e}^{-a^{2}\omega^{2}t}\big]\\&=\frac{1}{8a^{3}(\pi t)^{3/2}}\iiint_{-\infty}^{\infty}\varphi(\boldsymbol{r}^{\prime})\mathrm{e}^{-\frac{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|^{2}}{4a^{2}t}}\mathrm{d}\boldsymbol{r}^{\prime}\end{align*}   \tag*{(9.2.10)}$$

## 3. 稳定场问题

例 4 求解真空中静电势满足的方程

$$  \Delta u(x,y,z)=-\frac{1}{\varepsilon_{0}}\rho(x,y,z)   \tag*{(9.2.11)}$$

解上述方程即

$$  \triangle u(\pmb{r})=-\frac{1}{\varepsilon_{0}}\rho(\pmb{r})   \tag*{(9.2.12)}$$

<!-- page: 188 -->

为方便起见，令  $ f(r)=\frac{1}{\varepsilon_{0}}\rho(r) $，并记  $ F[u(r)]=\tilde{u}(\omega), F[f(r)]=\tilde{f}(\omega) $，对方程 (9.2.12) 进行傅氏变换得

 $$ \tilde{u}(\pmb{\omega})=\frac{1}{\omega^{2}}\tilde{f}(\pmb{\omega}) $$ 

利用变换公式

 $$ F\Big[\frac{1}{r}\Big]=\frac{4\pi}{\omega^{2}} $$ 

（见习题9.1第7题）有

 $$ F[u(\boldsymbol{r})]=\frac{1}{4\pi}F\Big[\frac{1}{|\boldsymbol{r}|}\Big]\bullet F[f(\boldsymbol{r})] $$ 

故由卷积定理有

 $$ u(\boldsymbol{r})=\frac{1}{4\pi}\iiint_{-\infty}^{\infty}\frac{f(\boldsymbol{r}^{\prime})}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}\mathrm{d}\boldsymbol{r}^{\prime} $$ 

#### 习题9.2

1. 试用傅氏变换法求解上半平面狄氏问题

 $$ \left\{\begin{aligned}\Delta u&=0,\quad y>0\\ u&\mid_{y=0}=f(x)\\ &\lim\limits_{(x^{2}+y^{2})\to\infty}u=0\end{aligned}\right. $$ 

2. 试用傅里叶变换法求解无界弦的强迫振动

 $$ \begin{cases}u_{tt}=a^{2}u_{xx}+f(x,t),&-\infty<x<\infty\\u\mid_{t=0}=\varphi(x)\\u_{t}\mid_{t=0}=\psi(x)\end{cases} $$ 

3. 用傅氏变换法求解无限长梁在初始条件下的自由振动问题

 $$ \begin{cases}u_{tt}+a^{2}u_{xxxx}=0,&-\infty<x<\infty\\u(x,0)=\varphi(x)\\u_{t}(x,0)=a\psi^{\prime \prime}(x)\end{cases} $$ 

4. 用傅氏变换法求解半无限长均匀细管中的扩散问题

 $$ \left\{\begin{aligned}&u_{t}-D u_{x x}=0,&&0\leqslant x<\infty,t\geqslant0\\ &u\mid_{x=0}=0,&&t>0\\ &u\mid_{t=0}=\mathrm{e}^{-\beta\mathrm{r}},&&0\leqslant x<\infty\end{aligned}\right. $$ 

5. 用傅氏变换法求解半无界弦的自由振动

 $$ \left\{\begin{aligned}&u_{t t}=a^{2}u_{x x},&x&>0\\ &u\mid_{t=0}=0,&u_{t}\mid_{t=0}&=0\\ &u\mid_{x=0}=f(t),&t&>0\\ \end{aligned}\right. $$ 

提示：先将  $ f(t) $ 延拓为  $ f(t)H(t) $，并将 x 看成参数来求解。其中

 $$ H(t)=\left\{\begin{aligned}&1,&t>0\\ &0,&t<0\end{aligned}\right. $$

<!-- page: 189 -->

为阶跃函数.

6. 求解热传导方程  $ u_{t}=a^{2}u_{xx}\left(-\infty<x<\infty,t>0\right) $ 的初值问题，已知

(1)  $ u(x,0)=\sin x $; (2)  $ u(x,0)=x^{2}+1 $.

7. 用傅氏变换法求解混合微分方程的定解问题

 $$ u_{tx}=u_{xx}\left(-\infty<x<\infty,t>0\right) $$ 

 $$ u(x,0)=\sqrt{\frac{\pi}{2}}\mathrm{e}^{-\mid x\mid}\quad(-\infty<x<\infty) $$ 

8. 求解下列非常数系数的定解问题：

 $$ \left\{\begin{aligned}t u_{x}+u_{t}&=0(-\infty<x<\infty,t>0)\\ u(x,0)&=f(x)(-\infty<x<\infty)\end{aligned}\right. $$ 

### 9.3 拉普拉斯变换

由上一节我们看到，在用傅氏变换解微分方程时，要求所出现的函数必须在 $ (-\infty, \infty) $内满足绝对可积这个条件。这样，常数、多项式及三角函数等函数类都不能进行傅氏变换。另一方面，傅氏变换还要求进行变换的函数在无穷区间 $ (-\infty, \infty) $有定义，如果要求解的问题是混合问题而不是初值问题，那么就不能对空间变量进行傅氏变换了。为了克服傅氏变换的这些缺点，于是，人们适当地把傅氏变换加以改造，提出了拉普拉斯变换（简称为拉氏变换）。

为了达到使读者掌握用“拉氏变换”的方法解“数理方程”的目的，本节将引入拉氏变换的概念、存在定理、性质和展开定理。

## 1. 拉氏变换及拉氏变换存在定理

对于任何函数  $ f(t) $，我们假定在 t<0 时  $ f(t)\equiv0 $，那么，只要  $ \beta $ 足够的大，函数  $ f(t)\mathrm{e}^{-\beta t} $ 的傅氏变换就有可能存在，即

 $$ F\big[f(t)\mathrm{e}^{-\beta t}\big]=\int_{-\infty}^{\infty}f(t)\mathrm{e}^{-\beta t}\mathrm{e}^{-\mathrm{i}\omega t}\mathrm{d}t=\int_{0}^{\infty}f(t)\mathrm{e}^{-(\beta+\mathrm{i}\omega)t}\mathrm{d}t $$ 

其中

 $$ f(t)\mathrm{e}^{-\beta t}=\frac{1}{2\pi}\int_{-\infty}^{\infty}F[f(t)\mathrm{e}^{-\beta t}]\cdot\mathrm{e}^{\mathrm{i}\omega t}\mathrm{d}\omega $$ 

记

 $$ p=\beta+\mathrm{i}\omega,\quad F(p)=F[f(t)\mathrm{e}^{-\beta t}] $$ 

并注意到

 $$ \mathrm{d}p=\mathrm{i}\mathrm{d}\omega $$ 

$$  F(p)=\int_{0}^{\infty}f(t)\mathrm{e}^{-pt}\mathrm{d}t   \tag*{(9.3.1)}$$

便得到

$$  f(t)=\frac{1}{2\pi\mathrm{i}}\int_{\beta-\mathrm{i}\infty}^{\beta+\mathrm{i}\infty}F(p)\mathrm{e}^{p t}\mathrm{d}p   \tag*{(9.3.2)}$$

<!-- page: 190 -->

这是一对新的互逆的积分变换. 我们称(9.3.1)式为函数  $ f(t) $ 的拉普拉斯变换, 记作

$$  L[f(t)]=F(p)=\int_{0}^{\infty}f(t)\mathrm{e}^{-pt}\mathrm{d}t   \tag*{(9.3.3)}$$

并称函数  $ F(p) $ 为  $ f(t) $ 的像函数；而称(9.3.2)式为函数  $ F(p) $ 的拉普拉斯逆变换或拉普拉斯反演公式，记作

$$  L^{-1}\left[F(p)\right]=f(t)=\frac{1}{2\pi\mathrm{i}}\int_{\beta\to\infty}^{\beta+\mathrm{i}\infty}F(p)\mathrm{e}^{p t}\mathrm{d}p   \tag*{(9.3.4)}$$

并称函数  $ f(t) $ 为  $ F(p) $ 的像原函数. 显然

$$  f(t)=L^{-1}\big[L\big[f(t)\big]\big]   \tag*{(9.3.5)}$$

拉氏变换的存在条件，由下述拉普拉斯变换的存在定理 $ ^{①} $给出.设函数  $ f(t) $ 满足以下条件：

（1）当t<0时， $ f(t)=0 $;

（2）当 $ t\geqslant0 $时， $ f(t) $及 $ f^{\prime}(t) $除去有限个第一类间断点以外，处处连续；

（3）当  $ t \to \infty $ 时， $ f(t) $ 的增长速度不超过某一个指数函数，亦即存在常数 M 及  $ \beta_{0} \geqslant 0 $ ，使得

$$  \mid f(t)\mid\leqslant M\mathrm{e}^{\beta_{0}t},\quad0<t<\infty   \tag*{(9.3.6)}$$

其中， $ \beta_{0} $ 称为  $ f(t) $ 的增长指数。则  $ f(t) $ 的拉氏变换  $ F(p) $ 在半平面  $ \mathrm{Rep} > \beta_{0} $ 上存在、解析，且当  $ \left|\arg p\right| \leqslant \frac{\pi}{2} - \delta $ ( $ \delta $ 是任意小的正数) 时，有

$$  \lim_{p\to\infty}F(p)=0   \tag*{(9.3.7)}$$

例1  $ f(t)=\mathrm{e}^{at} $，式中 $ \alpha $为复数，求 $ L\left[\mathrm{e}^{at}\right] $的解.

解 由定义式(9.3.3)有

$$  L[\mathrm{e}^{a t}]=\int_{0}^{\infty}\mathrm{e}^{a t}\mathrm{e}^{-p t}\mathrm{d}t=\frac{1}{p-\alpha},\quad\mathrm{R e}p>\mathrm{R e}\alpha   \tag*{(9.3.8)}$$

若 $ \alpha=0 $,则有

$$  L[1]=\frac{1}{p}   \tag*{(9.3.9)}$$

例2 求  $ L[\sin at] $ 和  $ L[\cos at] $，a 为实数.

解 由定义

$$  \begin{aligned}L[\sin at]=&\int_{0}^{\infty}\sin at\mathrm{e}^{-pt}\mathrm{d}t=\frac{1}{2\mathrm{i}}\int_{0}^{\infty}[\mathrm{e}^{-(p-\mathrm{i}a)t}-\mathrm{e}^{-(p+\mathrm{i}a)t}]\mathrm{d}t\\ =&\frac{1}{2\mathrm{i}}\Big(\frac{1}{p-\mathrm{i}a}-\frac{1}{p+\mathrm{i}a}\Big)\\ =&\frac{a}{p^{2}+a^{2}},\quad\mathrm{Rep}>0\end{aligned}   \tag*{(9.3.10)}$$

同法可得

$$  L[\cos at]=\frac{p}{p^{2}+a^{2}},\quad Re p>0   \tag*{(9.3.11)}$$

例3 求  $ f(t)=t^{\alpha}(\mathrm{Re}\alpha>-1) $ 的拉氏变换.

<!-- page: 191 -->

解 由拉氏变换的定义和  $ \Gamma $ 函数的定义，有

$$  L\left[t^{\alpha}\right]=\int_{0}^{\infty}t^{\alpha}\mathrm{e}^{-p t}\mathrm{d}t=\frac{1}{p^{\alpha+1}}\int_{0}^{\infty}\mathrm{e}^{-p t}\left(p t\right)^{\alpha}\mathrm{d}(p t)=\frac{\Gamma(\alpha+1)}{p^{\alpha+1}},\quad\mathrm{R e}p>0   \tag*{(9.3.12)}$$

特别地，取  $ \alpha=-\frac{1}{2} $，则得

 $$ L[t^{-\frac{1}{2}}]=\frac{1}{\sqrt{p}}\Gamma\bigl(\frac{1}{2}\bigr) $$ 

即

$$  L\left[\frac{1}{\sqrt{\pi t}}\right]=\frac{1}{\sqrt{p}}   \tag*{(9.3.13)}$$

取  $ \alpha=n(n=1,2,\cdots) $ 则得

$$  L[t^{n}]=\frac{n!}{p^{n+1}}   \tag*{(9.3.14)}$$

对于常见函数的拉氏变换，已制成了表，见附录Ⅲ.

## 2. 拉氏变换的性质

设凡是要求拉氏变换的函数，均是满足拉氏变换存在定理的，则由拉氏变换的定义，类似于上节证傅氏变换的性质的方法，我们易于证得拉氏变换有如下与傅氏变换类似的一些重要性质：

（1）线性性质

$$  L[\alpha f_{1}+\beta f_{2}]=\alpha L[f_{1}]+\beta L[f_{2}]   \tag*{（9.3.15）}$$

（2）延迟性质

$$  L\left[\mathrm{e}^{p_{0}t}f(t)\right]=F(p-p_{0}),\quad\mathrm{R e}(p-p_{0})>\beta_{0}   \tag*{(9.3.16)}$$

其中

 $$ F(p)=L[f(t)] $$ 

（3）位移性质设 $ \tau>0 $，则

$$  L\big[f(t-\tau)\big]=\mathrm{e}^{-t\kappa}L\big[f(t)\big]   \tag*{(9.3.17)}$$

（4）相似性质 设 a>0,  $ F(p)=L[f(t)] $，则

$$  L[f(at)]=\frac{1}{a}F\biggl(\frac{p}{a}\biggr)   \tag*{(9.3.18)}$$

（5）微分性质

$$  \left\{\begin{aligned}L\big[f^{\prime}(t)\big]&=p L\big[f(t)\big]-f(0)\\ L\big[f^{\prime \prime}(t)\big]&=\big.p^{2}L\big[f(t)\big]-p f(0)-f^{\prime}(0)\\ &\cdots\cdots\\ L\big[f^{(n)}(t)\big]&=p^{n} L\big[f(t)\big]-p^{n-1}f(0)-p^{n-2}f^{\prime}(0)-\cdots-f^{(n-1)}(0)\end{aligned}\right.   \tag*{(9.3.19)}$$

#### （6）积分性质

<!-- page: 192 -->

$$  L\biggl[\int_{0}^{t}f(\tau)\mathrm{d}\tau\biggr]=\frac{1}{p}L\bigl[f(t)\bigr]   \tag*{（9.3.20）}$$

#### （7）卷积定理

$$  L[f_{1}(t)*f_{2}(t)]=L[f_{1}(t)]\bullet L[f_{2}(t)]   \tag*{(9.3.21)}$$

其中，定义

$$  f_{1}(t)*f_{2}(t)=\int_{0}^{t}f_{1}(\tau)f_{2}(t-\tau)\mathrm{d}\tau^{2}   \tag*{（9.3.22）}$$

熟练地掌握以上这些性质，对于我们用拉氏变换解线性常微分方程和积分方程的初值问题极为方便。

#### 例 4 解常微分方程的初值问题

 $$ \begin{cases}T_{n}^{\prime \prime}(t)+\left(\frac{n\pi a}{l}\right)^{2}T_{n}(t)=f_{n}(t)\\T_{n}(0)=0\\T_{n}^{\prime}(0)=0\end{cases} $$ 

解 对方程两边取拉氏变换，并设

 $$ \tilde{T}(p)=L\big[T_{n}(t)\big],\quad F(p)=L\big[f_{n}(t)\big] $$ 

则由微分性质(9.3.19)式有

 $$ p^{2}\widetilde{T}(p)-p T_{n}(0)-T_{n}^{\prime}(0)+\left(\frac{a n\pi}{l}\right)^{2}\widetilde{T}(p)=F(p) $$ 

代入初始条件得

 $$ \boldsymbol{p}^{2}\widetilde{T}(\boldsymbol{p})+\left(\frac{a n\pi}{l}\right)^{2}\widetilde{T}(\boldsymbol{p})=F(\boldsymbol{p}) $$ 

 $$ \tilde{T}(p)=F(p)\bullet\frac{1}{p^{2}+\left(\frac{a n\pi}{l}\right)^{2}} $$ 

而由(9.3.10)式有

 $$ \frac{1}{p^{2}+\left(\frac{a n\pi}{l}\right)^{2}}=\frac{l}{n\pi a}L\Big[\sin\frac{n\pi a}{l}t\Big],\quad\mathrm{R e}p>0 $$ 

所以，由卷积定理有

 $$ \begin{aligned}T_{n}(t)&=L^{-1}\big[\widetilde{T}(p)\big]=L^{-1}\left\lfloor F(p)\bullet\frac{1}{p^{2}+\left(\frac{n\pi a}{l}\right)^{2}}\right\rfloor\\&=\frac{l}{n\pi a}L^{-1}\Big[L\big[f_{n}(t)\big]\bullet L\Big[\sin\frac{n\pi a}{l}t\Big]\Big]\\&=\frac{l}{n\pi a}f_{n}(t)*\sin\frac{n\pi a}{l}t\\&=\frac{l}{n\pi a}\int_{0}^{t}f_{n}(\tau)\sin\frac{n\pi a}{l}(t-\tau)\mathrm{d}\tau\\ \end{aligned} $$ 

此即第八章定解问题（8.2.5）、（8.2.7）式的解.

<!-- page: 193 -->

例 5 求如图 9.1 中，LC 串联电路当电容器 C 放电时的电流，电容器上的初始电荷为  $ \pm q_{0} $.

解 该电路电流  $ i(t) $ 所满足的方程是

 $$ \left\{\begin{aligned}L\frac{\mathrm{d}i}{\mathrm{d}t}+\frac{1}{C}\int_{0}^{t}i\mathrm{d}t&=\frac{q_{0}}{C}\\ i(0)&=0\end{aligned}\right. $$ 

<div style="text-align: center;"><img src="images/p0193_img_in_image_box_586_156_859_306.jpg" alt="图9.1" width="28%" /></div>


对方程两边进行拉氏变换，并设 $ i(t) $的拉氏变换 $ \int_{0}^{\infty}i(t)\mathrm{e}^{-pt}\mathrm{d}t=I(p) $，则有

<div style="text-align: center;"><div style="text-align: center;">图9.1</div> </div>


 $$ L\bullet\left[p I(p)-i(0)\right]+\frac{1}{C}\bullet\frac{I(p)}{p}=\frac{q_{0}}{C}\bullet\frac{1}{p} $$ 

代入初始条件得

 $$ I(p)=\frac{q_{0}}{LC}\frac{1}{p^{2}+\frac{1}{LC}} $$ 

故由(9.3.10)式有

 $$ i(t)=L^{-1}\big[I(p)\big]=\frac{q_{0}}{L C}L^{-1}\left(\frac{1}{p^{2}+\frac{1}{L C}}\right)=\frac{q_{0}}{\sqrt{L C}}\sin\frac{1}{\sqrt{L C}}t $$ 

此例中 L 表示电感， $ L^{-1} $ 仍表示拉氏逆变换.

由以上二例我们看到，在用拉氏变换求解方程时，毋需考虑方程的齐次与否，其步骤都是一样的，而且作变换时把初值都包括进去了，省去了其他解法中用初值定解的一步。

## 3. 拉氏反演及展开定理

应用拉氏变换的关键，在于求拉氏反演。求拉氏反演的方法比较灵活，基本的做法是利用拉氏变换的性质及已知的基本变换式来作反演，在上面的例4、例5中正是这样做的。下面再看两个例子。

例6 求 $ \frac{1}{\sqrt{2p+5}} $的原函数 $ f(t) $.

解

 $$ \frac{1}{\sqrt{2p+5}}=\frac{1}{\sqrt{2}}\frac{1}{\sqrt{p+\frac{5}{2}}} $$ 

故由线性性质、延迟性质和 $ (9.3.13) $式的结果有

 $$ f(t)=L^{-1}\left(\frac{1}{\sqrt{2}}\frac{1}{\sqrt{p+\frac{5}{2}}}\right)=\frac{1}{\sqrt{2}}\mathrm{e}^{-\frac{5}{2}t}\bullet\frac{1}{\sqrt{\pi t}}=\frac{1}{\sqrt{2\pi t}}\mathrm{e}^{-\frac{5}{2}t} $$

<!-- page: 194 -->

例7 求  $ L^{-1}\left[\frac{p}{p^{2}-2p+5}\right] $

解  $ \frac{p}{p^{2}-2p+5}=\frac{p-1+1}{(p-1)^{2}+4}=\frac{p-1}{(p-1)^{2}+4}+\frac{1}{(p-1)^{2}+4} $

故由（9.3.11）、（9.3.10）式和延迟性质、线性性质，有

 $$ \begin{aligned}L^{-1}\bigg[\frac{p}{p^{2}-2p+5}\bigg]&=L^{-1}\bigg[\frac{p-1}{(p-1)^{2}+4}+\frac{1}{(p-1)^{2}+4}\bigg]\\&=\mathrm{e}^{t}\Big(\cos2t+\frac{1}{2}\sin2t\Big)\end{aligned} $$ 

还可以根据拉氏反演公式(9.3.4)和留数理论来求反演。(9.3.4)式可写为

 $$ f(t)=\frac{1}{2\pi\mathrm{i}}\int_{l_{1}}F(p)\mathrm{e}^{p t}\mathrm{d}p,\quad t>0 $$ 

其中  $ l_{1} $ 为 p 平面上  $ \mathrm{Rep}=\beta>\beta_{0} $ 的与虚轴平行的任一条直线.

若  $ F(p) $ 是单值的，且在  $ 0 \leq \arg p \leq 2\pi $ 中当  $ p \to \infty $

时  $ F(p) \to 0 $，则我们将会看到

<div style="text-align: center;"><img src="images/p0194_img_in_image_box_98_539_366_827.jpg" alt="图9.2" width="27%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图9.2</div> </div>


$$  f(t)=\sum_{k}\mathrm{res}[F(p_{k})\mathrm{e}^{p_{k} t}],\quad t>0   \tag*{（9.3.23）}$$

其中， $ p_{k} $ 为像函数  $ F(p) $ 在全平面的奇点. 此即所谓的展开定理.

因为在此种情况下，只要 $ \beta $取得足够大，总能使 $ F(p) $在直线 $ l_{1} $的右边解析。考虑 $ F(p)\mathrm{e}^{pt} $沿如图9.2所示实线闭合围道的积分，其中 $ C_{R} $为以p=0为中心，R为半径，从A到B不经过 $ F(p) $的奇点的实线圆弧。则

 $$ \frac{1}{2\pi\mathrm{i}}\int_{B}^{A}F(p)\mathrm{e}^{p t}\mathrm{d}p+\frac{1}{2\pi\mathrm{i}}\int_{C_{k}}F(p)\mathrm{e}^{p t}\mathrm{d}p=\sum_{k}\mathrm{res}\big[F(p)\mathrm{e}^{p t}\big]_{l 内 },\quad l=\overline{B}\overline{A}+C_{R} $$ 

而由若尔当引理可以证明 $ ^{③} $

$$  \lim_{R\to\infty}\int_{C_{R}}F(p)\mathrm{e}^{p t}\mathrm{d}p=0   \tag*{(9.3.24)}$$

所以，当 $ R \to \infty $有

 $$ f(t)=\frac{1}{2\pi\mathrm{i}}\int_{l_{1}}F(p)\mathrm{e}^{p t}\mathrm{d}p=\sum_{k}\mathrm{r e s}\big[F(p_{k})\mathrm{e}^{p_{k}t}\big] $$ 

可见求反演的问题，转化成了计算留数的问题.

例8 求  $  F(p) = \frac{\mathrm{ch}\frac{\sqrt{p}}{a} x}{p \mathrm{ch}\frac{\sqrt{p}}{a} l}  $ 的原函数  $  f(t)  $.

<!-- page: 195 -->

解 这是单值函数，它的奇点全是单极点

 $$ p_{0}=0,\quad p_{k}=-\frac{a^{2}\pi^{2}(2k-1)^{2}}{4l^{2}},\quad k=1,2,\cdots $$ 

 $$  res\left[F(p)\mathrm{e}^{pt}\right]_{p=0}=1 $$ 

 $$ \mathrm{res}\left[F(p_{k})\mathrm{e}^{p_{k}l}\right]=\frac{\mathrm{ch}\frac{\sqrt{p}}{a}x\cdot\mathrm{e}^{p_{t}}}{\left(p\mathrm{ch}\frac{\sqrt{p}}{a}l\right)^{\prime}}\Bigg|_{b=b_{t}}=\frac{\cos\frac{(2k-1)\pi x}{2l}\mathrm{e}^{\frac{-a^{2}\pi^{2}(2k-1)^{2}}{4l^{2}}t}}{(-1)^{k}\frac{(2k-1)\pi}{4}},\quad k=1,2,\cdots $$ 

所以

 $$ \begin{align*}f(t)&=\mathrm{res}\big[F(p)\mathrm{e}^{pt}\big]_{p=0}+\sum_{k=1}^{\infty}\mathrm{res}\big[F(p_{k})\mathrm{e}^{p_{k}t}\big]\\&=1+\frac{4}{\pi}\sum_{k=1}^{\infty}\frac{(-1)^{k}}{2k-1}\mathrm{cos}\frac{(2k-1)\pi x}{2l}\mathrm{e}^{-\frac{a^{2}\pi^{2}(2k-1)^{2}}{4l^{2}}t}\end{align*} $$ 

必须注意，在用上述方法求拉氏反演时，如果像函数 $ F(p) $是多值函数，则当然不能简单地取如图9.2那样的积分围道，如，对于 $ F(p)=\frac{1}{\sqrt{p}} $，则应选择图9.3中的围道，因为此时p=0是 $ \frac{1}{\sqrt{p}} $的支点，此函数的原函数已由(9.3.13)式给出，读者不妨用展开定理再求一次.



<div style="text-align: center;"><img src="images/p0195_img_in_image_box_545_737_610_801.jpg" alt="图9.3" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0195_img_in_image_box_689_520_844_698.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图9.3</div> </div>


拉氏变换存在定理证明

②拉氏变换卷积定义的由来见二维码.

注 ① 拉氏变换存在定理证明见二维码.

③ 见参考文献[7]第156页.

<div style="text-align: center;"><img src="images/p0195_img_in_image_box_742_737_806_801.jpg" alt="Image" width="6%" /></div>


拉氏变换卷积定义的由来

#### 习题9.3

1. 求下列函数的拉氏变换：

(1)  $ f(t) = \mathrm{e}^{-2t} $; (2)  $ f(t) = t^2 + te^t $;

(3)  $ f(t) = t\cos at + t\sin at $; (4)  $ f(t) = \mathrm{e}^{-2t}\sin 6t - 5\mathrm{e}^{-2t} $;

(5)  $ f(t) = t^n \mathrm{e}^{at} - t^{n-1} $.

2. 利用性质或查表法求下列函数的拉氏逆变换：

 $$ \frac{p+8}{p^{2}+4p+5}； $$ 

 $$ \frac{p}{(p^{2}+a^{2})^{2}},\quad a>0. $$ 

3. 试用反演公式（或展开定理）计算下列函数的拉氏逆变换：

(1)

 $$ F(p)=\frac{1}{p(p+a)(p+b)}; $$ 

 $$ F(p)=\frac{1}{(p^{2}+2p+2)^{2}}. $$ 

4. 试用拉氏变换法解下列常微分方程及方程组：

(1)

 $$ \begin{cases}y^{\prime}-y=-3\mathrm{e}^{-2t}\\y(0)=2;\end{cases} $$ 

(2)

 $$ \left\{\begin{aligned}y^{\prime \prime}+4y^{\prime}+3y=&\mathrm{e}^{-t}\\ y(0)=&y^{\prime}(0)=1;\end{aligned}\right. $$

<!-- page: 196 -->

(3)

 $$ \left\{\begin{aligned}&y^{\prime \prime \prime}-2y^{\prime \prime}+y^{\prime}=4\\ &y(0)=1,y^{\prime}(0)=2,y^{\prime \prime}(0)=-2;\end{aligned}\right. $$ 

(4) $ \left\{\begin{aligned}&y^{\prime}-2z^{\prime}=f(t)\\&y^{\prime\prime}-z^{\prime\prime}+z=0\end{aligned}\right. $ 其中  $ \left\{\begin{aligned}&y(0)=y^{\prime}(0)=0\\&z(0)=z^{\prime}(0)=0.\end{aligned}\right. $

5. 求解弹簧振子的受迫振动问题

 $$ \begin{cases}m\ddot{x}(t)+kx(t)=f(t)\\x(0)=0,\dot{x}(0)=0\end{cases} $$ 

6. 求解直流电源的 RLC 电路方程的初值问题.

 $$ \begin{cases}Li^{\prime}(t)+Ri(t)+\frac{1}{C}\int_{0}^{t}i(\tau)\mathrm{d}\tau=E_{0}\\i(0)=\frac{E_{0}}{L}\end{cases} $$ 

7. 若  $ F(p)=L[f(t)] $，试证像函数的微分性质

$$  L\bigl[(-t)^{n}f(t)\bigr]=F^{(n)}(p)   \tag*{(9.3.25)}$$

8. 若  $ F(p)=L[f(t)] $，且  $ \int_{0}^{\infty}F(\xi)\mathrm{d}\xi(\mathrm{Re}p>\beta_{0}) $ 收敛，试证像函数积分性质

$$  L\bigg[\frac{f(t)}{t}\bigg]=\int_{p}^{\infty}F(p)\mathrm{d}p   \tag*{(9.3.26)}$$

### 9.4 拉普拉斯变换法

在上一节中，我们已用拉氏变换求解了常微分方程的初值问题。我们更感兴趣的是，用拉氏变换求解偏微分方程的混合问题。下面通过两个具体的例子来说明拉氏变换法的求解步骤。

例 1 求解半无界弦的振动问题

 $$ \begin{cases}u_{t t}=a^{2}u_{x x},&0<x<\infty,t>0\\u(0,t)=f(t),\lim_{x\to\infty}(x,t)=0,&t\geqslant0\\u(x,0)=0,u_{t}(x,0)=0,&0\leqslant x<\infty\end{cases} $$ 

解 对方程两边关于变量 t 作拉氏变换，并记

 $$ U(x,p)=L[u(x,t)]=\int_{0}^{\infty}u(x,t)\mathrm{e}^{-p t}\mathrm{d}t $$ 

则

 $$ p^{2}U(x,p)-pu(x,0)-u_{t}(x,0)=a^{2}\frac{\mathrm{d}^{2}U(x,p)}{\mathrm{d}x^{2}} $$ 

代入初始条件得

$$  \frac{\mathrm{d}^{2}U}{\mathrm{d}x^{2}}-\frac{p^{2}}{a^{2}}U(x,p)=0   \tag*{(9,4,1)}$$

再对边界条件关于变量 t 作拉氏变换，并记  $ F(p) = L[f(t)] $，则有

<!-- page: 197 -->

$$  \begin{cases}U(0,p)=F(p)\\\lim_{x\to\infty}U(x,p)=0\end{cases}   \tag*{(9.4.2)}$$

常微分方程(9.4.1)的通解为

 $$ U(x,p)=C_{1}(p)\mathrm{e}^{-p x/a}+C_{2}(p)\mathrm{e}^{p x/a} $$ 

代入边界条件（9.4.2）得

 $$ C_{2}(p)=0,\quad C_{1}(p)=F(p) $$ 

故

 $$ U(x,p)=\mathrm{e}^{-p x/a}\cdot F(p) $$ 

而由位移定理 $ (9.3.17) $式有

 $$ \mathrm{e}^{-p\frac{x}{a}}F(p)=L\biggl[f\biggl(t-\frac{x}{a}\biggr)\biggr] $$ 

所以

 $$ \begin{align*}u(x,t)&=L^{-1}\big[U(x,p)\big]=L^{-1}\bigg[L\Big[f\Big(t-\frac{x}{a}\Big)\Big]\bigg]\\&=\begin{cases}0,&t<\frac{x}{a}\\f\Big(t-\frac{x}{a}\Big),&t\geqslant\frac{x}{a}\end{cases}\end{align*} $$ 

例2 求解长为 l 的均匀细杆的热传导问题

 $$ \begin{cases}u_{t}=a^{2}u_{xx},&0<x<l,t>0\\u_{x}(0,t)=0,u(l,t)=u_{1},&t\geqslant0\\u(x,0)=u_{0},&0\leqslant x\leqslant l\end{cases} $$ 

解 对方程和边界条件（关于变量 t）进行拉氏变换，记  $ L[u(x,t)]=U(x,p) $，并考虑到初始条件，则得

$$  \frac{\mathrm{d}^{2}U}{\mathrm{d}x^{2}}-\frac{p}{a^{2}}U+\frac{u_{0}}{a^{2}}=0   \tag*{(9,4,3)}$$

$$  U_{x}(0,p)=0   \tag*{(9,4,4)}$$

$$  U(l,p)=\frac{u_{1}}{p}   \tag*{（9.4.5）}$$

方程(9.4.3)的通解为

 $$ U(x,p)=\frac{u_{0}}{p}+C_{1}(p)\mathrm{s h}\frac{\sqrt{p}}{a}x+C_{2}(p)\mathrm{c h}\frac{\sqrt{p}}{a}x $$ 

由边界条件(9.4.4)～(9.4.5)定出 $ C_{1}(p) $、 $ C_{2}(p) $便得

<!-- page: 198 -->

$$ U(x,p)=\frac{u_{0}}{p}+\frac{u_{1}-u_{0}}{p}\frac{\mathrm{ch}\frac{\sqrt{p}}{a}x}{\mathrm{ch}\frac{\sqrt{p}}{a}l} $$ 

而由上节的(9.3.9)式和例8分别有

 $$ L^{-1}\left[\frac{1}{p}\right]=1 $$ 

 $$ L^{-1}\left(\frac{\mathrm{ch}\frac{\sqrt{p}}{a}x}{p\mathrm{ch}\frac{\sqrt{p}}{a}l}\right)=1+\frac{4}{\pi}\sum_{k=1}^{\infty}\frac{(-1)^{k}}{2k-1}\cos\frac{(2k-1)\pi x}{2l}\mathrm{e}^{-\frac{a^{2}\pi^{2}(2k-1)^{2}}{4l^{2}}t} $$ 

故

 $$ u(x,t)=L^{-1}\left[U(x,p)\right]=u_{1}+\frac{4}{\pi}\sum_{k=1}^{\infty}\frac{(-1)^{k}}{2k-1}\cos\frac{(2k-1)\pi x}{2l}\mathrm{e}^{-\frac{a^{2}\pi^{2}(2k-1)^{2}}{4l^{2}}} $$ 

可以看出，用拉氏变换法求解数理方程的定解问题时，无论方程与边界条件的齐次与否，都是采取同样的步骤。

当然，拉氏变换法同样也可用来求解无界区域的问题。

#### 习题9.4

1. 求解定解问题

 $$ \begin{cases}\frac{\partial^{2}u}{\partial x\partial y}=1,&x>0,y>0\\u\mid_{x=0}=y+1,&y>0\\u\mid_{y=0}=1,&x>0\end{cases} $$ 

2. 求解一维半无限长杆的热传导问题

 $$ \begin{cases}u_{t}=a^{2}u_{xx},&0<x<\infty,t>0\\u(0,t)=u_{0},\lim_{x\to\infty}u(x,t)=0,&t\geqslant0\\u(x,0)=0,&0\leqslant x<\infty\end{cases} $$ 

3. 求解杆的纵横振动问题

 $$ \begin{cases}u_{tt}=a^{2}u_{xx},&0<x<l,t>0\\u(0,t)=0,E u_{x}(l,t)=A\mathrm{sin}\omega t,&t>0\\u(x,0)=0,u_{t}(x,0)=0,&0\leqslant x\leqslant l\end{cases} $$ 

4. 求解定解问题

 $$ \left\{\begin{aligned}&u_{t}-a^{2}u_{x x}=\cos\omega t,\quad0<x<\infty,t>0\\ &u(x,0)=0,u_{t}(x,0)=0\\ &u(0,t)=0,\lim_{x\to\infty}u_{x}=0\end{aligned}\right. $$

<!-- page: 199 -->

5. 长为 l 的均匀细杆，一端保持零度，另一端保持恒定温度  $ u_{0} $，若初始温度也是零，求杆中温度分布.

6. 试用拉氏变换法求解无界弦的一般受迫振动问题.

7. 求解有界杆的热传导问题

 $$ \left\{\begin{aligned}u_{t}=&a^{2}u_{x x}\quad(0<x<l,t>0)\\ u(0,t)=&u(l,t)=0\quad(t>0)\\ u(x,0)=&\sin\frac{\pi x}{l}\quad(x\geqslant0)\end{aligned}\right. $$ 

8. 试将拉氏变换和傅氏变换结合起来求解下列具有高斯初始温度分布的对流热传导问题

 $$ \left\{\begin{aligned}u_{t}=&a^{2}u_{x x}-k u_{x}\left(-\infty<x<\infty,t>0\right)\\ u(x,0)=&\frac{1}{\sqrt{\pi}}\mathrm{e}^{-x^{2}}\left(-\infty<x<\infty\right)\end{aligned}\right. $$ 

其中 a 和 k 分别为扩散系数和对流系数.

9. 试将拉氏变换和傅氏变换结合起来求解无界弦的强迫振动

 $$ \left\{\begin{aligned}u_{tt}&=u_{xx}+t\sin x\quad(-\infty<x<\infty,t>0\\ u(x,0)&=0\quad(-\infty<x<\infty)\\ u_{t}(x,0)&=\sin x\end{aligned}\right. $$

<!-- page: 200 -->

<div style="text-align: center;"><div style="text-align: center;">本章小结</div> </div>


<div style="text-align: center;"><img src="images/p0200_img_in_image_box_599_141_661_205.jpg" alt="本章小结" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0200_img_in_image_box_729_141_792_205.jpg" alt="Image" width="6%" /></div>


本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>变换类型
主要内容</td><td style='text-align: center; word-wrap: break-word;'>傅氏变换</td><td style='text-align: center; word-wrap: break-word;'>拉氏变换</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>像函数</td><td style='text-align: center; word-wrap: break-word;'>$ G(\omega) = \int_{-\infty}^{\infty} f(x) e^{-i\omega x} dx $</td><td style='text-align: center; word-wrap: break-word;'>$ F(p) = \int_{0}^{\infty} f(t) e^{-pt} dt $,  $ p = \beta + i\omega $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>原函数</td><td style='text-align: center; word-wrap: break-word;'>$ f(x) = \frac{1}{2\pi} \int_{-\infty}^{\infty} G(\omega) e^{i\omega x} d\omega $</td><td style='text-align: center; word-wrap: break-word;'>$ f(t) = \frac{1}{2\pi i} \int_{\beta \to \infty}^{\beta + i\infty} F(p) e^{pt} dp $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>主要性质</td><td colspan="2">1. 线性性质; 2. 延迟性质; 3. 位移性质; 4. 相似性质; 5. 微分性质; 6. 积分性质; 7. 卷积定理; 8. 像函数卷积定理</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>解数理方程的步骤</td><td colspan="2">1. 对方程和定解条件(关于某个变量)施行变换
2. 解变换后得到的像函数的常微分方程的定解问题
3. 求像函数的逆变换(反演)即得原定解问题的解</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>求逆变换方法</td><td colspan="2">1. 查表并利用变换的性质(如卷积定理等)
2. 由逆变换公式来求,常常要用留数定理计算积分</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>解法优点</td><td colspan="2">1. 减少了自变量个数,使偏微分方程化为了常微分方程求解,从而使问题大大简化
2. 不必考虑方程(边界条件)的齐次与否,都采用一种固定的步骤求解,易于掌握</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>缺点</td><td style='text-align: center; word-wrap: break-word;'>对函数要求苛刻(绝对可积)</td><td style='text-align: center; word-wrap: break-word;'>有些逆变换难求</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>常用于求解</td><td style='text-align: center; word-wrap: break-word;'>没有边界条件的初值问题(对空间变量变换)</td><td style='text-align: center; word-wrap: break-word;'>带有初始条件的混合问题特别是半无界问题(对时间变量变换)</td></tr></table>

<!-- page: 201 -->

## 第十章 格林函数法

我们已看到，分离变量法主要适用于求解各种有界问题，而傅氏变换法主要适用于求解各种无界问题，这两种方法所得到的解一般分别为无穷级数和无穷积分的形式。本章将介绍求解数理方程的另一重要方法——格林（Green）函数法，它在近代物理学特别是量子理论的发展中起着重要的作用。与分离变量法和傅氏变换法不同，它给出的解是有限的积分形式，十分便于理论分析和研究。

格林函数又称为点源函数或影响函数。顾名思义，它表示一个点源在一定的边界条件和（或）初值条件下所产生的场或影响。由于在线性问题中任意分布的源所产生的场均可看成许许多多点源产生的场的叠加，因此格林函数一旦求出，就可算出任意源的场。

格林函数法以统一的方式处理各类数学物理方程，既可以研究常微分方程，又可以研究偏微分方程；既可以研究齐次方程又可以研究非齐次方程；既可以研究有界问题又可以研究无界问题……它的内容十分丰富，应用极其广泛，故不可能在短短的一章中把这个问题讨论得十分全面。本章将通过用格林函数法解决泊松方程的边值问题（着重以第一边值问题为例）来向读者介绍格林函数法的思想、方法、步骤及格林函数的特点。为此，我们首先需引入一个能够表示点源的密度分布的函数。

## 10. 1  $ \delta $ 函数

## 1.  $ \delta $ 函数的引入

设在 x 轴上有一细长的金属线，则在任一点 x 处该金属线的密度为  $ \rho(x)=\lim_{\Delta x\to0}\frac{\Delta m}{\Delta x} $. 若金属线的总质量为 1，且质量集中在 x=0 处，显然此时

 $$ \begin{cases}\rho(x)=0,&x\neq0\\\rho(x)=\infty,&x=0\\\displaystyle\int_{-\infty}^{\infty}\rho(x)\mathrm{d}x=1\end{cases} $$ 

满足以上关系式的量在物理上不少，如点电荷、点热源等. 我们定义满足以上关系式的函数为  $ \delta $ 函数. 即

$$  \begin{cases}\delta(x)=\begin{cases}0,&x\neq0\\\infty,&x=0\end{cases}\\ \int_{-\infty}^{\infty}\delta(x)\mathrm{d}x=1\end{cases}   \tag*{(10.1.1)}$$

<!-- page: 202 -->

更一般有

$$  \left\{\begin{aligned}&\delta(x-x_{0})=\left\{\begin{aligned}&0,&x\neq x_{0}\\ &\infty,&x=x_{0}\end{aligned}\right.\\ &\int_{-\infty}^{\infty}\delta(x-x_{0})\mathrm{d}x=1\end{aligned}\right.   \tag*{(10.1.2)}$$

由此定义我们不难看出：

（1） $ \delta $ 函数是一点源函数，也是一密度函数。若在 x=a 处有一质量为 m 的质点，则 x 轴上任一点 x 处的质量密度为  $ \rho(x)=m\delta(x-a) $;

（2） $ \delta $ 函数是一归一化的分布函数.

（3） $ \delta $ 函数不是普通意义下的函数，因为它没有普通意义下的随自变量取值不同而不断改变的“函数值”。数学家称之为广义函数。

## 2.  $ \delta $ 函数的性质

∂函数具有一些重要的性质. 下面，仅给出几个常用的（其他性质见本节习题）.

（1）对任何一个连续函数  $ f(x) $ 都有

$$  \int_{-\infty}^{\infty}f(x)\delta(x)\mathrm{d}x=f(0)   \tag*{(10.1.3)}$$

或

$$  \int_{-\infty}^{\infty}f(x)\delta(x-x_{0})\mathrm{d}x=f(x_{0})   \tag*{(10.1.4)}$$

证 因为对于任何  $ \varepsilon>0 $，都有

 $$ 1=\int_{-\infty}^{\infty}\delta(x)\mathrm{d}x=\int_{-\varepsilon}^{\varepsilon}\delta(x)\mathrm{d}x $$ 

因此，由积分中值定理有

 $$ \int_{-\infty}^{\infty}f(x)\delta(x)\mathrm{d}x=\int_{-\varepsilon}^{\varepsilon}f(x)\delta(x)\mathrm{d}x=f(\xi)\int_{-\varepsilon}^{\varepsilon}\delta(x)\mathrm{d}x=f(\xi) $$ 

其中， $ -\varepsilon<\xi<\varepsilon $ 。令  $ \varepsilon\to0 $ ，则  $ \xi\to0 $ ，于是得到(10.1.3)式。利用坐标变换和(10.1.3)式，便可得到(10.1.4)式。

这一性质又称之为  $ \delta $ 函数的“筛选”性质。它表明，虽然  $ \delta $ 函数是一种广义函数，但它和任何连续函数的乘积在  $ (-\infty, \infty) $ 内的积分能将函数在定点的值选出来。都有很明确的意义，这使得  $ \delta $ 函数在近代物理和工程技术中有较广泛的应用。

（2）若记 $ \delta^{\prime}(x-a)=\frac{\mathrm{d}}{\mathrm{d}x}\delta(x-a) $，则对于任意的连续函数 $ f(x) $有

$$  \int_{-\infty}^{\infty}f(x)\delta^{(n)}(x-a)\mathrm{d}x=(-1)^{n}f^{(n)}(a)   \tag*{(10.1.5)}$$

证

 $$ \begin{align*}\int_{-\infty}^{\infty}f(x)\delta^{\prime}(x-a)\mathrm{d}x&=\int_{-\infty}^{\infty}f(x)\mathrm{d}\delta(x-a)\\&=f(x)\delta(x-a)\left|_{-\infty}^{\infty}-\int_{-\infty}^{\infty}f^{\prime}(x)\delta(x-a)\mathrm{d}x\right.\\&=-\left.f^{\prime}(a)\right.\end{align*} $$

<!-- page: 203 -->

即

$$  \int_{-\infty}^{\infty}f(x)\delta^{^{\prime}}(x-a)\mathrm{d}x=-f^{^{\prime}}(a)   \tag*{(10.1.6)}$$

我们称满足(10.1.6)式的 $ \delta^{\prime}(x-a) $为 $ \delta(x-a) $的导数.类似地我们易于推得 $ \delta(x-a) $的任意阶导数所具有的性质(10.1.5)式.

（3）若  $ \delta $ 函数以函数  $ \varphi(x) $ 为宗量，则有

$$  \delta\bigl[\varphi(x)\bigr]=\sum_{i=1}^{k}\frac{\delta(x-x_{i})}{\mid\varphi^{^{\prime}}(x_{i})\mid}   \tag*{(10.1.7)}$$

其中  $ x_{i} $ 为  $ \varphi(x)=0 $ 的单根.

证 因为由  $ \delta $ 函数的定义有

 $$ \delta[\varphi(x)]=\left\{\begin{aligned}&0,&&\varphi(x)\neq0\\ &\infty,&&\varphi(x)=0\end{aligned}\right. $$ 

即

 $$ \delta\big[\varphi(x)\big]=\left\{\begin{aligned}&0,&x\neq x_{i}\\ &\infty,&x=x_{i}\end{aligned}\right. $$ 

现将全部积分区间分成一些间隔，使每一间隔 $ [x_{i}-\varepsilon,x_{i}+\varepsilon] $内只含有 $ \varphi(x)=0 $的一个单根 $ (\varepsilon>0) $，则对于任意的连续函数 $ f(x) $有

 $$ \begin{align*}\int_{-\infty}^{\infty}f(x)\delta\big[\varphi(x)\big]\mathrm{d}x&=\sum_{i=1}^{k}\int_{x_{i}-\epsilon}^{x_{i}+\epsilon}f(x)\delta\big[\varphi(x)\big]\mathrm{d}x\\&=\sum_{i=1}^{k}f(\xi)\int_{x_{i}-\epsilon}^{x_{i}+\epsilon}\delta\big[\varphi(x)\big]\mathrm{d}x\end{align*} $$ 

其中， $ x_{i}-\varepsilon<\xi<x_{i}+\varepsilon $，当 $ \varepsilon\to0 $时 $ \xi_{i}\to x_{i} $，记 $ w=\varphi(x) $，注意到 $ \mathrm{d}\left[\varphi(x)\right]=\varphi'(x)\mathrm{d}x $，即 $ \mathrm{d}x=\frac{1}{\varphi'(x)}\mathrm{d}\left[\varphi(x)\right]=\frac{\mathrm{d}w}{\varphi'(x)} $，且考虑到 $ \varphi'(x_{i})>0 $时 $ \varphi(x_{i}+\varepsilon)>\varphi(x_{i}-\varepsilon) $，和 $ \varphi'(x_{i})<0 $时 $ \varphi(x_{i}+\varepsilon)<\varphi(x_{i}-\varepsilon) $，于是有

而

$$  \begin{align*}\int_{x_{i}-\varepsilon}^{x_{i}+\varepsilon}\delta\big[\varphi(x)\big]\mathrm{d}x&=\frac{1}{\varphi^{^{\prime}}(\xi)}\int_{\varphi(x_{i}-\varepsilon)}^{\varphi(x_{i}+\varepsilon)}\delta(w)\mathrm{d}w=\frac{1}{|\varphi^{^{\prime}}(x_{i})|}\\&\int_{-\infty}^{\infty}f(x)\delta\big[\varphi(x)\big]\mathrm{d}x=\sum_{i=1}^{k}\frac{f(x_{i})}{|\varphi^{^{\prime}}(x_{i})|}\end{align*}   \tag*{（10.1.8）}$$

又

$$  \begin{align*}\int_{-\infty}^{\infty}f(x)\sum_{i=1}^{k}\frac{\delta(x-x_{i})}{\mid\varphi^{^{\prime}}(x_{i})\mid}\mathrm{d}x=&\sum_{i=1}^{k}\int_{x_{i}-\varepsilon}^{x_{i}+\varepsilon}f(x)\frac{\delta(x-x_{i})}{\mid\varphi^{^{\prime}}(x_{i})\mid}\mathrm{d}x\\=&\sum_{i=1}^{k}\frac{f(x_{i})}{\mid\varphi^{^{\prime}}(x_{i})\mid}\end{align*}   \tag*{（10.1.9）}$$

比较(10.1.8)和(10.1.9)的结果即得(10.1.7)式 $ ^{①} $.

## 3. 高维空间中的  $ \delta $ 函数

以三维空间为例，若用  $ \delta(M-M_{0}) $ 表示把单位质量集中于点  $ M_{0}(x_{0},y_{0},z_{0}) $ 的密度函数，则

<!-- page: 204 -->

$$  \left\{\begin{aligned}&\delta(M-M_{0})=\left\{\begin{aligned}&0,&M\neq M_{0}\\ &\infty,&M=M_{0}\end{aligned}\right.\\ &\iiint_{-\infty}^{\infty}\delta(M-M_{0})\mathrm{d}v=1\end{aligned}\right.   \tag*{(10.1.10)}$$

其中

 $$ \delta(M-M_{0})=\delta(x-x_{0},y-y_{0},z-z_{0}) $$ 

又定义

$$  \iiint_{-\infty}^{\infty}f(M)\delta(M-M_{0})\mathrm{d}v=f(M_{0})   \tag*{(10.1.11)}$$

 $ f(M) $为任意的连续函数.则由(10.1.4)式有

 $$ \begin{aligned}&\iiint_{-\infty}^{\infty}f(M)\delta(x-x_{0})\delta(y-y_{0})\delta(z-z_{0})\mathrm{d}v\\=&\iint_{-\infty}^{\infty}\delta(y-y_{0})\delta(z-z_{0})\mathrm{d}y\mathrm{d}z\int_{-\infty}^{\infty}f(x,y,z)\delta(x-x_{0})\mathrm{d}x\\=&\int_{-\infty}^{\infty}\delta(z-z_{0})\mathrm{d}z\int_{-\infty}^{\infty}f(x_{0},y,z)\delta(y-y_{0})\mathrm{d}y\\=&\int_{-\infty}^{\infty}f(x_{0},y_{0},z)\delta(z-z_{0})\mathrm{d}z\\=&f(x_{0},y_{0},z_{0})=f(M_{0})\end{aligned} $$ 

与(10.1.11)式相比较，故有

$$  \delta(x-x_{0},y-y_{0},z-z_{0})=\delta(x-x_{0})\delta(y-y_{0})\delta(z-z_{0})   \tag*{（10.1.12）}$$

这说明三维  $ \delta $ 函数可看作三个一维  $ \delta $ 函数的乘积.

同样可以定义二维或其他维的  $ \delta $ 函数.

注 ① 这里，我们引用了高等数学中判断函数相等的一种方法：

设  $ \varphi(x) $,  $ \psi(x) $ 与  $ g(x) $ 均为定义在  $ [a,b] $ 上的函数，若对于定义在  $ [a,b] $ 上的任意连续函数  $ f(x) $，都有

 $$ \int_{a}^{b}f(x)\varphi(x)\mathrm{d}x=\int_{a}^{b}f(x)\psi(x)\mathrm{d}x $$ 

则必有

 $$ \varphi(x)=\psi(x) $$ 

若有

 $$ \int_{a}^{b}f(x)g(x)\mathrm{d}x=0 $$ 

则必有

 $$ g(x)=0 $$ 

此方法很有用，习题10.1中的很多题都可用它来证.

#### 习题10.1

1. 证明

(1)

 $$ x\delta(x)=0； $$ 

(2)

 $$ \delta(a x)=\frac{1}{|a|}\delta(x)\;; $$

<!-- page: 205 -->

(3)  $ f(x)\delta(x-a)=f(a)\delta(x-a) $;

(4)

 $$ \delta(-x)=\delta(x) $$ 

(5)  $ \delta(x^2 - a^2) = \frac{1}{2|a|} [\delta(x - a) + \delta(x + a)] $; (6)

 $$ \delta(x^{2}){\stackrel{}{=}}\frac{\delta(x)}{|x|}. $$ 

其中a为常数.

## 2. 证明

(1)  $ \delta^{'}(-x) = -\delta^{'}(x) $; (2)  $ x\delta^{'}(x) = -\delta(x) $.

3. 证明  $ \delta(x)=\frac{\mathrm{d}H(x)}{\mathrm{d}x} $

提示:证明 $ \int_{-\infty}^{\infty}f(x)\delta(x)\mathrm{d}x=\int_{-\infty}^{\infty}f(x)\frac{\mathrm{d}H(x)}{\mathrm{d}x}\mathrm{d}x $

4. 求  $ \delta $ 函数的傅氏变换和积分表达式.

5. 试证  $ \delta $ 函数的几种极限形式的表达式

 $$ \delta(x)=\lim_{k\to\infty}\frac{\operatorname{sink}x}{\pi x}; $$ 

 $$ \delta(x)=\lim_{\varepsilon\to0}\frac{1}{\sqrt{\pi\varepsilon}}\mathrm{e}^{-\frac{x^2}{\varepsilon}}; $$ 

 $$ \delta(x)=\lim_{\varepsilon\to0}\frac{\varepsilon}{\pi(x^2+\varepsilon^2)}. $$ 

6. 计算下列积分：

(1)  $ \int_{1}^{2} \tan x \delta(x) dx $;

(2)  $ \iiint_{-\infty}^{\infty}\frac{y}{x^{2}+z}\cos(x+z)\delta(x,y-1,z+2)dxdydz; $

 $$ \int_{-2}^{1}\sin x\delta^{^{\prime}}\left(x+\frac{1}{3}\right)\mathrm{d}x； $$ 

 $$ \int_{-1}^{1}\mathrm{e}^{x}x\delta^{^{\prime}}(x)\mathrm{d}x. $$ 

7. 设在  $ M_{0}(x_{0},y_{0},z_{0}) $ 处有一带电量 q 的点电荷，试写出空间中任意一点处的电势  $ V(x,y,z) $ 所满足的方程.

8. 梳状函数  $ \text{comb}(x) = \sum_{n=-\infty}^{\infty} \delta(x-n) $ 的傅氏变换是傅里叶光学中常要用到的，试证

 $$ F[\operatorname{comb}(x)\operatorname{comb}(y)]=\operatorname{comb}\left(\tfrac{\omega_1}{2\pi}\right)\operatorname{comb}\left(\tfrac{\omega_2}{2\pi}\right) $$ 

9. 计算  $ F^{-1}\left[\pi\delta(\omega)+\frac{1}{\mathrm{i}\omega}\right] $

10. 求解下列微分积分方程：

 $$ \delta(x)-f(x)=\frac{\mathrm{d}^{2}f(x)}{\mathrm{d}x^{2}}(-\infty<x<\infty) $$ 

 $$ \delta(x)-\frac{\mathrm{d}f(x)}{\mathrm{d}x}=\int_{-\infty}^{\infty}f(x)\mathrm{d}x(-\infty<x<\infty) $$ 

11. 试用傅氏变换法重解 7.3 节中例题.

12. 用傅氏变换法求解三维无界空间的受迫振动问题

 $$ \begin{cases}u_{tt}(\boldsymbol{r},t)=a^{2}\Delta u(\boldsymbol{r},t)+f(\boldsymbol{r},t),&-\infty<x,y;z<\infty\\u\mid_{t=0}=\varphi(\boldsymbol{r})\\u_{t}\mid_{t=0}=\psi(\boldsymbol{r})\end{cases} $$ 

### 10.2 边值问题的格林函数法

本节将以泊松方程的边值问题为例来初步了解格林函数法。三维泊松方程的边值问题，可用统一的形式表示为

<!-- page: 206 -->

$$  \triangle u(M)=-h(M),\quad M\in\tau   \tag*{(10.2.1)}$$

$$  \left\{\begin{array}{l}{\left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=g(M)}\end{array}\right.   \tag*{（10.2.2）}$$

其中  $ \alpha,\beta $ 是不同时为零的常数.

这类问题的解，应该说在第八章中我们已讨论过，在这里，我们将换一种方法来求解.

为了得到定解问题(10.2.1)和(10.2.2)式的解的积分表达式，我们首先引入格林公式.

## 1. 格林公式

设函数  $ u(x,y,z) $ 和  $ v(x,y,z) $ 在区域  $ \tau $ 直到边界  $ \sigma $ 上具有连续一阶导数，而在  $ \tau $ 中具有连续的二阶导数，则由高斯公式和微分算子的运算有 $ ^{①} $

$$  \iint_{\sigma}u\mathrm{\boldmath~\nabla~}v\bullet\mathrm{d}\pmb{\sigma}=\iiint_{\tau}\mathrm{\boldmath~\nabla~}\bullet(u\mathrm{\boldmath~\nabla~}v)\mathrm{d}\tau=\iiint_{\tau}u\Delta v\mathrm{d}\tau+\iiint_{\tau}\mathrm{\boldmath~\nabla~}u\bullet\nabla v\mathrm{d}\tau   \tag*{（10.2.3）}$$

此式称为格林第一公式. 同理有

$$  \iint_{\sigma}v\mathrm{\boldmath~\nabla~}u\cdot\mathrm{\boldmath~\mathbf{d}~}\pmb{\sigma}=\iiint_{\tau}v\Delta u\mathrm{d}\tau+\iiint_{\tau}\mathrm{\boldmath~\nabla~}v\cdot\mathrm{\boldmath~\nabla~}u\mathrm{d}\tau   \tag*{(10.2.4)}$$

将此二式相减得

 $$ \iint_{\sigma}\left(u\nabla v-v\nabla u\right)\bullet\mathrm{d}\pmb{\sigma}=\iiint_{\tau}\left(u\Delta v-v\Delta u\right)\mathrm{d}\tau $$ 

即

$$  \iint_{\sigma}\Big(u\frac{\partial v}{\partial n}-\upsilon\frac{\partial u}{\partial n}\Big)\mathrm{d}\sigma=\iiint_{\tau}\left(u\Delta v-v\Delta u\right)\mathrm{d}\tau   \tag*{（10.2.5）}$$

此式称为格林第二公式. 其中 n 为边界面  $ \sigma $ 的外法向.

## 2. 积分公式-格林函数法

现在让我们在有界区域 $ \tau $中讨论定解问题(10.2.1)～(10.2.2)式的解.引入函数 $ G(M,M_{0}) $，使之满足

$$  \Delta G(M,M_{0})=-{}\delta(M-M_{0}),\quad M\in\tau   \tag*{（10.2.6）}$$

其中， $ M_{0}=M_{0}(x_{0},y_{0},z_{0}) $ 为区域  $ \tau $ 中的任意点，则由  $ \delta $ 函数的定义知， $ G(M,M_{0}) $ 为在  $ M_{0} $ 点的点源所产生的场。以函数  $ G(M,M_{0}) $ 乘方程（10.2.1）的两边，同时以函数  $ u(M) $ 乘方程（10.2.6）的两边，然后相减得

 $ G(M,M_{0})\Delta u(M)-u(M)\Delta G(M,M_{0})=u(M)\delta(M-M_{0})-G(M,M_{0})h(M) $

将上式对  $ M(x,y,z) $ 积分，在下节我们将看到，满足方程 (10.2.6) 的解为  $ G(M,M_{0})=\frac{1}{4\pi r} $ [见 (10.3.4) 式]；其中  $ r=\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}+(z-z_{0})^{2}} $ 为 M 和  $ M_{0} $ 之间的距离，也就是说， $ G(M,M_{0}) $ 以  $ M(x,y,z) $ 为自变量时以  $ M_{0}(x_{0},y_{0},z_{0}) $ 为奇点。所以，为了将格林第二公式 (10.2.5) 应用于上式积分后的左端，积分区域应取  $ \tau $ 内挖去以  $ M_{0} $

<!-- page: 207 -->

点为中心、以 $ \varepsilon(\ll1) $为半径的小球体 $ \tau_{\varepsilon} $后的区域 $ \tau-\tau_{\varepsilon} $（见图10.1）. 记小球体的界面为 $ \sigma_{\varepsilon} $，在区域 $ \tau-\tau_{\varepsilon} $上积分上式 $ ^{①} $，利用(10.2.5)式，于是有

 $$ \begin{align*}\iint_{\sigma+\sigma_{\varepsilon}}\Big[G(M,M_{0})\frac{\partial u}{\partial n}-u(M)\frac{\partial}{\partial n}G(M,M_{0})\Big]\mathrm{d}\sigma\\=\iiint_{\tau-\tau_{\varepsilon}}\big[u(M)\delta(M-M_{0})-G(M,M_{0})h(M)\big]\mathrm{d}\tau\end{align*} $$ 

<div style="text-align: center;"><img src="images/p0207_img_in_image_box_667_141_859_295.jpg" alt="图10.1" width="20%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图10.1</div> </div>


注意到  $ M_{0} $ 点不属于区域  $ \tau-\tau_{\varepsilon} $，故由  $ \delta $ 函数定义有

 $$ \iiint_{\tau-\tau_{\varepsilon}}u\left(M\right)\delta(M-M_{0})\mathrm{d}\tau=0 $$ 

而由本篇(7.3.5)、(7.3.4)式可得

 $$ u(M_{0})=\lim_{r\to0}\frac{1}{4\pi r^{2}}\iint_{S_{r}^{M_{0}}}u\mathrm{d}s $$ 

故当  $ \varepsilon \to 0 $ 时有

 $$ \begin{align*}\iint_{\sigma_{\varepsilon}}G(M,M_{0})\frac{\partial u}{\partial n}\mathrm{d}\sigma=&\iint_{\sigma_{\varepsilon}}\frac{1}{4\pi\varepsilon}\frac{\partial u}{\partial n}\mathrm{d}\sigma=\varepsilon\cdot\frac{1}{4\pi\varepsilon^{2}}\iint_{\sigma_{\varepsilon}}u_{n}\mathrm{d}\sigma=\varepsilon u_{n}(M_{0})=0\\\iint_{\sigma_{\varepsilon}}u(M)\frac{\partial}{\partial n}G(M,M_{0})\mathrm{d}\sigma=&-\iint_{\sigma_{\varepsilon}}u\frac{\partial}{\partial r}\Big(\frac{1}{4\pi r}\Big)\mathrm{d}\sigma=\frac{1}{4\pi\varepsilon^{2}}\iint_{\sigma_{\varepsilon}}u\mathrm{d}\sigma=u(M_{0})\end{align*} $$ 

于是，当 $ \varepsilon\to0 $时，由(10.2.7)式得到

$$  u(M_{0})=\iiint_{\tau}G(M,M_{0})h(M)\mathrm{d}\tau+\iint_{\sigma}G(M,M_{0})\frac{\partial u}{\partial n}\mathrm{d}\sigma-\iint_{\sigma}u(M)\frac{\partial}{\partial n}G(M,M_{0})\mathrm{d}\sigma   \tag*{（10.2.8）}$$

上式在物理上很难解释清楚，如，在右边的第一项中， $ G(M,M_{0}) $ 所代表的是  $ M_{0} $ 点的点源在 M 点产生的场，而  $ h(M) $ 所代表的却是 M 点的源。稍后我们将会看到格林函数具有对称性[见(10.2.23)式]

 $$ G(M,M_{0})=G(M_{0},M) $$ 

于是我们可在(10.2.8)式中用 $ G(M_{0},M) $代替 $ G(M,M_{0}) $，并在全式中将M和 $ M_{0} $对换，而得到

$$  u(M)=\iiint_{\tau}G(M,M_{0})h(M_{0})\mathrm{d}\tau_{0}+\iiint_{\sigma}G(M,M_{0})\frac{\partial u}{\partial n_{0}}\mathrm{d}\sigma_{0}-\iiint_{\sigma}u(M_{0})\frac{\partial}{\partial n_{0}}G(M,M_{0})\mathrm{d}\sigma_{0}   \tag*{（10.2.9）}$$

(10.2.9)式被称为基本积分公式. 显然，它的物理意义是十分清楚的，其中右方第一个积分代表在区域  $ \tau $ 中体分布源  $ h\left(M_{0}\right) $ 在 M 点产生的场的总和，而第二、三两个积分则是边界上的源所产生的场. 这两种影响都是由同一格林函数给出的. (10.2.9)给出了泊松方程 (10.2.1) 或拉普拉斯方程 (即当 h=0 时) 解的积分表达式  $ \left(\frac{\partial}{\partial n_{0}}\right) $

<!-- page: 208 -->

表示对  $ M_{0} $ 求导，而  $ \mathrm{d}\sigma_{0} $ 和  $ \mathrm{d}\tau_{0} $ 则分别表示对  $ M_{0} $ 取面积元和体积元），但它还不能直接用来求解泊松方程或拉氏方程的边值问题，因为公式中的  $ G(M,M_{0}) $ 是未知的，且在一般的边值问题中  $ u|_{\sigma} $ 和  $ u_{n}\|_{\sigma} $ 之值也不会同时分别给出。下面针对不同边界条件作具体讨论。

（1）第一类边界条件，即在(10.2.2)中 $ \alpha=0 $，则有

$$  u\mid_{_{\sigma}}=\frac{1}{\beta}g(M)\stackrel{ 记 }{=}f(M)   \tag*{(10.2.10)}$$

若要求  $ G(M,M_{0}) $ 满足第一类齐次边界条件

$$  G(M,M_{0})\mid_{\sigma}=0   \tag*{(10.2.11)}$$

则(10.2.9)式的面积分中，含 $ \frac{\partial u}{\partial n} $的项消失，从而(10.2.9)式变为

$$  u(M)=\iiint_{\tau}G(M,M_{0})h(M_{0})\mathrm{d}\tau_{0}-\iint_{\sigma}f(M_{0})\frac{\partial}{\partial n_{0}}G(M,M_{0})\mathrm{d}\sigma_{0}   \tag*{(10.2.12)}$$

由此可见只要从(10.2.6)式和(10.2.11)式解出 $ G(M,M_{0}) $，则(10.2.12)式已全部由已知量表示。我们称由方程(10.2.6)和边界条件(10.2.11)所构成的定解问题

$$  \left\{\begin{aligned}\Delta G(M,M_{0})=&-\delta(M-M_{0}),&M\in\tau\\ G(M,M_{0})\mid_{\sigma}=0&\end{aligned}\right.   \tag*{(10.2.13)}$$

的解  $ G(M,M_{0}) $，为由方程（10.2.1）和边界条件（10.2.10）所构成的狄氏问题

$$  \left\{\begin{aligned}\triangle u(M)=&-h(M),\quad M\in\tau\\ u\mid_{\sigma}=&f(M)\end{aligned}\right.   \tag*{(10.2.14)}$$

的格林函数，简称为狄氏格林函数；而称(10.2.12)式为狄氏积分公式，它是狄氏问题(10.2.14)的积分形式的解.

（2）第二类边界条件，即在(10.2.2)式中 $ \beta=0 $，则有

 $$ \left.\frac{\partial u}{\partial n}\right|_{\sigma}=\frac{1}{\alpha}g\left(M\right) $$ 

若形式地同样要求 $ G(M,M_{0}) $满足第二类齐次边界条件

$$  \frac{\partial G}{\partial n}\big|_{\sigma}=0   \tag*{(10.2.15)}$$

显然也可以从(10.2.9)式得到

$$  u(M)=\iiint_{\tau}G(M,M_{0})h(M_{0})\mathrm{d}\tau_{0}+\frac{1}{\alpha}\iint_{\sigma}G(M,M_{0})g(M_{0})\mathrm{d}\sigma_{0}   \tag*{(10.2.16)}$$

但(10.2.16)式是不存在的，因为方程(10.2.6)在边界条件(10.2.15)下无解。这从物理上看，其意义十分明显。方程(10.2.6)可看成稳定的热传导方程在 $ M_{0} $点有一个点热源。而边界条件(10.2.15)式表示在边界上是绝热的，由于边界绝热，从点源出来的热量，会使体积 $ \tau $内的温度不断地升高，而不可能达到稳定状态。为了解决这一矛盾，或者修改格林函数所满足的方程(10.2.6)式，使之与边界条件(10.2.15)相容，这就要引入所谓广义格林函数方程；或者修改边界条件(10.2.15)式，使之与方程

<!-- page: 209 -->

(10.2.6)式相容.这已超出本书范围，在此不再详细讨论.

（3）第三类边界条件，即（10.2.2）中 $ \alpha $和 $ \beta $均不为零.若要求 $ G(M,M_{0}) $满足第三类的齐次边界，即

$$  \left[\alpha\frac{\partial}{\partial n}G(M,M_{0})+\beta G(M,M_{0})\right]_{\sigma}=0   \tag*{(10.2.17)}$$

则当以 $ G(M,M_{0}) $乘(10.2.2)式，以 $ u(M) $乘(10.2.17)式，然后再将两式相减得

 $$ \left[G(M,M_{0})\frac{\partial u}{\partial n}-u(M)\frac{\partial}{\partial n}G(M,M_{0})\right]_{\sigma}=\frac{1}{\alpha}G(M,M_{0})g(M) $$ 

代入(10.2.9)式，于是有

$$  u(M)=\iiint_{\tau}G(M,M_{0})h(M_{0})\mathrm{d}\tau_{0}+\frac{1}{\alpha}\iint_{\sigma}G(M,M_{0})g(M_{0})\mathrm{d}\sigma_{0}   \tag*{(10.2.18)}$$

可见，只要从(10.2.6)式和(10.2.17)式解出 $ G(M,M_{0}) $，则(10.2.18)式也已全部由已知量表示。我们称方程(10.2.6)和边界条件(10.2.17)所构成的定解问题

$$  \left\{\begin{aligned}&\Delta G(M,M_{0})=-\delta(M-M_{0}),\quad M\in\tau\\ &\left[\alpha\frac{\partial}{\partial n}G(M,M_{0})+\beta G(M,M_{0})\right]_{\sigma}=0\end{aligned}\right.   \tag*{(10.2.19)}$$

的解  $ G(M,M_{0}) $，为由方程（10.2.1）和边界条件（10.2.2）所构成的定解问题的格林函数，（10.2.18）式即为由（10.2.1）式和（10.2.2）式所构成的定解问题的积分形式的解.

显然，用完全同样的程序，我们可推得亥姆霍兹方程及其他的边值问题

$$  \left\{\begin{array}{l}\Delta u(M)+\lambda u(M)=-h(M),\ M\in\tau\\ \left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=g(M)\end{array}\right.   \tag*{(10.2.21)}$$

的基本积分公式及形式解亦分别是(10.2.9)及(10.2.12)、(10.2.16)、(10.2.18)式.只是对于边值问题(10.2.20)~(10.2.21)， $ \lambda $不能为相应的本征值问题的本征值，否则，格林函数不存在.

由上面的讨论我们看到，在各类非齐次边界条件下解泊松方程(10.2.1)式，可以先在相应的同类齐次边界条件下解格林函数所满足的方程(10.2.6)式，然后通过积分公式得到解 $ u(M) $.

格林函数的定解问题，其方程(10.2.6)式形式上比(10.2.1)式简单，而且边界条件又是齐次的，因此，相对地说，求G比求解u容易一些。不仅如此，对方程(10.2.1)式中不同的非齐次项 $ h(M) $和边界条件(10.2.2)式中不同的 $ g(M) $，只要属于同一类型边界条件，函数 $ G(M,M_{0}) $都是相同的。这就把解泊松方程的边值问题化为在几种类型边界条件下求格林函数 $ G(M,M_{0}) $的问题。

类似于上面的讨论过程，可以得到二维泊松方程的各类边值问题的积分公式。如二维泊松方程的狄氏问题

$$  \left\{\begin{aligned}\triangle u=&-h(M),\quad M\in\sigma\\ u&\mid_{l}=f(M)\end{aligned}\right.   \tag*{(10.2.22)}$$

<!-- page: 210 -->

的积分形式的解，即二维空间的狄氏积分公式为

$$  u(M)=\iint_{\sigma}G(M,M_{0})h(M_{0})\mathrm{d}\sigma_{0}-\int_{l}f(M_{0})\frac{\partial}{\partial n_{0}}G(M,M_{0})\mathrm{d}l_{0}   \tag*{（10.2.23）}$$

其中， $ G(M,M_{0}) $ 为二维泊松方程的狄氏格林函数即定解问题

$$  \left\{\begin{aligned}\Delta G(M,M_{0})=&-\delta(M-M_{0}),&M\in\sigma\\ G(M,M_{0})\mid_{l}&=0\end{aligned}\right.   \tag*{(10.2.24)}$$

的解： $ M=M(x,y) $， $ M_{0}=M_{0}(x_{0},y_{0}) $；l为区域 $ \sigma $的边界线；而 $ \frac{\partial}{\partial n_{0}} $， $ d\mathrm{l}_{0} $， $ d\sigma_{0} $分别表示对 $ M_{0}(x_{0},y_{0}) $求导、取线元和面积元.

## 3. 格林函数关于源点和场点是对称的

前面在导出积分公式时，用到格林函数的对称性

$$  G(M,M_{0})=G(M_{0},M)   \tag*{(10.2.25)}$$

现在对最一般的亥姆霍兹方程，实际上是算符  $ \Delta+\lambda $（泊松方程可看作  $ \lambda=0 $ 的特例），证明上述结论。设  $ G(M,M_{1}) $ 和  $ G(M,M_{2}) $ 均满足亥姆霍兹方程和某类齐次边界条件，即

$$  \Delta G(M,M_{1})+\lambda G(M,M_{1})=-\delta(M-M_{1})   \tag*{(10.2.26)}$$

$$  \left[\alpha\frac{\partial}{\partial n}G(M,M_{1})+\beta G(M,M_{1})\right]_{\sigma}=0   \tag*{（10.2.27）}$$

$$  \Delta G(M,M_{2})+\lambda G(M,M_{2})=-\delta(M-M_{2})   \tag*{(10.2.28)}$$

$$  \left[\alpha\frac{\partial}{\partial n}G(M,M_{2})+\beta G(M,M_{2})\right]_{\sigma}=0   \tag*{(10.2.29)}$$

以  $ G(M,M_{2}) $ 乘方程 (10.2.26)，同时以  $ G(M,M_{1}) $ 乘方程 (10.2.28)，然后相减，并做积分得 $ ^{②} $

 $$ \iiint_{\tau}\left[G(M,M_{2})\Delta G(M,M_{1})-G(M,M_{1})\Delta G(M,M_{2})\right]\mathrm{d}\tau=-G(M_{1},M_{2})+G(M_{2},M_{1}) $$ 

对上式左端应用格林第二公式得

 $$ \begin{align*}&G(M_{2},M_{1})-G(M_{1},M_{2})\\=&\iint_{\sigma}\Big[G(M,M_{2})\frac{\partial}{\partial n}G(M,M_{1})-G(M,M_{1})\frac{\partial}{\partial n}G(M,M_{2})\Big]\mathrm{d}\sigma\end{align*} $$ 

由边界条件(10.2.27)和(10.2.29)，因为 $ \alpha,\beta $不同时为零，所以有

 $$ \left[G(M,M_{2})\frac{\partial}{\partial n}G(M,M_{1})-G(M,M_{1})\frac{\partial}{\partial n}G(M,M_{2})\right]_{\sigma}=0 $$ 

代入上式右边，于是得

 $$ G(M_{2},M_{1})=G(M_{1},M_{2}) $$ 

由于在物理上，格林函数  $ G(M, M_{0}) $ 表示位于  $ M_{0} $ 点的点源，在一定边界条件下在 M 点产生的场，故其对称性说明，在相同边界条件下，位于  $ M_{0} $ 的点源在 M 点产生的场等于同强度的点源位于 M 点在  $ M_{0} $ 点产生的场。这种性质在物理上称为倒易性。

<!-- page: 211 -->

注 ① 见附录 I.

② 如果积分区域直接取  $ \tau $，虽然此时第二格林公式(10.2.5)的条件并不满足，但撇开这些条件之后所得结果其形式与(10.2.9)式相同。所以，以后用格林第二公式时对积分区域就不再作这样的处理了。

#### 习题10.2

1. 设  $ v(x,y) $ 和  $ u(x,y) $ 在区域  $ \sigma $ 直到边界 l 上具有连续一阶导数，而在  $ \sigma $ 内具有连续的二阶导数，

（1）试导出二维空间的格林第二公式

$$  \int_{l}\left(u\frac{\partial v}{\partial n}-v\frac{\partial u}{\partial n}\right)\mathrm{d}l=\iint_{s}\left(u\Delta v-v\Delta u\right)\mathrm{d}\sigma   \tag*{(10.2.30)}$$

（2）利用二维空间的格林第二公式（10.2.30），导出二维空间的狄氏积分公式（10.2.23）式.

2. 试证明亥姆霍兹方程的边值问题

 $$ \left\{\begin{aligned}&\Delta u(M)+\lambda u(M)=-h(M),\quad M\in\tau\\ &\left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=g(M)\end{aligned}\right. $$ 

在第一、二、三类边界条件下的形式解分别为(10.2.12)、(10.2.16)和(10.2.18)式。并证明其相应的本征值问题

 $$ \left\{\begin{aligned}&\Delta u+\lambda u=0\\ &\left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=0\end{aligned}\right. $$ 

中的 $ \lambda $为什么不能为本征值.

### 10.3 稳恒问题的格林函数

从上节的讨论可以看出，求解边值问题实际上归结为求相应的格林函数，只要求出格林函数，将其代入相应的积分公式，就可得到问题的解。

一般说来，实际求格林函数，并非一件容易的事。但在某些情况下，却可以比较容易地求出.

## 1. 无界区域的格林函数

无界区域的格林函数 G，又称为相应方程的基本解。G 满足含有  $ \delta $ 函数的非齐次方程，具有奇异性，一般可以用有限形式表示出来。下面通过具体例子，说明求基本解的方法。

例 1 求三维泊松方程的基本解.

解 其格林函数满足的方程为

$$  \Delta G=-\delta(x-x_{0},y-y_{0},z-z_{0})   \tag*{(10.3.1)}$$

采用球坐标，并将坐标原点放在源点  $ M_{0}(x_{0},y_{0},z_{0}) $ 上（r 是源点  $ M_{0} $ 到场点  $ M(x,y,z) $ 的距离， $ r=\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}+(z-z_{0})^{2}} $）。则由于区域是无界的，点源所产

<!-- page: 212 -->

生的场应与方向无关，而只是 r 的函数，于是(10.3.1)式简化为

 $$ \frac{1}{r^{2}}\frac{\mathrm{d}}{\mathrm{d}r}\Big(r^{2}\frac{\mathrm{d}G}{\mathrm{d}r}\Big)=-\delta(r) $$ 

当 $ r\neq0 $时，方程化为齐次的，即

 $$ \frac{\mathrm{d}}{\mathrm{d}r}\Big(r^{2}\ \frac{\mathrm{d}G}{\mathrm{d}r}\Big)=0 $$ 

易于求得其一般解为

$$  G=-C_{1}\frac{1}{r}+C_{2}   \tag*{(10.3.2)}$$

取 $ C_{2}=0 $，不失一般性，得

$$  G=-C_{1}\frac{1}{r}   \tag*{(10.3.3)}$$

考虑 r=0 的情形. 为此，对方程(10.3.1)式在以原点为球心， $ \varepsilon $ 为半径的小球体  $ \tau_{\varepsilon} $ 内作体积分

 $$ \iiint_{\tau_{\epsilon}}\Delta G\mathrm{d}x\mathrm{d}y\mathrm{d}z=-\iiint_{\tau_{\epsilon}}\delta(x-x_{0},y-y_{0},z-z_{0})\mathrm{d}x\mathrm{d}y\mathrm{d}z=-1 $$ 

从而

 $$ \lim_{\varepsilon\to0}\iiint_{\tau_{\varepsilon}}\Delta G\mathrm{d}x\mathrm{d}y\mathrm{d}z=-1 $$ 

而由散度定理

 $$ \iiint_{v}\nabla\bullet\nabla u\mathrm{d}v=\oint_{s}\nabla u\mathrm{d}s,\quad s 为 v 的边界面 $$ 

有

 $$ \iiint_{\tau_{e}}\Delta G\mathrm{d}x\mathrm{d}y\mathrm{d}z=\iint_{s_{e}}\frac{\partial G}{\partial n}\mathrm{d}x\mathrm{d}y $$ 

故

 $$ \lim_{\varepsilon\to0}\iint_{s_{\varepsilon}}\frac{\partial G}{\partial n}\mathrm{d}x\mathrm{d}y=\lim_{\varepsilon\to0}\iint_{s_{\varepsilon}}\frac{\partial G}{\partial r}\Big|_{r=\varepsilon}\mathrm{d}x\mathrm{d}y=-1 $$ 

将(10.3.3)式的结果代入上式得

 $$ \begin{aligned}\lim_{\varepsilon\rightarrow0}\int_{0}^{2\pi}\int_{0}^{\pi}C_{1}\frac{1}{\varepsilon^{2}}\cdot\varepsilon^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\varphi=&-1\\C_{1}=&-\frac{1}{4\pi}\end{aligned} $$ 

代入 $ （10.3.3} $式，于是

$$  G(M,M_{0})=\frac{1}{4\pi r}   \tag*{(10.3.4)}$$

例2 求二维泊松方程的基本解.

解 格林函数满足的方程为

$$  \Delta G=-\delta(x-x_{0},y-y_{0})   \tag*{（10.3.5）}$$

采用极坐标，并将坐标原点放在源点 $ M_{0}(x_{0},y_{0}) $上，则 $ r=\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}} $与三维问题一样，G应只是r的函数，于是(10.3.5)式简化为

<!-- page: 213 -->

$$  \frac{1}{r}\frac{\mathrm{d}}{\mathrm{d}r}\Big(r\frac{\mathrm{d}G}{\mathrm{d}r}\Big)=-\delta(r)   \tag*{(10.3.6)}$$

当 $ r\neq0 $时，解(10.3.6)式得

 $$ G=C_{1}ln r $$ 

当 r=0 时，在以原点为中心， $ \varepsilon $ 为半径的小圆内对方程（10.3.5）式两边作面积分，类似于对三维情况的讨论得

 $$ C_{1}=-\frac{1}{2\pi} $$ 

于是

$$  G=\frac{1}{2\pi}\ln\frac{1}{r}   \tag*{(10.3.7)}$$

当然，我们也可用傅氏变换法来求无界区域的格林函数（参见上章）.

## 2. 边值问题的格林函数

本征函数族展开法是求边值问题的格林函数的一个重要而又普遍的方法. 现以狄氏问题

$$  \left\{\begin{aligned}\Delta G(M,M_{0})+\lambda G(M,M_{0})=&-\delta(M-M_{0}),&M\in\tau\\ G\mid_{\sigma}=0&\end{aligned}\right.   \tag*{（10.3.8）}$$

为例来讨论此法. 写下相应的本征值问题

$$  \left\{\begin{aligned}\Delta\psi(M)+\lambda\psi(M)&=0,\quad M\in\tau\\ \psi\mid_{\sigma}&=0\end{aligned}\right.   \tag*{(10.3.9)}$$

设本征值问题（10.3.9）的全部本征值和相应的归一化本征函数分别是 $ \{\lambda_{n}\} $ 和  $ \{\psi_{n}(M)\}^{①} $，即

$$  \Delta\psi_{n}(M)+\lambda_{n}\psi_{n}(M)=0,\quad M\in\tau   \tag*{(10.3.10)}$$

$$  \psi_{n}\mid_{\sigma}=0   \tag*{(10.3.11)}$$

而且

$$  \iiint_{\tau}\phi_{n}(M)\bar{\psi}_{m}(M)\mathrm{d}\tau=\delta_{n m}   \tag*{(10.3.12)}$$

这里  $ \bar{\psi}_{m}(M) $ 表示  $ \phi_{m}(M) $ 的共轭复变函数. 将函数  $ G(M,M_{0}) $ 在区域  $ \tau $ 上展开为本征函数族  $ \{\phi_{n}(M)\} $ 的广义傅里叶级数

$$  G(M,M_{0})=\sum_{n}C_{n}\psi_{n}(M)   \tag*{(10.3.13)}$$

为定出系数  $ C_{n} $，将（10.3.13）式代入定解问题（10.3.8）的方程中，并利用方程（10.3.10）得

 $$ \lambda\sum_{n}C_{n}\psi_{n}(M)-\sum_{n}\lambda_{n}C_{n}\psi_{n}(M)=-\delta(M-M_{0}) $$ 

设  $ \lambda \neq \lambda_{n} $，以  $ \bar{\psi}_{m}(M) $ 乘上式两端，然后在区域  $ \tau $ 上积分，并利用(10.3.12)式可得

 $$ C_{m}=\frac{1}{\lambda_{m}-\lambda}\bar{\psi}_{m}(M_{0}) $$

<!-- page: 214 -->

代入10.3.13式即得

$$  G(M,M_{0})=\sum_{n}\frac{1}{\lambda_{n}-\lambda}\bar{\psi}_{n}(M_{0})\psi_{n}(M)   \tag*{(10.3.14)}$$

显然，它满足齐次边界条件  $ G|_{\sigma}=0 $.

如果格林函数  $ G(M,M_{0}) $ 的齐次边界条件是第二类的或第三类的，这时可以类似地求得 G，只要本征函数也满足相应的齐次边界条件即可.

例3 求泊松方程在矩形区域0<x<a,0<y<b内的狄氏问题的格林函数.

解 其格林函数的定解问题为

$$  \Delta G(M,M_{0})=-\delta(x-x_{0})\delta(y-y_{0})   \tag*{（10.3.15）}$$

$$  G\mid_{x=0}=G\mid_{x=a}=G\mid_{y=0}=G\mid_{y=b}=0   \tag*{(10.3.16)}$$

它是定解问题

$$  \int\Delta G(M,M_{0})+\lambda G(M,M_{0})=-\delta(x-x_{0})\delta(y-y_{0})   \tag*{（10.3.17）}$$

$$  G\mid_{x=0}=G\mid_{x=a}=G\mid_{y=0}=G\mid_{y=b}=0   \tag*{（10.3.18）}$$

当 $ \lambda=0 $的特例.而与定解问题(10.3.17)～(10.3.18)式相应的本征值问题为

 $$ \left\{\begin{aligned}\Delta\psi(x,y)+\lambda\psi(x,y)&=0\\ \psi\mid_{x=0}=\psi\mid_{x=a}=\psi\mid_{y=0}&=\psi\mid_{y=b}=0\end{aligned}\right. $$ 

它的本征值和归一化的本征函数分别是

 $$ \lambda_{mn}=\pi^{2}\left(\frac{m^{2}}{a^{2}}+\frac{n^{2}}{b^{2}}\right)=\mu_{m}^{2}+\mu_{n}^{2},\qquad m,n=1,2,\cdots $$ 

 $$ \phi_{mn}(x,y)=\frac{2}{\sqrt{ab}}\sin\mu_{m}x\sin\mu_{n}y $$ 

其中

 $$ \mu_{m}=\frac{m\pi}{a},\qquad\mu_{n}=\frac{n\pi}{b} $$ 

在 $  (10.3.15)  $式中  $ \lambda = 0 \neq \lambda_{mn} $，故根据（10.3.14）式有

 $$ G(M,M_{0})=\sum_{m,n=1}^{\infty}\frac{4}{ab}\frac{\sin\mu_{m}x_{0}\sin\mu_{n}y_{0}\sin\mu_{m}x\sin\mu_{n}y}{\mu_{m}^{2}+\mu_{n}^{2}} $$ 

注 ① 这里所说的归一化本征函数，即是指满足(10.3.12)式的本征函数  $ \psi_{n}(M) $. 其中

$$  \delta_{nm}=\left\{\begin{aligned}&1,& 当 n=m\\ &0,& 当 n\neq m\end{aligned}\right.   \tag*{(10.3.19)}$$

称为克罗内克尔(Kronecker) $ \delta $符号. 关于归一化本征函数的一般性讨论见第三篇施图姆-刘维尔本征值问题.

#### 习题10.3

1. 试用傅氏变换法求三维泊松方程的狄氏格林函数.

2. 求解格林函数的定解问题

 $$ \left\{\begin{array}{l}\frac{\mathrm{d}^{2}G}{\mathrm{d}x^{2}}=-\delta(x-x_{0}),\quad0<x,x_{0}<l\\ G\mid_{x=0}=0,\quad G\mid_{x=l}=0\end{array}\right. $$

<!-- page: 215 -->

3. 求一维亥姆霍兹方程的格林函数，即求解定解问题

 $$ \frac{\mathrm{d}^{2}G}{\mathrm{d}x^{2}}+k^{2}G=-\delta(x-x_{0}) $$ 

#####  $ ^{*} $4. 考虑非均匀方程

 $$ u^{\prime \prime}(x)+4u(x)=f(x) $$ 

（1）求这个方程的格林函数  $ G(x,x^{\prime}) $，具有边界条件

 $$ u(0)=u^{^{\prime}}(1)=0 $$ 

（2）考虑边界条件

 $$ u(0)=a,\quad u^{^{\prime}}(1)=b $$ 

求  $ u(x) $ 的解. 将它表示成包含着(1)中所求得的  $ G(x,x^{\prime}) $ 的一个积分.

 $ ^{*} $5.（1）求解方程

 $$ y^{\prime \prime}+k^{2}y=\delta(x-x_{1}),\quad a\leqslant x\leqslant b,a<x_{1}<b $$ 

其边界条件为  $ y(a)=0, y(b)=0 $;

（2）利用(1)的解求出在同样边界条件下方程  $ y''+k^{2}y=f(x) $ 的解.

（4、5题为加州理工学院研究生试题）

### 10.4 电像法与狄氏格林函数

## 1. 泊松方程的狄氏格林函数及其物理意义

为了求三维泊松方程的狄氏格林函数，即求解定解问题

$$  \int\Delta G=-\delta(x-x_{0},y-y_{0},z-z_{0}),\quad M\in\tau   \tag*{(10.4.1)}$$

$$  \left\lfloor G\mid_{\sigma}=0\right.   \tag*{（10.4.2）}$$

可令

$$  G(M,M_{0})=F(M,M_{0})+g(M,M_{0})   \tag*{（10.4.3）}$$

使

$$  \Delta F=-\delta(x-x_{0},y-y_{0},z-z_{0})   \tag*{（10.4.4）}$$

则 g 应满足

$$  \left\{\begin{aligned}\Delta g&=0,\quad M\in\tau\\ g\mid_{\sigma}&=-F\mid_{\sigma}\end{aligned}\right.   \tag*{（10.4.5）}$$

而非齐次方程(10.4.4)的解，已由(10.3.4)式给出，即

 $$ F=\frac{1}{4\pi r} $$ 

其中

 $$ r=\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}+(z-z_{0})^{2}} $$ 

为源点  $ M_{0}(x_{0},y_{0},z_{0}) $ 与  $ M(x,y,z) $ 点之间的距离， $ \sigma $ 为区域  $ \tau $ 的边界面. 所以三维泊松方程的狄氏格林函数为

$$  G=\frac{1}{4\pi r}+g   \tag*{(10.4.6)}$$

其中

<!-- page: 216 -->

$$  \left\{\begin{aligned}\Delta g&=0,\quad M\in\tau\\ g\mid_{\sigma}&=-\frac{1}{4\pi r}\bigg|_{\sigma}\end{aligned}\right.   \tag*{(10.4.7)}$$

类似地，我们可以写出满足定解问题

$$  \left\{\begin{aligned}\Delta G=&-\delta(x-x_{0},y-y_{0}),&M\in\sigma\\ G&\mid_{l}=0\end{aligned}\right.   \tag*{(10.4.8)}$$

的二维泊松方程的狄氏格林函数

$$  G=\frac{1}{2\pi}\ln\frac{1}{r}+g   \tag*{(10.4.9)}$$

其中

$$  \left\{\begin{aligned}\Delta g=0,\quad M\in\sigma\\ g\mid_{l}=-\frac{1}{2\pi}\ln\frac{1}{r}\bigg|_{l}\end{aligned}\right.   \tag*{（10.4.10）}$$

而

 $$ r=\sqrt{(x-x_{0})^{2}+(y-y_{0})^{2}} $$ 

为源点  $ M_{0}(x_{0},y_{0}) $ 与  $ M(x,y) $ 点之间的距离，l 为区域  $ \sigma $ 的边界线.

由此可见，求泊松方程的狄氏格林函数 G 的问题，已转化为了求 g 的齐次方程（即拉普拉斯方程）的狄氏问题。

不难看出狄氏格林函数 G 所具有的物理意义.

如图 10.2 所示，设  $ \sigma $ 为空间接地的导电壳，在其中  $ M_{0}(x_{0},y_{0},z_{0}) $ 点放有正点电荷  $ \varepsilon_{0} $，则由静电学知，满足 (10.4.6) 式和定解问题 (10.4.7) 的 G 正好是  $ \sigma $ 内除  $ M_{0} $ 点以外的任意一点  $ M(x,y,z) $ 处的电势。它由两部分组成：一部分是处在  $ M_{0} $ 点的正点电荷  $ \varepsilon_{0} $ 在 M 点所产生的电势  $ \frac{1}{4\pi r} $；另一部分是边界面  $ \sigma $ 上感应的



<div style="text-align: center;"><img src="images/p0216_img_in_image_box_97_673_353_861.jpg" alt="图10.2" width="26%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图10.2</div> </div>


负电荷在 M 点所产生的电势 g. 所以求 G 的问题，也就转化为了求感应电荷所产生的电势 g 的问题. 正因为 G 具有这样的物理意义，所以对于一些边界形状简单的泊松方程的狄氏格林函数 G，可用电像法来求.

## 2. 用电像法求格林函数

下面我们将通过具体的例子，来了解如何用电像法求狄氏格林函数。

例 1 求解球的狄氏问题

$$  \left\{\begin{array}{l}\Delta u=0,\quad\rho<a\\ u\mid_{\rho=a}=f(M)\end{array}\right.   \tag*{(10.4.11)}$$

解 此时方程的非齐次项 h(M)=0，故由积分公式 (10.2.12) 式得定解问题 (10.4.11) 的解为

<!-- page: 217 -->

$$  u(M)=-\iint_{\sigma}f(M_{0})\frac{\partial}{\partial n_{0}}G(M,M_{0})\mathrm{d}\sigma_{0}   \tag*{(10.4.12)}$$

其中  $ \sigma $ 为球面  $ \rho = a $，G 为球的狄氏格林函数，它满足定解问题

$$  \left\{\begin{aligned}\Delta G=&-\delta(x-x_{0},y-y_{0},z-z_{0}),&\rho<a\\ G\mid_{\rho=a}=0&\end{aligned}\right.   \tag*{(10.4.13)}$$

故求 u 的问题就转化为了求边界为球面的三维泊松方程的狄氏格林函数 G 的问题。而由上面所述的 G 的物理意义知，求 G 即要求在  $ M_{0} $ 点置有正电荷  $ \varepsilon_{0} $ 的接地导体球内任意一点 M 处的电势，亦即要求感应电荷所产生的电势 g，它满足

$$  \left\{\begin{aligned}\Delta g&=0,\quad\rho<a\\ g&\mid_{\rho=a}=-\frac{1}{4\pi r}\Big\vert_{\rho=a}\end{aligned}\right.   \tag*{(10.4.14)}$$

由物理学知识知，倘若我们在  $ M_{0} $ 点关于球面的对称点（又称像点） $ ^{①} $ 处放置一负点电荷 -q，则由于 -q 在球外，它对球内电势的贡献必然满足拉氏方程。因此，只要适当选择 q 的大小，使之对边界面上电势的贡献与  $ M_{0} $ 点的正电荷  $ \varepsilon_{0} $ 对边界面上电势的贡献等值，则 -q 对球内任一点电势的贡献即与 g 等效。为此，如图 10.3 所示，我们延长  $ OM_{0} $ 到  $ M_{1} $，并记  $ \overrightarrow{OM} = \rho_{0} \overrightarrow{OM_{0}} = \rho_{0} $， $ \overrightarrow{OM_{1}} = \rho_{1} $， $ \overrightarrow{MM_{1}} = r_{1} $， $ \overrightarrow{MM_{0}} = r $，使  $ \rho_{0} \cdot \rho_{1} = a^{2} $，即

 $$ \frac{\rho_{0}}{a}=\frac{a}{\rho_{1}} $$ 

则  $ M_{1} $ 为  $ M_{0} $ 关于球面  $ \rho = a $ 的像点。显然，当 M 点在球面  $ \rho = a $ 上时（如图 10.4 所示）， $ \triangle O M_{0} M \sim \triangle O M M_{1} $，故有

$$  \frac{r}{r_{1}}=\frac{\rho_{0}}{a}=\frac{a}{\rho_{1}}   \tag*{(10.4.15)}$$

<div style="text-align: center;"><img src="images/p0217_img_in_image_box_131_785_424_1080.jpg" alt="图10.3" width="30%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图10.3</div> </div>


<div style="text-align: center;"><img src="images/p0217_img_in_image_box_502_785_827_1081.jpg" alt="图10.4" width="33%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图10.4</div> </div>


从而有

 $$ \begin{aligned}\frac{1}{r}&=\frac{a/\rho_{0}}{r_{1}}\\-\frac{1}{4\pi r}\Big|_{\rho=a}&=-\frac{a/\rho_{0}}{4\pi r_{1}}\Big|_{\rho=a}\end{aligned} $$ 

即

<!-- page: 218 -->

由(10.4.16)式可以看出，只要我们在 $ M_{1} $点放置一负电荷 $ -\varepsilon_{0}a/\rho_{0} $，则它在球内直到球上任意一点 $ M(x,y,z) $处（除 $ M_{0} $外）所产生的电势 $ -\frac{a/\rho_{0}}{4\pi r_{1}} $，对于球内的任意一点M，均满足拉氏方程

 $$ \Delta\bigl(\frac{a/\rho_{0}}{-4\pi r_{1}}\bigr)=0 $$ 

且在边界面上亦满足(10.4.14)式的边界条件.所以

 $$ g=\frac{a/\rho_{0}}{-4\pi r_{1}} $$ 

我们称这个设想的负点电荷  $ -\varepsilon_{0}a/\rho_{0} $ 为球内  $ M_{0} $ 点所放置的正点电荷  $ \varepsilon_{0} $ 的电像；而称这种在像点放置一虚构的点电荷来等效地代替导体面或介面上的感应电荷的方法为电像法.

将求得的 g 代入(10.4.6)式便得球的狄氏格林函数为

$$  G=\frac{1}{4\pi r}-\frac{a/\rho_{0}}{4\pi r_{1}}   \tag*{(10.4.17)}$$

为了计算积分(10.4.12)式，引入球坐标变量.设

 $$ M_{0}=M_{0}(\rho_{0},\varphi_{0},\theta_{0}),\quad M=M(\rho,\varphi,\theta) $$ 

则

$$  r=\sqrt{\rho^{2}+\rho_{0}^{2}-2\rho\rho_{0}\cos\gamma}   \tag*{(10.4.18)}$$

$$  r_{1}=\sqrt{\rho^{2}+\rho_{1}^{2}-2\rho_{1}\rho\cos\gamma}=\sqrt{\rho^{2}+\left(\frac{a^{2}}{\rho_{0}}\right)^{2}}-2\frac{a^{2}}{\rho_{0}}\rho\cos\gamma   \tag*{(10.4.19)}$$

其中  $ \gamma $ 为矢量  $ OM_{0} $ 和 OM 的夹角（见图 10.3），所以

 $$ \cos\gamma=\cos\theta_{0}\cos\theta+\sin\theta_{0}\sin\theta\cos(\varphi-\varphi_{0})^{\textcircled{2}} $$ 

将(10.4.18)式和(10.4.19)式代入(10.4.17)式并对 $ M_{0}(\rho_{0},\varphi_{0},\theta_{0}) $ 求导，则得

 $$ \frac{\partial G}{\partial n_{0}}\Big|_{\sigma}=\frac{\partial G}{\partial\rho_{0}}\Big|_{\rho_{0}=a}=\frac{1}{4\pi a}\frac{\rho^{2}-a^{2}}{(\rho^{2}+a^{2}-2\rho a\cos\gamma)^{3/2}} $$ 

代入(10.4.12)式，于是得球的狄氏问题(10.4.11)的解为

$$  u(\rho,\theta,\varphi)=\frac{a}{4\pi}\int_{0}^{2\pi}\int_{0}^{\pi}f(\theta_{0},\varphi_{0})\frac{a^{2}-\rho^{2}}{(a^{2}+\rho^{2}-2a\rho\cos\gamma)^{3/2}}\sin\theta_{0}\mathrm{d}\theta_{0}\mathrm{d}\varphi_{0}   \tag*{(10.4.20)}$$

称做球的泊松积分公式.

类似地，用电像法我们可求得定解问题

$$  \left\{\begin{aligned}\Delta G=&-\delta(x-x_{0},y-y_{0}),&\rho<a\\ G\mid_{\rho=a}=0&\end{aligned}\right.   \tag*{(10.4.21)}$$

的解即圆的狄氏格林函数为

$$  G=\frac{1}{2\pi}\ln\frac{\rho_{0}r_{1}}{ar}   \tag*{（10.4.22）}$$

从而可得圆的狄氏问题

<!-- page: 219 -->

$$  \left\{\begin{aligned}&\Delta u=0,\quad\rho=\sqrt{x^{2}+y^{2}}<a\\ &u\mid_{\rho=a}=f(\varphi)\end{aligned}\right.   \tag*{(10.4.23)}$$

的积分形式的解为

$$  u(\rho,\varphi)=\frac{1}{2\pi}\int_{0}^{2\pi}f(\varphi_{0})\frac{a^{2}-\rho^{2}}{a^{2}+\rho^{2}-2a\rho\cos(\varphi-\varphi_{0})}\mathrm{d}\varphi_{0}   \tag*{(10.4.24)}$$

称做圆的泊松积分公式.

容易看出，由于球内、外法向导数只差一个符号，故积分

$$  u_{1}(\rho,\theta,\varphi)=\frac{a}{4\pi}\int_{0}^{2\pi}\int_{0}^{\pi}f(\theta_{0},\varphi_{0})\frac{\rho^{2}-a^{2}}{(a^{2}+\rho^{2}-2a\rho\cos\gamma)^{3/2}}\sin\theta_{0}\mathrm{d}\theta_{0}\mathrm{d}\varphi_{0}   \tag*{（10.4.25）}$$

恰好给出球的狄氏问题在球外的解，只不过这里 $ \rho>a $罢了，称做球外问题的泊松积分公式.同样，积分

$$  u_{1}(\rho,\varphi)=\frac{1}{2\pi}\int_{0}^{2\pi}f(\varphi_{0})\frac{\rho^{2}-a^{2}}{a^{2}+\rho^{2}-2a\rho\cos(\varphi-\varphi_{0})}\mathrm{d}\varphi_{0}   \tag*{(10.4.26)}$$

给出平面上拉氏方程关于圆外问题的解. 其中  $ \rho>a $. 称做圆外问题的泊松积分公式.

例2 求上半空间的狄氏格林函数.

解 其定解问题为

$$  \left\{\begin{aligned}\Delta G=&-\delta(x-x_{0},y-y_{0},z-z_{0}),&z>0\\ G&\mid_{z=0}=0\end{aligned}\right.   \tag*{(10.4.27)}$$

由（10.4.6）式和（10.4.7）式有

$$  G=\frac{1}{4\pi r}+g   \tag*{（10.4.28）}$$

其中

$$  \left\{\begin{aligned}\Delta g&=0,\quad z>0\\ g&\mid_{z=0}=-\frac{1}{4\pi r}\Big|_{z=0}\end{aligned}\right.   \tag*{（10.4.29）}$$

为了求 g，由电像法知，可在  $ M_{0}(x_{0},y_{0},z_{0}) $ 关于边界面 z=0 的像点  $ M_{1}(x_{0},y_{0},-z_{0}) $ 处放置一负电荷 -q，使得它在上半空间中任意一点  $ M(x,y,z) $ 处所产生的电势  $ \frac{-q}{4\pi\varepsilon_{0}r_{1}} $，与  $ M_{0} $ 点的正点电荷  $ \varepsilon_{0} $ 在边界面 z=0 上的感应电荷所产生的电势 g 等效. 为此，只需

 $$ \left.\begin{array}{l}\frac{-q}{4\pi\varepsilon_{0}r_{1}}\Big|_{z=0}=\frac{-1}{4\pi r}\Big|_{z=0}\\ \end{array}\right\} $$ 

则

对比(10.4.29)式和(10.4.30)式知

 $$ g=\frac{-q}{4\pi\varepsilon_{0}r_{1}} $$

<!-- page: 220 -->

注意到在边界面 z=0 上  $ r_{1}=r $，故由定解问题(10.4.30)中的第一个式子有

 $$ \begin{array}{r}{-q=-\varepsilon_{0}}\end{array} $$ 

于是

 $$ g=-\frac{1}{4\pi r_{1}} $$ 

代入(10.4.28)式，得上半空间的狄氏格林函数为

$$  G=\frac{1}{4\pi r}-\frac{1}{4\pi r_{1}},\quad z>0   \tag*{(10.4.31)}$$

类似地，我们可以得到定解问题

$$  \left\{\begin{aligned}\Delta G=&-\delta(x-x_{0},y-y_{0}),&y>0\\ G&\mid_{y=0}=0\end{aligned}\right.   \tag*{(10.4.32)}$$

的解，即上半平面的狄氏格林函数为

$$  G=\frac{1}{2\pi}\ln\frac{r_{1}}{r}   \tag*{（10.4.33）}$$

注 ① 所谓像点即反演点或对称点.

<div style="text-align: center;"><img src="images/p0220_img_in_image_box_744_528_809_593.jpg" alt="Image" width="6%" /></div>


②  $ \cos\nu $ 表达式的证明见二维码.

 $ \cos\nu $表达式的证明

#### 习题10.4

1. 用电像法求圆的狄氏格林函数.

2. 用电像法求上半平面的狄氏格林函数.

3. 求解圆的狄氏问题(10.4.23). 即用电像法导出泊松积分公式(10.4.24). 你能用柯西公式导出此泊松积分公式吗?

提示：令  $ f(z)=f(\rho\mathrm{e}^{\mathrm{i}\varphi})=u(\rho,\varphi)+\mathrm{i}v(\rho,\varphi) $，且设  $ f(z) $ 在  $ \rho<a $ 中解析.

4. 用格林函数法求解上半平面的狄氏问题

 $$ \left\{\begin{aligned}\Delta_{2}u&=0,\quad y>0\\ u&\mid_{y=0}=f(x)\end{aligned}\right. $$ 

并试用柯西公式将此定解问题再求解一遍.

5. 求解上半空间的狄氏问题

 $$ \left\{\begin{aligned}\Delta u&=0,&z&>0\\ u&\mid_{z=0}&=f(x,y)\end{aligned}\right. $$ 

（芝加哥大学研究生试题）

6. 求解四分之一平面的狄氏问题

 $$ \begin{cases}u_{xx}+u_{yy}=0,&0\leqslant x<\infty,0\leqslant y<\infty\\u(0,y)=f(y),&0\leqslant y<\infty\\u(x,0)=0,&0\leqslant x<\infty\end{cases} $$ 

7. 求解圆的狄氏问题

 $$ \left\{\begin{aligned}u_{xx}+u_{yy}=&-xy,\quad\rho<a\\ u\mid_{\rho=a}=&0\end{aligned}\right. $$

<!-- page: 221 -->

8. 求解球的狄氏问题

 $$ \left\{\begin{aligned}\Delta u&=0,\quad\rho<1\\ u&\mid_{\rho=1}=3\cos2\theta+1\end{aligned}\right. $$ 

9.（1）求关于上半圆域的格林函数；

（2）求关于上半球域的格林函数（见图10.5）.

10. 用电像法证明：由一半径为 R 的导电球在均匀电场  $ E_{0} $ 内产生的电势为

 $$ V=-E_{0}\left(r-\frac{R^{3}}{r^{2}}\right)\cos\theta $$ 

<div style="text-align: center;"><img src="images/p0221_img_in_image_box_540_144_858_389.jpg" alt="图10.5" width="33%" /></div>


其中 r,  $ \theta $ 是以原点为中心的球坐标变量.

<div style="text-align: center;"><div style="text-align: center;">图10.5</div> </div>


###  $ ^{*}10.5 $ 含时问题的格林函数法

对于含时方程（扩散方程和波动方程）及其定解问题，我们当然也能用格林函数法求解。特别是对于非齐次方程及非齐次边界条件的定解问题，我们将会看到，一旦导出了这类问题的积分公式，其求解过程比直接用分离变量法要简单得多。下面我们将推出（或给出）几个常用的含时积分公式。

## 1. 一维扩散方程的混合问题

（1）对于一维的扩散问题

$$  u_{t}-a^{2}u_{x x}=0,\quad0<x<l,t>0   \tag*{(10.5.1)}$$

$$  u\mid_{x=0}=u\mid_{x=l}=0   \tag*{（10.5.2）}$$

$$  u_{t=0}=\varphi(x)   \tag*{（10.5.3）}$$

我们可以推得其积分公式为

$$  u(x,t)=\int_{0}^{l}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}   \tag*{(10.5.4)}$$

其中，格林函数  $ G(x,t|x_{0},0) $ 满足如下定解问题：

$$  G_{t}-a^{2}G_{x x}=0   \tag*{（10.5.5）}$$

$$  G(x,t\mid x_{0},0)\mid_{x=0}=G(x,t\mid x_{0},0)\mid_{x=l}=0   \tag*{（10.5.6）}$$

$$  G(x,t\mid x_{0},0)\mid_{t=0}=\delta(x-x_{0})   \tag*{（10.5.7）}$$

证 将(10.5.4)式代入方程(10.5.1)，并记算符  $ a^{2}\frac{\partial^{2}}{\partial x^{2}}=L $ 得

 $$ \frac{\partial}{\partial t}\int_{0}^{l}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}-L\int_{0}^{l}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}=0 $$ 

注意到 L 只对变量 x 起作用，于是上式可写为

$$  \int_{0}^{l}(G_{t}-LG)\varphi(x_{0})\mathrm{d}x_{0}=0   \tag*{（10.5.8）}$$

又将(10.5.4)式分别代入边界条件(10.5.2)式和初始条件(10.5.3)式，得到

$$  \int_{0}^{l}G(x,t\mid x_{0},0)\mid_{x=0}\varphi(x_{0})\mathrm{d}x_{0}=\int_{0}^{l}G(x,t\mid x_{0},0)\mid_{x=l}\varphi(x_{0})\mathrm{d}x_{0}=0   \tag*{(10.5.9)}$$

<!-- page: 222 -->

$$  \int_{0}^{l}G(x,t\mid x_{0},0)\mid_{t=0}\varphi(x_{0})\mathrm{d}x_{0}=\varphi(x)=\int_{0}^{l}\delta(x-x_{0})\varphi(x_{0})\mathrm{d}x_{0}   \tag*{(10.5.10)}$$

由于  $ \varphi(x_{0}) $ 是任意函数，于是，由（10.5.8）、（10.5.9）和（10.5.10）式分别可得到（10.5.5）、（10.5.6）及（10.5.7）式。即结论证毕。

格林函数的定解问题(10.5.5)~(10.5.7)式的解，易于由分离变量法求得[见习题8.1,1(2)]：

$$  G(x,t\mid x_{0},0)=\frac{2}{l}\sum_{n=1}^{\infty}\sin\frac{n\pi}{l}x\sin\frac{n\pi}{l}x_{0}\exp\left[-\left(\frac{n\pi a}{l}\right)^{2}t\right]   \tag*{(10.5.11)}$$

代入积分公式 $  (10.5.4)  $，于是得到定解问题 $  (10.5.1) \sim (10.5.3)  $式的解为

$$  u(x,t)=\frac{2}{l}\int_{0}^{l}\left[\sum_{n=1}^{\infty}\sin\frac{n\pi x}{l}\sin\frac{n\pi x_{0}}{l}\exp-\left(\frac{n\pi a}{l}\right)^{2}t\right]\varphi(x_{0})\mathrm{d}x_{0}   \tag*{（10.5.12）}$$

（2）对于一维的扩散问题

$$  u_{t}-a^{2}u_{x x}=f(x,t),\quad0<x<l,t>0   \tag*{（10.5.13）}$$

$$  u\mid_{x=0}=u\mid_{x=l}=0   \tag*{（10.5.14）}$$

$$  u\mid_{t=0}=0   \tag*{（10.5.15）}$$

我们可推得其解的积分公式为

$$  u(x,t)=\int_{0}^{t}\mathrm{d}t_{0}\int_{0}^{l}G(x,t\mid x_{0},t_{0})f(x_{0},t_{0})\mathrm{d}x_{0}   \tag*{（10.5.16）}$$

其中，格林函数  $ G(x,t|x_{0},t_{0}) $ 满足的定解问题为

$$  G_{t}-a^{2}G_{x x}=0   \tag*{（10.5.17）}$$

$$  G(x,t\mid x_{0},t_{0})\mid_{x=0}=G(x,t\mid x_{0},t_{0})\mid_{x=l}=0   \tag*{（10.5.18）}$$

$$  G(x,t\mid x_{0},t_{0})\mid_{t=t_{0}}=\delta(x-x_{0})   \tag*{（10.5.19）}$$

证 由冲量原理（见7.2节）可知，欲求解定解问题（10.5.13）～（10.5.15）式，即要求解定解问题

$$  v_{t}-a^{2}v_{x x}=0,\quad0<x<l,t>0   \tag*{（10.5.20）}$$

$$  v\mid_{x=0}=0,\quad v\mid_{x=l}=0   \tag*{(10.5.21)}$$

$$  v\mid_{t=t_{0}}=f(x,t_{0})   \tag*{（10.5.22）}$$

而

$$  u(x,t)=\int_{0}^{t}v(x,t\mid t_{0})\mathrm{d}t_{0}   \tag*{（10.5.23）}$$

将定解问题(10.5.20)~(10.5.22)式与定解问题(10.5.1)~(10.5.3)式相比较，可见其形式完全一样，只是将初始时刻 t=0 换成了  $ t=t_{0} $ 而已. 故参照(10.5.4)式，有

$$  v(x,t\mid t_{0})=\int_{0}^{l}G(x,t\mid x_{0},t_{0})f(x_{0},t_{0})\mathrm{d}x_{0}   \tag*{(10.5.24)}$$

将(10.5.24)式代入(10.5.23)式即得(10.5.16)式. 又参照(10.5.5)~(10.5.7)式知，其中的 $ G(x,t|x_{0},t_{0}) $ 显然应满足定解问题(10.5.17)~(10.5.19)式. 当然，我们也可将积分公式(10.5.16)代入定解问题(10.5.13)~(10.5.15)式中，以验证它是否

<!-- page: 223 -->

是该定解问题的解.

由（10.5.11）式我们立即可得定解问题（10.5.17）～（10.5.19）式的解为

$$  G(x,t\mid x_{0},t_{0})=\frac{2}{l}\sum_{n=1}^{\infty}\sin\frac{n\pi}{l}x\sin\frac{n\pi}{l}x_{0}\exp\left[-\left(\frac{n\pi a}{l}\right)^{2}(t-t_{0})\right]   \tag*{（10.5.25）}$$

将上式代入(10.5.16)式，即得定解问题(10.5.13)~(10.5.14)式的解.

（3）由以上分析可见，对于一维扩散方程的混合问题

$$  u_{t}-a^{2}u_{x x}=f(x,t),\quad0<x<l,t>0   \tag*{（10.5.26）}$$

$$  u\mid_{x=0}=u\mid_{x=l}=0   \tag*{(10.5.27)}$$

$$  u\mid_{t=0}=\varphi(x)   \tag*{（10.5.28）}$$

易于得到其解的积分公式为

$$  u(x,t)=\int_{0}^{t}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}+\int_{0}^{t}\mathrm{d}t_{0}\int_{0}^{t}G(x,t\mid x_{0},t_{0})f(x_{0},t_{0})\mathrm{d}x_{0}   \tag*{（10.5.29）}$$

其中， $ G(x,t|x_{0},t_{0}) $ 满足定解问题(10.5.17)～(10.5.19)式，它可由分离变量法得到.以上结果是基于叠加原理得到的.因此定解问题是上述两个定解问题(10.5.1)～(10.5.3)式和(10.5.13)～(10.5.15)式的叠加，故其解就是这两个定解问题的解之和.

思考 对于定解问题(10.5.26)~(10.5.28)式，若其边界条件换为非齐次的，即  $ u|_{x=0}=h(t) $,  $ u|_{x=l}=g(t) $，又如何用格林函数法求解呢？

## 2. 一维无界区域的扩散问题

对于一维无界区域的扩散问题

 $$ \int u_{t}-a^{2}u_{x x}=f(x,t),\quad-\infty<x<\infty,t>0 $$ 

$$  \left(u\mid_{t=0}=\varphi(x)\right.   \tag*{（10.5.31）}$$

我们可用与上面完全相同的程序（只是要注意对变量 x 的积分区间不是从 0 到 l，而是从  $ -\infty $ 到  $ \infty $），而推得其解的积分公式为

$$  u(x,t)=\int_{-\infty}^{\infty}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}+\int_{0}^{t}\mathrm{d}t_{0}\int_{-\infty}^{\infty}G(x,t\mid x_{0},t_{0})f(x_{0},t_{0})\mathrm{d}x_{0}   \tag*{（10.5.32）}$$

其中， $ G(x,t|x_{0},t_{0}) $ 满足定解问题

$$  \int G_{t}-a^{2}G_{x x}=0,\quad-\infty<x<\infty,t>0   \tag*{（10.5.33）}$$

$$  G(x,t\mid x_{0},t_{0})\mid_{t=t_{0}}=\delta(x-x_{0})   \tag*{（10.5.34）}$$

可由傅氏变换法求得 $  (10.5.33) \sim (10.5.34)  $式的解为

$$  G(x,t\mid x_{0},t_{0})=\frac{1}{2a\sqrt{\pi(t-t_{0})}}\exp\left[-\frac{(x-x_{0})^{2}}{4a^{2}(t-t_{0})}\right]   \tag*{（10.5.35）}$$

故得  $ G(x,t|x_{0},0)=\frac{1}{2a\sqrt{\pi t}}\exp\left[-\frac{(x-x_{0})^{2}}{4a^{2}t}\right] $，一并代入（10.5.32）式，即得定解问题（10.5.30）～（10.5.31）式的解.

<!-- page: 224 -->

用类似的方法和思路，我们可推得一系列含时定解问题的积分公式.

## 3. 一维有界的波动问题

对于波动问题

$$  u_{t t}-a^{2}u_{x x}=f(x,t),\quad0<x<l,t>0   \tag*{（10.5.36）}$$

$$  u\mid_{x=0}=u\mid_{x=l}=0   \tag*{（10.5.37）}$$

$$  u\mid_{t=0}=\varphi(x),\quad u_{t}\mid_{t=0}=\psi(x)   \tag*{（10.5.38）}$$

可推得其积分公式为

$$  \begin{align*}u(x,t)=&\int_{0}^{t}\frac{\partial}{\partial t}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}+\int_{0}^{t}G(x,t\mid x_{0},0)\psi(x_{0})\mathrm{d}x_{0}\\&+\int_{0}^{t}\mathrm{d}t_{0}\int_{0}^{t}G(x,t\mid x_{0},t_{0})\mathrm{d}x_{0}\tag{1}\end{align*}   \tag*{（10.5.39）}$$

其中， $ G(x,t|x_{0},t_{0}) $ 满足定解问题

$$  G_{t t}-a^{2}G_{x x}=0,\quad0<x<l,t>0   \tag*{（10.5.40）}$$

$$  G\mid_{x=0}G\mid_{x=l}=0   \tag*{（10.5.41）}$$

$$  G\mid_{t=t_{0}}=0,\quad G_{t}\mid_{t=t_{0}}=\delta(x-x_{0})   \tag*{（10.5.42）}$$

它可由分离变量法求出（见 8.1 节）.

## 4. 一维无界的波动问题

对于波动问题

$$  \int u_{tt}-a^{2}u_{xx}=f(x,t),\quad-\infty<x<\infty,t>0   \tag*{（10.5.43）}$$

$$  u\mid_{t=0}=\varphi(x),\quad u_{t}\mid_{t=0}=\psi(x)   \tag*{（10.5.44）}$$

可得其解的积分公式为

$$  \begin{align*}u(x,t)=&\int_{-\infty}^{\infty}\frac{\partial}{\partial t}G(x,t\mid x_{0},0)\varphi(x_{0})\mathrm{d}x_{0}+\int_{-\infty}^{\infty}G(x,t\mid x_{0},0)\psi(x_{0})\mathrm{d}x_{0}\\&+\int_{0}^{t}\mathrm{d}t_{0}\int_{-\infty}^{\infty}G(x,t\mid x_{0},t_{0})f(x_{0},t_{0})\mathrm{d}x_{0}\tag{10.}\end{align*}   \tag*{（10.5.45）}$$

其中， $ G(x,t|x_{0},t_{0}) $ 满足定解问题

$$  \int G_{t t}-a^{2}G_{x x}=0,\qquad-\infty<x<\infty,t>0   \tag*{（10.5.46）}$$

$$  G\mid_{t=t_{0}}=0,\quad G_{t}\mid_{t=t_{0}}=\delta(x-x_{0})   \tag*{（10.5.47）}$$

其解可由积分变换法求得.

## 5. 一些三维问题的积分公式

（1）对于三维扩散方程的混合问题

$$  \left\{\begin{aligned}&u_{t}-a^{2}\Delta u(M,t)=f(M,t),\quad M\in\tau\\&\left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=g(M^{\prime},t),\quad&M^{\prime}\in\sigma\\&u\mid_{t=0}=\varphi(M)\end{aligned}\right.   \tag*{（10.5.48）}$$

<!-- page: 225 -->

其解的积分公式为

 $$ \begin{align*}u(M,t)=&\iiint_{\tau}G(M,t\mid M_{0},0)\varphi(M_{0})\mathrm{d}\tau_{0}+\int_{0}^{t}\mathrm{d}t_{0}\iiint_{\tau}G(M,t\mid M_{0},t_{0})f(M_{0},t_{0})\mathrm{d}\tau_{0}\\&+a^{2}\int_{0}^{t}\mathrm{d}t_{0}\iiint_{\tau}\Big[G\frac{\partial u}{\partial n_{0}}-u\frac{\partial G}{\partial n_{0}}\Big]\mathrm{d}\sigma_{0}\tag{10.5.49}\end{align*} $$ 

其中， $ G(M,t|M_{0},t_{0}) $ 是定解问题

$$  \left\{\begin{aligned}&G_{t}-a^{2}G(M,t)=0,\quad M\in\tau\\&\left[\alpha\frac{\partial G}{\partial n}+\beta G\right]_{\sigma}=0\\&G(M,t\mid M_{0},t_{0})\mid_{t=t_{0}}=\delta(M-M_{0})\end{aligned}\right.   \tag*{（10.5.50）}$$

的解，可由分离变量法求得. 而解（10.5.49）式中的最后一项，应根据不同的边界条件而具体化.

（2）对于三维无界的扩散问题

$$  \left\{\begin{aligned}u_{t}-a^{2}\Delta u(M,t)&=f(M,t),\quad-\infty<x,y,z<\infty;t>0\\ u\mid_{t=0}&=\varphi(M)\end{aligned}\right.   \tag*{(10.5.51)}$$

其解的积分公式为

$$  \begin{align*}u(M,t)=&\iiint_{-\infty}^{\infty}G(M,t\mid M_{0},0)\varphi(M_{0})\mathrm{d}\tau_{0}\\&+\int_{0}^{t}\mathrm{d}t_{0}\iiint_{-\infty}^{\infty}G(M,t\mid M_{0},t_{0})f(M_{0},t_{0})\mathrm{d}\tau_{0}\end{align*}   \tag*{（10.5.52）}$$

其中， $ G(M,t|M_{0},t_{0}) $ 是定解问题

$$  \left\{\begin{aligned}&G_{t}-a^{2}\Delta G=0,\quad-\infty<x,y,z<\infty;t>0\\ &G(M,t\mid M_{0},t_{0})\mid_{t=t_{0}}=\delta(M-M_{0})\end{aligned}\right.   \tag*{（10.5.53）}$$

的解，可由三维的傅氏变换法求得.

（3）对于三维波动方程的混合问题

$$  \left\{\begin{aligned}&u_{t t}-a^{2}\Delta u(M,t)=f(M,t),\quad M\in\tau\\ &\left[\alpha\frac{\partial u}{\partial n}+\beta u\right]_{\sigma}=g(M^{\prime},t),\quad M^{\prime}\in\sigma\\ &u\mid_{t=0}=\varphi(M),\quad u_{t}\mid_{t=0}=\psi(M)\end{aligned}\right.   \tag*{（10.5.54）}$$

其解的积分公式为

$$  \begin{align*}u(M,t)=&\iiint_{\tau}\frac{\partial}{\partial t}G(M,t\mid M_{0},0)\varphi(M_{0})\mathrm{d}\tau_{0}+\iiint_{\tau}G(M,t\mid M_{0},0)\psi(M_{0})\mathrm{d}\tau_{0}\\&+\int_{0}^{t}\mathrm{d}t_{0}\iiint_{\tau}G(M,t\mid M_{0},t_{0})f(M_{0},t_{0})\mathrm{d}\tau_{0}+a^{2}\int_{0}^{t}\mathrm{d}t_{0}\iint_{\sigma}\Big(G\frac{\partial u}{\partial n_{0}}-u\frac{\partial G}{\partial n_{0}}\Big)\mathrm{d}\sigma_{0}\end{align*}   \tag*{（10.5.55）}$$

其中， $ G(M,t|M_{0},t_{0}) $ 是定解问题

$$  \left\{\begin{aligned}&G_{t t}-a^{2}\Delta G(M,t)=0\\ &\left[\alpha\frac{\partial G}{\partial n}+\beta G\right]_{\sigma}=0\\ &G(M,t\mid M_{0},t_{0})\mid_{t=t_{0}}=0,\quad G_{t}(M,t\mid M_{0},t_{0})\mid_{t=t_{0}}=\delta(M-M_{0})\end{aligned}\right.   \tag*{（10.5.56）}$$

<!-- page: 226 -->

的解可由分离变量法求得.

（4）对于三维无界的波动问题

$$  \left\{\begin{aligned}u_{t t}&-a^{2}\Delta u(M,t)=f(M,t),\quad-\infty<x,y,z<\infty;t>0\\ u&\mid_{t=0}=\varphi(M),\quad u_{t}\mid_{t=0}=\psi(M)\end{aligned}\right.   \tag*{（10.5.57）}$$

其解的积分公式为

$$  \begin{align*}u(M,t)=&\iiint_{-\infty}^{\infty}\frac{\partial G(M,t\mid M_{0},0)}{\partial t}\varphi(M_{0})\mathrm{d}\tau_{0}+\iiint_{-\infty}^{\infty}G(M,t\mid M_{0},0)\psi(M_{0})\mathrm{d}\tau_{0}\\&+\int_{0}^{t}\mathrm{d}t_{0}\iiint_{-\infty}^{\infty}G(M,t\mid M_{0},t_{0})f(M_{0},t_{0})\mathrm{d}\tau_{0}\tag{10.5}.\end{align*}   \tag*{（10.5.58）}$$

其中  $ G(M,t|M_{0},t_{0}) $ 是定解问题

$$  \left\{\begin{aligned}G_{t t}&-a^{2}\Delta G(M,t)=0,\quad-\infty<x,y,z<\infty;t>0\\ G&\mid_{t=t_{0}}=0,\quad G_{t}\mid_{t=0}=\delta(M-M_{0})\end{aligned}\right.   \tag*{（10.5.59）}$$

的解，可由三维的傅氏变换法求得.

#### 习题10.5

1. 用格林函数法求解

 $$ \begin{cases}u_{t}-a^{2}u_{x x}=A\mathrm{s i n}\omega t,\quad0<x<l;t>0\\u_{x}\mid_{x=0}=0,\quad u_{x}\mid_{x=l}=0\\u\mid_{t=0}=0\end{cases} $$ 

2. 用格林函数法求解有界弦振动问题

 $$ \begin{cases}u_{tt}-a^{2}u_{xx}=A\cos\frac{x}{l}\sin\omega t,&0<x<l;t>0\\u_{x}\mid_{x=0}=0,\quad u_{x}\mid_{x=l}=0\\u\mid_{t=0}=0,\quad u_{t}\mid_{t=0}=0\end{cases} $$ 

3. 用格林函数法求解如下的弦的受迫振动问题：

 $$ \left\{\begin{aligned}&u_{t t}-a^{2}u_{x x}=f(x,t),\quad0<x<l;t>0\\ &u\mid_{x=0}=0,\quad u\mid_{x=l}=0\\ &u\mid_{t=0}=\varphi(x),\quad u_{t}\mid_{t=0}=\psi(x)\end{aligned}\right. $$ 

4. 试用格林函数法求解如下更一般的弦的受迫振动问题：

 $$ \left\{\begin{aligned}&u_{t t}-a^{2}u_{x x}=f(x,t),\quad0<x<l;t>0\\ &u\mid_{x=0}=g(t),\quad u\mid_{x=l}=h(t)\\ &u\mid_{t=0}=\varphi(x),\quad u_{t}\mid_{t=0}=\psi(x)\end{aligned}\right. $$ 

5. 用格林函数法求解三维无界区域的扩散问题

 $$ \left\{\begin{aligned}u_{t}&-a^{2}\Delta u=f(\boldsymbol{r},t)\\ u&\mid_{t=0}=0\end{aligned}\right. $$ 

6. 用格林函数法求解三维无界空间的波动问题

 $$ \left\{\begin{aligned}u_{t t}-a^{2}\Delta u&=f(\boldsymbol{r},t)\\ u\mid_{t=0}&=\varphi(\boldsymbol{r}),\quad u_{t}\mid_{t=0}=\psi(\boldsymbol{r})\end{aligned}\right. $$

<!-- page: 227 -->

# 本章小结

## 一、格林函数法的解题要领

1. 由格林第二公式（或推广的格林公式）等导出定解问题的解的积分式（其中含有 G）；

2. 求出该定解问题相应的格林函数 G;

3. 将求得的 G 代入积分公式，化简整理即得定解问题的解.

## 二、格林函数的求法

1. 对于边界为简单几何形状的问题的狄氏格林函数（如：圆、球；平面等）可用电像法来求，这种方法的要领是将格林函数 G 视为其内置有点电荷的接地导体壳内任意一点处的电势，而用虚构的点电荷即电像产生的电势，来等效地代替感应电荷所产生的电势。

2. 其他问题的格林函数可用其他各种方法求，如本征函数展开法、傅氏变换法、分离变量法等.

## 三、格林函数法的优点

一旦求出了某个区域上的(狄氏)格林函数，便可“一劳永逸”地得到这个区域上的一切定解问题的解，而不管其具体的边界条件和方程的非齐次项的形式如何.

## 四、用电像法求得的几个特殊区域的格林函数



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>区域</td><td style='text-align: center; word-wrap: break-word;'>格林函数</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>圆域  $ \rho&lt;a $</td><td style='text-align: center; word-wrap: break-word;'>$ G=\frac{1}{2\pi}\ln\frac{\rho_{0}r_{1}}{ar} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>球域  $ \rho&lt;a $</td><td style='text-align: center; word-wrap: break-word;'>$ G=\frac{1}{4\pi r}-\frac{a/\rho_{0}}{4\pi r_{1}} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>半平面 y&gt;0</td><td style='text-align: center; word-wrap: break-word;'>$ G=\frac{1}{2\pi}\ln\frac{r_{1}}{r} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>半空间 z&gt;0</td><td style='text-align: center; word-wrap: break-word;'>$ G=\frac{1}{4\pi r}-\frac{1}{4\pi r_{1}} $</td></tr></table>

<!-- page: 228 -->

<div style="text-align: center;"><div style="text-align: center;">几个常用的积分公式</div> </div>




<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>类型</td><td style='text-align: center; word-wrap: break-word;'>定解问题</td><td style='text-align: center; word-wrap: break-word;'>积分公式(基本解)</td><td style='text-align: center; word-wrap: break-word;'>其格林函数满足</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>三维狄氏问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} \Delta u = -h(M), M \in \tau \\ u \mid_\sigma = f(M) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(M) = \int_{\tau} G(M,M_0) h(M_0) d\tau_0 - \int_{\sigma} f(M_0) \frac{\partial G}{\partial n_0} d\sigma_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ G(M,M_0) = \frac{1}{4\pi r} + g \cdot \begin{cases} \Delta g = 0, M \in \tau \\ g \mid_\sigma = -\frac{1}{4\pi r} \end{cases} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>二维狄氏问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} \Delta u(M) = -h(M), M \in \sigma \\ u \mid_f = f(M) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(M) = \iint_{\sigma} G(M,M_0) h(M_0) d\sigma_0 - \int_{f} f(M_0) \frac{\partial G}{\partial n_0} d\rho_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ G = \frac{1}{2\pi} \ln \frac{1}{r} + g \cdot \begin{cases} \Delta g = 0, M \in \sigma \\ g \mid_f = -\frac{1}{2\pi} \ln \frac{1}{r} \end{cases} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>一维有界输运问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} u_t - a^2 u_{xx} = f(x,t) \\ u \mid_{x=0} = 0, u \mid_{x=t} = 0 \\ u \mid_{t=0} = \varphi(x) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(x,t) = \int_0^t G(x,t) |x_0,0) \varphi(x_0) dx_0 + \int_0^t d\theta_0 \int_0^t G(x,t) |x_0,t_0) f(x_0,t_0) dx_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \begin{cases} G_t - a^2 G_{xx} = 0 \\ G \mid_{x=0} = 0, G \mid_{x=t} = 0 \\ G \mid_{t=t_0} = 0, G_t = \delta(x-x_0) \end{cases} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>三维无界运输问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} u_t - a^2 \Delta u = f(M,t) \\ u \mid_{t=0} = \varphi(M) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(M,t) = \iiint_{-\infty}^\infty G(M,t) |M_0,0) \varphi(M_0) dM_0 + \int_0^t d\theta_0 \iiint_{-\infty}^\infty G(M,t) |M_0,t_0) f(M_0,t_0) dM_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \begin{cases} G_t - a^2 \Delta G = 0 \\ G \mid_{x=t_0} = \delta(M-M_0) \end{cases} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>一维有界波动问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} u_{tt} = a^2 u_{xx} = f(x,t) \\ u \mid_{x=0} = 0, u \mid_{x=t} = 0 \\ u \mid_{t=0} = \varphi(x), u_t \mid_{t=0} = \psi(x) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(x,t) = \int_0^t \frac{\partial}{\partial t} G(x,t) |x_0,0) \varphi(x_0) dx_0 + \int_0^t d\theta_0 \int_0^t G(x,t) |x_0,t_0) f(x_0,t_0) dx_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \begin{cases} G_{tt} - a^2 G_{xx} = 0 \\ G \mid_{x=0} = 0, G \mid_{x=t} = 0 \\ G \mid_{t=t_0} = 0, G_t = \delta(x-x_0) \end{cases} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>三维无界波动问题</td><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} u_{tt} - a^2 \Delta u = f(M,t) \\ u \mid_{t=0} = \varphi(M), u_t \mid_{t=0} = \psi(M) \end{array}\right. $</td><td style='text-align: center; word-wrap: break-word;'>$ u(M,t) = \int_0^t d\theta_0 \iiint_{-\infty}^\infty G(M,t) |M_0,t_0) f(M_0,t_0) dM_0 + \iiint_{-\infty}^\infty \left[\begin{array}{l} G(M,t) |M_0,t_0) \psi(M_0) \\ + \varphi(M_0) \frac{\partial}{\partial t} G(M,t) |M_0,t_0) \end{array}\right] dM_0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \begin{cases} G_{tt} - a^2 \Delta G = 0 \\ G \mid_{x=t_0} = 0, G_t = \delta(M-M_0) \end{cases} $</td></tr></table>

<!-- page: 229 -->

在数学物理问题中一个方法的成功不是由于巧妙的谋略或是幸运的偶遇，而是因为他表达着物理真理的某个方面。

——O.G.沙顿

## 第三篇 特殊函数

特殊函数是一些高级超越函数的总称（不是代数函数的完全解析函数通称为超越函数），它多半是从寻求某些数理方程的解得出的，其种类繁多，而且不断有新的出现。常见的有：勒让德多项式、贝塞尔函数、超几何函数、雅可比多项式、切比雪夫多项式、埃米特多项式、拉盖尔多项式等。特殊函数在物理学、工程技术、计算方法等方面有广泛的应用。

本书在第二篇第八章分离变量法中，曾通过在柱坐标系和球坐标系中对亥姆霍兹方程、拉氏方程的分离变数，得到了几个变系数的常微分方程，如，贝塞尔方程、勒让德方程等。本篇前两章将用级数解法对贝塞尔方程和勒让德方程进行求解，并对其解两类重要的特殊函数——贝塞尔函数和勒让德多项式的性质及其在分离变量法中的应用进行较详细的讨论；在此基础上最后一章再介绍特殊函数的普遍理论。

<!-- page: 230 -->

在第二篇第八章中我们曾通过在球坐标系中对亥姆霍兹方程和拉氏方程分离变量而得到了关于变量 $ \theta $的连带勒让德方程[见第二篇(8.4.34)式]

 $$ (1-x^{2})y^{\prime \prime}-2xy^{\prime}+\left[l(l+1)-\frac{m^{2}}{(1-x^{2})}\right]y=0 $$ 

其中  $ x=\cos\theta, y=\Theta(\theta) $. 该方程当 m=0 的特例为

 $$ (1-x^{2})y^{\prime \prime}-2xy^{\prime}+l(l+1)y=0 $$ 

称为勒让德方程. 若物理问题关于 z 轴对称，即场量  $ u(r,\theta,\varphi) $ 与  $ \varphi $ 无关， $ \frac{\partial u}{\partial\varphi}=0 $，则分离变量后所得到的关于变量  $ \theta $ 的方程正是这种情形 [见(8.4.29)~(8.4.32)式].

本章将在 x=0 的邻域求解勒让德方程，并着重讨论其特解勒让德多项式（一种特殊函数）所具有的性质.

### 11.1 勒让德多项式

## 1. 勒让德方程的级数解

让我们首先求出勒让德方程

$$  (1-x^{2})y^{\prime \prime}-2xy^{\prime}+l(l+1)y=0   \tag*{(11.1.1)}$$

在 x=0 点邻域的级数解.

由于 x=0 为方程的常点，故在 x=0 的邻域内可设其解 $ ^{①} $为

$$  y=\sum_{k=0}^{\infty}c_{k}x^{k}   \tag*{（11.1.2）}$$

代入方程(11.1.1)得到

 $$ (1-x^{2})\sum_{k=2}^{\infty}k(k-1)c_{k}x^{k-2}-2x\sum_{k=1}^{\infty}k c_{k}x^{k-1}+l(l+1)\sum_{k=0}^{\infty}c_{k}x^{k}=0 $$ 

即

 $$ \sum_{k=2}^{\infty}k(k-1)c_{k}x^{k-2}+l(l+1)\sum_{k=0}^{\infty}c_{k}x^{k}-2\sum_{k=1}^{\infty}kc_{k}x^{k}-\sum_{k=2}^{\infty}k(k-1)c_{k}x^{k}=0 $$ 

比较方程两边 x 的各次幂的系数有

 $$ \begin{aligned}2\bullet1c_{2}+l(l+1)c_{0}&=0\\3\bullet2c_{3}+\left[l(l+1)-2\right]c_{1}&=0\end{aligned} $$

<!-- page: 231 -->

$$ (k+2)(k+1)c_{k+2}+\left[l(l+1)-k(k+1)\right]c_{k}=0 $$ 

从而得如下一组系数递推公式

$$  \begin{aligned}&c_{2}=\frac{-l(l+1)}{2\bullet1}c_{0}\\&c_{3}=-\frac{l(l+1)-2}{3\bullet2}c_{1}\\&\quad\cdots\cdots\\&c_{k+2}=-\frac{l(l+1)-k(k+1)}{(k+2)(k+1)}c_{k},\quad k=0,1,2,\cdots\\ \end{aligned}   \tag*{(11.1.3)}$$

由（11.1.3）式于是有

 $$ \begin{align*}c_{4}=&-\frac{\left[l(l+1)-2\cdot3\right]}{4\cdot3}c_{2}=(-1)^{2}\frac{(l-2)l(l+1)(l+3)}{4!}c_{0};\\c_{5}=&-\frac{\left[l(l+1)-3\cdot4\right]}{5\cdot4}c_{3}=(-1)^{2}\frac{(l-3)(l-1)(l+2)(l+4)}{5!}c_{1};\end{align*} $$ 

即

$$  c_{2n}=\frac{(-1)^{n}(l-2n+2)(l-2n+4)\cdots l(l+1)\cdots(l+2n-1)}{(2n)!}c_{0}   \tag*{(11.1.4)}$$

$$  c_{2n+1}=\frac{(-1)^{n}(l-2n+1)(l-2n+3)\cdots(l-1)(l+2)\cdots(l+2n)}{(2n+1)!}c_{1}   \tag*{（11.1.5）}$$

其中 n=1,2,\cdots 将以上系数代入(11.1.2)式则得方程(11.1.1)的通解为

 $$ y(x)=y_{0}(x)+y_{1}(x) $$ 

其中

$$  \begin{align*}y_{0}(x)&=c_{0}\Big[1-\frac{l(l+1)}{2!}x^{2}+\frac{(l-2)l(l+1)(l+3)}{4!}x^{4}+\cdots\\&\quad+\frac{(-1)^{n}(l-2n+2)(l-2n+4)\cdots l(l+1)\cdots(l+2n-1)}{(2n)!\}x^{2n}+\cdots\Big]\\&=c_{0}+c_{2}x^{2}+c_{4}x^{4}+\cdots+c_{2n}x^{2n}+\cdots\tag{11.1.}\end{align*}   \tag*{（11.1.6）}$$

这是只含有偶次幂的特解. 而

 $$ \begin{aligned}y_{1}(x)&=c_{1}\Big[x-\frac{(l-1)(l+2)}{3!}x^{3}+\frac{(l-3)(l-1)(l+2)(l+4)}{5!}x^{5}+\cdots\\&\quad+\frac{(-1)^{n}(l-2n+1)(l-2n+3)\cdots(l-1)(l+2)\cdots(l+2n)}{(2n+1)!\}x^{2n+1}+\cdots\Big]\\&=c_{1}x+c_{3}x^{3}+c_{5}x^{5}+\cdots+c_{2n+1}x^{2n+1}+\cdots\tag{11.1.7}\end{aligned} $$ 

这是只含有奇次幂的特解.

## 2. 解的敛散性

既然解是无穷级数的形式，故必须讨论其敛散性。由达朗贝尔判别法[见第一篇(3.2.2)式]和递推公式(11.1.3)知， $ y_{0}(x) $ 和  $ y_{1}(x) $ 的收敛半径为

<!-- page: 232 -->

$$ R=\lim_{k\to\infty}\left|\frac{c_{k}}{c_{k+2}}\right|=\lim_{k\to\infty}\left|\frac{(k+2)(k+1)}{l(l+1)-k(k+1)}\right|=1 $$ 

这就是说，当 $ |x|<1 $时， $ y_{0}(x) $和 $ y_{1}(x) $绝对收敛；当 $ |x|>1 $时， $ y_{0} $和 $ y_{1} $发散；当 $ |x|=1 $时达朗贝尔判别法失效，但由高斯判别法[见第一篇(3.1.7)式]知 $ y_{0}(x) $和 $ y_{1}(x) $在 $ x=\pm1 $发散。因为此时 $ y_{0}(x) $和 $ y_{1}(x) $可表示为常数项级数

 $$ y_{0}=c_{0}+\sum_{n=1}^{\infty}c_{2n}=\sum_{n=0}^{\infty}f_{n}, $$ 

 $$ y_{1}=c_{1}+\sum_{n=1}^{\infty}(-1)^{2n+1}c_{2n+1}=\sum_{n=0}^{\infty}g_{n} $$ 

其中， $ c_{2n} $ 和  $ c_{2n+1} $ 分别由(11.1.4)式和(11.1.5)式给出。于是由(11.1.3)式，对于 $ y_{0} $ 有

 $$ \frac{f_{n}}{f_{n+1}}=\frac{(2n+2)(2n+1)}{(2n-l)(2n+1+l)}=1+\frac{1}{n}+O\Big(\frac{1}{n^{2}}\Big) $$ 

同样，对于 $ y_{1} $有

 $$ \frac{g_{n}}{g_{n+1}}=\frac{(2n+3)(2n+2)}{(2n+1-l)(2n+2+l)}=1+\frac{1}{n}+O\Big(\frac{1}{n^{2}}\Big) $$ 

因此  $ y_{0}(\pm1) $ 和  $ y_{1}(\pm1) $ 均发散.

## 3. 本征值和本征函数

在物理上我们常常是要求问题的有限解. 由于勒让德方程中  $ x=\cos\theta $, 即  $ \left|x\right|\leqslant1 $, 这就要求我们所求得的级数解必须满足自然边界条件

$$  y\mid_{|x|\leq1}\rightarrow 有限   \tag*{(11.1.8)}$$

由上面的讨论知，当  $ x = \pm 1 $ 时  $ y_{0} $ 和  $ y_{1} $ 却均不满足这一条件。但是由递推公式 (11.1.3) 我们看到，若取参数 l = 0, 1, 2,  $ \cdots $，则当 l = k 时便有  $ c_{l+2} = 0 $，于是接着便有  $ c_{l+4} = 0, c_{l+6} = 0, \cdots $，而  $ y_{0}(x) $ 和  $ y_{1}(x) $ 两级数解中势必有一个成为 l 次多项式。

具体而言，若 l=k=2n(n=0,1,2,\cdots)，则

于是

$$  \begin{aligned}c_{l+2}&=c_{2n+2}=0\\c_{2n+4}&=0,\quad c_{2n+6}=0,\quad\cdots\\y_{0}(x)&=c_{0}+c_{2}x^{2}+c_{4}x^{4}+\cdots+c_{l}x^{l}\end{aligned}   \tag*{(11.1.9)}$$

是一仅含有偶次幂的 l 次多项式[其中各次幂的系数依附于  $ c_{0} $，由(11.1.4)给出]. 而  $ y_{1}(x) $ 中由于不会出现终止项  $ c_{2n+2}=0 $，故仍为无穷级数. 类似地有

若  $ l=k=2n+1(n=0,1,2,\cdots) $，则

 $$ \begin{aligned}c_{l+2}&=c_{2n+3}=0\\c_{2n+5}&=0,\quad c_{2n+7}=0,\quad\cdots\\x)&=c_{1}x+c_{3}x^{3}+c_{5}x^{5}+\cdots+c_{l}x^{l}\end{aligned} $$ 

于是

是一只含有奇次幂的 l 次多项式[其中各次幂系数依附于  $ c_{1} $，由(11.1.7)给出].而

<!-- page: 233 -->

$ y_{0}(x) $仍为无穷级数.

综上所述，勒让德方程(11.1.1)只有当参数l取0,1,2, $ \cdots $时，才在闭区间 $ -1\leqslant x\leqslant1 $中有有限的解。我们称参数 $ l(l+1),l=0,1,2,\cdots $为方程(11.1.1)在边界条件(11.1.8)下的本征值，而相应的l次多项式解(11.1.9)或(11.1.10)式，为本征函数。

## 4. 勒让德多项式

可以看出，以上 l 次多项式的系数是相当烦的，为了使以上多项式有比较简洁的形式，并使它在 x=1 处的值恒为 1，选最高次幂的系数

 $$ c_{l}=\frac{(2l)!}{2^{l}(l!)^{2}} $$ 

并称以上 l 次多项式为 l 阶勒让德多项式，记为  $ P_{l}(x) $，则由(11.1.3)式有

 $$ c_{k}=\frac{(k+2)(k+1)}{k(k+1)-l(l+1)}c_{k+2}=-\frac{(k+2)(k+1)}{(l-k)(l+k+1)}c_{k+2} $$ 

于是

 $$ \begin{align*}c_{l-2}=&-\frac{l(l-1)}{2(2l-1)}c_{l}=(-1)\frac{l(l-1)}{2(2l-1)}\bullet\frac{(2l)!}{2^{l}(l!)^{2}}\\=&(-1)\frac{(2l-2)!}{2^{l}(l-1)!(l-2)!}\end{align*} $$ 

 $$ \begin{aligned}c_{l-4}=&-\frac{(l-2)(l-3)}{4(2l-3)}c_{l-2}\\=&(-1)^{2}\frac{(l-2)(l-3)}{4(2l-3)}\bullet\frac{(2l-2)!}{2^{l}(l-1)!(l-2)!}\\=&(-1)^{2}\frac{(2l-4)!}{2^{l}\bullet2(l-2)!(l-4)!}\end{aligned} $$ 

 $$ \begin{aligned}c_{l-6}=&-\frac{(l-4)(l-5)}{6(2l-5)}c_{l-4}\\=&(-1)^{3}\frac{(l-4)(l-5)}{6(2l-5)}\bullet\frac{(2l-4)!}{2^{l}\bullet2(l-2)!(l-4)!}\\=&(-1)^{3}\frac{(2l-6)!}{2^{l}3!(l-3)!(l-6)!}\end{aligned} $$ 

仿此做下去，用数学归纳法可得

 $$ c_{l-2n}=(-1)^{n}\frac{(2l-2n)!}{2^{l}n!(l-n)!(l-2n)!},\quad n=0,1,\cdots,\left[\frac{l}{2}\right] $$ 

其中

 $$ \left[\frac{l}{2}\right]=\left\{\begin{aligned}&\frac{l}{2},& 当 l 为偶数 \\&\frac{l-1}{2},& 当 l 为奇数 \end{aligned}\right. $$ 

故有

<!-- page: 234 -->

$$  P_{l}(x)=\sum_{n=0}^{\left[\frac{l}{2}\right]}(-1)^{n}\frac{(2l-2n)!}{2^{l}n!(l-n)!(l-2n)!}x^{l-2n}   \tag*{(11.1.11)}$$

这是一按降幂排列的 l 次多项式，它是 l 阶勒让德方程(11.1.1)的一有界解，即

$$  y=P_{l}(x)   \tag*{(11.1.12)}$$

由（11.1.11）式可得到

$$  \begin{aligned}&P_{0}(x)=1\\&P_{1}(x)=x\\&P_{2}(x)=\frac{1}{2}(3x^{2}-1)\\&P_{3}(x)=\frac{1}{2}(5x^{3}-3x)\\ \end{aligned}   \tag*{(11.1.13)}$$

等等. 且

 $$ P_{0}(1)=P_{1}(1)=P_{2}(1)=P_{3}(1)=\cdots\equiv1 $$ 

在讨论勒让德多项式的一些性质或在与其相关的一些计算中，还要用到它的别种表达式，下面我们导出它的其他两种表达式。

## 5. 勒让德多项式的微分表达式

$$  P_{l}(x)=\frac{1}{2^{l}l!}\frac{\mathrm{d}^{l}}{\mathrm{d}x^{l}}(x^{2}-1)^{l}   \tag*{(11.1.14)}$$

这个表达式又称为罗德里格斯(Rodrigues)公式.

证明 由二项式展开定理

可得到

 $$ \begin{aligned}&(a+b)^{k}=\sum_{n=0}^{k}\frac{k!}{n!(k-n)!}a^{k-n}b^{n}\\ &(x^{2}-1)^{l}=\sum_{n=0}^{l}\frac{(-1)^{n}l!}{n!(l-n)!}x^{2l-2n}\\ \end{aligned} $$ 

因此

 $$ \begin{align*}\frac{1}{2^{l} l!}\frac{\mathrm{d}^{l}}{\mathrm{d}x^{l}}(x^{2}-1)^{l}&=\frac{1}{2^{l} l!}\sum_{n=0}^{l}\frac{(-1)^{n} l!}{n!(l-n)!}\frac{\mathrm{d}^{l}}{\mathrm{d}x^{l}}x^{2l-2n}=\sum_{n=0}^{\left\lfloor\frac{l}{2}\right\rfloor}\frac{(-1)^{n}}{2^{l} n!(l-n)!}\\&\quad\bullet(2l-2n)(2l-2n-1)\cdots(2l-2n-l+1)x^{2l-2n-l}\\&=\sum_{n=0}^{\left\lfloor\frac{l}{2}\right\rfloor}\frac{(-1)^{n}(2l-2n)!}{2^{l} n!(l-n)!(l-2n)!}x^{l-2n}=P_{l}(x)\end{align*} $$ 

## 6. 勒让德多项式的积分表达式

$$  P_{l}(x)=\frac{1}{2\pi\mathrm{i}}\oint_{l^{*}}\frac{(\zeta^{2}-1)^{l}}{2^{l}(\zeta-x)^{l+1}}\mathrm{d}\zeta   \tag*{(11.1.15)}$$

其中  $ l^{*} $ 为包围  $ \zeta = x $ 的回路. 此表达式又称为拖拉夫利 (Schläfli) 公式.

<!-- page: 235 -->

证明 令  $ f(z)=(z^{2}-1)^{l} $，则由解析函数的 n 阶导数公式 [见第一篇(2.3.5)式] 有

 $$ \frac{\mathrm{d}^{l}}{\mathrm{d}z^{l}}(z^{2}-1)^{l}=\frac{l!}{2\pi\mathrm{i}}\oint_{l^{*}}\frac{(\zeta^{2}-1)^{l}}{(\zeta-z)^{l+1}}\mathrm{d}\zeta $$ 

即

 $$ \frac{\mathrm{d}^{l}}{\mathrm{d}x^{l}}(x^{2}-1)^{l}=\frac{l!}{2\pi\mathrm{i}}\oint_{l^{*}}\frac{(\zeta^{2}-1)^{l}}{(\zeta-x)^{l+1}}\mathrm{d}\zeta $$ 

上式两边同乘以因子 $ \frac{1}{2^{l}!} $ 便得(11.1.15)式.

注 ① 对于二阶线性常微分方程

$$  \begin{align*}w''(z)+p(z)w'(z)+q(z)w(z)=0\end{align*}   \tag*{(11.1.16)}$$

若其系数 p(z) 和 q(z) 均在某点  $ z_{0} $ 及其邻域内解析，则称  $ z_{0} $ 为方程的常点.

在常点  $ z = z_{0} $ 的邻域  $ \left| z - z_{0} \right| < R $ 内，方程 (11.1.16) 有唯一的一个满足初始条件

 $$ w(z_{0})=c_{0},\quad w^{\prime}(z_{0})=c_{1} $$ 

的形式为

$$  w(z)=\sum_{k=0}^{\infty}c_{k}(z-z_{0})^{k}   \tag*{(11.1.17)}$$

的幂级数解. 其中  $ c_{0} $ 和  $ c_{1} $ 是任意常数; 而其他各次幂系数与  $ c_{0} $ 和  $ c_{1} $ 的关系, 均由将形式解 (11.1.17) 代入方程 (11.1.16) 中通过比较方程两边同次幂的系数 [即让左边  $ (z - z_{0}) $ 的各次幂的系数均为零] 来确定 (参见参考书目 [5], § 95).

#### 习题11.1

1. 在 x=0 点的邻域求解常微分方程

 $$ y^{\prime \prime}+\omega^{2}y=0 $$ 

2. 用级数解法求艾里方程

 $$ y^{\prime \prime}-xy=0 $$ 

在 x=0 点邻域分别满足条件  $ y(0)=0, y^{\prime}(0)=1 $ 和  $ y(0)=1, y^{\prime}(0)=0 $ 的级数解.

3. 在量子力学中讨论一维谐振子问题会遇到厄米方程. 在 x=0 的邻域求解厄米方程

 $$ y^{\prime \prime}-2xy^{\prime}+(\lambda-1)y=0 $$ 

λ取什么数值可使级数解退化为多项式？这些多项式乘以适当常数可使最高项成为 $ (2x)^{n} $形式，叫做厄米多项式，记作 $ H_{n}(x) $.写出前几个 $ H_{n}(x) $.

4. 在 x=0 的邻域内求解雅可比 (Jacobi) 方程

 $$ (1-x^{2})y^{\prime \prime}+\left[\beta-\alpha-(\alpha+\beta+2)x\right]y^{\prime}+\lambda(\alpha+\beta+\lambda+1)y=0. $$ 

其中 $ \alpha,\beta,\lambda $均为常数.

5. 求方程  $ y'' - x^{2}y = 0 $ 在 x = 0 邻域内的两个级数解

### 11.2 勒让德多项式的性质

在这一节中，我们将首先导出勒让德多项式的母函数展开公式，由此再导出勒让

<!-- page: 236 -->

德多项式的其他一些有用性质.

如果函数  $ w(x,t) $ 满足如下关系：

 $$ w(x,t)=\sum_{n}F_{n}(x)t^{n},\quad t 为复数 $$ 

则称  $ w(x,t) $ 为  $ F_{n}(x) $ 的母函数（或生成函数）.

## 1.  $ P_{i}(x) $ 的母函数

勒让德多项式最早是由勒让德在势论中引入的。如图11.1所示，设在单位球的北极N点放有一电量q为 $ 4\pi\varepsilon_{0} $的正电荷，则由电学知识知，在球内任一点M（设M与N之间的距离为d）处的电势为

 $$ v(r,\theta)=\frac{1}{d}=\frac{1}{\sqrt{1-2r\cos\theta+r^{2}}} $$ 

<div style="text-align: center;"><img src="images/p0236_img_in_image_box_652_313_860_566.jpg" alt="图11.1" width="21%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图11.1</div> </div>


其中 r,  $ \theta $ 均为球坐标变量（由于问题是轴对称的，所以与变量  $ \varphi $ 无关）. 若令  $ x = \cos\theta $，则

$$  v(r,\theta)=\frac{1}{d}=\frac{1}{\sqrt{1-2rx+r^{2}}},\quad\mid x\mid\leqslant1   \tag*{(11.2.1)}$$

另一方面，在单位球内

 $$ \Delta v(r,\theta)=0,\quad r<1 $$ 

用分离变量法求解此方程，令

 $$ v(r,\theta)=R(r)\Theta(\theta) $$ 

代入上式，实现变数分离得

$$  \left\{\begin{array}{l}r^{2}\frac{\mathrm{d}^{2}R}{\mathrm{d}r^{2}}+2r\frac{\mathrm{d}R}{\mathrm{d}r}-l(l+1)R=0\end{array}\right.   \tag*{(11.2.2)}$$

$$  (1-x^{2})y^{\prime \prime}-2xy^{\prime}+l(l+1)y=0   \tag*{（11.2.3）}$$

其中， $ l=0,1,2,\cdots;x=\cos\theta,y=\Theta(\theta) $ [参见第二篇8.4节].方程(11.2.2)是我们所熟悉的欧拉方程，其解为

 $$ R(r)=A r^{l}+B r^{-(l+1)} $$ 

其中 A, B 为任意常数. 方程(11.2.3) 的有限解已由(11.1.12)式给出, 即

 $$ y_{l}(x)=P_{l}(x) $$ 

于是

$$  v(r,\theta)=\sum_{l=0}^{\infty}[A_{l}r^{l}+B_{l}r^{-(l+1)}]P_{l}(\cos\theta)   \tag*{(11.2.4)}$$

注意到在原点处不存在电荷，所以  $ v|_{r=0}= $ 有限，因此必须  $ B_{l}=0 $ 。于是

$$  \upsilon(r,\theta)=\sum_{l=0}^{\infty}A_{l}r^{l}P_{l}(\cos\theta),\quad r<1   \tag*{（11.2.5）}$$

对比(11.2.1)式和(11.2.5)式，可得

<!-- page: 237 -->

$$  \frac{1}{\sqrt{1-2rx+r^{2}}}=\sum_{l=0}^{\infty}A_{l}r^{l}P_{l}(x)   \tag*{(11.2.6)}$$

取x=1，并注意到 $ P_{l}(1)\equiv1 $，可得

 $$ \frac{1}{1-r}=\sum_{l=0}^{\infty}A_{l}r^{l} $$ 

与几何级数对比，于是可定出系数

 $$ A_{l}=1,\quad l=0,1,2,\cdots $$ 

代入(11.2.6)式并将 r 改写为  $ t(t $ 为复数)更具有一般性，最后得

$$  \frac{1}{\sqrt{1-2tx+t^{2}}}=\sum_{l=0}^{\infty}P_{l}(x)t^{l},\quad\mid t\mid<1   \tag*{(11.2.7)}$$

所以， $ P_{l}(x) $ 的母函数是含参数的初等函数  $ \frac{1}{\sqrt{1-2tx+t^{2}}} $.

利用特殊函数的母函数展开式，研究特殊函数将十分方便。下面我们将利用(11.2.7)式，导出勒让德多项式的递推公式和归一性，这种用母函数来研究问题的方法，称做母函数法。

## 2. 递推公式

邻阶的勒让德多项式，满足如下的递推公式：

$$  (l+1)P_{l+1}(x)-(2l+1)x P_{l}(x)+l P_{l-1}(x)=0,\quad l=1,2,3,\cdots   \tag*{(11.2.8)}$$

证明 将(11.2.7)式两边对 t 求导，得

 $$ (x-t)(1-2xt+t^{2})^{-\frac{3}{2}}=\sum_{l=0}^{\infty}lP_{l}(x)t^{l-1} $$ 

以 $ (1-2xt+t^{2}) $乘两边，对左边再用（11.2.7）式得

 $$ (x-t)\sum_{l=0}^{\infty}P_{l}(x)t^{l}=(1-2xt+t^{2})\sum_{l=0}^{\infty}lP_{l}(x)t^{l-1} $$ 

比较两边同次幂 $ t^{i} $的系数便得(11.2.8)式.

## 3. 正交归一性

勒让德多项式，在 $ [-1,1] $上满足如下正交归一关系：

$$  \int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x=\frac{2}{2l+1}\delta_{kl}   \tag*{(11.2.9)}$$

证明 我们先证明其正交性，即

 $$ \int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x=0,\quad k\neq l $$ 

由于  $ P_{l}(x) $ 和  $ P_{k}(x) $ 分别为 l 阶和 k 阶勒让德方程的一特解，故有

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\Big[(1-x^{2})\frac{\mathrm{d}P_{l}(x)}{\mathrm{d}x}\Big]+l(l+1)P_{l}(x)=0 $$

<!-- page: 238 -->

$$ \frac{\mathrm{d}}{\mathrm{d}x}\Big[(1-x^{2})\frac{\mathrm{d}P_{k}(x)}{\mathrm{d}x}\Big]+k(k+1)P_{k}(x)=0 $$ 

以  $ P_{k}(x) $ 乘以第一个式子， $ P_{i}(x) $ 乘以第二个式子，再把结果相减，然后积分得

 $$ \begin{aligned}&\int_{-1}^{1}P_{k}(x)\frac{\mathrm{d}}{\mathrm{d}x}\big[(1-x^{2})P_{l}^{\prime}(x)\big]\mathrm{d}x-\int_{-1}^{1}P_{l}(x)\frac{\mathrm{d}}{\mathrm{d}x}\big[(1-x^{2})P_{k}^{\prime}(x)\big]\mathrm{d}x\\ +\big[l(l+1)-k(k+1)\big]\int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x&=0\end{aligned} $$ 

对前两项利用分部积分得

 $$ \begin{align*}&(1-x^{2})P_{k}(x)P_{l}^{\prime}(x)\big|_{-1}^{1}-\int_{-1}^{1}(1-x^{2})P_{l}^{\prime}(x)P_{k}^{\prime}(x)\mathrm{d}x\\&-(1-x^{2})P_{l}(x)P_{k}^{\prime}(x)\big|_{-1}^{1}+\int_{-1}^{1}(1-x^{2})P_{k}^{\prime}(x)P_{l}^{\prime}(x)\mathrm{d}x\\=&\big[k(k+1)-l(l+1)\big]\int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x\end{align*} $$ 

即

 $$ \left[k(k+1)-l(l+1)\right]\int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x=0 $$ 

因为  $ k \neq l $ ，故有

 $$ \int_{-1}^{1}P_{i}(x)P_{k}(x)\mathrm{d}x=0 $$ 

又由母函数关系式(11.2.7)式，有

 $$ \frac{1}{1-2xt+t^{2}}=\sum_{l=0}^{\infty}P_{l}(x)t^{l}\bullet\sum_{k=0}^{\infty}P_{k}(x)t^{k}=\sum_{l=0}^{\infty}\sum_{k=0}^{\infty}P_{l}(x)P_{k}(x)t^{l+k} $$ 

将上式两边对 x 积分，并引用正交性，便有

 $$ \begin{align*}\int_{-1}^{1}\frac{\mathrm{d}x}{1-2xt+t^{2}}&=\sum_{l=0}^{\infty}\sum_{k=0}^{\infty}\int_{-1}^{1}P_{l}(x)P_{k}(x)\mathrm{d}x\bullet t^{l+k}\\&=\sum_{l=0}^{\infty}\int_{-1}^{1}P_{l}^{2}(x)\mathrm{d}xt^{2l}\end{align*} $$ 

又

 $$ \begin{aligned}\int_{-1}^{1}\frac{\mathrm{d}x}{1-2xt+t^{2}}=&-\frac{1}{2t}\int_{-1}^{1}\frac{\mathrm{d}(1-2xt+t^{2})}{(1-2xt+t^{2})}\\=&\frac{1}{2t}\ln\frac{(1+t)^{2}}{(1-t)^{2}}=\sum_{l=0}^{\infty}\frac{2}{2l+1}t^{2l}\end{aligned} $$ 

对比上两式故有

 $$ \sum_{l=0}^{\infty}\frac{2}{2l+1}t^{2l}=\sum_{l=0}^{\infty}\int_{-1}^{1}P_{l}^{2}(x)\mathrm{d}x t^{2l} $$ 

比较等式两边  $ t^{21} $ 的系数，于是有

 $$ \int_{-1}^{1}P_{l}^{2}(x)\mathrm{d}x=\frac{2}{2l+1} $$ 

记

 $$ N_{l}^{2}=\frac{2}{2l+1} $$

<!-- page: 239 -->

称  $ N_{l} $ 为  $ P_{l}(x) $ 的模，而  $ \frac{1}{N_{l}} $ 为  $ P_{l}(x) $ 的归一化因子。因为函数  $ \frac{P_{l}(x)}{N_{l}} $ 在  $ [-1,1] $ 上归一

 $$ \int_{-1}^{1}\left[\frac{P_{l}(x)}{N_{l}}\right]^{2}\mathrm{d}x=1 $$ 

我们常常利用勒让德多项式的递推公式和正交归一性来计算一些含勒让德多项式的积分.

例1 求积分 $ \int_{-1}^{1}xP_{l}(x)P_{k}(x)\mathrm{d}x $之值.

解 由递推公式 $  (11.2.8)  $式有

 $$ x P_{l}(x)=\frac{1}{2l+1}\big[(l+1)P_{l+1}(x)+l P_{l-1}(x)\big] $$ 

所以

 $$ \begin{aligned}\int_{-1}^{1}xP_{l}(x)P_{k}(x)\mathrm{d}x=&\frac{l+1}{2l+1}\int_{-1}^{1}P_{l+1}(x)P_{k}(x)\mathrm{d}x\\&+\frac{l}{2l+1}\int_{-1}^{1}P_{l-1}(x)P_{k}(x)\mathrm{d}x\end{aligned} $$ 

再利用正交性(11.2.9)式，便有

$$  \int_{-1}^{1}x P_{l}(x)P_{k}(x)\mathrm{d}x=\left\{\begin{aligned}&\frac{2k}{4k^{2}-1},&l&=k-1\\&\frac{2(k+1)}{(2k+3)(2k+1)},&l&=k+1\\&0,&l-k\neq&\pm1\end{aligned}\right.   \tag*{(11.2.10)}$$

最后，我们讨论函数按  $ P_{1}(x) $ 展开为广义傅氏级数的问题.

## 4. 广义傅氏展开

若函数  $ f(x) $ 在区间  $ [-1,1] $ 上有连续的一阶导数，分段连续的二阶导数，且  $ f(x) $ 在  $ [-1,1] $ 上平方可积，则  $ f(x) $ 在  $ [-1,1] $ 上可展开为如下的绝对且一致收敛的级数

$$  f(x)=\sum_{l=0}^{\infty}C_{l}P_{l}(x)   \tag*{(11.2.11)}$$

其中

$$  C_{l}=\frac{2l+1}{2}\int_{-1}^{1}f(x)P_{l}(x)\mathrm{d}x,\quad l=0,1,2,\cdots   \tag*{(11.2.12)}$$

关于展开定理的证明，可参看参考书目[6]第5章，而展开系数公式(11.2.12)，只要在(11.2.11)两边乘上 $ P_{k}(x) $后，再在区间 $ [-1,1] $上对x积分，并利用正交归一性(11.2.9)式便可得到.

由于在物理上常将某一作为表征的物理量展开成级数进行分析，而在数学上数理方程的解又常常是无穷级数的形式（如分离变量解），这就使得函数的广义傅氏展开有重要意义和用处。广义傅氏展开又称之为完备性。

例2 在匀强电场  $ E_{0} $ 中，放一接地的导体球，球的半径等于a，求球外电场.

解 选择球坐标系讨论此问题（见图11.2）. 在球外，由于没有电荷存在，故电势

<!-- page: 240 -->

v 满足拉氏方程

$$  \Delta v=0   \tag*{(11.2.13)}$$

由于导体球接地，故有边界条件

$$  v\mid_{r=a}=0   \tag*{(11.2.14)}$$

又由于问题中的区域是球外，延伸无穷远处，

故还需考虑在无穷远处电势应满足的边界条件。

在无穷远处只有原来的匀强电场  $ E = E_{0} $，

其方向沿 z 轴，即  $ E|_{r \to \infty} = -\frac{\partial v}{\partial z} \bigg|_{r \to \infty} = E_{0} $，设

<div style="text-align: center;"><img src="images/p0240_img_in_image_box_545_144_859_351.jpg" alt="图11.2" width="32%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图11.2</div> </div>


在导体未放入前，r=0 处的电势为  $ v_{0} $，则在  $ \infty $ 处电势满足的边界条件为

$$  v\mid_{r\to\infty}=-E_{0}z+v_{0}=-E_{0}r\cos\theta+v_{0}   \tag*{(11.2.15)}$$

现在在球坐标中，用分离变量法来求解定解问题(11.2.13)~(11.2.15)式.考虑到问题的轴对称性，故令

$$  v(r,\theta)=R(r)\Theta(\theta)   \tag*{(11.2.16)}$$

代入(11.2.13)式，类似于前面的过程[见(11.2.2)~(11.2.4)式]实现变数分离，得其解为

$$  v(r,\theta)=\sum_{l=0}^{\infty}[A_{l}r^{l}+B_{l}r^{-(l+1)}]P_{l}(\cos\theta)   \tag*{(11.2.17)}$$

将(11.2.17)式代入边界条件(11.2.14)式得

 $$ B_{l}=-a^{2l+1}A_{l},\quad l=0,1,2,\cdots $$ 

因此，解(11.2.17)式可写成

$$  v(r,\theta)=\sum_{l=0}^{\infty}A_{l}\left[r^{l}-a^{2l+1}r^{-(l+1)}\right]P_{l}(\cos\theta)   \tag*{(11.2.18)}$$

再将上式代入边界条件(11.2.15)得

$$  \sum_{l=0}^{\infty}A_{l}r^{l}P_{l}(\cos\theta)=v_{0}-E_{0}r\cos\theta   \tag*{(11.2.19)}$$

此式左边是函数  $ f(x)=v_{0}-E_{0}rx $ 以勒让德多项式  $ P_{l}(x) $ 为基本函数族的广义傅氏展开，故由(11.2.11)式和(11.2.12)式立即可得

 $$ \begin{align*}A_{l}r^{l}&=\frac{2l+1}{2}\int_{-1}^{1}(v_{0}-E_{0}rx)P_{l}(x)\mathrm{d}x\\&=\frac{2l+1}{2}\Big[v_{0}\int_{-1}^{1}P_{0}(x)P_{l}(x)\mathrm{d}x-E_{0}r\int_{-1}^{1}P_{1}(x)P_{l}(x)\mathrm{d}x\Big],\quad l=0,1,2,\cdots\end{align*} $$ 

而由正交归一公式(11.2.9)式便有

 $$ A_{0}r^{0}=v_{0};\quad A_{1}r=-E_{0}r;\quad A_{l}r^{l}=0,\quad l\neq0,1 $$ 

即

 $$ A_{0}=v_{0}；A_{1}=-E_{0}；A_{l}=0，l\neq0,1 $$ 

这样求展开系数，由于要计算积分，常常是相当麻烦的，特别是对于较复杂的函数  $ f(x) $. 事实上此题不必这样做. 重写(11.2.19)为如下形式：

<!-- page: 241 -->

$$ \begin{aligned}&A_{0}P_{0}(\cos\theta)+A_{1}r P_{1}(\cos\theta)+A_{2}r^{2}P_{2}(\cos\theta)+\cdots\\&=v_{0}P_{0}(\cos\theta)-E_{0}r P_{1}(\cos\theta)\\ \end{aligned} $$ 

比较等式两边同阶勒让德多项式的系数立即可得

 $$ A_{0}=v_{0}；A_{1}=-E_{0}；A_{l}=0,l\neq0,1 $$ 

所以用展开系数公式(11.2.12)式求展开系数除非是不得已[如，没给出 $ f(x) $的具体形式]才为之.将求得的系数 $ A_{l}(l=0,1,2,\cdots) $代入解(11.2.18)得

 $$ v(r,\theta)=v_{0}-\frac{a}{r}v_{0}-E_{0}r\cos\theta+\frac{E_{0}a^{3}}{r^{2}}\cos\theta,\quad r\geqslant a $$ 

#### 习题11.2

1. 试利用母函数关系式(11.2.7)式和递推公式(11.2.8)式导出下列递推公式：

(1)

$$  P_{l}(x)=P_{l+1}^{\prime}(x)-2xP_{l}^{\prime}(x)+P_{l-1}^{\prime}(x);   \tag*{(11.2.20)}$$

$$  (2)P_{l+1}^{\prime}(x)=x P_{l}^{\prime}(x)+(l+1)P_{l}(x);   \tag*{(11.2.21)}$$

(3)

$$  xP_{i}^{\prime}(x)-P_{i-1}^{\prime}(x)=lP_{i}(x);   \tag*{(11.2.22)}$$

(4)

$$  P_{l+1}^{\prime}(x)-P_{l-1}^{\prime}(x)=(2l+1)P_{l}(x);   \tag*{(11.2.23)}$$

$$  (5)\ (x^{2}-1)P_{l}^{\prime}(x)=lxP_{l}(x)-lP_{l-1}(x).   \tag*{(11.2.24)}$$

## 2. 计算积分

(1)

 $$ \int_{-1}^{1}x^{2}P_{t}(x)P_{t+2}(x)\mathrm{d}x; $$ 

(2)

 $$ \int_{-1}^{1}x P_{t}(x)P_{t+1}(x)\mathrm{d}x; $$ 

(3)

 $$ \int_{-1}^{1}P_{l}(x)\mathrm{d}x,l=1,2,3,\cdots; $$ 

(4)

 $$ \int_{-1}^{1}(1-x^{2})\big[P_{i}^{\prime}(x)\big]^{2}\mathrm{d}x. $$ 

3. 从(11.1.11)式出发证明

(1)

$$  P_{i}(-x)=(-1)^{i}P_{i}(x);   \tag*{(11.2.25)}$$

(2)

$$  P_{2n+1}(0)=0,P_{2n+1}^{\prime}(0)=\frac{(-1)^{n}(2n+2)!}{2^{2n+1}n!(n+1)!},   \tag*{(11.2.26)}$$

$$  P_{2n}(0)=(-1)^{n}\frac{(2n)!}{2^{2n}n!n!},\quad P_{2n}^{\prime}(0)=0\quad(n=0,1,2,\cdots)   \tag*{（11.2.27）}$$

(3)

$$  P_{l}(1)=1,P_{l}(-1)=(-1)^{l}   \tag*{（11.2.28）}$$

4. 求下列函数按勒让德多项式展开：

(1)

 $$ f(x)=x^{3} $$ 

(2)

 $$ f(x)=\left|x\right|； $$ 

(3)

 $$ f(x)=\left\{\begin{aligned}&0,&-1\leqslant&x<0\\ &x,&0\leqslant&x<1;\end{aligned}\right. $$ 

(4)

 $$ 4)f(x)=\sqrt{1-2xt+t^{2}}. $$ 

5. 设有一单位球，其边界球面上温度分布为

 $$ u\mid_{r=1}=\frac{1}{4}(\cos3\theta+3\cos\theta) $$ 

试求球内的稳定温度分布.

6. 设有一个半径为 a 的均匀介质球，介电常数为  $ \varepsilon $，在与球心距离为  $ b (b > a) $ 的地方放一点电荷  $ 4\pi\varepsilon_{0}q $，求介质球内外的电势.

7. 设有半径为 a 的导体球壳，被一层过球心的水平的绝缘薄片分隔为两个半球壳。若上、下半球壳各充电到电势为  $ v_{1} $ 和  $ v_{2} $，试求球壳内、外的电势分布。

<!-- page: 242 -->

8. 设有一个均匀的细圆环，环的半径等于 a，质量为 m，求它的引力势.

9. 求表面充电至电势为  $ v_{0}(1+2\cos\theta+3\cos^{2}\theta) $ 的单位空心球内各点的电势  $ (v_{0} $ 为常数 $ ) $.

10. 半径为 a 的半球，其球面保持恒温  $ u_{0} $，而底面温度为零度。求半球内的稳定温度分布。

11. 长为 l 的柔软匀质轻绳，一端固定在以角速度  $ \omega $ 转动的竖直轴上，由于惯性离心力的作用，弦的平衡位置为水平线。设初始位移为  $ \varphi(x) $，初始速度为  $ \psi(x) $，求解弦相对于水平线的横振动。

 $ ^{*} $12. 内半径为 a、外半径为 b 的薄圆环面均匀带电，其总电量为  $ 4\pi\varepsilon_{0}q $，将球坐标系的原点取在环心，极轴垂直于环面，求空间各点的电势.

 $$ v(r,\theta)\mid_{\theta=0}=v(r,\theta)\mid_{\theta=\pi}=\frac{2q}{b^{2}-a^{2}}(\sqrt{b^{2}+r^{2}}-\sqrt{a^{2}+r^{2}}). $$ 

13. 一半径为 a 的带电薄圆盘，其电荷密度  $ \sigma(d)=\frac{4\varepsilon_{0}v_{0}}{\pi\sqrt{a^{2}-d^{2}}} $，其中 d 为圆盘上任一点至盘心的距离， $ v_{0} $ 为常数。求空间各点的电势。

### 11.3 连带勒让德函数与球函数

在球坐标系中，当我们对拉氏方程

$$  \Delta u=0   \tag*{(11.3.1)}$$

分离变量，即令

 $$ u(r,\theta,\varphi)=R(r)y(\theta,\varphi) $$ 

$$  y(\theta,\varphi)=\Theta(\theta)\Phi(\varphi)   \tag*{（11.3.2）}$$

便可得到三个常微分方程（见第二篇8.4节）

$$  \Phi^{\prime \prime}+m^{2}\Phi=0,\quad m=0,1,2,\cdots   \tag*{（11.3.3）}$$

$$  r^{2}R^{\prime \prime}+2rR^{\prime}-l(l+1)R=0   \tag*{（11.3.4）}$$

$$  (1-x^{2})y^{\prime \prime}-2xy^{\prime}+\left[l(l+1)-\frac{m^{2}}{1-x^{2}}\right]y=0,\quad x=\cos\theta,y=\Theta(\theta)   \tag*{（11.3.5）}$$

方程（11.3.3）式和（11.3.4）式的解都是我们所熟悉的，即

$$  \Phi_{m}(\varphi)=A_{m}\cos m\varphi+B_{m}\sin m\varphi   \tag*{（11.3.6）}$$

$$  R_{l}(r)=c_{l}r^{l}+d_{l}r^{-(l+1)}   \tag*{（11.3.7）}$$

因此，只要求出连带勒让德方程(11.3.5)式的解，便可得到拉氏方程在球坐标系中的解。现在我们就来求解方程(11.3.5)。

## 1. 连带勒让德函数

由于 11.1 节中所求解过的勒让德方程(11.1.1)，是连带勒让德方程(11.3.5)在轴对称（即 m=0）情况下的特例，故我们可通过连带勒让德方程和勒让德方程的联系，来得到连带勒让德方程的解.

对于方程(11.3.5)，作变换

<!-- page: 243 -->

$$  y(x)=(1-x^{2})^{\frac{m}{2}}v(x)   \tag*{(11.3.8)}$$

则

 $$ \begin{aligned}&y^{\prime}(x)=(1-x^{2})^{\frac{m}{2}}\Big[v^{\prime}(x)-\frac{mx}{1-x^{2}}v(x)\Big]\\&y^{\prime \prime}(x)=(1-x^{2})^{\frac{m}{2}}\Big[v^{\prime \prime}(x)-\frac{2mx}{1-x^{2}}v^{\prime}(x)+\frac{m^{2}x^{2}-m-mx^{2}}{(1-x^{2})^{2}}v(x)\Big]\\ \end{aligned} $$ 

代入(11.3.5)式并将方程两边乘以 $ (1-x^{2})^{-\frac{m}{2}} $得

$$  (1-x^{2})v^{\prime \prime}-2(m+1)x v^{\prime}+\left[l(l+1)-m(m+1)\right]v=0   \tag*{(11.3.9)}$$

不难看出，这个方程正好是勒让德方程逐项微分 m 次的结果。因为对于勒让德方程

 $$ (1-x^{2})P_{l}^{\prime \prime}(x)-2x P_{l}^{\prime}(x)+l(l+1)P_{l}(x)=0 $$ 

微分一次，得

 $$ (1-x^{2})\big[P_{l}^{\prime}(x)\big]^{\prime \prime}-2x(1+1)\big[P_{l}^{\prime}(x)\big]^{\prime}+\big[l(l+1)-1(1+1)\big]P_{l}^{\prime}(x)=0 $$ 

两微分一次，得

 $$ (1-x^{2})\big[P_{l}^{\prime \prime}(x)\big]^{\prime \prime}-2x(2+1)\big[P_{l}^{\prime \prime}(x)\big]^{\prime}+\big[l(l+1)-2(2+1)\big]P_{l}^{\prime \prime}(x)=0 $$ 

于是，连续微分 m 次，可得

$$  (1-x^{2})\big[P_{l}^{(m)}(x)\big]^{\prime \prime}-2x(m+1)\big[P_{l}^{(m)}(x)\big]^{\prime}+\big[l(l+1)-m(m+1)\big]P_{l}^{(m)}(x)=0   \tag*{(11.3.10)}$$

对比(11.3.9)式和(11.3.10)式知， $ P_{l}^{(m)}(x) $ 是(11.3.9)式的一个特解，即

 $$ v(x)=P_{l}^{(m)}(x),\quad0\leqslant m\leqslant l $$ 

代入(11.3.8)式，得

 $$ y(x)=(1-x^{2})^{\frac{m}{2}}P_{l}^{(m)}(x) $$ 

记

$$  P_{l}^{m}(x)=(1-x^{2})^{\frac{m}{2}}P_{l}^{(m)}(x),\quad0\leqslant m\leqslant l   \tag*{(11.3.11)}$$

称之为 m 阶 l 次的连带勒让德函数，则得连带勒让德方程(11.3.5)的一特解为

$$  y=P_{i}^{m}(x)   \tag*{（11.3.12）}$$

显然，这个解在 $ -1\leqslant x\leqslant1 $是有界的。因为 $ m\geqslant0 $，而 $ P_{l}(x) $是一个l次多项式。这样一来，连带勒让德方程(11.3.5)和自然边界条件 $ y|_{|x|\leqslant1}= $有限值也构成本征值问题，其本征值为 $ l(l+1) $， $ l=0,1,2,\cdots $；本征函数就是连带勒让德函数 $ P_{l}^{m}(x) $。

由(11.3.11)式我们易于写出前几个 $ P_{l}^{m}(x) $，如

$$  \left.\begin{aligned}&P_{1}^{1}(x)=(1-x^{2})^{\frac{1}{2}}=\sin\theta\\ &P_{2}^{1}(x)=3(1-x^{2})^{\frac{1}{2}}x=\frac{3}{2}\sin2\theta\\ &P_{2}^{2}(x)=3(1-x^{2})=\frac{3}{2}(1-\cos2\theta)\\ &P_{3}^{1}(x)=\frac{3}{2}(1-x^{2})^{\frac{1}{2}}(5x^{2}-1)=\frac{3}{8}(\sin\theta+5\sin3\theta)\\ &P_{3}^{2}(x)=15(1-x^{2})x=\frac{15}{4}(\cos\theta-\cos3\theta)\\ \end{aligned}\right\}   \tag*{(11.3.13)}$$

等等.

<!-- page: 244 -->

根据勒让德多项式的微分表达式(11.1.14)，立即可写出连带勒让德函数的微分表达式

$$  P_{l}^{m}(x)=\frac{(1-x^{2})^{\frac{m}{2}}}{2^{l}l!}\frac{\mathrm{d}^{l+m}}{\mathrm{d}x^{l+m}}(x^{2}-1)^{l}   \tag*{(11.3.14)}$$

而由(11.3.14)式和解析函数的导数公式[第一篇(2.3.5)式]，又可写出连带勒让德函数的积分表达式.

$$  P_{l}^{m}(x)=\frac{(1-x^{2})^{\frac{m}{2}}}{2^{l}}\bullet\frac{1}{2\pi\mathrm{i}}\frac{(l+m)!}{l!}\oint_{l^{*}}\frac{(\zeta^{2}-1)^{l}}{(\zeta-x)^{l+m+1}}\mathrm{d}\zeta   \tag*{(11.3.15)}$$

其中  $ l^{*} $ 为平面中包围  $ \zeta = x $ 的回路.

（11.3.14）式虽然是在条件  $ 0 \leqslant m \leqslant l $ 下得到的，但若把（11.3.14）式中的 m 换成 -m，所得到的函数

$$  P_{l}^{-m}(x)=\frac{1}{2^{l}l!}(1-x^{2})^{-\frac{m}{2}}\frac{\mathrm{d}^{l-m}}{\mathrm{d}x^{l-m}}(x^{2}-1)^{l}   \tag*{(11.3.16)}$$

也是方程的解. 因为(11.3.5)仅依赖于 $ m^{2} $，且m是整数. 事实上可以证明, $ P_{l}^{-m}(x) $和 $ P_{l}^{m}(x) $只差一常数因子. 即

$$  P_{l}^{-m}(x)=(-1)^{m}\frac{(l-m)!}{(l+m)!}P_{l}^{m}(x),\quad0\leqslant m\leqslant l   \tag*{(11.3.17)}$$

## 2. 连带勒让德函数的性质

在勒让德多项式的基础上，我们易于导出连带勒让德函数的一系列性质。比如，利用勒让德多项式的递推公式(11.2.8)和习题11.2中的第1题(4)，便可导出连带勒让德函数的递推公式

$$  (l+1-m)P_{l+1}^{m}(x)-(2l+1)x P_{l}^{m}(x)+(l+m)P_{l-1}^{m}(x)=0   \tag*{（11.3.18）}$$

而连带勒让德函数的正交归一性表现为

$$  \int_{-1}^{1}P_{l}^{m}(x)P_{k}^{m}(x)\mathrm{d}x=\frac{(l+m)!}{(l-m)!}\frac{2}{2l+1}\delta_{kl}=(N_{l}^{m})^{2}\delta_{kl}   \tag*{(11.3.19)}$$

它可通过分部积分 m 次并利用勒让德多项式的正交归一性得到. 其中  $ N_{l}^{m} $ 称为  $ P_{l}^{m}(x) $ 的模.

类似的在区间 $ [-1,1] $上有连续的一阶导数，分段连续的二阶导数的函数 $ f(x) $，也可按连带勒让德函数进行广义的傅氏展开

$$  f(x)=\sum_{l=0}^{\infty}C_{l}^{m}P_{l}^{m}(x)   \tag*{(11.3.20)}$$

其中

$$  C_{l}^{m}=\frac{(2l+1)(l-m)!}{2(l+m)!}\int_{-1}^{1}f(x)P_{l}^{m}(x)\mathrm{d}x   \tag*{(11.3.21)}$$

由(11.3.17)式可以看出，若用-m代替m，(11.3.20)、(11.3.21)式仍然有效.

## 3. 球函数

到此为止，我们已可写出拉氏方程在球坐标系中的变量分离的解。将（11.3.6）、

<!-- page: 245 -->

(11.3.7)和(11.3.12)式一并代入(11.3.2)得到拉氏方程(11.3.1)式的一系列特解为

 $$ u_{l,m}=\Big(c_{l}r^{l}+d_{l}\frac{1}{r^{l+1}}\Big)y_{l}^{m}(\theta,\varphi) $$ 

其中

$$  y_{l}^{m}(\theta,\varphi)=P_{l}^{m}(\cos\theta)(A_{m}\cos m\varphi+B_{m}\sin m\varphi),\quad m=0,1,2,\cdots,l;l=0,1,2,\cdots   \tag*{（11.3.22）}$$

或

$$  y_{l}^{m}(\theta,\varphi)=P_{l}^{m}(\cos\theta)\mathrm{e}^{\mathrm{i}m\varphi},\quad m=0,\pm1,\pm2,\cdots,\pm l;l=0,1,2,\cdots   \tag*{（11.3.23）}$$

而

 $$ u=\sum_{m=0}^{l}\sum_{l=0}^{\infty}u_{l,m}\quad 或 \quad u=\sum_{m=-l}^{l}\sum_{l=0}^{\infty}u_{l,m} $$ 

显然， $ y_{l}^{m}(\theta,\varphi) $ 是对拉氏方程  $ \Delta u=0 $，按变量 u=R(r)Y( $ \theta $,  $ \varphi $) 进行变量分离后，所得到的本征值问题

$$  \left\{\begin{aligned}&\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}\Big(\sin\theta\frac{\partial Y}{\partial\theta}\Big)+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}Y}{\partial\varphi^{2}}+l(l+1)Y=0\\ &Y(\theta,\varphi) 单值、有限 \end{aligned}\right.   \tag*{(11.3.24)}$$

的本征函数，其本征值为： $ l(l+1)(l=0,1,2,\cdots) $ 和  $ m(m=0,\pm1,\cdots,\pm l) $.

为了应用的方便，常将(11.3.23)式所表示的  $ y_{l}^{m}(\theta,\varphi) $ 乘上  $ P_{l}^{m}(\cos\theta) $ 和  $ e^{i m\varphi} $ 的归一化常数后记为  $ Y_{l,m}(\theta,\varphi) $，即

$$  \begin{array}{r}{Y_{l,m}(\theta,\varphi)=(-1)^{m}\sqrt{\frac{2l+1}{4\pi}}\frac{(l-m)!}{(l+m)!}P_{l}^{m}(\cos\theta)\mathrm{e}^{\mathrm{i}m\varphi},}\\ {m=0,\pm1,\pm2,\cdots,\pm l;l=0,1,2,\cdots}\end{array}   \tag*{（11.3.25）}$$

并称之为 l 阶球函数. 显然，l 阶球函数在单位球面上是正交归一的，即

$$  \int_{0}^{\pi}\int_{0}^{2\pi}Y_{l,m}(\theta,\varphi)\overline{Y}_{l^{\prime},m^{\prime}}(\theta,\varphi)\sin\theta\mathrm{d}\varphi\mathrm{d}\theta=\delta_{mm^{\prime}}\delta_{ll^{\prime}}   \tag*{（11.3.26）}$$

其中  $ \bar{Y}_{l,m} $ 是  $ Y_{l,m} $ 的共轭复数，且

$$  \overline{Y}_{l,m}=(-1)^{m}Y_{l,-m}   \tag*{(11.3.27)}$$

(11.3.27)式可由(11.3.17)式证得.

独立的l阶球函数共有2l+1个，这由定义(11.3.25)立即可看出.例如

$$  \left\{\begin{aligned}Y_{0,0}&=\frac{1}{\sqrt{4\pi}}\\ Y_{1,0}&=\sqrt{\frac{3}{4\pi}}\cos\theta,Y_{1,\pm1}=\mp\sqrt{\frac{3}{8\pi}}\sin\theta\mathrm{e}^{\pm\mathrm{i}\varphi}\\ Y_{2,0}&=\sqrt{\frac{5}{16\pi}}(3\cos^{2}\theta-1),Y_{2,\pm1}=\mp\sqrt{\frac{15}{8\pi}}\sin\theta\cos\theta\mathrm{e}^{\pm\mathrm{i}\varphi}\\ Y_{2,\pm2}&=\sqrt{\frac{15}{32\pi}}\sin^{2}\theta\mathrm{e}^{\pm\mathrm{i}2\varphi}\end{aligned}\right.   \tag*{（11.3.28）}$$

同样，定义在  $ 0 < \theta < \pi, 0 \leqslant \varphi \leqslant 2\pi $ 上的连续函数  $ f(\theta, \varphi) $，可按球函数  $ Y_{l,m} $ 进行广

<!-- page: 246 -->

义傅氏展开

$$  f(\theta,\varphi)=\sum_{m=-l}^{l}\sum_{l=0}^{\infty}C_{l,m}Y_{l,m}(\theta,\varphi)   \tag*{(11.3.29)}$$

其中

$$  C_{l,m}=\int_{0}^{\pi}\int_{0}^{2\pi}f(\theta,\varphi)\bar{Y}_{l,m}(\theta,\varphi)\sin\theta\mathrm{d}\varphi\mathrm{d}\theta   \tag*{（11.3.30）}$$

例 将  $ f(\theta,\varphi)=\cos\varphi\sin3\theta $ 按球函数展开.

解  $ \cos\varphi\sin3\theta=\sin3\theta\frac{\mathrm{e}^{\mathrm{i}\varphi}+\mathrm{e}^{-\mathrm{i}\varphi}}{2} $

由（11.3.13）式知

 $$ \sin3\theta=\frac{8}{15}P_{3}^{1}(\cos\theta)-\frac{1}{5}P_{1}^{1}(\cos\theta) $$ 

故

 $$ \begin{aligned}\cos\varphi\sin3\theta=&\left[\frac{8}{15}P_{3}^{1}(\cos\theta)-\frac{1}{5}P_{1}^{1}(\cos\theta)\right]\bullet\frac{\mathrm{e}^{\mathrm{i}\varphi}+\mathrm{e}^{-\mathrm{i}\varphi}}{2}\\ =&\frac{4}{15}P_{3}^{1}(\cos\theta)\mathrm{e}^{\mathrm{i}\varphi}+\frac{4}{15}P_{3}^{1}(\cos\theta)\mathrm{e}^{-\mathrm{i}\varphi}-\frac{1}{10}P_{1}^{1}(\cos\theta)\mathrm{e}^{\mathrm{i}\varphi}-\frac{1}{10}P_{1}^{1}(\cos\theta)\mathrm{e}^{-\mathrm{i}\varphi}\\ =&\frac{4}{15}\sqrt{\frac{4\pi}{6+1}\bullet\frac{4!}{2!}}Y_{3,1}(\theta,\varphi)+\frac{4}{15}\sqrt{\frac{4\pi}{7}\bullet\frac{4!}{2!}}Y_{3,-1}(\theta,\varphi)\\ &+\frac{1}{10}\sqrt{\frac{4\pi}{3}\bullet\frac{2!}{0!}}Y_{1,1}(\theta,\varphi)-\frac{1}{10}\sqrt{\frac{4\pi}{3}\bullet\frac{2!}{0!}}Y_{1,-1}(\theta,\varphi)\\ =&-\frac{16}{15}\sqrt{\frac{3\pi}{7}}Y_{3,1}(\theta,\varphi)+\frac{16}{15}\sqrt{\frac{3\pi}{7}}Y_{3,-1}(\theta,\varphi)\\ &+\frac{1}{5}\sqrt{\frac{2\pi}{3}}Y_{1,1}(\theta,\varphi)-\frac{1}{5}\sqrt{\frac{2\pi}{3}}Y_{1,-1}(\theta,\varphi)\end{aligned} $$ 

最后两步，用到了公式（11.3.25）和（11.3.17）。当然，我们也可用展开系数公式（11.3.30）式求上述函数的球函数展开。

球函数在物理学中有着广泛应用，如在量子力学中，角动量平方算符

 $$ \hat{L}^{2}=-\hbar^{2}\Big[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}\big(\sin\theta\frac{\partial}{\partial\theta}\big)+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}}{\partial\varphi^{2}}\Big] $$ 

的本征值方程为

 $$ -\hbar^{2}\left[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}\left(\sin\theta\frac{\partial}{\partial\theta}\right)+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}}{\partial\varphi^{2}}\right]Y(\theta,\varphi)=\lambda\hbar^{2}Y(\theta,\varphi) $$ 

故其本征函数

 $$ Y(\theta,\varphi)=Y_{l,m}(\theta,\varphi),\quad m=0,\pm1,\cdots,\pm l;l=0,1,2,\cdots $$ 

就是球函数.

<!-- page: 247 -->

#### 习题11.3

1. 用球函数把下列函数展开：

(1)  $ 3\sin^{2}\theta\cos^{2}\varphi $; (2)  $ (1+3\cos\theta)\sin\theta\cos\varphi $.

2. 有一均匀的球体，球心在原点，在球面上温度为

(1) $ u\big|_{r-a}=u_{0}\cos\theta(1-\cos\theta) $; (2) $ u\big|_{r-a}=\cos\varphi\sin3\theta $.

试在稳定状态下，分别就这两种边界条件求球内的温度分布.

3. 试利用  $ P_{l}^{m}(x) $ 的递推公式，证明球函数的递推公式

(1)

$$  \begin{array}{r}{\sin\theta\mathrm{e}^{\mathrm{i}\varphi}Y_{l,m}=\sqrt{\frac{(l-m+1)(l-m-1)}{(2l+1)(2l-1)}}Y_{l-1,m+1}-\sqrt{\frac{(l+m+1)(l+m+2)}{(2l+1)(2l+3)}}Y_{l+1,m+1};}\end{array}   \tag*{(11.3.31)}$$

(2)

$$  \begin{align*}\sin\theta e^{-i\varphi}Y_{l,m}=-\sqrt{(l+m)(l+m-1)}\;Y_{l-1,m-1}+\sqrt{(l-m+1)(l-m+2)}\;Y_{l+1,m-1}.\end{align*}   \tag*{（11.3.32）}$$

 $ ^{*} $4. 试证球函数的加法公式

$$  \begin{align*}P_{l}(\cos\gamma)&=\sum_{m=-l}^{l}(-1)^{m}P_{l}^{m}(\cos\theta)P_{l}^{-m}(\cos\theta^{\prime})\mathrm{e}^{\mathrm{i}m(\varphi-\varphi^{\prime})}\\&=\sum_{m=-1}^{l}\frac{(l-m)!}{(l+m)!}P_{l}^{m}(\cos\theta)P_{l}^{m}(\cos\theta^{\prime})\mathrm{e}^{\mathrm{i}m(\varphi-\varphi^{\prime})}\\&=P_{l}(\cos\theta)P_{l}(\cos\theta^{\prime})+2\sum_{m=1}^{l}\frac{(l-m)!}{(l+m)!}\cdot P_{l}^{m}(\cos\theta)P_{l}^{m}(\cos\theta^{\prime})\cos m(\varphi-\varphi^{\prime})\end{align*}   \tag*{(11.3.33)}$$

其中

 $$ \cos\gamma=\cos\theta\cos\theta^{\prime}+\sin\theta\sin\theta^{\prime}\cos(\varphi-\varphi^{\prime}) $$ 

 $ \gamma $ 是 OP (方向为  $ \theta, \varphi $) 与改变了方向后的极轴 OP' (方向为  $ \theta', \varphi' $) 之间的夹角 (见图 11.3).

<div style="text-align: center;"><img src="images/p0247_img_in_image_box_97_838_378_1056.jpg" alt="图11.3" width="29%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图11.3</div> </div>


5. 证明： $ P_{l}^{2n}(x)(n=0,\pm1,\pm2,\cdots,\pm n_{m}) $ 是多项式，而  $ P_{l}^{2k-1}(x)(k=0,\pm1,\pm2,\cdots,\pm k_{m}) $ 不是多项式，其中  $ n_{m}=\left\{\begin{aligned}&\frac{l}{2},& 当 l 为偶数 \\ &\frac{l-1}{2},& 当 l 为奇数\end{aligned}\right. $； $ k_{m}=\left\{\begin{aligned}&\frac{l}{2},& 当 l 为偶数 \\ &\frac{l+1}{2},& 当 l 为奇数\end{aligned}\right. $

6. 试求解微观粒子的宋太薛宗遇方程

 $$ -\frac{\hbar^{2}}{z\mu}\Delta\psi(r,\theta,\varphi)+v(r)\psi(r,\theta,\varphi)=E\psi(r,\theta,\varphi) $$ 

其中， $ \mu $ 是粒子质量， $ \psi $ 是定态波函数， $ v(r) $ 是给定的中心势场，E 是能量.

<!-- page: 248 -->

<!-- page: 249 -->

## 第十二章 贝塞尔函数

在第二篇第八章中我们曾通过在柱坐标系中对亥姆霍兹方程和拉氏方程分离变量而得到了关于变量 $ \rho $的贝塞尔方程[见第二篇(8.4.16)式]

 $$ x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-n^{2})y=0 $$ 

其中， $ x=k\rho, y=R(\rho) $，而  $ k^{2}=\lambda-\mu $（或  $ -\mu $，当  $ \lambda=0 $ 时）是大于或等于零的常数，n=0,1,2, $ \cdots $。更一般有

 $$ x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-\nu^{2})y=0 $$ 

其中  $ \nu $ 为任意实数。本章将在 x=0 的邻域求解贝塞尔方程，并着重讨论其特解贝塞尔函数（一种特殊函数）所具有的性质。为了便于类比和掌握，基本采取类似于上一章的讨论顺序。

### 12.1 贝塞尔函数

## 1. 贝塞尔方程的级数解

由于 x=0 为贝塞尔方程

$$  x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-\nu^{2})y=0   \tag*{(12.1.1)}$$

的正则奇点，故在 x=0 的邻域内，可设其解 $ ^{①} $为

$$  y=x^{\rho}\sum_{k=0}^{\infty}c_{k}x^{k}=\sum_{k=0}^{\infty}c_{k}x^{\rho+k}   \tag*{(12.1.2)}$$

代入方程(12.1.1)得

 $$ \sum_{k=0}^{\infty}(k+\rho)(k+\rho-1)c_{k}x^{k+\rho}+\sum_{k=0}^{\infty}(k+\rho)c_{k}x^{k+\rho}+\sum_{k=0}^{\infty}c_{k}x^{k+\rho+2}-\nu^{2}\sum_{k=0}^{\infty}c_{k}x^{k+\rho}=0 $$ 

即

$$  \sum_{k=0}^{\infty}\left[(k+\rho)^{2}-\nu^{2}\right]c_{k}x^{k+\rho}+\sum_{k=0}^{\infty}c_{k}x^{k+\rho+2}=0   \tag*{(12.1.3)}$$

令方程左边 x 的最低次幂项  $ x^{\rho} $ 的系数为零得

 $$ (\rho^{2}-\nu^{2})c_{0}=0 $$ 

取 $ c_{0}\neq0 $，则得指标方程

$$  \rho^{2}-\nu^{2}=0   \tag*{(12.1.4)}$$

由此求得指标

 $$ \rho_{1}=\nu,\quad\rho_{2}=-\nu $$

<!-- page: 250 -->

先取  $ \rho=\rho_{1}=\nu $，并设  $ \nu>0 $，令

$$  y_{1}=\sum_{k=0}^{\infty}c_{k}x^{k+\nu}   \tag*{(12.1.5)}$$

代入方程(12.1.1)，则由(12.1.3)式有

 $$ \sum_{k=0}^{\infty}\left[(k+\nu)^{2}-\nu^{2}\right]c_{k}x^{k+\nu}+\sum_{k=0}^{\infty}c_{k}x^{k+\nu+2}=0 $$ 

令各次幂的系数为零，则得

 $$ \begin{aligned}&(\nu^{2}-\nu^{2})c_{0}=0\\ &[(\nu+1)^{2}-\nu^{2}]c_{1}=0\\ &\quad\cdots\cdots\\ &[(\nu+k)^{2}-\nu^{2}]c_{k}+c_{k-2}=0\\ \end{aligned} $$ 

由此得一组系数递推公式

 $$ \begin{aligned}c_{0}&\neq0&c_{1}&=0[ 因为 (\nu+1)^{2}-\nu^{2}>0]\\c_{2}&=-\frac{1}{2(2\nu+2)}c_{0}&c_{3}&=-\frac{1}{3(2\nu+3)}c_{1}=0\\c_{4}&=-\frac{1}{4(2\nu+4)}c_{2}&c_{5}&=0\\&=(-1)^{2}\frac{1}{4\cdot2(2\nu+4)(2\nu+2)}c_{0}\\&=(-1)^{2}\frac{1}{2^{4}\cdot2(\nu+2)(\nu+1)}c_{0}\end{aligned} $$ 

于是有

 $$ \begin{aligned}c_{2n}&=-\frac{1}{2n(2\nu+2n)}c_{2n-2}=(-1)^{n}\frac{1}{2^{2n}n!(\nu+n)(\nu+n-1)\cdots(\nu+1)}c_{0}\\&=(-1)^{n}\frac{c_{0}\Gamma(\nu+1)}{2^{2n}n!\Gamma(\nu+n+1)}\end{aligned} $$ 

 $$ c_{2n+1}=0 $$ 

其中n=1,2, $ \cdots $.

将以上系数代入(12.1.5)式得贝塞尔方程的一个特解

 $$ y_{1}(x)=\sum_{k=0}^{\infty}c_{k}x^{k+\nu}=c_{0}x^{\nu}+\sum_{n=1}^{\infty}c_{2n}x^{2n+\nu}=\sum_{n=0}^{\infty}\frac{(-1)^{n}c_{0}\Gamma(\nu+1)}{2^{2n}n!\Gamma(\nu+n+1)}x^{2n+\nu} $$ 

类似地，若令

 $$ y_{2}(x)=\sum_{k=0}^{\infty}c_{k}x^{k-v} $$ 

则可得贝塞尔方程的另一特解

 $$ y_{2}(x)=\sum_{n=0}^{\infty}\frac{(-1)^{n}c_{0}\Gamma(-\nu+1)}{2^{2n}n!\Gamma(-\nu+n+1)}x^{2n-\nu} $$

<!-- page: 251 -->

## 2. 解的敛散性

由于 x=0 是方程的正则奇点，方程的另一奇点是  $ x=\infty $，故级数解  $ y_{1}(x) $ 的收敛范围是  $ 0\leqslant|x|<\infty $，而级数解  $ y_{2}(x) $ 的收敛范围是  $ 0<|x|<\infty $。

## 3. 贝塞尔函数

为了方便及与其他理论一致起见，在上述贝塞尔方程的特解  $ y_{1}(x) $ 中，选  $ c_{0}=\frac{1}{2^{\nu}\Gamma(\nu+1)} $ 并记  $ y_{1}(x) $ 为  $ \mathrm{J}_{\nu}(x) $，称之为  $ \nu $ 阶的贝塞尔函数，则

$$  y_{1}(x)=\mathrm{J}_{\nu}(x)=\sum_{k=0}^{\infty}(-1)^{k}\frac{1}{k!\Gamma(\nu+k+1)}\Big(\frac{x}{2}\Big)^{2k+\nu}   \tag*{(12.1.6)}$$

类似的，对于特解  $ y_{2}(x) $，若选  $ c_{0}=\frac{1}{2-\nu}\Gamma(-\nu+1) $，并记  $ y_{2}(x) $ 为  $ \mathrm{J}_{-\nu}(x) $，称之为一 $ \nu $ 阶的贝塞尔函数，则

$$  y_{2}(x)=\mathrm{J}_{\neg}(x)=\sum_{k=0}^{\infty}(-1)^{k}\frac{1}{k!\Gamma(-\nu+k+1)}\Big(\frac{x}{2}\Big)^{2k\neg}   \tag*{(12.1.7)}$$

 $ \mathrm{J}_{\nu}(x) $ 和  $ \mathrm{J}_{-\nu}(x) $ 又均称为第一类柱函数.

显然，若  $ \nu \neq n $（整数）， $ J_{\nu}(x) $ 和  $ J_{-\nu}(x) $ 是线性无关的。因为当  $ x \to 0 $ 时，

类似的

 $$ \begin{aligned}\mathrm{J}_{\nu}(x)=\left(\frac{x}{2}\right)^{\nu}\sum_{k=0}^{\infty}(-1)^{k}\frac{1}{k!\Gamma(\nu+k+1)}\Big(\frac{x}{2}\Big)^{2k}\sim\left(\frac{x}{2}\right)^{\nu}\frac{1}{\Gamma(\nu+1)}\\ \mathrm{J}_{\neg}(x)\sim\left(\frac{x}{2}\right)^{\neg}\frac{1}{\Gamma(-\nu+1)}\rightarrow\infty\\ \frac{\mathrm{J}_{\nu}(x)}{\mathrm{J}_{\neg}(x)}\sim\left(\frac{x}{2}\right)^{2\nu}\frac{\Gamma(-\nu+1)}{\Gamma(\nu+1)}\neq 常数 \end{aligned} $$ 

所以

故此时贝塞尔方程的通解可表示为

$$  y(x)=a_{\nu}\mathrm{J}_{\nu}(x)+b_{\nu}\mathrm{J}_{\neg\nu}(x)   \tag*{(12.1.8)}$$

其中  $ a_{v}, b_{v} $ 为任意常数（注意到问题的有限性，所以在研究柱体内部的解时应将  $ J_{-v}(x) $ 舍去。）

若  $ \nu=n $，则  $ \mathrm{J}_{n}(x) $ 和  $ \mathrm{J}_{-n}(x) $ 是线性相关的。因为

 $$ \mathrm{J}_{-n}(x)=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!\Gamma(-n+k+1)}\Big(\frac{x}{2}\Big)^{2k-n} $$ 

而由  $ \Gamma $ 函数的定义知  $ -n+k+1 $ 应大于零即 k>n-1，故

 $$ \mathrm{J}_{-n}(x)=\sum_{k=n}^{\infty}\frac{(-1)^{k}}{k!\Gamma(-n+k+1)}\Big(\frac{x}{2}\Big)^{2k-n} $$ 

令 k-n=l，则 k=n+l。

 $$ \mathrm{J}_{-n}(x)=\sum_{l=0}^{\infty}\frac{(-1)^{l+n}}{(l+n)!\Gamma(l+1)}\Big(\frac{x}{2}\Big)^{2l+n} $$

<!-- page: 252 -->

$$  \begin{aligned}&=(-1)^{n}\sum_{l=0}^{\infty}\frac{(-1)^{l}}{l!\Gamma(l+n+1)}\Big(\frac{x}{2}\Big)^{2l+n}\\&=(-1)^{n}\mathrm{J}_{n}(x)\end{aligned}   \tag*{(12.1.9)}$$

可见正、负 n 阶的贝塞尔函数只差一个常数因子，它们不能组合为通解，我们应按常微分方程的级数解法去寻求另一与  $ \mathrm{J}_{n}(x) $ 线性无关的解，即令

 $$ y_{2}(x)=a\mathrm{J}_{n}(x)\ln x+x^{-\nu}\sum_{k=0}^{\infty}d_{k}x^{k} $$ 

代入方程(12.1.1)去具体确定各常数和系数.但这样作其计算是相当麻烦和冗长的，在此我们不这样作，而将在12.3节中定义诺伊曼函数 $ N_{n}(x) $作为与 $ \mathrm{J}_{n}(x) $线性无关的解.我们将会看到， $ N_{n}(x) $在x=0是无限的.

由（12.1.6）式有

$$  \mathrm{J}_{n}(x)=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!(n+k)!}\Big(\frac{x}{2}\Big)^{2k+n}   \tag*{(12.1.10)}$$

整数阶的贝塞尔函数比较重要，特别是  $ \mathrm{J}_{0}(x) $ 和  $ \mathrm{J}_{1}(x) $，在应用上经常遇到，因此数学家已将它们的值制作成表（见数学手册）。

## 4. 本征值问题

现在我们来讨论由在柱坐标系中对亥姆霍兹方程（或拉氏方程）分离变量所得到的贝塞尔方程在柱体内的本征值问题. 即

$$  \left\{\begin{aligned}&\rho^{2}R^{\prime \prime}+\rho R^{\prime}+(k^{2}\rho^{2}-n^{2})R=0,\quad0<\rho<a\\ &R(\rho)\mid_{\rho=0}\rightarrow 有限 \\ &\left[\alpha\frac{\mathrm{d}R}{\mathrm{d}\rho}+\beta R\right]_{\rho=a}=0\end{aligned}\right.   \tag*{(12.1.11)}$$

其中 $ k^{2}=\lambda-\mu $（或 $ -\mu $）是待定常数； $ n=0,1,2,\cdots;R(\rho)|_{\rho=0}\rightarrow $有限，是自然边界条件； $ \alpha $和 $ \beta $是常数。当 $ \alpha=0 $或 $ \beta=0 $或 $ \alpha,\beta $均不为0时分别表示方程在 $ \rho=a $端附有第一、第二、第三类齐次边界条件。由自然边界条件 $ R(\rho)|_{\rho=0}\rightarrow $有限，立即可得方程(12.1.11)的解为

$$  R(\rho)=\mathrm{J}_{n}(k\rho)   \tag*{(12.1.12)}$$

下面仅就在  $ \rho=a $ 端具有第一类边界条件

$$  R(a)=0   \tag*{(12.1.13)}$$

的情况进行讨论.

由（12.1.10）式，可得

 $$ \begin{aligned}\mathrm{J}_{0}(x)=&1-\left(\frac{x}{2}\right)^{2}+\frac{1}{(2!)^{2}}\Big(\frac{x}{2}\Big)^{4}-\frac{1}{(3!)^{2}}\Big(\frac{x}{2}\Big)^{6}\\ &+\cdots+\frac{(-1)^{k}}{(k!)^{2}}\Big(\frac{x}{2}\Big)^{2k}+\cdots\end{aligned} $$

<!-- page: 253 -->

$$ \begin{aligned}\mathrm{J}_{1}(x)=&\frac{x}{2}-\frac{1}{2!}\Big(\frac{x}{2}\Big)^{3}+\frac{1}{2!3!}\Big(\frac{x}{2}\Big)^{5}-\frac{1}{3!4!}\Big(\frac{x}{2}\Big)^{7}\\ &+\cdots+\frac{(-1)^{k}}{(k!)(k+1)!\Big(\frac{x}{2}\Big)^{2k+1}}+\cdots\end{aligned} $$ 

<div style="text-align: center;"><img src="images/p0253_img_in_image_box_98_263_410_417.jpg" alt="图12.1" width="32%" /></div>


它们分别是 x 的偶函数和奇函数。在图 12.1 中，画出了  $ \mathrm{J}_{0}(x) $ 和  $ \mathrm{J}_{1}(x) $ 当 x>0 时的图形；x<0 的图形可以分别根据  $ \mathrm{J}_{0}(x) $ 和  $ \mathrm{J}_{1}(x) $ 的奇偶性得到。由此图形可以看出， $ \mathrm{J}_{n}(x) $ 是一个衰减振荡函数， $ \mathrm{J}_{n}(x) $ 的图线与 x 轴有无穷多个交点，即  $ \mathrm{J}_{n}(x)=0 $ 有无穷多个实数根。我们称之为  $ \mathrm{J}_{n}(x) $ 的零点，并记作  $ x_{m}^{n} $，表示 n 阶贝塞尔

<div style="text-align: center;"><div style="text-align: center;">图12.1</div> </div>


函数的第m个零点. 由图12.1我们大致可看出 $ J_{0}(x) $的零点分别为二点几、五点几、八点几等等. 事实上 $ \mathrm{J}_{0}(x) $和 $ \mathrm{J}_{1}(x) $的零点值，数学家也已将之制作成了表. $ \mathrm{J}_{0}(x) $和 $ \mathrm{J}_{1}(x) $的前八个零点为



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>m</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td><td style='text-align: center; word-wrap: break-word;'>7</td><td style='text-align: center; word-wrap: break-word;'>8</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{m}^{0} $</td><td style='text-align: center; word-wrap: break-word;'>2.4048</td><td style='text-align: center; word-wrap: break-word;'>5.5201</td><td style='text-align: center; word-wrap: break-word;'>8.6537</td><td style='text-align: center; word-wrap: break-word;'>11.7915</td><td style='text-align: center; word-wrap: break-word;'>14.9309</td><td style='text-align: center; word-wrap: break-word;'>18.0711</td><td style='text-align: center; word-wrap: break-word;'>21.2116</td><td style='text-align: center; word-wrap: break-word;'>24.3525</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{m}^{1} $</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>3.8317</td><td style='text-align: center; word-wrap: break-word;'>7.0156</td><td style='text-align: center; word-wrap: break-word;'>10.1735</td><td style='text-align: center; word-wrap: break-word;'>13.3237</td><td style='text-align: center; word-wrap: break-word;'>16.4706</td><td style='text-align: center; word-wrap: break-word;'>19.6159</td><td style='text-align: center; word-wrap: break-word;'>22.7601</td></tr></table>

了解了  $ J_{n}(x) $ 的零点的存在，则由边界条件（12.1.13）式立即可得

 $$ ka=x_{m}^{n} $$ 

故本征值问题(12.1.11)、(12.1.13)式的本征值为

$$  k_{m}^{n}=\frac{x_{m}^{n}}{a}   \tag*{(12.1.14)}$$

而相应的本征函数为

$$  R(\rho)=\mathrm{J}_{n}(k_{m}^{n}\rho)=\mathrm{J}_{n}\left(\frac{x_{m}^{n}}{a}\rho\right)   \tag*{(12.1.15)}$$

至于其他两类边值问题，也可完全按照以上的方法，求得其本征值和本征函数，如在第二类边界条件

 $$ R^{^{\prime}}(a)=0 $$ 

下，方程(12.1.11)的本征值和本征函数分别为

$$  \tilde{k}_{m}^{n}=\frac{\tilde{x}_{m}^{n}}{a},\quad R(\rho)=\mathrm{J}_{n}\left(\frac{\tilde{x}_{m}^{n}}{a}\rho\right)   \tag*{(12.1.16)}$$

其中  $ \tilde{x}_{m}^{n} $ 是  $ \mathrm{J}_{n}^{\prime}(k\rho) $ 的零点.

① 对于本篇 11.1 节附注中的方程(11.1.16)，即

$$  \begin{align*}w''(z)+p(z)w'(z)+q(z)w(z)=0\end{align*}   \tag*{（11.1.16）}$$

若  $ z=z_{0} $ 是它的奇点[即在  $ z_{0} $ 点 p(z) 和 q(z) 之一或均不解析]，且是 p(z) 不高于一阶的极点 q(z) 不高于二阶的极点，则称  $ z_{0} $ 为该方程的正则奇点.

在正则奇点  $ z=z_{0} $ 的邻域  $ 0<|z-z_{0}|<R $ 内，方程（11.1.16）至少有一个形式为  $ w(z)= $

<!-- page: 254 -->

$ (z-z_{0})^{\rho}\sum_{k=0}^{n}c_{k}(z-z_{0})^{k} $ 的正则解. 将此正则解代入方程(11.1.16),通过比较方程两边最低次幂项的系数[即让方程左边 $ (z-z_{0}) $的最低次幂的系数为零],便可得到一关于 $ \rho $的二次方程,称为指标方程(或判别方程),由此方程可求得两个指标(即二次方程的两个根): $ \rho=\rho_{1},\rho=\rho_{2} $(设 $ \rho_{1}>\rho_{2} $).那么,方程(11.1.16)的两线性无关解为

$$  w_{1}(z)=(z-z_{0})^{\rho_{1}}\sum_{k=0}^{\infty}c_{k}(z-z_{0})^{k}   \tag*{(12.1.17)}$$

$$  \int\left(z-z_{0}\right)^{p_{2}}\sum_{k=0}^{+\infty}d_{k}\left(z-z_{0}\right)^{k},\quad\rho_{1}-\rho_{2}\neq\frac{1}{2}   \tag*{（12.1.18）}$$

$$  w_{2}(z)=\left\{\begin{aligned}_{k=0}\\ arw_{1}(z)\ln(z-z_{0})+(z-z_{0})^{\rho_{2}}\sum_{k=0}^{\infty}d_{k}^{\prime}(z-z_{0})^{k},\quad\rho_{1}-\rho_{2}= 整数 \end{aligned}\right.   \tag*{(12.1.19)}$$

其中  $ \rho_{1},\rho_{2},a,c_{k},d_{k},d_{k}^{\prime} $ 为常数，由将形式解代入方程 (11.1.16) 中逐个确定（参见参考文献 [5], 98 节）.

#### 习题12.1

1. 量子力学中的氢原子问题，当用球坐标分离变量后，其波函数的径向方程是拉盖尔（Laguerre）方程。试在 x=0 的邻域求拉盖尔方程

 $$ xy^{\prime \prime}+(1-x)y^{\prime}+\lambda y=0 $$ 

的级数解. $ \lambda $ 取什么数值可使级数退化为多项式？这些多项式乘以适当常数使最高幂项成为 $ (-x)^{n} $ 形式，叫做拉盖尔多项式，记作 $ \mathrm{L}_{n}(x) $.写出前几个 $ \mathrm{L}_{n}(x) $.

2. 在 x=0 的邻域内求解下列方程：

(1)

 $$ x^{2}y^{\prime\prime}+xy^{\prime}+\left(x^{2}-\frac{1}{4}\right)y=0; $$ 

(2)

 $$ 2x^{2}y^{\prime \prime}-xy^{\prime}+(1-x^{2})y=0; $$ 

 $$ xy^{\prime\prime}-xy^{\prime}+y=0； $$ 

(4)

 $$ x^{2}y^{\prime\prime}-2y=0； $$ 

（5）

 $$ xy^{\prime \prime}+2y^{\prime}+m^{2}xy=0； $$ 

(6)

 $$ xy^{\prime\prime}+y^{\prime}+xy=0. $$ 

3. 求勒让德方程

 $$ (1-x^{2})y^{\prime \prime}-2xy^{\prime}+l(l+1)y=0 $$ 

在x=1的有界解.

### 12.2 贝塞尔函数的性质

## 1.  $ \mathrm{J}_{n}(x) $ 的母函数

对于整数阶的贝塞尔函数，有如下的母函数关系式：

$$  \mathrm{e}^{\frac{x}{2}\left(t-\frac{1}{t}\right)}=\sum_{n=-\infty}^{\infty}\mathrm{J}_{n}(x)t^{n}   \tag*{(12.2.1)}$$

证 因为

$$  \mathrm{e}^{\frac{x}{2}t}=\sum_{l=0}^{\infty}\frac{1}{l!}\left(\frac{xt}{2}\right)^{l},\quad\mid t\mid<\infty   \tag*{(12.2.2)}$$

$$  \mathrm{e}^{-\frac{x}{2t}}=\sum_{m=0}^{\infty}\frac{1}{m!}\left(-\frac{x}{2t}\right)^{m},\quad\mid t\mid>0   \tag*{(12.2.3)}$$

<!-- page: 255 -->

对于固定的 x，以上二级数在  $ 0<|t|< \infty $ 都是绝对收敛的，故可逐次相乘，即

 $$ \mathrm{e}^{\frac{x}{2}\left(t-\frac{1}{t}\right)}=\sum_{l=0}^{\infty}\frac{1}{l!}\left(\frac{xt}{2}\right)^{l}\bullet\sum_{m=0}^{\infty}\frac{1}{m!}\left(-\frac{x}{2t}\right)^{m} $$ 

注意到相乘后 t 的幂次数是可能大于、等于和小于零的，为了得到乘积中的 t 的正幂项  $ t^{n}(n \geqslant 0) $，我们应取 (12.2.3) 式中所有各项而分别用 (12.2.2) 式中  $ l = m + n $ 项去乘；为了得到乘积中 t 的负幂项  $ t^{-k}(k > 0) $，应取 (12.2.2) 式中所有各项而分别用 (12.2.3) 式中  $ m = k + l $ 项去乘，于是

 $$ \mathrm{e}^{\frac{x}{2}\left(t-\frac{1}{l}\right)}=\sum_{n=0}^{\infty}\left[\sum_{m=0}^{\infty}\frac{(-1)^{m}}{(m+n)!m!}\left(\frac{x}{2}\right)^{2m+n}\right]t^{n}+\sum_{k=1}^{\infty}\left[\sum_{l=0}^{\infty}\frac{(-1)^{k+l}}{(k+l)!l!}\left(\frac{x}{2}\right)^{2l+k}\right]t^{-k} $$ 

将上式第二项中的 -k 改作 n, l 改作 m, 则

 $$ \begin{align*}\mathrm{e}^{\frac{x}{2}(t-1)}=&\sum_{n=0}^{\infty}\biggl[\sum_{m=0}^{\infty}\frac{(-1)^{m}}{(m+n)!m!}\biggl(\frac{x}{2}\biggr)^{2m+n}\biggr]t^{n}\\&+\sum_{n=-1}^{\infty}(-1)^{n}\biggl[\sum_{m=0}^{\infty}\frac{(-1)^{m}}{(m-n)!m!}\biggl(\frac{x}{2}\biggr)^{2m-n}\biggr]t^{n}\\=&\sum_{n}^{\infty}\mathrm{J}_{n}(x)t^{n}\end{align*} $$ 

即，(12.2.1)式得证.最后一步用到了(12.1.10)式和(12.1.9)式.

由此关系和洛朗级数的系数公式[见第一篇(3.4.3)式]，立即可得到 $ J_{n}(x) $的一种积分表达式

$$  \mathrm{J}_{n}(x)=\frac{1}{2\pi\mathrm{i}}\oint_{l}\frac{\mathrm{e}^{\frac{x}{2}\left(t-\frac{1}{t}\right)}}{t^{n+1}}\mathrm{d}t   \tag*{(12.2.4)}$$

其中 l 为绕 t=0 的任一闭曲线. 若取 l 为单位圆  $ \left|t\right|=1 $，则在  $ \left|t\right|=1 $ 上有  $ t=e^{i\theta} $，于是又有

$$  \mathrm{J}_{n}(x)=\frac{1}{2\pi}\int_{-\pi}^{\pi}\frac{\mathrm{e}^{\frac{x}{2}(\mathrm{e}^{\mathrm{i}\theta}-\mathrm{e}^{-\theta})}}{\mathrm{e}^{\mathrm{i}(n+1)\theta}}\cdot\mathrm{e}^{\mathrm{i}\theta}\mathrm{d}\theta=\frac{1}{2\pi}\int_{-\pi}^{\pi}\mathrm{e}^{\mathrm{i}(x\sin\theta-n\theta)}\mathrm{d}\theta   \tag*{（12.2.5）}$$

$$  \mathrm{J}_{n}(x)=\frac{1}{2\pi}\int_{-\pi}^{\pi}\cos(x\sin\theta-n\theta)\mathrm{d}\theta   \tag*{（12.2.6）}$$

(12.2.5)式称为贝塞尔函数的路径积分，当n不为整数时，此式也成立. 利用贝塞尔函数的路径积分，可研究贝塞尔函数当变量甚大时的渐近行为 $ ^{①} $

$$  \mathrm{J}_{\nu}(x)\sim\sqrt{\frac{2}{\pi x}}\mathrm{c o s}\left(x-\frac{\nu\pi}{2}-\frac{\pi}{4}\right),\quad\mid x\mid\rightarrow\infty   \tag*{(12.2.7)}$$

## 2. 递推公式

我们当然可以如同上章中一样，利用母函数关系式(12.2.1)，而推得整数阶的贝塞尔函数的递推公式。但为了得到任意阶贝塞尔函数的递推公式，我们将从贝塞尔函数的级数表达式(12.1.6)出发进行推导。将(12.1.6)两边乘上 $ x^{v} $后对x求导得

<!-- page: 256 -->

$$ \begin{align*}\frac{\mathrm{d}}{\mathrm{d}x}\big[x^{\nu}\mathrm{J}_{\nu}(x)\big]&=\frac{\mathrm{d}}{\mathrm{d}x}\bigg[2^{\nu}\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!\Gamma(\nu+k+1)}\bigg(\frac{x}{2}\bigg)^{2(k+\nu)}\bigg]\\&=2^{\nu}\sum_{k=0}^{\infty}\frac{(-1)^{k}(k+\nu)}{k!\Gamma(\nu+k+1)}\bigg(\frac{x}{2}\bigg)^{2(k+\nu)-1}\\&=x^{\nu}\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!\Gamma(\nu+k)}\bigg(\frac{x}{2}\bigg)^{2k+\nu-1}\end{align*} $$ 

即

$$  \frac{\mathrm{d}}{\mathrm{d}x}\left[x^{\nu}\mathrm{J}_{\nu}(x)\right]=x^{\nu}\mathrm{J}_{\nu-1}(x)   \tag*{（12.2.8）}$$

类似可证

$$  \frac{\mathrm{d}}{\mathrm{d}x}\big[x^{\neg\nu}\mathrm{J}_{\nu}(x)\big]=-x^{\neg\nu}\mathrm{J}_{\nu+1}(x)   \tag*{(12.2.9)}$$

将此二式左边的导数具体写出，并分别消去等式两边的公共因子  $ x^{\nu-1} $ 和  $ x^{-\nu-1} $ 便可得

$$  \nu\mathrm{J}_{\nu}(x)+x\mathrm{J}_{\nu}^{\prime}(x)=x\mathrm{J}_{\nu-1}(x)   \tag*{(12.2.10)}$$

$$  -\nu\mathrm{J}_{\nu}(x)+x\mathrm{J}_{\nu}^{\prime}(x)=-x\mathrm{J}_{\nu+1}(x)   \tag*{(12.2.11)}$$

消去 $ J_{v}^{\prime}(x) $，可得

$$  \mathrm{J}_{\nu-1}(x)+\mathrm{J}_{\nu+1}(x)=\frac{2\nu}{x}\mathrm{J}_{\nu}(x)   \tag*{(12.2.12)}$$

消去 $ J_{\nu}(x) $又可得

$$  \mathrm{J}_{\nu-1}(x)-\mathrm{J}_{\nu+1}(x)=2\mathrm{J}_{\nu}^{\prime}(x)   \tag*{（12.2.13）}$$

由(12.2.10)我们看到，只要知道 $ J_{\nu}(x) $和 $ J_{\nu-1}(x) $之值，便可求得 $ J_{\nu}(x) $之值；而由(12.2.11)看到，只要知道 $ J_{\nu}(x) $与 $ J_{\nu}^{\prime}(x) $之值，便可求得 $ J_{\nu+1}(x) $之值，这样我们只要利用 $ J_{0}(x) $和 $ J_{1}(x) $的函数值的表，从原则上便可求得各整数阶贝塞尔函数及其导数之值.

(12.2.8)式和(12.2.9)式的两种特殊情况，也是常常要用到的。若 $ \nu=0 $，则由(12.2.9)式有

$$  \mathrm{J}_{0}^{\prime}(x)=-\mathrm{J}_{1}(x)   \tag*{(12.2.14)}$$

若 $ \nu=1 $则由(12.2.8)有

 $$ \left.\begin{aligned}&\left[x\mathrm{J}_{1}(x)\right]^{\prime}=x\mathrm{J}_{0}(x)\\ &x\mathrm{J}_{1}(x)=\int_{0}^{x}\xi\mathrm{J}_{0}(\xi)\mathrm{d}\xi\end{aligned}\right\} $$ 

或

例1 计算积分 $ \int_{0}^{a}x^{3}\mathrm{J}_{0}(x)\mathrm{d}x $.

解

 $$ \begin{align*}\int_{0}^{a}x^{3}\mathrm{J}_{0}(x)\mathrm{d}x&=\int_{0}^{a}x^{2}\big[x\mathrm{J}_{0}(x)\big]\mathrm{d}x=\int_{0}^{a}x^{2}\big[x\mathrm{J}_{1}(x)\big]^{\prime}\mathrm{d}x\\&=\big[x^{3}\mathrm{J}_{1}(x)\big]\Big|_{0}^{a}-\int_{0}^{a}x\mathrm{J}_{1}(x)\mathrm{d}x^{2}\\&=a^{3}\mathrm{J}_{1}(a)-2\int_{0}^{a}x^{2}\mathrm{J}_{1}(x)\mathrm{d}x\end{align*} $$

<!-- page: 257 -->

$$ \begin{aligned}&=a^{3}\mathrm{J}_{1}(a)-2\int_{0}^{a}\left[x^{2}\mathrm{J}_{2}(x)\right]^{\prime}\mathrm{d}x\\&=a^{3}\mathrm{J}_{1}(a)-2a^{2}\mathrm{J}_{2}(a)\end{aligned} $$ 

这里，两次用到了递推公式(12.2.8).

## 3. 正交归一性

n 阶贝塞尔函数系  $ \left\{\mathrm{J}_{n}\left(k_{m}^{n}\rho\right)\right\}:\mathrm{J}_{n}\left(k_{1}^{n}\rho\right),\mathrm{J}_{n}\left(k_{2}^{n}\rho\right),\cdots $，在区间  $ [0,a] $ 上满足如下带权  $ \rho $ 的正交归一关系

$$  \int_{0}^{a}\rho\mathrm{J}_{n}(k_{m}^{n}\rho)\mathrm{J}_{n}(k_{l}^{n}\rho)\mathrm{d}\rho=\frac{a^{2}}{2}\big[\mathrm{J}_{n+1}(k_{l}^{n}a)\big]^{2}\delta_{m l}   \tag*{(12.2.16)}$$

证明（12.1.11）式中的贝塞尔方程又可写为

 $$ \frac{\mathrm{d}}{\mathrm{d}\rho}\big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\big)+\Big[k^{2}\rho-\frac{n^{2}}{\rho}\Big]R=0 $$ 

由于  $ \mathrm{J}_{n}(k_{m}^{n}\rho) $， $ \mathrm{J}_{n}(k_{l}^{n}\rho) $ 均为贝塞尔方程的解，故有

 $$ \begin{align*}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big[\rho\frac{\mathrm{d}\mathrm{J}_{n}(k_{m}^{n}\rho)}{\mathrm{d}\rho}\Big]+\Big[(k_{m}^{n})^{2}\rho-\frac{n^{2}}{\rho}\Big]\mathrm{J}_{n}(k_{m}^{n}\rho)&=0\\\frac{\mathrm{d}}{\mathrm{d}\rho}\Big[\rho\frac{\mathrm{d}\mathrm{J}_{n}(k_{l}^{n}\rho)}{\mathrm{d}\rho}\Big]+\Big[(k_{l}^{n})^{2}\rho-\frac{n^{2}}{\rho}\Big]\mathrm{J}_{n}(k_{l}^{n}\rho)&=0\end{align*} $$ 

将  $ \mathrm{J}_{n}(k_{l}^{n}\rho) $ 遍乘前式， $ \mathrm{J}_{n}(k_{m}^{n}\rho) $ 遍乘后式，相减之后再积分得

 $$ \begin{align*}&\big[(\boldsymbol{k}_{l}^{n})^{2}-(\boldsymbol{k}_{m}^{n})^{2}\big]\int_{0}^{a}\rho\mathrm{J}_{n}(\boldsymbol{k}_{m}^{n}\rho)\mathrm{J}_{n}(\boldsymbol{k}_{l}^{n}\rho)\mathrm{d}\rho\\=&\int_{0}^{a}\mathrm{J}_{n}(\boldsymbol{k}_{l}^{n}\rho)\frac{\mathrm{d}}{\mathrm{d}\rho}\Big[\rho\frac{\mathrm{d}\mathrm{J}_{n}(\boldsymbol{k}_{m}^{n}\rho)}{\mathrm{d}\rho}\Big]\mathrm{d}\rho-\int_{0}^{a}\mathrm{J}_{n}(\boldsymbol{k}_{m}^{n}\rho)\frac{\mathrm{d}}{\mathrm{d}\rho}\Big[\rho\frac{\mathrm{d}\mathrm{J}_{n}(\boldsymbol{k}_{l}^{n}\rho)}{\mathrm{d}\rho}\Big]\mathrm{d}\rho\\=&\left[\rho\mathrm{J}_{n}(\boldsymbol{k}_{l}^{n}\rho)\frac{\mathrm{d}\mathrm{J}_{n}(\boldsymbol{k}_{m}^{n}\rho)}{\mathrm{d}\rho}-\rho\mathrm{J}_{n}(\boldsymbol{k}_{m}^{n}\rho)\frac{\mathrm{d}\mathrm{J}_{n}(\boldsymbol{k}_{l}^{n}\rho)}{\mathrm{d}\rho}\right]\Big|_{0}^{a}=0\end{align*} $$ 

上式当 $ \rho=a $时等于零，这是因为 $ \mathrm{J}_{n}(k_{m}^{n}a)=\mathrm{J}_{n}(x_{m}^{n})=0(m=1,2,\cdots,l,\cdots) $

若  $ m \neq l $，则  $ k_{l}^{n} \neq k_{m}^{n} $，故有

 $$ \int_{0}^{a}\rho\mathrm{J}_{n}(k_{m}^{n}\rho)\mathrm{J}_{n}(k_{l}^{n}\rho)\mathrm{d}\rho=0 $$ 

若 m=l，令  $ m\to l $，即  $ k_{m}^{n}\to k_{l}^{n} $，此时有  $ \mathrm{J}_{n}(k_{l}^{n}a)=0 $，而  $ \mathrm{J}_{n}(k_{m}^{n}a)\neq0 $；于是有

 $$ \begin{align*}\int_{0}^{a}\rho\mathrm{J}_{n}(k_{m}^{n}\rho)\mathrm{J}_{n}(k_{l}^{n}\rho)\mathrm{d}\rho=&\lim_{k_{m}^{n}\to k_{l}^{n}}\frac{-a\mathrm{J}_{n}(k_{m}^{n}a)\bullet\mathrm{J}_{n}^{\prime}(k_{l}^{n}a)\bullet k_{l}^{n}}{(k_{l}^{n})^{2}-(k_{m}^{n})^{2}}\\=&\lim_{k_{m}^{n}\to k_{l}^{n}}\frac{-a^{2}\mathrm{J}_{n}^{\prime}(k_{m}^{n}a)\bullet\mathrm{J}_{n}^{\prime}(k_{l}^{n}a)\bullet k_{l}^{n}}{-2k_{m}^{n}}\\=&\frac{a^{2}}{2}\big[\mathrm{J}_{n}^{\prime}(k_{l}^{n}a)\big]^{2}\end{align*} $$ 

在上面证明过程中，由于当  $ k_{m}^{n} \rightarrow k_{l}^{n} $ 时，出现了  $ \frac{0}{0} $ 型不定式，故运用了洛必达法则。又

<!-- page: 258 -->

由（12.2.11）式有

 $$ \mathrm{J}_{n}^{\prime}(k_{l}^{n}a)=-\mathrm{J}_{n+1}(k_{l}^{n}a) $$ 

所以

 $$ \int_{0}^{a}\rho\mathrm{J}_{n}(k_{m}^{n}\rho)\mathrm{J}_{n}(k_{l}^{n}\rho)\mathrm{d}\rho=\frac{a^{2}}{2}\big[\mathrm{J}_{n+1}(k_{l}^{n}a)\big]^{2},\quad m=l $$ 

至于函数系 $ \left\{\mathrm{J}_{n}\left(\tilde{k}_{m}^{n}\rho\right)\right\} $，类似地可证明它满足如下正交归一关系：

$$  \begin{array}{r}{\displaystyle\int_{0}^{a}\rho\mathrm{J}_{n}(\tilde{k}_{m}^{n}\rho)\mathrm{J}_{n}(\tilde{k}_{l}^{n}\rho)\mathrm{d}\rho=\frac{a^{2}}{2}\bigg[1-\Big(\frac{n}{(\tilde{k}_{l}^{n}a)}\Big)^{2}\bigg]\big[\mathrm{J}_{n}(\tilde{k}_{l}^{n}a)\big]^{2}\delta_{m l}}\end{array}   \tag*{(12.2.17)}$$

## 4. 广义傅氏展开

可以证明，如果函数  $ f(\rho) $ 在区间  $ (0, a) $ 上有连续的一阶导数和分段连续的二阶导数，且  $ f(\rho) $ 在  $ (0, a) $ 上平方可积，则  $ f(\rho) $ 在  $ (0, a) $ 上可以展开为绝对且一致收敛的级数

$$  f(\rho)=\sum_{m=1}^{\infty}C_{m}\mathrm{J}_{n}(k_{m}^{n}\rho)   \tag*{(12.2.18)}$$

其中

$$  C_{m}=\frac{1}{\frac{a^{2}}{2}\mathrm{J}_{n+1}^{2}(k_{m}^{n}a)}\int_{0}^{a}\rho f(\rho)\mathrm{J}_{n}(k_{m}^{n}\rho)\mathrm{d}\rho   \tag*{(12.2.19)}$$

例2 半径为a、高为h的圆柱体，下底和侧面保持温度为零度，上底温度分布为 $ u=u_{0} $，求柱内稳定温度分布.

解 选择柱坐标系，其定解问题为

$$  \Delta u=0   \tag*{(12.2.20)}$$

$$  u\mid_{p=a}=0   \tag*{(12.2.21)}$$

$$  u\mid_{z=0}=0,u\mid_{z=h}=u_{0}   \tag*{(12.2.22)}$$

由于问题关于 z 轴对称（与  $ \varphi $ 无关），故令

$$  u(\rho,z)=R(\rho)Z(z)   \tag*{（12.2.23）}$$

代入12.2.20式得

 $$ \left\{\begin{aligned}&z^{\prime \prime}-k^{2}z=0\\ &\rho^{2}R^{\prime \prime}+\rho R^{\prime}+(k^{2}\rho^{2}-0)R=0\end{aligned}\right. $$ 

其中  $ k^{2} $ 为分离变量过程中引入的任意常数. 将边界条件(12.2.21)代入式(12.2.23)有

 $$ R(a)Z(z)=0 $$ 

即

 $$ R(a)=0 $$ 

解本征值问题

 $$ \begin{cases}\rho^{2}R^{\prime \prime}+\rho R^{\prime}+k^{2}\rho^{2}R=0\\R(a)=0\end{cases} $$ 

并注意到  $ R(0)\rightarrow $ 有限的自然边界条件，便有

 $$ R_{m}(\rho)=\mathrm{J}_{0}(k_{m}^{0}\rho) $$

<!-- page: 259 -->

其中

 $$ k_{m}^{0}=\frac{x_{m}^{0}}{a} $$ 

将  $ k=k_{m}^{0} $ 代入关于 z 的方程而得其通解为

于是得到

 $$ \begin{align*}Z_{m}&=A_{m}\mathrm{e}^{k_{m}^{0}z}+B_{m}\mathrm{e}^{-k_{m}^{0}z}\\_i=&R_{m}Z_{m}=(A_{m}\mathrm{e}^{k_{m}^{0}z}+B_{m}\mathrm{e}^{-k_{m}^{0}z})\mathrm{J}_{0}(k_{m}^{0}\rho)\end{align*} $$ 

而由边界条件  $ u|_{z=0}=0 $ 有

所以

 $$ \begin{aligned}A_{m}+B_{m}&=0\\u_{m}&=C_{m}\mathrm{sh}(k_{m}^{0}z)\mathrm{J}_{0}(k_{m}^{0}\rho)\\\iota=\sum_{m=1}^{\infty}u_{m}&=\sum_{m=1}^{\infty}C_{m}\mathrm{sh}(k_{m}^{0}z)\mathrm{J}_{0}(k_{m}^{0}\rho)\end{aligned} $$ 

而

又由边界条件  $ u|_{z=h}=u_{0} $ 有

 $$ \sum_{m=1}^{\infty}C_{m}\mathrm{sh}(k_{m}^{0}h)\mathrm{J}_{0}(k_{m}^{0}\rho)=u_{0} $$ 

故由系数公式12.2.19有

 $$ C_{m}\mathrm{s h}(k_{m}^{0}h)=\frac{\displaystyle\int_{0}^{a}\rho u_{0}\mathrm{J}_{0}(k_{m}^{0}\rho)\mathrm{d}\rho}{\frac{a^{2}}{2}\mathrm{J}_{1}^{2}(k_{m}^{0}a)} $$ 

而由公式12.2.15有

 $$ (k_{m\downarrow}^{\circ}\rho)\mathrm{J}_{\mathrm{0}}(k_{m\downarrow}^{\circ}\rho)=\frac{\mathrm{d}}{\mathrm{d}(k_{m\downarrow}^{\circ}\rho)}\big[(k_{m\uparrow}^{\circ}\rho)\mathrm{J}_{\mathrm{1}}(k_{m\uparrow}^{\circ}\rho)\big] $$ 

所以

 $$ \begin{align*}\int_{0}^{a}\rho\mathrm{J}_{0}(k_{m}^{0}\rho)\mathrm{d}\rho&=\frac{1}{(k_{m}^{0})^{2}}\int_{0}^{a}(k_{m}^{0}\rho)\mathrm{J}_{0}(k_{m}^{0}\rho)\mathrm{d}(k_{m}^{0}\rho)\\&=\frac{1}{(k_{m}^{0})^{2}}\int_{0}^{a}\frac{\mathrm{d}}{\mathrm{d}(k_{m}^{0}\rho)}\big[(k_{m}^{0}\rho)\mathrm{J}_{1}(k_{m}^{0}\rho)\big]\mathrm{d}(k_{m}^{0}\rho)\\&=\frac{1}{(k_{m}^{0})^{2}}\big[k_{m}^{0}\rho\mathrm{J}_{1}(k_{m}^{0}\rho)\big]\Big|_{0}^{a}=\frac{a}{k_{m}^{0}}\mathrm{J}_{1}(k_{m}^{0}a)\end{align*} $$ 

从而得

 $$ C_{m}=\frac{2u_{0}}{\left(\mathrm{sh}k_{m}^{0}h\right)\bullet a^{2}\mathrm{J}_{1}^{2}(k_{m}^{0}a)}\bullet\frac{a\mathrm{J}_{1}(k_{m}^{0}a)}{k_{m}^{0}}=\frac{2u_{0}}{\Big(\mathrm{sh}\frac{x_{m}^{0}}{a}h\Big)x_{m}^{0}\mathrm{J}_{1}(x_{m}^{0})} $$ 

代入(12.2.24)式，得到定解问题(12.2.20)～(12.2.22)式的解为

 $$ u=\sum_{m=1}^{\infty}\frac{2u_{0}}{x_{m}^{0}}\frac{\mathrm{sh}\frac{x_{m}^{0}}{a}z}{\mathrm{sh}\frac{x_{m}^{0}}{a}h}\frac{\mathrm{J}_{0}\left(\frac{x_{m}^{0}}{a}\rho\right)}{\mathrm{J}_{1}\left(x_{m}^{0}\right)} $$ 

最后指出，若将  $ f(\rho) $ 展开为本征函数族  $ \left\{\mathrm{J}_{n}\left(\bar{k}_{m}^{n}\rho\right)\right\} $ (m=1,2,3, $ \cdots $) 的广义傅氏级数，则当  $ n\neq0 $ 时

<!-- page: 260 -->

$$  f(\rho)=\sum_{m=1}^{\infty}C_{m}\mathrm{J}_{n}(\bar{k}_{m}^{n}\rho)   \tag*{（12.2.25）}$$

其中

$$  C_{m}=\frac{2}{a^{2}\left[1-\left(\frac{n}{\tilde{k}_{m}^{n}a}\right)^{2}\right]\left[\mathrm{J}_{n}(\tilde{k}_{m}^{n}a)\right]^{2}}\int_{0}^{a}f(\rho)\mathrm{J}_{n}(\tilde{k}_{m}^{n}\rho)\rho\mathrm{d}\rho   \tag*{（12.2.26）}$$

而当 n=0 时则为

$$  f(\rho)=c_{0}+\sum_{m=1}^{\infty}C_{m}\mathrm{J}_{0}(\tilde{k}_{m}^{0}\rho)   \tag*{(12.2.27)}$$

其中

$$  C_{0}=\frac{2}{a^{2}}\int_{0}^{a}f(\rho)\rho\mathrm{d}\rho   \tag*{（12.2.28）}$$

注 ① 用路径积分公式和最陡下降法证明，见参考文献 $ ^{[3]} $第7章.

#### 习题12.2

1. 若 v=n，试用母函数关系式（12.2.1）重新导出递推公式（12.2.12）和（12.2.13）式，由（12.2.12）和（12.2.13）式再导出（12.2.10）和（12.2.11）式.

2. 试证

(1)

 $$ \left.\begin{array}{r}\cos x=\mathrm{J}_{0}(x)+2\displaystyle\sum_{m=1}^{\infty}(-1)^{m}\mathrm{J}_{2m}(x)\\ \sin x=2\displaystyle\sum_{m=0}^{\infty}(-1)^{m}\mathrm{J}_{2m+1}(x)\end{array}\right\} $$ 

(2)

(3)

 $$ \left.\begin{array}{l}\mathrm{J}_{0}(x)+2\displaystyle\sum_{m=1}^{\infty}\mathrm{J}_{2m}(x)=1\\ 2\displaystyle\sum_{m=0}^{\infty}(2m+1)\mathrm{J}_{2m+1}(x)=x\end{array}\right\} $$ 

(4)

3. 在区间[0,1]试将函数  $ f(\rho)=1 $ 按零阶贝塞尔函数系  $ \left\{J_{0}(k_{m}^{0}\rho)\right\} $ 展开，而将函数  $ g(\rho)=\rho $，按一阶贝塞尔函数系  $ \left\{J_{1}(k_{m}^{1}\rho)\right\} $ 展开 (m=1,2,\cdots).

4. 试证贝塞尔函数的加法公式

$$  \mathrm{J}_{n}(x+y)=\sum_{k=-\infty}^{\infty}\mathrm{J}_{k}(x)\mathrm{J}_{n-k}(y)   \tag*{(12.2.31)}$$

5. 在圆柱形的结构，例如同轴线和圆形截面波导中，电磁场分量  $ E_{z} $ 所满足的方程用柱坐标表示为

 $$ \frac{\partial^{2}E_{z}}{\partial r^{2}}+\frac{1}{r}\frac{\partial E_{z}}{\partial r}+\frac{1}{r^{2}}\frac{\partial^{2}E_{z}}{\partial\varphi^{2}}+k^{2}E_{z}=0 $$ 

试用分离变量法求解.

6. 圆柱形空腔内电磁振荡的定解问题为

 $$ \begin{cases}\Delta u+\lambda u=0,&\sqrt{\lambda}=\frac{\omega}{c}\\u\mid_{r=a}=0&\\\left.\frac{\partial u}{\partial z}\right|_{x=0,l}=0&\end{cases} $$

<!-- page: 261 -->

试证电磁振荡的固有频率为

 $$ \omega_{nm}=c\sqrt{\lambda}=c\sqrt{\left(\frac{x_{m}^{0}}{a}\right)^{2}+\left(\frac{n\pi}{l}\right)^{2}} $$ 

7. 设一无穷长的圆柱体，半径为 R，初温为常数  $ u_{0} $，表面温度维持为零，求柱体内温度的变化.

8. 半径为 R 的圆形膜，边缘固定。初始形状是旋转抛物面  $ \left.u\right|_{t=0}=(1-\rho^{2}/R^{2})H $，初速为零，求解膜的振动情况。

9. 计算积分：

 $$ (1)\int_{0}^{x}t^{-n}J_{n+1}(t)\mathrm{d}t;\quad(2)\int_{0}^{i}J_{0}(\sqrt{x(t-x)})\mathrm{d}x $$ 

10. 计算含贝塞尔函数的积分

(1)

 $$ \int_{0}^{a}x^{4}\mathrm{J}_{1}(x)\mathrm{d}x； $$ 

 $$ \int_{0}^{a}\mathrm{J}_{0}\left(x\right)\mathrm{d}x； $$ 

(3) $ \int_{0}^{\infty}xe^{-ax}J_{1}(bx)dx;\quad(4)\int_{0}^{\infty}e^{-ax}J_{0}(bx)dx,a,b $为实数，a>0.

11. 长为 l 的轴对称匀质细杆，其横截面积正比于它与尖端 x=0 的距离。已知杆的初始位移为  $ \varphi(x) $，初始速度为零，杆的粗端是自由的，求解杆的纵振动情况。

12. 一半径为 R 的圆膜，边缘固定，质量密度为  $ \sigma $（常数），单位面积上作用力为  $ b\left(1-\frac{\rho^{2}}{R^{2}}\right)\sin\omega t $ （ $ b,\omega $ 为常数），求解膜的稳恒振动.

###  $ ^{*}12.3 $ 其他柱函数

## 1. 第二类柱函数

在12.1中，我们已证明当 $ \nu=n(0,1,2,\cdots) $时， $ \mathrm{J}_{n}(x) $和 $ \mathrm{J}_{-n}(x) $是线性相关的，需引入另一与 $ \mathrm{J}_{n}(x) $线性无关的解来组成贝塞尔方程的通解.为此，人们定义

$$  \mathrm{N}_{\nu}(x)=\frac{\cos\nu\pi\mathrm{J}_{\nu}(x)-\mathrm{J}_{\neg\nu}(x)}{\sin\nu\pi}   \tag*{(12.3.1)}$$

为  $ \nu $ 阶的贝塞尔方程的另一特解，称之为第二类柱函数或诺伊曼函数.

显然，当 $ \nu $不为整数时， $ N_{v}(x) $是贝塞尔方程的与 $ \mathrm{J}_{v}(x) $线性无关的解。因为 $ N_{v}(x) $是两个线性无关的解 $ \mathrm{J}_{v}(x) $和 $ \mathrm{J}_{-v}(x) $的线性组合。

当v=n时，(12.3.1)式右方是一不定式，我们可将之表示为

 $$ \mathrm{N}_{n}(x)=\lim_{\nu\to n}\mathrm{N}_{\nu}(x)=\lim_{\nu\to n}\frac{\cos\nu\pi\mathrm{J}_{\nu}(x)-\mathrm{J}_{\neg\nu}(x)}{\sin\nu\pi} $$ 

而由洛必达法则可得

$$  \mathrm{N}_{n}(x)=\frac{1}{\pi}\Big(\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}-(-1)^{n}\frac{\partial\mathrm{J}_{-\nu}(x)}{\partial\nu}\Big)\bigg|_{\nu=n}   \tag*{(12.3.2)}$$

将 $ J_{\pm}(x) $的级数表达式代入(12.3.2)，经过冗长的计算，可得 $ N_{n}(x) $的级数表达式为

<!-- page: 262 -->

$$  \begin{align*}\mathrm{N}_{n}(x)=&\frac{2}{\pi}\mathrm{J}_{n}(x)\ln\frac{x}{2}-\frac{1}{\pi}\sum_{k=0}^{n-1}\frac{(n-k-1)!}{k!}\Big(\frac{x}{2}\Big)^{2k-n}\\&-\frac{1}{\pi}\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!(n+k)!}[\psi(k+1)+\psi(n+k+1)]\Big(\frac{x}{2}\Big)^{2k+n}\end{align*}   \tag*{(12.3.3)}$$

其中  $ \psi(1)=-\gamma=-0.577216 $ 是欧拉常数 $ ^{①} $， $ \psi(k+1)=-\gamma+1+\frac{1}{2}+\cdots+\frac{1}{k} $. 当 n=0 时，须去掉右方第二项有限和.

 $ N_{n}(x) $是贝塞尔方程的解.因为

 $$ x^{2}\mathrm{J}_{\nu}^{\prime\prime}(x)+x J_{\nu}^{\prime}(x)+(x^{2}-\nu^{2})\mathrm{J}_{\nu}(x)=0 $$ 

将此式对 $ \nu $求导得

$$  x^{2}\frac{\mathrm{d}^{2}}{\mathrm{d}x^{2}}\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}+x\frac{\mathrm{d}}{\mathrm{d}x}\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}+(x^{2}-\nu^{2})\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}-2\nu\mathrm{J}_{\nu}(x)=0   \tag*{(12.3.4)}$$

同理

$$  x^{2}\frac{\mathrm{d}^{2}}{\mathrm{d}x^{2}}\frac{\partial\mathrm{J}_{-\nu}(x)}{\partial\nu}+x\frac{\mathrm{d}}{\mathrm{d}x}\frac{\partial\mathrm{J}_{-\nu}(x)}{\partial\nu}+(x^{2}-\nu^{2})\frac{\partial\mathrm{J}_{-\nu}x}{\partial\nu}-2\nu\mathrm{J}_{-\nu}(x)=0   \tag*{（12.3.5）}$$

由(12.3.4)式减去 $ (-1)^{n} $乘 $ (12.3.5) $式得

 $$ \begin{aligned}&x^{2}\frac{\mathrm{d}^{2}}{\mathrm{d}x^{2}}\Big[\frac{\mathrm{d}\mathrm{J}_{\nu}(x)}{\partial\nu}-(-1)^{n}\frac{\partial\mathrm{J}_{\neg}(x)}{\partial\nu}\Big]+x\frac{\mathrm{d}}{\mathrm{d}x}\Big[\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}-(-1)^{n}\frac{\partial\mathrm{J}_{\neg}(x)}{\partial\nu}\Big]\\&\quad+(x^{2}-\nu^{2})\Big[\frac{\partial\mathrm{J}_{\nu}(x)}{\partial\nu}-(-1)^{n}\frac{\partial\mathrm{J}_{\neg}(x)}{\partial\nu}\Big]\\&\quad-2\nu\big[\mathrm{J}_{\nu}(x)-(-1)^{n}\mathrm{J}_{\neg}(x)\big]=0\\ \end{aligned} $$ 

当 $ \nu=n $时，则有

 $$ x^{2}\mathrm{N}_{n}^{\prime\prime}(x)+x\mathrm{N}_{n}^{\prime}(x)+(x^{2}-n^{2})\mathrm{N}_{n}(x)=0 $$ 

这就证明了当 v=n 时， $ N_{n}(x) $ 是 n 阶贝塞尔方程的解。而且， $ N_{n}(x) $ 也是与  $ \mathrm{J}_{n}(x) $ 线性无关的，因为当 x=0 时由 (12.1.10) 式有

 $$ \mathrm{J}_{0}(x)=1;\quad\mathrm{J}_{n}(x)=0,\quad n\geqslant1 $$ 

故在 x=0 点有

 $$ \begin{aligned}N_{0}(x)&\sim\frac{2}{\pi}\ln\frac{x}{2}\rightarrow-\infty\\ N_{n}(x)&\sim-\frac{(n-1)!}{\pi}\Big(\frac{x}{2}\Big)^{-n}\rightarrow-\infty,\quad n\geqslant1\end{aligned} $$ 

可见，当 x 为小变量时， $ \mathrm{J}_{n}(x) $ 和  $ \mathrm{N}_{n}(x) $ 有明显的不同行径.

综上所述，无论 v 是否为整数， $ N_{v}(x) $ 都是与  $ \mathrm{J}_{v}(x) $ 线性无关的贝塞尔方程的解，故贝塞尔方程的通解总可表示为

$$  y=A_{v}J_{v}(x)+B_{v}N_{v}(x)   \tag*{（12.3.6）}$$

但注意到在 x=0 点，当  $ \nu=n $ 时， $ \mathrm{N}_{n}(x)\rightarrow-\infty $；当  $ \nu\neq n $ 时，由于  $ \mathrm{J}_{-\nu}(x)\rightarrow\infty $ 故  $ \mathrm{N}_{\nu}(x) $ 也趋于  $ -\infty $。所以，在研究圆柱内部的亥姆霍兹方程或拉氏方程时，为了满足解在圆

<!-- page: 263 -->

柱轴（即 $ \rho=0 $或x=0）上有限，应当舍去 $ N_{v}(x) $.

还可以证明，当  $ x \to \infty $ 时，诺伊曼函数的渐近行为为

 $$ \mathrm{N}_{\nu}(x)\sim\sqrt{\frac{2}{\pi x}}\sin\left(x-\frac{\nu\pi}{2}-\frac{\pi}{4}\right) $$ 

## 2. 第三类柱函数

在实际应用中（如，在讨论波的散射问题时），人们又定义

$$  \left\{\begin{aligned}\mathrm{H}_{\nu}^{(1)}(x)&=\mathrm{J}_{\nu}(x)+\mathrm{i}\mathrm{N}_{\nu}(x)\\ \mathrm{H}_{\nu}^{(2)}(x)&=\mathrm{J}_{\nu}(x)-\mathrm{i}\mathrm{N}_{\nu}(x)\end{aligned}\right.   \tag*{(12.3.7)}$$

为第三类柱函数或汉开尔(Hankel)函数. 显然，这两个汉开尔函数是贝塞尔方程的两线性无关的解. 由(12.3.7)式可看出，三类柱函数  $ \mathrm{H}_{\nu}^{(1)}(x) $,  $ \mathrm{H}_{\nu}^{(2)}(x) $,  $ \mathrm{J}_{\nu}(x) $,  $ \mathrm{N}_{\nu}(x) $ 之间的关系、颇似  $ \mathrm{e}^{\mathrm{i}x} $,  $ \mathrm{e}^{-\mathrm{i}x} $,  $ \cos x $,  $ \sin x $ 之间的关系.

通常把三类柱函数，统称为柱函数，以 $ Z_{v}(x) $来表示。由于 $ \mathrm{N}_{v}(x) $和 $ \mathrm{H}_{v}^{(1)}(x) $、 $ \mathrm{H}_{v}^{(2)}(x) $的定义，均建立在 $ \mathrm{J}_{v}(x) $的基础之上，故很易证得 $ \mathrm{N}_{v}(x) $和 $ \mathrm{H}_{v}^{(1)}(x) $、 $ \mathrm{H}_{v}^{(2)}(x) $也均满足与 $ \mathrm{J}_{v}(x) $所满足的同样的递推关系，于是有

$$  \frac{\mathrm{d}}{\mathrm{d}x}\left[x^{\nu}Z_{\nu}(x)\right]=x^{\nu}Z_{\nu-1}(x)   \tag*{(12.3.8)}$$

$$  \frac{\mathrm{d}}{\mathrm{d}x}\left[x^{\neg\nu}Z_{\nu}(x)\right]=-x^{\neg\nu}Z_{\nu+1}(x)   \tag*{(12.3.9)}$$

$$  Z_{\nu-1}(x)+Z_{\nu+1}(x)=\frac{2\nu}{x}Z_{\nu}(x)   \tag*{(12.3.10)}$$

$$  Z_{\nu-1}(x)-Z_{\nu+1}(x)=2Z_{\nu}^{\prime}(x)   \tag*{(12.3.11)}$$

## 3. 球贝塞尔函数

在第二篇第八章中，我们曾通过在球坐标系中对亥姆霍兹方程分离变量，而得到了关于变量 r 的球贝塞尔方程[见第二篇(8.4.29)式]，即

 $$ \begin{aligned}&r^{2}\frac{\mathrm{d}^{2}R}{\mathrm{d}r^{2}}+2r\frac{\mathrm{d}R}{\mathrm{d}r}+\left[k^{2}r^{2}-l(l+1)\right]R=0\\&\quad x^{2}\frac{\mathrm{d}^{2}y}{\mathrm{d}x^{2}}+2x\frac{\mathrm{d}y}{\mathrm{d}x}+\left[x^{2}-l(l+1)\right]y=0\\ \end{aligned} $$ 

亦即

其中，x=kr, y=R. 在第二篇中，我们已看到，若令  $ y(x)=x^{-\frac{1}{2}}v(x) $，则  $ v(x) $ 满足  $ l+\frac{1}{2} $ 阶的贝塞尔方程 [第二篇 (8.4.33) 式]

 $$ x^{2}v^{\prime \prime}(x)+x v^{\prime}(x)+\left[x^{2}-\left(l+\frac{1}{2}\right)^{2}\right]v(x)=0 $$ 

因此球贝塞尔方程(12.3.12)的线性独立解为

 $$ x^{-\frac{1}{2}}\mathrm{J}_{l+\frac{1}{2}}(x),\quad x^{-\frac{1}{2}}\mathrm{N}_{l+\frac{1}{2}}(x) $$

<!-- page: 264 -->

$$ x^{-\frac{1}{2}}\mathrm{H}_{l+\frac{1}{2}}^{(1)}(x),\quad x^{-\frac{1}{2}}\mathrm{H}_{l+\frac{1}{2}}^{(2)}(x) $$ 

但在现今的物理学中，通常是将以上解再乘上一个因子 $ \sqrt{\frac{\pi}{2}} $之后，记之为

$$  \mathrm{j}_{l}(x)=\sqrt{\frac{\pi}{2x}}\mathrm{J}_{l+\frac{1}{2}}(x)   \tag*{(12.3.13)}$$

$$  \mathrm{n}_{l}(x)=\sqrt{\frac{\pi}{2x}}\mathrm{N}_{l+\frac{1}{2}}(x)   \tag*{(12.3.14)}$$

$$  \mathrm{h}_{l}^{(1)}(x)=\sqrt{\frac{\pi}{2x}}\mathrm{H}_{l+\frac{1}{2}}^{(1)}(x)   \tag*{（12.3.15）}$$

$$  \mathrm{h}_{l}^{(2)}(x)=\sqrt{\frac{\pi}{2x}}\mathrm{H}_{l+\frac{1}{2}}^{(2)}(x)   \tag*{（12.3.16）}$$

分别称之为第一类球贝塞尔函数（或球贝塞尔函数）、第二类球贝塞尔函数（或球诺伊曼函数）和第三类球贝塞尔函数（或球汉开尔函数）。

于是，方程(12.3.12)的通解可以写成

$$  y(x)=A_{l}\mathrm{j}_{l}(x)+B_{l}\mathrm{n}_{l}(x)   \tag*{(12.3.17)}$$

当 l 为整数时，球贝塞尔函数可以用初等函数来表示，如

$$   j_{0}\left(x\right)=\frac{\sin x}{x},\quad n_{0}\left(x\right)=-\frac{\cos x}{x}   \tag*{（12.3.18）}$$

 $$ \mathrm{j}_{1}(x)=\frac{1}{x^{2}}(\sin x-x\cos x),\quad n_{1}(x)=-\frac{1}{x^{2}}(\cos x+x\sin x) $$ 

类似于上两节对贝塞尔函数的讨论，我们有本征值问题

$$  \begin{cases}r^{2}\frac{\mathrm{d}^{2}R}{\mathrm{d}r^{2}}+2r\frac{\mathrm{d}R}{\mathrm{d}r}+\left[k^{2}r^{2}-l(l+1)\right]R=0\\R(0)\neq\infty\\R(a)=0\end{cases}   \tag*{（12.3.19）}$$

的本征值和本征函数分别是

$$  k=k_{m}^{\binom{l+\frac{1}{2}}{}}\stackrel{}{=}\frac{x_{m}^{\binom{l+\frac{1}{2}}{}}}{a},\quad R(r)=\mathrm{j}_{l}(k_{m}^{\binom{l+\frac{1}{2}}{}}r),\quad m=1,2,3,\cdots   \tag*{(12.3.20)}$$

其中  $ x_{m}^{(l+\frac{1}{2})} $ 是  $ \mathrm{J}_{l+\frac{1}{2}}(x) $ 的正零点.

本征函数族 $ \left\{\mathrm{j}_{l}\left(k_{m}^{\left(l+\frac{1}{2}\right)}r\right)\right\} $对固定l满足如下正交归一关系

$$  \begin{array}{r}{\displaystyle\int_{0}^{a}\mathrm{j}_{l}(k_{m}^{\left(l+\frac{1}{2}\right)}r)\mathrm{j}_{l}(k_{n}^{\left(l+\frac{1}{2}\right)}r)r^{2}\mathrm{d}r=\frac{\pi}{k_{n}^{\left(l+\frac{1}{2}\right)}}\Big(\frac{a}{2}\Big)^{2}\big[\mathrm{J}_{l+\frac{3}{2}}(k_{n}^{\left(l+\frac{1}{2}\right)}a)\big]^{2}\delta_{m n}}\end{array}   \tag*{(12.3.21)}$$

在区间  $ 0 \leqslant r \leqslant a $ 上满足一定条件的  $ f(r) $，均可按球贝塞尔函数展开为广义傅氏级数

<!-- page: 265 -->

$$  f(r)=\sum_{m=1}^{\infty}c_{m}\mathrm{j}_{l}(k_{m}^{\left(l+\frac{1}{2}\right)}r)   \tag*{（12.3.22）}$$

其中

$$  c_{m}=\frac{1}{\frac{\pi}{k_{m}^{\left(l+\frac{1}{2}\right)}}\left[\frac{a}{2}\mathrm{J}_{l+\frac{3}{2}}\left(k_{m}^{\left(l+\frac{1}{2}\right)}a\right)\right]^{2}}\int_{0}^{a}f(r)\mathrm{j}_{l}\left(k_{m}^{\left(l+\frac{1}{2}\right)}r\right)r^{2}\mathrm{d}r   \tag*{(12.3.23)}$$

例 1 半径为 a 的均匀导热介质球，原来的温度为  $ u_{0} $ 将它放入冰水中，使球面保持为零度。求球内温度的变化。

解 显然温度  $ u(r,t) $ 与  $ \theta $ 和  $ \varphi $ 无关，故其定解问题为

$$  \frac{\partial u}{\partial t}-D\Delta u(r,t)=0   \tag*{(12.3.24)}$$

 $$ u\mid_{r=0}\to 有限 $$ 

$$  u\mid_{r=a}=0   \tag*{（12.3.26）}$$

令

$$  u\mid_{t=0}=u_{0}   \tag*{(12.3.27)}$$

$$  u(r,t)=R(r)T(t)   \tag*{（12.3.28）}$$

代入方程和边界条件得

 $$ \int r R^{\prime \prime}(r)+2R^{\prime}(r)+\lambda rR(r)=0 $$ 

 $ R(0) $ 有限， $ R(a)=0 $

$$  T^{^{\prime}}(t)+\lambda D T(t)=0   \tag*{（12.3.31）}$$

方程(12.3.29)是零阶球贝塞尔方程. 本征值问题(12.3.29)~(12.3.30)的本征值和本征函数分别是

 $$ \lambda=\left(\frac{x_{m}^{\left(\frac{1}{2}\right)}}{a}\right)^{2},\quad R(r)=\mathrm{j}_{0}\left(\frac{x_{m}^{\left(\frac{1}{2}\right)}}{a}r\right) $$ 

由（12.3.18）式又可写成

 $$ \lambda=\left(\frac{m\pi}{a}\right)^{2},\quad R(r)=\frac{a}{m\pi r}\sin\frac{m\pi r}{a},\quad m=1,2,3,\cdots $$ 

将  $ \lambda $ 之值代入方程(12.3.31)并求解此方程得

 $$ T(t)=c_{m}\mathrm{e}^{-(\frac{m\pi}{a})^{2}D t} $$ 

于是

 $$ u(r,t)=\sum_{m=1}^{\infty}c_{m}\frac{a}{m\pi r}\sin\frac{m\pi r}{a}\mathrm{e}^{-(\frac{m\pi}{a})^{2}D t} $$ 

将此式代入初始条件(12.3.27)式定出系数  $ c_{m} $，最后求得定解问题(12.3.24)～(12.3.27)式的解为

 $$ u(r,t)=\frac{2au_{0}}{\pi r}\sum_{m=1}^{\infty}\frac{(-1)^{m-1}}{m}\sin\frac{m\pi r}{a}\mathrm{e}^{-(\frac{m\pi}{a})^{2}D t} $$ 

## 4. 虚宗量贝塞尔函数

在第二篇中，我们曾引入了虚宗量的贝塞尔方程[见第二篇8.4注 $ ^{①} $]

<!-- page: 266 -->

$$  x^{2}y^{\prime \prime}+xy^{\prime}-(x^{2}+\nu^{2})y=0   \tag*{（12.3.32）}$$

其中 x 是实数. 易于看出, 只要令 z=ix, 则方程 (12.3.32) 便化为自变数 z 的贝塞尔方程

 $$ z^{2}w^{\prime \prime}(z)+zw^{\prime}(z)+(z^{2}-\nu^{2})w=0 $$ 

因此当  $ \nu \neq n $（整数）时，方程(12.3.32)的两线性无关的解为

 $$ \begin{aligned}y&=\mathrm{J}_{\pm\nu}(\mathrm{i}x)=\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!\Gamma(\pm\nu+k+1)}\Big(\frac{\mathrm{i}x}{2}\Big)^{2k\pm\nu}\\&=\mathrm{i}^{\pm\nu}\sum_{k=0}^{\infty}\frac{1}{k!\Gamma(\pm\nu+k+1)}\Big(\frac{x}{2}\Big)^{2k\pm\nu}\end{aligned} $$ 

为了应用上的方便，经常希望将解表示为实数的形式，为此，人们定义

$$  \left\{\begin{aligned}\mathrm{I}_{\nu}(x)&=\mathrm{i}^{-\nu}\mathrm{J}_{\nu}(\mathrm{i}x)\\ \mathrm{L}_{-\nu}(x)&=\mathrm{i}^{\nu}\mathrm{J}_{-\nu}(\mathrm{i}x)\end{aligned}\right.   \tag*{(12.3.33)}$$

并称之为虚宗量的贝塞尔函数或第一类虚宗量的柱函数，则

$$  \mathrm{I}_{\pm\nu}(x)=\sum_{k=0}^{\infty}\frac{1}{k!\Gamma(\pm\nu+k+1)}\Big(\frac{x}{2}\Big)^{2k\pm\nu}   \tag*{（12.3.34）}$$

当  $ \nu \neq n $ 时  $ \mathrm{I}_{\nu}(x) $ 和  $ \mathrm{I}_{-\nu}(x) $ 当然是线性无关的。而当  $ \nu = n $ 时，我们有

$$   I_{-n}(x)=I_{n}(x)   \tag*{（12.3.35）}$$

即  $ \mathrm{I}_{n}(x) $ 和  $ \mathrm{I}_{-n}(x) $ 是线性相关的. 为了寻求另一线性无关的解, 人们定义

$$  \mathrm{K}_{\nu}(x)=\frac{\pi}{2}\bullet\frac{\mathrm{L}_{\nu}(x)-\mathrm{I}_{\nu}(x)}{\sin\nu\pi}   \tag*{（12.3.36）}$$

称之为第二类虚宗量柱函数或麦克唐纳（Macdonald）函数。

显然，当  $ \nu \neq n $ 时， $ K_{\nu}(x) $ 是方程 (12.3.32) 的与  $ \mathrm{I}_{\nu}(x) $ 线性无关的解。当  $ \nu = n $ 时

 $$ \mathrm{K}_{n}(x)=\lim_{\nu\to n}\frac{\pi}{2}\frac{\mathrm{L}_{-\nu}(x)-\mathrm{I}_{\nu}(x)}{\sin\nu\pi}=\frac{(-1)^{n}}{2}\bigg[\frac{\partial\mathrm{L}_{-\nu}(x)}{\partial\nu}-\frac{\partial I_{\nu}(x)}{\partial\nu}\bigg]_{\nu=n} $$ 

可计算出

$$  \begin{align*}\mathrm{K}_{n}(x)=&\frac{1}{2}\sum_{k=0}^{n-1}(-1)^{k}\frac{(n-k-1)!\}{k!}\Big(\frac{x}{2}\Big)^{2k-n}+(-1)^{n+1}\sum_{k=0}^{\infty}\frac{1}{k!(n+k)!}\\&\bullet\Big[\ln\frac{x}{2}-\frac{1}{2}\psi(n+k+1)-\frac{1}{2}\psi(k+1)\Big]\Big(\frac{x}{2}\Big)^{2k+n},\quad n=0,1,2,\cdots\end{align*}   \tag*{(12.3.37)}$$

当n=0时，去掉右边第一项. 可见x=0是 $ \mathrm{K}_{n}(x) $的奇点

 $$ \begin{aligned}\mathrm{K}_{0}\left(x\right)&\sim-\ln\frac{x}{2}\rightarrow\infty\\\mathrm{K}_{n}\left(x\right)&\sim\frac{\left(n-1\right)!}{2}\Big(\frac{x}{2}\Big)^{-n}\rightarrow\infty,\quad n\geqslant1\end{aligned} $$ 

而由(12.3.34)有

 $$  I_{0}(0)=1；I_{n}(0)=0,\quad n\geqslant1 $$

<!-- page: 267 -->

故由类似于对诺伊曼函数的讨论知， $ K_{n}(x) $ 不仅是（12.3.32）的解，而且是（12.3.32）的一个与  $ \mathrm{I}_{n}(x) $ 线性无关的解.

总之，不论 v 是否为整数，虚宗量的贝塞尔方程（12.3.32）的通解均可表示为

$$  y(x)=A_{\nu}\mathrm{I}_{\nu}(x)+B_{\nu}\mathrm{K}_{\nu}(x)   \tag*{（12.3.38）}$$

在实际问题中，如果圆柱的上、下底具有齐次边界条件，而在圆柱的侧面有非齐次的边界条件，则在柱坐标系中用分离变量法解拉氏方程或亥姆霍兹方程时，便会出现虚宗量贝塞尔方程.

#### 例2 求定解问题

$$  \Delta u=0,0<\rho<b,0<\varphi<2\pi,0<z<h   \tag*{（12.3.39）}$$

$$  u\mid_{z=0}=0,u\mid_{z=h}=0   \tag*{(12.3.40)}$$

$$  u\mid_{p=b}=u_{0}   \tag*{(12.3.41)}$$

解 由于问题的对称性，令  $ u(\rho,z)=R(\rho)Z(z) $ 代入方程 (12.3.39) 和齐次边界条件 (12.3.40) 得

$$  \left\{\begin{aligned}Z^{\prime \prime}+\mu Z&=0\\ Z(0)&=0,\quad Z(h)&=0\end{aligned}\right.   \tag*{(12.3.42)}$$

$$  \frac{1}{\rho}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)-\mu R=0   \tag*{(12.3.43)}$$

本征问题（12.3.42）的解是我们熟知的

 $$ \mu=k_{m}^{2}=\frac{m^{2}\pi^{2}}{h^{2}},\quad Z_{m}(z)=\sin\frac{m\pi}{h}z,\quad m=1,2,\cdots $$ 

将  $ \mu=k_{m}^{2} $ 代入方程(12.3.43)，并令  $ x=k_{m}\rho,y(x)=R(\rho) $，则方程(12.3.43)变为

 $$ x^{2}y^{\prime \prime}+xy^{\prime}-x^{2}y=0 $$ 

这是零阶虚宗量的贝塞尔方程，注意到 $ K_{0}(0)\rightarrow\infty $，于是有

 $$ R_{m}(\rho)=y_{m}(x)=\mathrm{I}_{0}(k_{m}^{0}\rho),\quad m=1,2,\cdots $$ 

从而有

 $$ u(\rho,z)=\sum_{m=1}^{\infty}A_{m}\mathrm{I}_{0}\left(\frac{m\pi}{h}\rho\right)\sin\frac{m\pi}{h}z $$ 

代入非齐次边界条件(12.3.41)得

 $$ u(b,z)=u_{0}=\sum_{m=1}^{\infty}A_{m}\mathrm{I}_{0}\left(\frac{m\pi}{h}b\right)\sin\frac{m\pi}{h}z $$ 

即  $ A_{m}I_{0}\left(\frac{m\pi}{h}b\right) $ 是  $ u_{0} $ 的傅氏正弦展开系数，为

 $$ \mathrm{A}_{m}\mathrm{I}_{0}\left(\frac{m\pi}{h}b\right)=\frac{2}{h}\int_{0}^{h}u_{0}\sin\frac{m\pi}{h}z\mathrm{d}z=\frac{2u_{0}}{m\pi}\Big(-\cos\frac{m\pi}{h}z\Big)\bigg|_{0}^{h}=\frac{2u_{0}}{m\pi}\big[1-(-1)^{m}\big] $$ 

故

 $$ A_{2n}=0,\quad A_{2n+1}=\frac{4u_{0}}{(2n+1)\pi\mathrm{I}_{0}\left(\frac{2n+1}{h}\pi b\right)} $$

<!-- page: 268 -->

因此

$$  u(\rho,z)=\frac{4u_{0}}{\pi}\sum_{n=0}^{\infty}\frac{\sin\frac{(2n+1)\pi}{h}z\mathrm{I}_{0}\left(\frac{2n+1}{h}\pi\rho\right)}{(2n+1)\mathrm{I}_{0}\left(\frac{2n+1}{h}\pi b\right)}   \tag*{(12.3.44)}$$

## 5. 可以化为贝塞尔方程的微分方程

我们已看到，球贝塞尔方程和虚宗量的贝塞尔方程均可化为贝塞尔方程。实际上，在物理学中有许多微分方程都可以化为贝塞尔方程，因而能借助于贝塞尔方程的解来求得其解。例如，我们可由贝塞尔方程

$$  x^{2}y^{\prime \prime}+xy^{\prime}+(x^{2}-\nu^{2})y=0   \tag*{(12.3.45)}$$

出发，通过作变换

$$  x=\mu t^{\beta},\quad y(x)=t^{-\alpha}w(t)   \tag*{（12.3.46）}$$

便可推得如下的一类方程

$$  t^{2}w^{\prime \prime}(t)+(1-2\alpha)t w^{\prime}(t)+\left[\mu^{2}\beta^{2}t^{2\beta}+(\alpha^{2}-\nu^{2}\beta^{2})\right]w(t)=0   \tag*{(12.3.47)}$$

从而，我们可写出此方程的解为

$$  w(t)=t^{\alpha}J_{\nu}(\mu t^{\beta})   \tag*{（12.3.48）}$$

其中， $ J_{v}(x) $ 是  $ \nu $ 阶的贝塞尔方程（12.3.45）的解。我们所熟悉的艾里方程便是这类方程。不难看出，在方程（12.3.47）中，只要取  $ \alpha=\frac{1}{2},\beta=\frac{3}{2},\mu=i\frac{2}{3},\nu^{2}=\frac{1}{9} $，即，作变换

$$  x=\mathrm{i}\frac{2}{3}t^{2/3},\quad y(x)=t^{-1/2}\varpi(t)   \tag*{(12.3.49)}$$

则方程(12.3.47)就转化为艾里方程

$$  w^{\prime \prime}(t)-t w(t)=0   \tag*{（12.3.50）}$$

我们在第9章曾经已求得其指数形式的解——艾里函数。至此，读者也不妨自行求出其柱函数形式的解。

注 ① 参看参考文献 $ ^{[6]} $第122页.

② 见本节习题第2题.

#### 习题12.3

1. 半奇数阶贝塞尔函数的一个重要特点是可以用初等函数来表示，试证

$$  \left.\begin{array}{l}\mathrm{J}_{\frac{1}{2}}(x)=\sqrt{\frac{2}{\pi x}}\sin x\\ \mathrm{J}_{-\frac{1}{2}}(x)=\sqrt{\frac{2}{\pi x}}\cos x\end{array}\right\}   \tag*{(12.3.51)}$$

<!-- page: 269 -->

$$  \left.\begin{array}{r}\mathrm{J}_{n+\frac{1}{2}}(x)=(-1)^{n}\sqrt{\frac{2}{\pi}}x^{n+\frac{1}{2}}\frac{\mathrm{d}^{n}}{(x\mathrm{d}x)^{n}}\Big(\frac{\sin x}{x}\Big)\\ \mathrm{J}_{-}\big(_{n+\frac{1}{2}}\big)\left(x\right)=\sqrt{\frac{2}{\pi}}x^{n+\frac{1}{2}}\frac{\mathrm{d}^{n}}{(x\mathrm{d}x)^{n}}\Big(\frac{\cos x}{x}\Big)\\ \end{array}\right\}   \tag*{(12.3.52)}$$

2. 试证，对于虚宗量的柱函数有如下递推公式：

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\big[x^{\nu}\mathrm{I}_{\nu}(x)\big]=x^{\nu}\mathrm{I}_{\nu-1}(x),\quad\frac{\mathrm{d}}{\mathrm{d}x}\big[x^{\neg\nu}\mathrm{I}_{\nu}(x)\big]=x^{\neg\nu}\mathrm{I}_{\nu+1}(x), $$ 

 $$ \frac{\mathrm{d}}{\mathrm{d}x}[x^{\nu}\mathrm{K}_{\nu}(x)]=-x^{\nu}\mathrm{K}_{\nu-1}(x),\quad\mathrm{I}_{\nu-1}(x)-I_{\nu+1}(x)=\frac{2\nu}{x}\mathrm{I}_{\nu}(x), $$ 

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\bigl[x^{\neg}\mathrm{K}_{\nu}(x)\bigr]=-x^{\neg}\mathrm{K}_{\nu+1}(x),\quad\mathrm{I}_{\nu-1}(x)+\mathrm{I}_{\nu+1}(x)=2\mathrm{I}_{\nu}^{\prime}(x), $$ 

 $$ \mathrm{K}_{\nu-1}(x)-\mathrm{K}_{\nu+1}(x)=-\frac{2\nu}{x}\mathrm{K}_{\nu}(x),\quad\mathrm{K}_{\nu-1}(x)+\mathrm{K}_{\nu+1}(x)=-2\mathrm{K}_{\nu}^{\prime}(x). $$ 

3. 试证下列含有虚宗量的积分结果：

(1)

 $$ \int_{0}^{\infty}\mathrm{e}^{-\frac{1}{2}ax}\sin bx\mathrm{I}_{0}\left(\frac{1}{2}ax\right)\mathrm{d}x=\frac{1}{\sqrt{(2b)(a^{2}+b^{2})}}\sqrt{b+\sqrt{a^{2}+b^{2}}}, $$ 

 $$ \int_{0}^{\infty}\mathrm{e}^{-\frac{1}{2}ax}\cos bx\mathrm{I}_{0}\left(\frac{1}{2}ax\right)\mathrm{d}x=\frac{1}{\sqrt{2b\left(a^{2}+b^{2}\right)}}\frac{a}{\sqrt{b+\sqrt{a^{2}+b^{2}}}},a>0,b>0; $$ 

(2)

 $$ \int_{0}^{\infty}\mathrm{J}_{0}(\alpha x)\mathrm{K}_{0}(\beta x)x\mathrm{d}x=\frac{1}{\alpha^{2}+\beta^{2}},\alpha>0,\mathrm{Re}\beta>0. $$ 

4. 半径为 a、高为 h 的导热介质圆柱，其侧面有强度为  $ q(z) $ 的恒定热流垂直流入，上下两底保持恒温  $ u_{0} $，求柱体内的稳定温度分布.

5. 圆柱体半径为 a，高为 h，上底保持温度  $ u_{1} $，下底保持温度  $ u_{2} $，侧面温度分布为  $ f(z)=\frac{2u_{1}}{h^{2}}\left(z-\frac{h}{2}\right)z+\frac{u_{2}}{h}(h-z) $. 求柱内各点的稳定温度.

6. 半径为  $ 2a_{0} $ 的匀质球，初始温度为  $ u|_{t=0}=\left\{\begin{aligned}&u_{0},0\leqslant r\leqslant a_{0}\\&0,a_{0}<r<2a_{0}\end{aligned}\right. $ （ $ u_{0} $ 为常数），将球面温度保持为零度而使球冷却，求球内的温度变化.

 $ ^{*} $7. 一块半径为 a 的圆形金属板，围绕它的圆周被牢固地夹紧。描述金属板振动的定解问题为

 $$ \left\{\begin{aligned}&\nabla^{4}u+b\frac{\partial^{2}u}{\partial t^{2}}=0\\ &u\mid_{r=a}=0,\quad\left.\frac{\partial u}{\partial r}\right|_{r=a}=0\end{aligned}\right. $$ 

（1）考虑和这个解的等价的数学问题. 即在单位圆内求解

 $$ \left\{\begin{aligned}&\nabla^{4}u-k^{4}u=0\\ &u\mid_{r=1}=0,\quad\left.\frac{\partial u}{\partial r}\right|_{r=1}=0\end{aligned}\right. $$ 

设该本征值问题的最小本征值是  $ k_{0}^{4} $，试用  $ k_{0} $，a 和 b 表示板的最低振动模式的频率  $ \omega $？

（2）注意到因式分解 $ \nabla^{4}-k^{4}=(\nabla^{2}-k^{2})(\nabla^{2}+k^{2}) $，给出适合于本问题 $ \nabla^{4}u-k^{4}u=0 $的两个线性独立解.

（3）利用（1）的边界条件，求一个超越方程，它的本征值是 k.

<!-- page: 270 -->

（4）如果金属板的周围是自由的而不是夹紧的，边界条件是什么？

*8. 设  $ K_{0}(x)=\int_{0}^{\infty}\exp(-x\cos h\varphi)d\varphi $，证明

（1） $ \mathrm{K}_{0}(x) $ 满足虚宗量的零阶贝塞尔方程，即 $ \mathrm{K}_{0}(x)\equiv\mathrm{J}_{0}(\mathrm{i}x) $;

（2）对很大的 x， $ K_{0}(x) $ 具有渐近形式  $ De^{-x}/\sqrt{x} $，并求出常数 D 的值.

（芝加哥大学研究生试题）

 $ ^{*} $9. 计算和数  $ \sum_{n=1}x_{nl}^{-2} $ 的值，其中  $ x_{nl} $ 是球贝塞尔函数  $ \mathrm{j}_{l}(z) $ 的第 n 个正的零点 [即  $ \mathrm{j}_{l}(x_{nl})=0 $]。有用的公式

 $$ \mathrm{j}_{l}(x)=\frac{2^{l}}{(2l+1)!!}\bigg[1-\frac{z^{2}}{2(2l+3)}+\frac{z^{4}}{8(2l+3)(2l+5)}-\cdots\bigg] $$ 

（第7、9题为加州理工学院研究生试题）

<!-- page: 271 -->

<div style="text-align: center;"><img src="images/p0271_img_in_image_box_115_350_179_415.jpg" alt="Image" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0271_img_in_image_box_115_485_179_550.jpg" alt="Image" width="6%" /></div>


本章授课课件 本章习题分析与讨论



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>在柱、球坐标系中  $ \Delta u + \lambda u = 0 $ 的求解</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>在柱坐标中\n令  $ u(\rho, \varphi, z) = R(\rho) \Phi(\varphi) Z(z) $，则\n1.  $ \Delta u + \lambda u = 0 \rightarrow $\n $ \left\{\begin{array}{l}Z&#x27;&#x27; + \mu Z = 0 \rightarrow Z(z) = c_\mu e^{\sqrt{\mu z}} + d_\mu e^{-\sqrt{\mu z}} \\ \Phi&#x27;&#x27; + n^2 \Phi = 0 \rightarrow \Phi_n(\varphi) = A_n \cos n\varphi + B_n \sin n\varphi \\ \rho^2 R&#x27;&#x27; + \rho R&#x27; + [(\lambda - \mu)\rho^2 - n^2] R = 0 \quad \text{若 }\lambda - \mu \geq 0, \text{令 }\lambda - \mu = k^2 \\ \rho^2 R&#x27;&#x27; + \rho R&#x27; + (k^2 \rho^2 - n^2) R = 0 \quad \text{若 }\lambda - \mu &lt; 0, \text{令 }\lambda - \mu = -k^2 \quad \rho^2 R&#x27;&#x27; + \rho R&#x27; - (k^2 \rho^2 + n^2) R = 0\end{array}\right. $ ①\n②\n又令  $ x = k\rho, y(x) = R(\rho) $，则\n $ \rho^2 R&#x27;&#x27; + \rho R&#x27; + (k^2 \rho^2 - n^2) R = 0 \rightarrow x^2 y&#x27;&#x27; + xy&#x27; + (x^2 - n^2) y = 0 \rightarrow \begin{cases} y_{特} = J_{\pm x}(x) (柱体内) \\ y_{温} = a_n J_n(x) + b_n N_n(x) \end{cases} $ ③\n $ \rho^2 R&#x27;&#x27; + \rho R&#x27; - (k^2 \rho^2 + n^2) R = 0 \rightarrow x^2 y&#x27;&#x27; + xy&#x27; - (x^2 + n^2) y = 0 \rightarrow \begin{cases} y_{特} = I_{\pm x}(x) (柱体内) \\ y_{温} = a_n I_n(x) + b_n K_n(x) \end{cases} $ ③&#x27;</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>故在柱坐标系中， $ \Delta u + \lambda u = 0 $ 的解，应由将上面的①、②、③（或③&#x27;）相乘后叠加得到，其中  $ \mu $、 $ \lambda $、 $ \mu $、叠加系数以及对③和③&#x27;之一的选择，都由题目所给定的边界条件确定，具体而言.当圆柱的上、下底的边界条件至少有一个是非齐次的，而侧面的边界条件是齐次的时，其解应由①、②、③组合成；而当圆柱的上、下底的边界条件是齐次的，而侧面的边界条件是非齐次的时，其解应由①、②和③组成.</td></tr></table>

<!-- page: 272 -->

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>2. 至于  $ \Delta u=0 $ 的求解,只需将上述求解过程每一步中的  $ \lambda $ 取零即可.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>在球坐标系中</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>令  $ u(r,\theta,\varphi)=R(r)\Theta(\theta)\Phi(\varphi) $,则\n $ \Delta u+\lambda u=0\rightarrow\begin{cases}\Phi&#x27;&#x27;+m^{2}\Phi=0&amp;\longrightarrow\Phi_m(\varphi)=A_m\cos m\varphi+B_m\sin m\varphi\\\frac{1}{\sin\theta}\frac{\mathrm{d}}{\mathrm{d}\theta}\left(\sin\theta\frac{\mathrm{d}\theta}{\mathrm{d}\theta}\right)+\left[l(l+1)-\frac{m^{2}}{\sin^{2}\theta}\right]\Theta=0\\\frac{1}{\sqrt{r^2R&#x27;&#x27;+2rR&#x27;}+[k^{2}r^{2}-l(l+1)]R=0}\quad(k^{2}=\lambda)\\\quad x=kr,y=R(r)\\\quad x^{2}y&#x27;&#x27;-2xy&#x27;+[x^{2}-l(l+1)]y=0\rightarrow\begin{cases}y_特=\mathrm{j}_l(x)(球内)\\y_通=c_{ij}(x)+d_{m}(x)\end{cases}\end{cases} $</td></tr></table>

<!-- page: 273 -->

### 13.1 施图姆-刘维尔本征值问题

本章相当于前面两章，即特殊函数问题的一个小结。

## 1. 施图姆-刘维尔型方程

在运用分离变量法求解偏微分方程时，会出现种种含有参量的常微分方程，如勒让德方程、贝塞尔方程等，这些方程初看起来无什么关系，但只要我们将之稍加变形，便均可写成下述方程：

$$  \frac{\mathrm{d}}{\mathrm{d}x}\bigg[k(x)\frac{\mathrm{d}y}{\mathrm{d}x}\bigg]-q(x)y+\lambda\rho(x)y=0   \tag*{(13.1.1)}$$

其中， $ a \leqslant x \leqslant b, k(x) \geqslant 0, q(x) \geqslant 0, \rho(x) \geqslant 0, \lambda $ 为参数。通常称（13.1.1）为施图姆-刘维尔（Sturm-Liouville）方程，而称  $ \rho(x) $ 为权函数。如贝塞尔方程

 $$ x^{2}y^{\prime \prime}+xy^{\prime}+(k^{2}x^{2}-n^{2})y=0 $$ 

可写为

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\Big[x\frac{\mathrm{d}y}{\mathrm{d}x}\Big]-\frac{n^{2}}{x}y+k^{2}xy=0 $$ 

其中  $ k(x)=x, q(x)=\frac{n^{2}}{x}, \lambda=k^{2}, \rho(x)=x $ 。又如，勒让德方程

 $$ (1-x^{2})y^{\prime \prime}-2xy^{\prime}+l(l+1)y=0 $$ 

可写为

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\bigg[(1-x^{2})\frac{\mathrm{d}y}{\mathrm{d}x}\bigg]+l(l+1)y=0 $$ 

其中  $ k(x)=1-x^{2}, q(x)=0, \lambda=l(l+1), \rho(x)=1. $

任意的二阶常微分方程

 $$ y^{\prime \prime}(x)+p(x)y^{\prime}(x)+h(x)y(x)=0 $$ 

以函数  $ k(x) = \exp\left[\int p(x)dx\right] $ 乘其两端后均可写成施-刘型方程. 如：

对于厄米方程

 $$ y^{\prime \prime}-2xy^{\prime}+2ny=0 $$ 

有

 $$ k(x)=\mathrm{e}^{-x^{2}},\quad\left[\mathrm{e}^{-x^{2}}y^{\prime}\right]^{\prime}+2n\mathrm{e}^{-x^{2}}y=0 $$ 

对卡拉盖尔方程

<!-- page: 274 -->

$$ xy^{\prime \prime}+(1-x)y^{\prime}+\alpha y=0 $$ 

有

 $$ k(x)=x\mathrm{e}^{-x},\quad\left[x\mathrm{e}^{-x}y^{\prime}\right]^{\prime}+\alpha\mathrm{e}^{-x}y=0 $$ 

对于高斯方程

 $$ x(x-1)y^{\prime \prime}+\left[(\alpha+\beta+1)x-\gamma\right]y^{\prime}+\alpha\beta y=0 $$ 

有

 $$ k(x)=x^{\gamma}(x-1)^{\alpha+\beta+1-\gamma} $$ 

 $$ \left[x^{\gamma}(x-1)^{\alpha+\beta+1-\gamma}y^{^{\prime}}\right]^{\prime}+\alpha\beta x^{\gamma-1}(x-1)^{\alpha+\beta-\gamma}y=0 $$ 

对于库默尔方程

 $$ xy^{\prime \prime}+(c-x)y^{\prime}-ay=0 $$ 

有

 $$ k(x)=x^{c}\mathrm{e}^{-x},\quad\left[x^{c+1}\mathrm{e}^{-x}y^{\prime}\right]^{\prime}-x^{c}\mathrm{e}^{-x}y^{\prime}-ax^{c}\mathrm{e}^{-x}y=0 $$ 

等等.

## 2. 自然边界条件

定义在某一区间上的施图姆-刘维尔方程

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\bigg[k(x)\frac{\mathrm{d}y}{\mathrm{d}x}\bigg]-q(x)y+\lambda o(x)y=0,\quad a\leqslant x\leqslant b $$ 

（1）若端点 a 或 b 是 k(x) 的一级零点，则在那个端点就存在着自然的边界条件。因为在此种情况下若(13.1.1)存在一有界解  $ y_{1}(x) $，则由求解公式

 $$ y_{2}(x)=y_{1}(x)\Big[\int_{x_{0}}^{x}\frac{\mathrm{e}^{-\left|p(\zeta)\mathrm{d}\zeta\right.}}{y_{1}^{2}(\zeta)}\mathrm{d}\zeta+c\Big]=y_{1}(x)\Big[\int_{x_{0}}^{x}\frac{\mathrm{d}\zeta}{k(\zeta)y_{1}^{2}(\zeta)}+c\Big]^{\textcircled{1}} $$ 

知，与  $ y_{1}(x) $ 线性无关的解  $ y_{2}(x) $ 在该端点必是无界的. 即

 $$ y_{2}(a)=\infty\quad 或 \quad y_{2}(b)=\infty $$ 

故此时存在有限性的自然边界条件

$$  y(a)= 有限 \quad 或 \quad y(b)= 有限   \tag*{(13.1.2)}$$

如，贝塞尔方程

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\Big[x\frac{\mathrm{d}y}{\mathrm{d}x}\Big]-\frac{n^{2}}{x^{2}}y+k^{2}xy=0,\quad0\leqslant x\leqslant a $$ 

 $ k(x)=x $，在端点 x=0 的值  $ k(0)=0 $，在端点 x=0 存在着自然边界条件  $ y|_{x=0}\rightarrow $ 有限。又如，勒让德方程

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\bigg[(1-x^{2})\frac{\mathrm{d}y}{\mathrm{d}x}\bigg]+l(l+1)y=0,\quad-1\leqslant x\leqslant1 $$ 

 $ k(x)=1-x^{2} $，在端点  $ x=\pm1 $ 的值  $ k(\pm1)=1-(\pm1)^{2}=0 $，在端点存在着自然边界条件  $ y|_{x=\pm1}\rightarrow $ 有限.

（2）若  $ k(a)=k(b) $，则在端点存在有周期性的自然边界条件

$$  y(a)=y(b),\quad y^{^{\prime}}(a)=y^{^{\prime}}(b)   \tag*{(13.1.3)}$$

如，第二篇8.4节中我们所遇到的本征值问题.

<!-- page: 275 -->

$$ \left\{\begin{aligned}\Phi^{\prime \prime}(\varphi)+n^{2}\Phi(\varphi)&=0\\ \Phi(0)&=\Phi(2\pi)\end{aligned}\right. $$ 

即属此种情况的一个特例.

## 3. 施图姆-刘维尔本征值问题的共同性质

对施图姆-刘维尔方程附加以齐次的第一类、第二类或第三类的边界条件或自然边界条件

$$  \left\{\begin{aligned}&\frac{\mathrm{d}}{\mathrm{d}x}\Big[k(x)\frac{\mathrm{d}y}{\mathrm{d}x}\Big]-q(x)y+\lambda o(x)y=0,\quad a\leqslant x\leqslant b\\ &\Big[\alpha\frac{\mathrm{d}y}{\mathrm{d}x}+\beta y(x)+\gamma k(x)\Big]_{x=a,b}=0\end{aligned}\right.   \tag*{(13.1.4)}$$

就称为施图姆-刘维尔本征值问题. 这类本征值问题具有如下共同性质 $ ^{②} $:

（1）如  $ k(x) $ 及其导数连续， $ q(x) $ 连续或者最多在边界有一阶极点，则存在无限多分立的实本征值

 $$ \lambda_{1}\leqslant\lambda_{2}\leqslant\lambda_{3}\leqslant\cdots $$ 

相应地，有本征函数（可以是 x 的复函数）

 $$ y_{1}(x),y_{2}(x),y_{3}(x),\cdots $$ 

（2）所有本征值  $ \lambda_{m} \geqslant 0 (m = 1, 2, 3, \cdots) $

（3）相应于不同的本征值 $ \lambda_{m} $ 和 $ \lambda_{n} $ 的本征函数 $ y_{m}(x) $ 和 $ y_{n}(x) $，在区间 $ [a,b] $ 上带权重 $ \rho(x) $ 正交归一，即

$$  \int_{a}^{b}\rho(x)y_{m}(x)\bar{y}_{n}(x)\mathrm{d}x=\left\{\begin{aligned}&0,&m\neq n\\ &N_{n}^{2},&m=n\end{aligned}\right.   \tag*{（13.1.5）}$$

其中  $ N_{n} $ 称为  $ y_{n}(x) $ 的模， $ \frac{1}{N_{n}} $ 称为归一化因子， $ \bar{y}_{n}(x) $ 为  $ y_{n}(x) $ 的共轭函数.

（4）本征函数族 $ \left\{y_{m}(x)\right\}:y_{1}(x),y_{2}(x),y_{3}(x),\cdots $是完备的.即，若函数 $ f(x) $具有连续一阶导数和分段连续的二阶导数且满足本征函数族 $ y_{m}(x)(m=1,2,3,\cdots) $所满足的边界条件，则必可展开为绝对且一致收敛的级数

$$  f(x)=\sum_{m=1}^{\infty}c_{m} y_{m}(x)   \tag*{(13.1.6)}$$

其中

$$  c_{m}=\frac{1}{N_{m}^{2}}\int_{a}^{b}\rho(x)f(x)\bar{y}_{m}(x)\mathrm{d}x   \tag*{(13.1.7)}$$

事实上，只要  $ f(x) $ 在  $ [a,b] $ 上平方可积，就能按 (13.1.6) 展开（见参考文献 [7] 15.3 节）

若施图姆-刘维尔方程的解，是不能用初等函数的有限形式表示的函数（如，贝塞尔函数、勒让德多项式等），则称之为特殊函数，故常常将对特殊函数问题的研究，归结为对施图姆-刘维尔问题的研究.

<!-- page: 276 -->

现将两个主要的特殊函数的性质，列入本篇末的表中，作为本篇的小结。读者不妨将本篇各章节和习题中所出现的其他特殊函数，如厄米多项式、拉盖尔多项式，此外还有超几何级数、合流超几何级数 $ ^{③} $等这些物理学中常会遇到的特殊函数的主要性质，自己归纳整理后也列入该表中。

注 ① 见一般高等数学教科书中高阶常微分方程部分.

② 施-刘问题共性证明见二维码.

③ 超几何级数和合流超几何级数分别为高斯方程和库默尔方程的解. 见 13.2 节.

<div style="text-align: center;"><img src="images/p0276_img_in_image_box_761_277_826_342.jpg" alt="Image" width="6%" /></div>


施-刘问题共性证明

#### 习题13.1

1. 厄米多项式的微分表达式为

$$  \mathrm{H}_{n}(x)=(-1)^{n}\mathrm{e}^{x^{2}}\frac{\mathrm{d}^{n}\mathrm{e}^{-x^{2}}}{\mathrm{d}x^{n}}   \tag*{(13.1.8)}$$

试证

（1）其母函数关系式： $ \mathrm{e}^{-t^{2}+2tx}=\sum_{n=0}^{\infty}\frac{\mathrm{H}_{n}(x)}{n!}t^{n}\quad(t>0) $

(2) 其递推公式:  $ \left\{\begin{aligned}H_{n}^{\prime}(x)&=2nH_{n-1}(x)\\ H_{n+1}(x)&-2xH_{n}(x)+2nH_{n-1}(x)\end{aligned}\right.=0 $

$$  \begin{aligned}(3)& 其正交归一性 :\int_{-\infty}^{\infty}e^{-x^{2}}H_{m}(x)H_{n}(x)d x=\begin{cases}0,&m\neq n\\2^{n}n!\sqrt{\pi},&m=n\end{cases}(m,n=0,1,2,\cdots)\end{aligned}   \tag*{(13.1.11)}$$

（芝加哥大学研究生试题）

$$  2.\  拉盖尔多项式的表达式为 L_{n}(x)=\sum_{k=0}^{n}\frac{(-1)^{k}(n!)^{2}}{(k!)^{2}(n-k)!}x^{k}   \tag*{(13.1.12)}$$

$$  \begin{aligned} 试证：(1) 微分表达式为 \quad\mathrm{L}_{n}(x)=e^{x}\frac{\mathrm{d}^{n}}{\mathrm{d}x^{n}}(x^{n}\mathrm{e}^{-x})\end{aligned}   \tag*{（13.1.13）}$$

$$  (2) 母函数展开式为 \quad\frac{\mathrm{e}^{-\frac{xt}{1-t}}}{1-t}=\sum_{n=0}^{\infty}\frac{1}{n!}\mathrm{L}_{n}(x)t^{n}   \tag*{(13.1.14)}$$

$$   正交归一性为 \quad\int_{0}^{\infty}\mathrm{e}^{-x}\mathrm{L}_{m}(x)\mathrm{L}_{n}(x)\mathrm{d}x=\left\{\begin{aligned}&0,&m\neq n\\ &(n!!)^{2},&m=n\end{aligned}\right.   \tag*{(13.1.15)}$$

3. 证明：施-刘方程

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\bigg[k(x)\frac{\mathrm{d}y}{\mathrm{d}x}\bigg]-q(x)y+\lambda\rho(x)y=0,\quad a\leqslant x\leqslant b $$ 

的本征函数  $ y_{m}(x) $ 和  $ y_{n}(x) $ 在区间  $ [a,b] $ 上带权重  $ \rho(x) $ 正交归一

 $$ \int_{a}^{b}\rho(x)y_{m}(x)\bar{y}_{n}(x)\mathrm{d}x=\left\{\begin{aligned}&0,&m\neq n\\ &N_{n}^{2},&m=n\end{aligned}\right. $$ 

 $ ^{*} $4.（1）考虑 $ a \leqslant x \leqslant b $内的微分方程

 $$ \frac{\mathrm{d}y^{2}}{\mathrm{d}x^{2}}+w(x)\big[\lambda-q(x)\big]y=0 $$

<!-- page: 277 -->

$ w(x), q(x) $ 是固定函数，且在  $ a \leqslant x \leqslant b $ 中  $ w(x) \geqslant 0 $，方程的边界条件是

 $$ y(a)=0,\quad y^{^{\prime}}(b)=0 $$ 

解释这个方程的本征值  $ \lambda=\lambda_{n} $ 和本征函数的意义。证明本征值是实的且具有不同本征值的本征函数以一个适当的权函数而正交。叙述一般函数按这些本征函数的展开定理（你不需证明方程总是存在一个或更多个本征函数，假定它们存在而导出这些性质）。

（2）求下列系统的本征值

 $$ \left\{\begin{aligned}&\frac{\mathrm{d}^{2}y}{\mathrm{d}x^{2}}+\lambda y=0,&0\leqslant x\leqslant b\\ &y(0)=0,&y^{\prime}(b)=0\end{aligned}\right. $$ 

5. 量子力学中的薛定谔方程为

 $$ H\psi=E\psi $$ 

其中

 $$ H=-\frac{h^{2}}{2mdx^{2}}+V(x) $$ 

为哈密顿算符， $ \phi $ 和 E 分别是 H 的本征函数和本征值，m 是微观粒子的质量。假定粒子在  $ \delta $ 势阱中运动

 $$ V(x)=-a\delta(x)\quad(a>0) $$ 

对于束缚态情况 $ (E<0) $，求解薛定谔方程.

###  $ ^{*} $13.2 高斯方程和库默尔方程

在前两章中我们着重讨论了贝塞尔方程和勒让德方程，这两个在物理问题中常碰到的施图姆-刘维尔方程。除此以外，高斯方程和库默尔方程也是物理中应用较广的施图姆-刘维尔方程。特别是这两个方程及其解答与其他的斯-刘方程及其解答之间，有着千丝万缕的联系，故本节将对它们及其解答进行简单的介绍。

## 1. 高斯方程和超几何级数

高斯方程

$$  x(x-1)y^{\prime \prime}+\left[(\alpha+\beta+1)x-\gamma\right]y^{\prime}+\alpha\beta y=0   \tag*{(13.2.1)}$$

又称超几何方程. 它有三个正则奇点 x=0,1, $ \infty $. 其中  $ \alpha,\beta $ 和  $ \gamma $ 是实数. 现求其在 x=0 的级数解.

设

$$  y(x)=\sum_{k=0}^{\infty}c_{k}x^{k+\rho},\quad c_{0}\neq0   \tag*{(13.2.2)}$$

则得判定方程的两个根分别为

 $$ \rho=\rho_{1}=0,\quad\rho=\rho_{2}=1-\gamma $$ 

设  $ \gamma \neq $ 整数且  $ \gamma > 1 (\gamma < 1 $ 时结论相同)，则当  $ \rho = \rho_{1} = 0 $ 时将 (13.2.2) 式代入 (13.2.1) 式得到  $ c_{k} $ 的递推公式为

$$  c_{k+1}=\frac{(k+\alpha)(k+\beta)}{(k+\gamma)(k+1)}c_{k},\quad k=0,1,2,\cdots   \tag*{(13.2.3)}$$

<!-- page: 278 -->

故当取 $ c_{0}=1 $时，可得方程(13.2.1)的第一个特解为

$$  \begin{align*}y_{1}(x)&=1+\sum_{k=1}^{\infty}\frac{\alpha(\alpha+1)\cdots(\alpha+k-1)\beta(\beta+1)\cdots(\beta+k-1)}{k!\gamma(\gamma+1)\cdots(\gamma+k-1)}x^{k}\\&=\frac{\Gamma(\gamma)}{\Gamma(\alpha)\Gamma(\beta)}\sum_{k=0}^{\infty}\frac{\Gamma(\alpha+k)\Gamma(\beta+k)}{k!\Gamma(\gamma+k)}x^{k}\end{align*}   \tag*{(13.2.4)}$$

显然该级数解的收敛半径为1. 常将此级数解记为  $ F(\alpha,\beta,\gamma;x) $，即

$$  F(\alpha,\beta,\gamma;x)=\frac{\Gamma(\gamma)}{\Gamma(\alpha)\Gamma(\beta)}\sum_{k=0}^{\infty}\frac{\Gamma(\alpha+k)\Gamma(\beta+k)}{k!\Gamma(\gamma+k)}x^{k},\quad\mid x\mid<1   \tag*{（13.2.5）}$$

称之为超几何级数. 于是, 方程(13.2.1)有一超几何级数解

$$  y_{1}(x)=F(\alpha,\beta,\gamma;x)   \tag*{(13.2.6)}$$

当 $ \left|x\right|=1 $时，由于在k足够大时

 $$ \left|\frac{c_{k}x^{k}}{c_{k+1}x^{k+1}}\right|=1+\frac{\gamma+1-\alpha-\beta}{k}+O\left(\frac{1}{k^{2}}\right) $$ 

故由高斯判别法得知，当  $ \gamma > \alpha + \beta $ 时， $ y_{1}(x) $ 收敛；而当  $ \gamma \leqslant \alpha + \beta $ 时， $ y_{1}(x) $ 发散。

用类似的方法我们可求得:当 $ \rho=\rho_{2}=1-\gamma $ 时方程(13.2.1)的另一超几何级数特解

$$  y_{2}(x)=x^{1-\gamma}F(\alpha-\gamma+1,\beta-\gamma+1,2-\gamma;x)   \tag*{(13.2.7)}$$

由对(13.2.5)式中级数的敛散性讨论立即可知，当 $ |x|=1 $时，亦当 $ \gamma>\alpha+\beta $时收敛， $ \gamma\leqslant\alpha+\beta $时， $ y_{2}(x) $发散.

由上面讨论可知，当  $ \gamma \neq $ 整数时高斯方程（13.2.1）的两个线性独立解为

 $$ \left\{\begin{aligned}y_{1}(x)&=F(\alpha,\beta,\gamma;x)\\ y_{2}(x)&=x^{1-\gamma}F(\alpha-\gamma+1,\beta-\gamma+1,2-\gamma;x)\end{aligned}\right. $$ 

且当  $ \gamma > \alpha + \beta $ 时，它们均在  $ |x| \leqslant 1 $ 上收敛；当  $ \gamma $ 是整数时，方程的一个线性独立解是

 $$ y_{1}(x)=\begin{cases}F(\alpha,\beta,\gamma;x),&\gamma=1,2,3,\cdots\\x^{1-\gamma}F(\alpha-\gamma+1,\beta-\gamma+1,2-\gamma;x),&\gamma=0,-1,-2,\cdots\end{cases} $$ 

而另一个线性独立解则应具有(12.1.18)式的形式. 在此不作详细讨论.

由递推公式(13.2.3)还可看出，当 $ \alpha $或 $ \beta=-l(l=0,1,2,\cdots) $时 $ c_{k}=0(k\geqslant l+1) $，此时 $ F(\alpha,\beta,\gamma;x) $退化为l次多项式.事实上能够证明，勒让德方程是高斯方程的特例 $ ^{①} $，

$$  \mathrm{P}_{l}(x)=F(-l,l+1,1;x)   \tag*{（13.2.8）}$$

## 2. 库默尔(Kummer)方程和合流超几何函数

在高斯方程中，若令  $ x=\frac{X}{\beta} $，则高斯方程化为

 $$ X\Big(\frac{X}{\beta}-1\Big)y^{\prime \prime}(X)+\Big[X+\frac{\alpha+1}{\beta}X-\gamma\Big]y^{\prime}(X)+\alpha y(X)=0 $$

<!-- page: 279 -->

令  $ \beta \to \infty $，仍记 X 为 x，则得

$$  xy^{\prime \prime}+(\gamma-x)y^{\prime}-\alpha y=0   \tag*{(13.2.9)}$$

被称为库默尔方程或合流超几何方程. 它实际上是一个退化了的高斯方程. 其正则奇点为 x=0, $ \infty $. 故当  $ \gamma\neq $ 整数时, 易于得到其两个线性独立的解为

$$  \begin{aligned}y_{1}(x)&=\lim_{\beta\to\infty}F(\alpha,\beta,\gamma;x)=\frac{\Gamma(\gamma)}{\Gamma(\alpha)}\sum_{k=0}^{\infty}\frac{\Gamma(k+\alpha)}{k!\Gamma(k+\gamma)}x^{k}\\&=F(\alpha,\gamma;x)\end{aligned}   \tag*{（13.2.10）}$$

$$  \begin{aligned}y_{2}(x)&=\lim_{\beta\to\infty}x^{1-\gamma}F(\alpha-\gamma+1,\beta-\gamma+1,2-\gamma;x)\\&=x^{1-\gamma}F(\alpha-\gamma+1,2-\gamma;x)\end{aligned}   \tag*{(13.2.11)}$$

其中

$$  F(\alpha,\gamma;x)=\frac{\Gamma(\gamma)}{\Gamma(\alpha)}\sum_{k=0}^{\infty}\frac{\Gamma(k+\alpha)}{k!\Gamma(k+\gamma)}x^{k}   \tag*{（13.2.12）}$$

称为库默尔函数或合流超几何级数. 其收敛半径为∞.

由级数的系数递推公式可知，当  $ \alpha = -n (n = 0, 1, 2, \cdots) $ 时  $ F(\alpha, \gamma; x) $ 退化为 n 次多项式.

许多特殊函数都能用合流超几何函数表示，如

贝塞尔函数

$$  \mathrm{J}_{\nu}(x)=\frac{1}{\Gamma(\nu+1)}\mathrm{e}^{-\mathrm{i}x}\left(\frac{x}{2}\right)^{\nu}F\left(\nu+\frac{1}{2},2\nu+1;2\mathrm{i}x\right)   \tag*{(13.2.13)}$$

厄米函数

$$  \mathrm{H}_{\nu}(x)=\frac{\sqrt{\pi}}{\Gamma\left(\frac{1-\nu}{2}\right)}F\Big(-\frac{\nu}{2},\frac{1}{2};x^{2}\Big)-\frac{\sqrt{2\pi}}{\Gamma\left(\frac{-\nu}{2}\right)}x F\Big(\frac{1-\nu}{2},\frac{3}{2};x^{2}\Big)   \tag*{(13.2.14)}$$

$$  \left\{\mathrm{H}_{2n}(x)=(-1)^{n}\frac{(2n)!}{n!}F\left(-n,\frac{1}{2};x^{2}\right)\right.   \tag*{（13.2.15）}$$

厄米多项式

$$  \mathrm{H}_{2n+1}(x)=(-1)^{n}\frac{(2n+1)!}{n!}2x F\left(-n,\frac{3}{2};x^{2}\right)   \tag*{（13.2.16）}$$

$$  \mathrm{L}_{\nu}^{\mu}(x)=\frac{1}{\Gamma(\nu+1)}F(-\nu,\mu+1,x)   \tag*{(13.2.17)}$$

拉盖尔多项式  $ \mathrm{L}_{n}(x)=F(-n,1;x) $

误差函数  $ \mathrm{erf}(x)=\frac{2x}{\sqrt{\pi}}F\left(\frac{1}{2},\frac{3}{2};-x^{2}\right) $

等等.

注 ① 令  $ x=\frac{1-t}{2},\alpha=-l,\beta=(l+1),\gamma=1 $ ，则方程 (13.2.1) 便化为

 $$ (1-t^{2})y^{\prime \prime}-2ty^{\prime}+l(l+1)y=0 $$

<!-- page: 280 -->

<div style="text-align: center;"><img src="images/p0280_img_in_image_box_100_311_163_378.jpg" alt="本篇主要特殊函数性质小结" width="6%" /></div>


本章授课课件

<div style="text-align: center;"><div style="text-align: center;">本篇主要特殊函数性质小结</div> </div>




<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>名称性质</td><td style='text-align: center; word-wrap: break-word;'>$ P_i(x) $</td><td style='text-align: center; word-wrap: break-word;'>$ P_i^m(x) $</td><td style='text-align: center; word-wrap: break-word;'>$ J_n(x) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>表达式</td><td style='text-align: center; word-wrap: break-word;'>$ P_i(x) = \begin{cases} \left[\frac{L}{2}\right] &amp; \left(-\frac{1}{2}\right)^n(2l-2n)!x^{l-2n} \\ \sum_{n=0}^{2n-1} \frac{2^n}{n!}(l-n)!(l-2n)! \\ \frac{1}{2^l} \frac{d^l}{dx^l} (x^2-1)^l \\ \frac{1}{2\pi i} \oint_L (\zeta_i-1)^l \int_0 d\zeta_i \\ l=0,1,2,\cdots \end{cases} $\n $ P_i^m(x) = \begin{cases} (1-x^2)^{m_1^2}P_i^{(m)}(x) \\ \frac{1}{2^l!}(1-x^2)^{m_2^2} \frac{d^{l+m}}{dx^{l+m}}(x^2-1)^l \\ \frac{(1-x^2)^{m_2^2}}{2^l} \frac{1}{2\pi i} \frac{(l+m)!}{l!} \\ \cdot \oint_{L^s} (\frac{(\zeta_i-1)^l}{\zeta-x})^{l+m+1} \\ m=0,1,\cdots,l \end{cases} $\n $ P_i^m(x) = \begin{cases} (1-x^2)^{m_1^2}P_i^{(m)}(x) \\ \frac{1}{2^l!}(1-x^2)^{m_2^2} \frac{d^{l+m}}{dx^{l+m}}(x^2-1)^l \\ \frac{(1-x^2)^{m_2^2}}{2^l} \frac{1}{2\pi i} \frac{(l+m)!}{l!} \\ \cdot \oint_{L^s} (\frac{(\zeta_i-1)^l}{\zeta-x})^{l+m+1} \end{cases} $\n $ P_i^m(x) = \sum_{n=-\infty}^{\infty} J_n(x)t^n $</td><td style='text-align: center; word-wrap: break-word;'>$ J_n(x) = \begin{cases} \sum_{k=0}^{\infty} \frac{(-1)k}{k!(n+k)!}\left(\frac{x}{2}\right)^{2k+n} \\ \frac{1}{2\pi i} \int_{-\pi}^{\pi} e^{i(x+h-w\theta)} d\theta \\ \frac{1}{2\pi i} \int_{-\pi}^{\pi} \cos(x\sin\theta-n\theta) d\theta \end{cases} $</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>关系母函数</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{\sqrt{1-2xt+t^2}} = \sum_{i=0}^{\infty} P_i(x)t^i $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{(2m-1)!!(1-x^2)^{m/2}}{(1-2xt+t^2)^{m+1/2}} = \sum_{i=m}^{\infty} P_i^m(x)t^{i-m} $</td><td style='text-align: center; word-wrap: break-word;'>$ e^{\frac{i}{2}(r-\frac{1}{r})} = \sum_{n=-\infty}^{\infty} J_n(x)t^n $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>递推公式</td><td style='text-align: center; word-wrap: break-word;'>$ (l+1)P_{t+1}(x)=(2l+1)xP_t(x)-lP_{t-1}(x) $\n $ P_{t+1}(x)-P_{t-1}^r(x)=(2l+1)P_t(x) $</td><td style='text-align: center; word-wrap: break-word;'>$ (l+1-m)P_{t+1}^m(x)-(2l+1)xP_t^m(x) $\n $ (l+m)P_{t-1}^m(x)=0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{\mathrm{d}}{\mathrm{d}x}\left[x^s J_s(x)\right] = x^s J_{s-1}(x) $\n $ \frac{\mathrm{d}}{\mathrm{d}x}\left[x^{-s} J_s(x)\right] = -x^{-s} J_{s+1}(x) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>正交性</td><td style='text-align: center; word-wrap: break-word;'>$ \int_{-1}^{t}P_i(x)P_k(x)\mathrm{d}x = \frac{2}{2l+1}\delta_{kl} $</td><td style='text-align: center; word-wrap: break-word;'>$ \int_{-1}^{t}P_i^m(x)P_k^m(x) = \frac{(l+m)!}{(l-m)!} \frac{2\delta_{kl}}{2l+1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \int_0^s J_n(k_m\rho)J_n(k_l\rho)\mathrm{d}\rho = \frac{a^2}{2}\left[J_{n+1}(k_m\rho)\right]^2 \delta_{ml} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>广义Fourier展开</td><td style='text-align: center; word-wrap: break-word;'>$ f(x) = \sum_{l=0}^{\infty} C_l P_l(x) $\n $ C_l = \frac{2l+1}{2}\int_{-1}^{l}f(x)P_l(x)\mathrm{d}x $</td><td style='text-align: center; word-wrap: break-word;'>$ f(x) = \sum_{l=0}^{\infty} C_l^m P_l^m(x) $\n $ C_l^m = \frac{2l+1}{2}\frac{(l-m)!}{(l+m)!}\int_{-1}^{l}f(x)P_l^m(x)\mathrm{d}x $</td><td style='text-align: center; word-wrap: break-word;'>$ f(\rho) = \sum_{m=1}^{\infty} C_m J_m(k_m\rho) $\n $ C_m = \frac{a^2}{2}\left[J_{m+1}(k_m\rho)\right]^2 \int_0^p f(\rho)J_m(k_m\rho)\mathrm{d}\rho $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>常用值</td><td style='text-align: center; word-wrap: break-word;'>$ P_0(x) = 1, P_1(x) = x $\n $ P_2(x) = \frac{1}{2}(3x^2-1) $\n $ P_1(1) \equiv 1 $,  $ P_i(-x)=(-1)^i P_i(x) $</td><td style='text-align: center; word-wrap: break-word;'>$ P_1^1(x) = (1-x^2)^+  $\n $ P_2^1(x) = 3(1-x^2)^+ x $</td><td style='text-align: center; word-wrap: break-word;'>$ J_0(0) = 1 $,  $ J_n(0) = 0 (n \geq 1) $\n $ J_1(x) = \sqrt{\frac{2}{\pi x}} \sin x $,  $ J_2(x) = \sqrt{\frac{2}{\pi x}} \cos x $,\n $ j_1(x) = \sqrt{\frac{\pi}{2x}} J_{i+1}(x) $,  $ j_0(x) = \frac{\sin x}{x} $,  $ j_1(x) = -\frac{\cos x}{x} $</td></tr></table>

<!-- page: 281 -->

记住要仰望星空，不要低头看脚下。无论生活如何艰难，请保持一颗好奇心。你总会找到自己的路和属于你的成功。

——霍金

##  $ ^{*} $第四篇 近似方法及现代内容

在第二篇中我们已导出了数学物理中三类典型的二阶线性偏微分方程，并介绍了求其解析解的各种方法。然而，从数学的角度看，能用线性描绘的事物微乎其微！事实上大多事物的本来面目都是非线性的，线性只不过是一理想的或近似的情况而已。由于物理问题的复杂性，特别是突飞猛进地发展的现代科学的需求，使得仅用传统的三类典型方程来描绘数学物理问题已远远不够！

对于复杂的泛定方程和不规则的边界条件，我们也无法用第二篇所介绍的方法求得其解析解和对其进行研究。在这种情况下，采用某种方法求近似程度满足需要的近似解（包括解析近似解和数值近似解）以及新的研究方法具有重要的现实意义。

本篇将引入理论物理特别是近代物理中常会碰到的非线性方程和积分方程的有关知识；介绍求解方程解析近似解的变分法、摄动法以及数值近似解的分步傅里叶变换法；还介绍近20年来迅猛发展起来的一种新的变换分析方法—小波变换。

<!-- page: 282 -->

变分法是求近似解析解的最有力的方法之一，它的原理和应用渗透到了物理学的各个部门，成为理论物理中广泛使用的一种数学工具。通常所说的变分法就是求泛函极值的方法。本章将从数学物理中应用的角度，来说明变分法的基本概念、原理及用来求解数学物理方程的基本思想。为此，我们首先必须了解泛函的概念和泛函的极值问题。

### 14.1 泛函和泛函的极值

## 1. 泛函

泛函是函数概念的推广.为了说明问题先看一个例子.

讨论力学中的最速落径(brachistochrone)问题. 如图14.1所示, 已知A和B为不在同一铅垂线和同一高度的两点, 要求找出A、B间的这样一条曲线, 当一质点在重力作用下沿这条曲线无摩擦地从A滑到B时, 所需时间T最小.

我们知道，此时质点的速度是

<div style="text-align: center;"><img src="images/p0282_img_in_image_box_623_680_858_870.jpg" alt="图14.1" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图14.1</div> </div>


 $$ \mathrm{\frac{ds}{d t}}=\sqrt{2 g y} $$ 

其中 g 为重力加速度，故从 A 滑到 B 所需的时间为

 $$ T=\int_{t_{1}(A)}^{t_{2}(B)}\mathrm{d}t=\int_{A}^{B}\frac{\mathrm{d}s}{\sqrt{2g y}}=\int_{A}^{B}\frac{\sqrt{1+y^{^{\prime}2}}}{\sqrt{2g y}}\mathrm{d}x $$ 

即

$$  T[y(x)]=\int_{A}^{B}\frac{\sqrt{1+y^{^{\prime}2}}}{\sqrt{2gy}}\mathrm{d}x   \tag*{(14.1.1)}$$

我们称上述的 T 为  $ y(x) $ 的泛函，而称  $ y(x) $ 可取的函数类，为泛函  $ T[y(x)] $ 的定义域。简单地说，泛函就是函数的函数（不是复合函数的那种含义）。一般地讲，设 C 是函数的集合，B 是实数或复数的集合，如果对于 C 的任一元素  $ y(x) $，在 B 中都有一个元素 J 与之对应，则称 J 为  $ y(x) $ 的泛函，记为

<!-- page: 283 -->

$$ J=J\bigl[y(x)\bigr] $$ 

必须注意，泛函不同于通常讲的函数，决定通常函数的值的因素是自变量的取值，而决定泛函的值的因素则是函数的取形。如，上面例子中的泛函 T 的变化是由函数  $ y(x) $ 本身的变化（即从 A 到 B 的不同曲线）所引起的。它的值既不取决于某一个 x 值，也不取决于某一个 y 值，而是取决于整个集合 C 中 y 与 x 的函数关系。

泛函通常以积分形式出现，比如，上面描述最速落径问题的(14.1.1)式。一般，最简单而又典型的泛函可表为

$$  J[y(x)]=\int_{a}^{b}F(x,y,y^{\prime})\mathrm{d}x   \tag*{(14.1.2)}$$

其中  $ F(x,y,y') $ 称为泛函的核.

## 2. 泛函的极值与泛函的变分

引入泛函的概念后，上述的最速落径问题就变为了求泛函  $ T[y(x)] $ 的极小值问题。泛函的极值问题在物理学中各部分都有，例如光学中的费马(Fermat)原理 $ ^{①} $，分析力学中的哈密顿(Hamilton)原理 $ ^{②} $等，都是泛函的极值问题。所谓变分法就是求泛函极值的方法，我们将会看到，研究泛函极值问题的方法可归纳为两类，一类叫直接法，即直接分析所提出的问题；另一类叫间接法，即把问题转化为求解微分方程。为讨论间接方法，先介绍泛函的变分。

设有连续函数  $ y(x) $，将它略为变形，即将  $ y(x) $ 变为  $ y(x)+t\eta(x) $，其中 t 为一个小参数，则称  $ t\eta(x) $ 为  $ y(x) $ 的变分。记为

$$  \delta y=t\eta(x)   \tag*{(14.1.3)}$$

此时函数  $ y'(x) $ 将相应地变形为

 $$ \begin{aligned}\lim_{\Delta x\to0}\frac{\Delta(y+t\eta)}{\Delta x}&=y^{\prime}(x)+t\eta^{\prime}(x)\\\delta y^{\prime}&=t\eta^{\prime}(x)=\frac{\mathrm{d}}{\mathrm{d}x}(\delta y)\end{aligned} $$ 

可见

这表明，对于一个给定的函数，变分和微分两种运算可以互换次序。

设(14.1.2)式中 F 对 x, y,  $ y' $ 都是连续二阶可导, y 的二阶导数连续, 则当  $ y(x) $ 有变分  $ \delta y $ 时, J 的变化为

 $$ \begin{aligned}\Delta J&=J\big[y(x)+t\eta(x)\big]-J\big[y(x)\big]\\&=\int_{a}^{b}\big[F(x,y+t\eta,y^{\prime}+t\eta^{\prime})-F(x,y,y^{\prime})\big]\mathrm{d}x\\&=\int_{a}^{b}\Big[\frac{\partial F}{\partial y}t\eta+\frac{\partial F}{\partial y^{\prime}}t\eta^{\prime}+t\  的高阶项 \Big]\mathrm{d}x^{\textcircled{3}}\\ \end{aligned} $$ 

我们称上式右边的线性主部（即略去高阶无穷小量的部分）为泛函  $ J[y(x)] $ 的第一次变分，简称泛函的变分，记为

<!-- page: 284 -->

$$  \delta J=\int_{a}^{b}\Bigl(\frac{\partial F}{\partial y}\delta y+\frac{\partial F}{\partial y^{\prime}}\delta y^{\prime}\Bigr)\mathrm{d}x   \tag*{(14.1.5)}$$

## 3. 泛函取极值的必要条件——欧拉方程

设  $ J[y(x)] $ 的极值问题有解

$$  y=y(x)   \tag*{(14.1.6)}$$

现在推导这个解所满足的常微分方程，这是用间接法研究泛函极值问题的重要一环。设想这个解有变分  $ t\eta(x) $，则  $ J[y(x)+t\eta(x)] $ 可视为参数 t 的函数  $ \Phi(t)=J[y(x)+t\eta(x)] $。而当 t=0 时， $ y(x)+t\eta(x)=y(x) $ 对应于 (14.1.6) 式，即  $ J[y(x)+t\eta(x)] $ 取极值。于是，原来的泛函的极值问题，就化为一个求普通函数  $ \Phi(t) $ 的极值问题。由函数取极值的必要条件，有

 $$ \frac{\mathrm{d}\Phi}{\mathrm{d}t}\bigg|_{t=0}=0 $$ 

即

 $$ \frac{\partial J\left[y(x)+t\eta(x)\right]}{\partial t}\bigg|_{t=0}=0 $$ 

将(14.1.2)式代入，也就是

 $$ \int_{a}^{b}\left[\frac{\partial}{\partial t}F(x,y+t\eta,y^{\prime}+t\eta^{\prime})\right]_{t=0}\mathrm{d}x=0 $$ 

即

 $$ \int_{a}^{b}\left(\frac{\partial F}{\partial y}\eta+\frac{\partial F}{\partial y^{\prime}}\eta^{\prime}\right)\mathrm{d}x=0 $$ 

上式两边乘以 t 得

$$  \int_{a}^{b}\Big(\frac{\partial F}{\partial y}\delta y+\frac{\partial F}{\partial y^{\prime}}\delta y^{\prime}\Big)\mathrm{d}x=0   \tag*{(14.1.7)}$$

与(14.1.5)式比较可知，使得 $ J[y(x)] $取极值的解(14.1.6)必须满足

$$  \delta J=0   \tag*{(14.1.8)}$$

此即泛函取极值的必要条件. 即，泛函 J 的极值函数  $ y(x) $，必须是满足泛函的变分  $ \delta J=0 $ 的函数类  $ y(x) $. 因此，把泛函的极值问题称为变分问题.

（14.1.7）式的积分号下既有 $ \delta y $，又有 $ \delta y' $，对第二项应用分部积分法可使积分号下只出现 $ \delta y $

 $$ \int_{a}^{b}\frac{\partial F}{\partial y^{^{\prime}}}\delta y^{^{\prime}}\mathrm{d}x=\int_{a}^{b}\frac{\partial F}{\partial y^{^{\prime}}}\frac{\mathrm{d}}{\mathrm{d}x}(\delta y)\mathrm{d}x=\frac{\partial F}{\partial y^{^{\prime}}}\delta y\bigg|_{a}^{b}-\int_{a}^{b}\frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial F}{\partial y^{^{\prime}}}\Big)\delta y\mathrm{d}x $$ 

在简单的变分问题中，都保持 $ \delta y|_{x=a}=0,\delta y|_{x=b}=0 $，即，端点的函数值是固定的 $ ^{④} $，故上式右边第一项为零，于是(14.1.7)式成为

 $$ \int_{a}^{b}\Bigl[\frac{\partial F}{\partial y}-\frac{\mathrm{d}}{\mathrm{d}x}\Bigl(\frac{\partial F}{\partial y^{\prime}}\Bigr)\Bigr]\delta y\mathrm{d}x=0 $$ 

上式对任意给定的 $ [a,b] $和任何的 $ \delta y $都成立，所以

$$  \frac{\partial F}{\partial y}-\frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial F}{\partial y^{^{\prime}}}\Big)=0   \tag*{(14.1.9)}$$

<!-- page: 285 -->

即，泛函(14.1.2)式有极值的必要条件，又可表示为方程(14.1.9)式，称为泛函(14.1.2)的极值问题的欧拉(Euler)方程 $ ^{⑤} $.

较复杂的泛函的欧拉方程可仿照上述方法导出. 比如，对于取决于一个自变数的几个函数的泛函

 $$ J\left[y_{1}(x),y_{2}(x)\cdots y_{n}(x)\right]=\int_{a}^{b}F(x;y_{1},y_{2}\cdots y_{n};y_{1}^{\prime},y_{2}^{\prime}\cdots y_{n}^{\prime})\mathrm{d}x $$ 

为了寻求这个泛函的极值条件，我们只让泛函中的一个函数，如  $ y_{k}(x) $ 获得变分，而令其余的函数保持不变。这样，原来的泛函 J 可以看成只依赖于一个函数的泛函  $ J_{k}[y_{k}] $，而使得这个泛函具有极值的函数  $ y_{k}(x) $ 应该满足

 $$ \frac{\partial F}{\partial y_{k}}-\frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial F}{\partial y_{k}^{^{\prime}}}\Big)=0 $$ 

这样的推理对于每一个函数都能适用，故泛函  $ J[y_{1}(x), y_{2}(x), \cdots, y_{n}(x)] $ 的变分问题对应于下列欧拉方程组：

$$  \frac{\partial F}{\partial y_{i}}-\frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial F}{\partial y_{i}^{^{\prime}}}\Big)=0,\quad i=1,2,3,\cdots,n   \tag*{(14.1.10)}$$

另外，对于泛函取决于  $ y(x) $ 及其 n 阶导数的情况，例如变分问题

 $$ \delta\int_{a}^{b}F(x;y,y^{\prime},y^{\prime \prime},y^{\prime \prime \prime})\mathrm{d}x=0 $$ 

对应的欧拉方程是

$$  \frac{\partial F}{\partial y}-\frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial F}{\partial y^{\prime}}\Big)+\frac{\mathrm{d}^{2}}{\mathrm{d}x^{2}}\Big(\frac{\partial F}{\partial y^{\prime \prime}}\Big)-\frac{\mathrm{d}^{3}}{\mathrm{d}x^{3}}\Big(\frac{\partial F}{\partial y^{\prime \prime \prime}}\Big)=0   \tag*{(14.1.11)}$$

对于泛函取决于多元函数的情况，例如取决于三元函数  $ u(x, y, z) $，其变分问题为

 $$ \delta\iiint_{v}F(x,y,z;u;u_{x},u_{y},u_{z})\mathrm{d}x\mathrm{d}y\mathrm{d}z=0 $$ 

对应的欧拉方程是偏微分方程

$$  \frac{\partial F}{\partial u}-\frac{\partial}{\partial x}\Big(\frac{\partial F}{\partial u_{x}}\Big)-\frac{\partial}{\partial y}\Big(\frac{\partial F}{\partial u_{y}}\Big)-\frac{\partial}{\partial z}\Big(\frac{\partial F}{\partial u_{z}}\Big)=0   \tag*{(14.1.12)}$$

例 1 求解最速落径问题，即变分问题

 $$ \delta\int_{A}^{B}\frac{\sqrt{1+y^{^{\prime}2}}}{\sqrt{2gy}}\mathrm{d}x=0 $$ 

解 目前我们只能用间接方法来求解. 由于

 $$ F=\frac{\sqrt{1+y^{^{\prime}2}}}{\sqrt{2gy}} $$ 

不显含 x，故其欧拉方程 $ ^{⑤} $为

 $$ y^{^{\prime}}\frac{\partial}{\partial y^{^{\prime}}}\sqrt{\frac{1+y^{^{\prime}2}}{y}}-\sqrt{\frac{1+y^{^{\prime}2}}{y}}=c $$ 

即

<!-- page: 286 -->

$$ \frac{y^{^{\prime}2}}{\sqrt{y(1+y^{^{\prime}2})}}-\sqrt{\frac{1+y^{^{\prime}2}}{y}}=c $$ 

亦即

 $$ \frac{1}{y(1+y^{^{\prime}2})}=c^{2} $$ 

令 $ \frac{1}{c^{2}}=c_{1} $，分离变数得

 $$ \frac{\sqrt{y}\mathrm{d}y}{\sqrt{c_{1}-y}}=\mathrm{d}x,\quad c_{1} 为积分常数 $$ 

再令

 $$ y=c_{1}\sin^{2}\frac{\theta}{2} $$ 

代入上式，则得

 $$ \mathrm{d}x=c_{1}\sin^{2}\frac{\theta}{2}\mathrm{d}\theta=\frac{c_{1}}{2}(1-\cos\theta)\mathrm{d}\theta $$ 

所以有

 $$ \left\{\begin{aligned}x&=\frac{c_{1}}{2}(\theta-\sin\theta)+c_{2}\\ y&=\frac{c_{1}}{2}(1-\cos\theta)\end{aligned}\right. $$ 

此即摆线的参数方程，积分常数  $ c_{1}, c_{2} $ 可由 A、B 的位置决定.

## 4. 泛函的条件极值问题

在许多泛函的极值问题中，变量函数还受到一些附加条件的限制，其中最重要的一种是以积分形式表示的限制

$$  \int_{a}^{b}G(x,y,y^{\prime})\mathrm{d}x=l   \tag*{(14.1.13)}$$

即所谓等周问题 $ ^{⑥} $

$$  \left\{\begin{aligned}J\big[y(x)\big]&=\int_{a}^{b}F(x,y,y^{\prime})\mathrm{d}x,y(a)=y_{0},y(b)=y_{1}\\ \int_{a}^{b}G(x,y,y^{\prime})\mathrm{d}x&=l\end{aligned}\right.   \tag*{(14.1.14)}$$

其中，l 和  $ y_{0} $， $ y_{1} $ 均为常数。用欧拉方程解这类问题，可仿照解函数的条件极值问题的拉格朗日（Lagrange）乘子法 $ ^{⑦} $，即将附加条件（14.1.13）乘以参数  $ \lambda $，求其变分后，加到泛函的变分问题（14.1.8）中，得到

 $$ \delta\int_{a}^{b}\left[F(x;y,y^{\prime})+\lambda G(x;y,y^{\prime})\right]\mathrm{d}x=0 $$ 

于是，问题转化为不带条件的由上式所表示的变分问题. 其对应的欧拉方程为

$$  \frac{\partial F}{\partial y}+\lambda\frac{\partial G}{\partial y}-\frac{\mathrm{d}}{\mathrm{d}x}\big(\frac{\partial F}{\partial y^{\prime}}+\lambda\frac{\partial G}{\partial y^{\prime}}\big)=0   \tag*{(14.1.15)}$$

这是通过 a 和 b 两点的  $ y(x) $ 在附加条件 (14.1.13) 之下使泛函 (14.1.2) 取极值的必

<!-- page: 287 -->

要条件. 它是一个关于  $ y(x) $ 的二阶常微分方程. 其通解中含有三个参数, 即  $ \lambda $ 和两个积分常数. 它们可由条件  $ y(a)=y_{0}, y(b)=y_{1} $ 和附加条件 (14.1.13) 来定.

例2 求  $ J[y(x)]=\int_{0}^{1}(y')^{2}dx $ 的极值，其中 y 是归一化的，即  $ \int_{0}^{1}y^{2}dx=1 $，且已知  $ y(0)=0,y(1)=0 $.

解 这是求泛函的条件极值问题，可化为变分问题

 $$ \delta\int_{0}^{1}(y^{\prime2}+\lambda y^{2})\mathrm{d}x=0 $$ 

对应的欧拉方程是

 $$ y^{\prime \prime}-\lambda y=0 $$ 

其通解为

 $$ y=c_{1}\mathrm{e}^{\sqrt{\lambda}x}+c_{2}\mathrm{e}^{-\sqrt{\lambda}x} $$ 

代入条件  $ y(0)=0, y(1)=0 $ 得

 $$ y_{n}(x)=c_{n}\mathrm{s i n}n\pi x,\quad n=1,2,\cdots $$ 

代入归一化条件得

 $$ \int_{0}^{1}c_{n}^{2}\sin^{2}n\pi x\mathrm{d}x=1 $$ 

于是得  $ c_{n}=\pm\sqrt{2} $，故原极值问题的解为

 $$ y_{n}=\pm\sqrt{2}\sin n\pi x $$ 

而泛函 $ \int_{0}^{1}(y^{\prime})^{2}\mathrm{d}x $的极值为

 $$ \int_{0}^{1}2\pi^{2}\cos^{2}n\pi x\mathrm{d}x=n^{2}\pi^{2} $$ 

当n=1时，极值函数 $ y_{1}(x)=\pm\sqrt{2}\sin\pi x $使泛函取得最小值 $ \pi^{2} $

## 5. 求泛函极值的直接方法——里兹(Ritz)方法

上面，我们将变分问题归结为求解微分方程的问题。而微分方程仅在不多的情况下能够积分为有限形式，因此人们就想到，从泛函本身出发，不经过微分方程直接求出其极值曲线。这就是所谓研究泛函极值问题的直接方法。

里兹方法就是比较典型的直接方法. 其基本要点是, 不把泛函  $ J[y(x)] $ 放在它的全部定义域内来考虑, 而把它放在其定义域的某一部分来考虑. 具体而言, 取某种完备函数系

 $$ \varphi_{1}(x),\varphi_{2}(x),\cdots $$ 

尝试以其中的前几个来表示变分问题  $ \delta J = 0 $ 的解，即，令解为

$$  y(x)=f(\varphi_{1},\varphi_{2},\varphi_{3},\cdots,\varphi_{n};c_{1},c_{2},c_{3},\cdots,c_{n})   \tag*{（14.1.16）}$$

其中  $ c_{1}, c_{2}, c_{3}, \cdots, c_{n} $ 为待定参数。把上式代入 J 的表示式，J 便成了  $ c_{1}, c_{2}, c_{3}, \cdots, c_{n} $ 的 n 元函数，即  $ J[y(x)] = \Phi(c_{1}, c_{2}, \cdots, c_{n}) $。由于 f 的形式是我们预先选定了的[如，可选  $ f = \sum_{i=1}^{n} c_{i} \varphi_{i}(x) $]，故按照多元函数的极值的方法令

<!-- page: 288 -->

$$  \frac{\partial\Phi}{\partial c_{i}}=0,\quad i=1,2,\cdots,n   \tag*{(14.1.17)}$$

而求出系数  $ c_{1}, c_{2}, \cdots, c_{n} $，从而也就完全确定了  $ y(x) $。但这样得到的  $ y(x) $ 并非  $ \delta J = 0 $ 的严格解，而只是近似解，若将上述近似解记作  $ y_{n}(x) $ 则严格解应该是

 $$ y(x)=\lim_{n\to\infty}y_{n}(x) $$ 

不过，这个极限过程是否收敛，收敛的快慢如何，是否收敛于严格解，都还是问题；而且实际问题中果真去求上列极限往往很麻烦，因此，通常就止于求出近似解。

在里兹方法中，如果函数系  $ \varphi_{1}(x) $， $ \varphi_{2}(x) $，…选得适当，而且尝试函数 f 也取得适当，便能求出近似程度很高的近似解；如果选得不当，所得“近似解”可能与严格解相差很远。至于怎样才能适当，并无一定方法可循，只能根据问题的性质（如边值的性质）结合经验来试选。常常选择函数系为多项式或三角函数系。

例 3 用里兹方法解例 2，求其最小值.

解 试以  $ c_{n}x^{n} $ 作为所选用的函数系，采用试探解

$$  y(x)=x(x-1)(c_{0}+c_{1}x)   \tag*{(14.1.18)}$$

头两个因式的取用，是为了满足  $ y(0)=0 $ 和  $ y(1)=0 $ 。将（14.1.18）式代入  $ \int_{0}^{1}(y^{\prime})^{2}dx $ ，则

$$  \begin{align*}J[y(x)]=&\int_{0}^{1}[3c_{1}x^{2}+2(c_{0}-c_{1})x-c_{0}]^{2}\mathrm{d}x\\=&\frac{1}{3}\Big(c_{0}^{2}+c_{0}c_{1}+\frac{2}{5}c_{1}^{2}\Big)\end{align*}   \tag*{(14.1.19)}$$

由归一化条件 $ \int_{0}^{1}y^{2}dx=1 $得到

$$  \frac{1}{30}\Big(c_{0}^{2}+c_{0}c_{1}+\frac{2}{7}c_{1}^{2}\Big)=1   \tag*{(14.1.20)}$$

在条件(14.1.20)式下求(14.1.19)式的极值本可采用拉格朗日乘子法，但本题有如下简便的方法，由(14.1.20)式

 $$ c_{0}^{2}+c_{0}c_{1}=30-\frac{2}{7}c_{1}^{2} $$ 

代入14.1.19式

 $$ J[y(x)]=\frac{1}{3}\Big(30-\frac{2}{7}c_{1}^{2}+\frac{2}{5}c_{1}^{2}\Big)=\frac{2}{3}\Big(15+\frac{2}{35}c_{1}^{2}\Big) $$ 

显然，在  $ c_{1}=0 $ 时， $ J[y(x)] $ 最小，其值为 10. 此时，由（14.1.20）式有  $ c_{0}=\pm\sqrt{30} $，所以

 $$ y(x)=\pm\sqrt{30}x(x-1) $$ 

让我们将这个近似解与例2求得的严格解比较。近似解为两条过 $ (0,0) $和 $ (1,0) $的、开口分别向上和向下的抛物线；严格解则为两条以 $ (0,0) $和 $ (1,0) $为拐点的正弦曲线。在区间 $ [0,1] $上，它们是很相近的。近似解反映泛函最小值的近似值为10，而严格解表明泛函的最小值为 $ \pi^{2} $。

<!-- page: 289 -->

在物理学中用变分法（中的直接方法）求泛函的极值是经常用到的。如，在量子力学中常用变分法求体系基态能量，其基本步骤是：选取含有参量  $ \lambda $ 的尝试波函数  $ \psi(\lambda) $，代入描述体系能量平均值的公式

 $$ \overline{{H}}=\int\psi^{*}\hat{H}\psi\mathrm{d}\tau $$ 

算出 $ \bar{H}(\lambda) $，然后由

 $$ \frac{\partial\overline{H}(\lambda)}{\partial\lambda}=0 $$ 

来求出  $ \overline{H}(\lambda) $ 的最小值. 可以看到, 用变分法求得的氦原子的基态能量, 比另一近似方法微扰法求得的更接近.

注 ① 费马原理指出：光线在 A、B 两点间传播的实际路径，与其他可能的邻近的路程相比，其光程为极值。即，光线的实际路径上光程的变分为零。其数学表述为

$$  \delta l=\delta\int_{A}^{B}n\mathrm{d}l=0   \tag*{(14.1.21)}$$

其中，n为介质的折射率，dl为沿光线进行方向的路程元。

②哈密顿原理指出：保守的、完整的力学体系在相同时间内，由某一初位形转移到另一已知位形的一切可能运动中，真实运动的作用函数具有极值，即，对于真实运动来讲，作用函数的变分等于零。其数学表述为

$$  \delta S=\delta\int_{t_{0}}^{t_{1}}L(q_{i},\dot{q}_{i},t)\mathrm{d}t=0,\quad i=1,2,\cdots,s   \tag*{(14.1.22)}$$

其中，L 为拉格朗日函数，等于力学体系动能和势能之差， $ q_{i} $ 为广义坐标，dt 为时间元。

除哈密顿原理外，在力学中用到变分法的还有虚功原理、最小作用量原理等其他一些原理，详见理论力学。

③这里引用了多元函数的泰勒展开公式： $ F(x,y+\Delta y,z+\Delta z)=F(x,y,z)+\frac{\partial F}{\partial y}\Delta y+\frac{\partial F}{\partial z}\Delta z+\cdots $

④如在最速落径问题中， $ y+\delta y $ 和 y 两曲线都从 A 出发到 B 终止，即  $ y+\delta y-y|_{A}=\delta y|_{A}=0 $； $ y+\delta_{y}-y|_{B}=\delta y|_{B}=0 $。有些变分问题其端点的函数值是可变的，如  $ y(b) $ 是可变的，则 (14.1.2) 式的变分问题除满足 (14.1.9) 式外，在变端点还需满足自然边界条件  $ \left.\frac{\partial F}{\partial y}\right|_{y=b}=0 $，对此类变端点问题本书不作详细讨论。

⑤（14.1.9）式是一个关于函数  $ y(x) $ 的二阶常微分方程。其中的偏导，不过是表明如何根据泛函 J 的核 F 来写出这个常微分方程。若 F 不显含 x，则欧拉方程（14.1.9）可化为

$$  y^{\prime}\frac{\partial F}{\partial y}-F=c   \tag*{(14.1.23)}$$

顺便提及，应该说方程（14.1.8）和（14.1.9）是等价的，如，在分析力学中，是用拉格朗日方程

$$  \frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{\partial L}{\partial\dot{q}_{i}}\Big)-\frac{\partial L}{\partial q_{i}}=0,\quad i=1,2,\cdots,s   \tag*{(14.1.24)}$$

推出哈密顿原理（14.1.22）的，反过来，当然也可以从哈密顿原理推出拉格朗日方程。

⑥ 这种问题之所以称为等周问题，是因为在历史上这种问题始原于求一条通过  $ p_{0} $ 和  $ p_{1} $ 两点、长度固定为 l 的曲线  $ y = y(x) $，使面积  $ S = \int_{a}^{b} y(x) \, dx $ 取极大值.

<!-- page: 290 -->

⑦ 所谓解函数的条件极值问题的拉格朗日乘子法是指：若要求函数  $ y=f(x) $， $ x=(x_{1},x_{2},\cdots,x_{n}) $ 在  $ m(m<n) $ 个约束条件  $ g_{k}(x)=0,k=1,2,\cdots,m $ 下的极值，可引进修正的函数  $ F=y+\sum_{k=1}^{m}\lambda_{k}g_{k} $，式中  $ \lambda_{k} $ 为待定常数。把 F 当作  $ n+m $ 个变量  $ x_{1},x_{2},\cdots,x_{n} $ 和  $ \lambda_{1},\lambda_{2},\cdots,\lambda_{m} $ 的无约束函数，对这些变量求一阶偏导数得极值点所要满足的方程

 $$ \left\{\begin{aligned}\frac{\partial F}{\partial x_{i}}&=0,\quad i=1,2,\cdots,n\\ g_{k}&=0,\quad k=1,2,\cdots,m\end{aligned}\right. $$ 

#### 习题14.1

1. 证明： $ \delta\int_{a}^{b}F(x)\mathrm{d}x=\int_{a}^{b}\delta F(x)\mathrm{d}x. $

2. 计算下列泛函的变分：

(1)  $ J[y(x)] = \int_{x_0}^{x_1} (y^2 + y'^2 - 2y\mathrm{ch}x)\mathrm{d}x; $

(2)  $ J[y(x)] = \int_{x_0}^{x_1} (x^4 y' + x^3 y + 3) \, dx. $

3. 试导出二元函数  $ u(x,y) $ 的欧拉方程

 $$ \frac{\partial F}{\partial u}-\frac{\partial}{\partial x}\Big(\frac{\partial F}{\partial u_{x}}\Big)-\frac{\partial}{\partial y}\Big(\frac{\partial F}{\partial u_{y}}\Big)=0 $$ 

4. 对于泛函

 $$ J\big[u(x,y)\big]=\iint_{D}\big[u_{x}^{2}+u_{y}^{2}+2uf(x,y)\big]\mathrm{d}x\mathrm{d}y $$ 

和

 $$ J\left[u(x,y)\right]=\iint_{D}\left[\left(\frac{\partial u}{\partial x}\right)^{2}-\left(\frac{\partial u}{\partial y}\right)^{2}\right]\mathrm{d}x\mathrm{d}y $$ 

分别写出其欧拉方程.

5. 求连接一平面上两定点间的曲线段中最短者.

6. 在质点力学中，系统的作用量表示为

 $$ S=\int_{t_{1}}^{t_{2}}L(t,q,\dot{q})\mathrm{d}t $$ 

是 $ q(t) $的泛函. 其中， $ q(t) $和 $ \dot{q}(t) $分别为广义坐标和广义速度，L称为拉格朗日函数. 已知

（1）自由质点的拉氏函数为

 $$ L=-m c^{2}\sqrt{1-\frac{v^{2}}{c^{2}}} $$ 

（2）在势能场 $ U(r) $中运动的质点的拉氏函数为

 $$ L=\frac{mv^{2}}{2}-U(r) $$ 

分别求它们的作用量 S 有极值的必要条件.

7. 在什么样的曲线上，下列泛函可能达到极值？

(1)

 $$ \begin{cases}J[y(x)]=\int_{0}^{\frac{\pi}{2}}[(y^{\prime})^{2}-y^{2}]\mathrm{d}x\\y(0)=0,y\Big(\frac{\pi}{2}\Big)=1;\end{cases} $$

<!-- page: 291 -->

(2)

 $$ \begin{cases}J[y(x)]=\displaystyle\int_{x_{0}}^{x_{1}}(16y^{2}-y^{\prime \prime}^{2}+x^{2})\mathrm{d}x\\y(x_{0})=y_{0},y^{\prime}(x_{0})=y^{\prime}_{0}\\y(x_{1})=y_{1},y^{\prime}(x_{1})=y^{\prime}_{1}.\end{cases} $$ 

8. 求解注释 $ ^{⑥} $中所述的始原的等周问题.

9. 用里兹方法求泛函  $ J[y(x)]=\int_{0}^{x}(y^{\prime2}+y^{2}+2xy)dx;y(0)=y(2)=0 $ 的极小值问题的近似解，并与其准确解进行比较.

提示：近似解可用  $ y(x)=x(2-x)(c_{0}+c_{1}x+\cdots+c_{n}x_{n}) $ 来试探.

10. 用拉格朗日乘子法，再求一次例3中的极值.

 $ ^{*} $11. 假设大气的折射率  $ n(y) $ 只依赖于高度 y.

（1）利用费马原理，导出在大气中光线轨迹的微分方程；

（2）一个旅行者与水平成角度  $ \varphi $ 的方向上看到“空中的绿洲”。如果  $ n=n_{0} $  $ \sqrt{1-\Omega^{2}y^{2}} $，其中  $ n_{0} $ 和  $ \Omega $ 是常数，问这块绿洲离旅行者有多远？

（加州理工学院研究生试题）

### 14.2 用变分法解数理方程

变分法解数理方程的基本原理是：

（1）把一个微分方程的本征值问题或者定解问题和一个泛函的极值问题联系起来，使原来的方程是这个泛函的欧拉方程.

（2）用直接方法求出使泛函取极值的函数. 由于这函数必满足欧拉方程，它也是原方程的解.

本节将以亥姆霍兹方程的本征值问题和泊松方程的边值问题为例，说明如何把一个微分方程的本征值问题或边值问题化为一个泛函的极值问题，然后便可利用上节介绍的里兹方法来求泛函的极值，此即原问题的解。

## 1. 本征值问题和变分问题的关系

考虑亥姆霍兹方程的本征值问题

$$  \left\{\begin{aligned}\Delta u+\lambda u&=0\\ u\mid_{\sigma}&=0\end{aligned}\right.   \tag*{(14.2.1)}$$

其中设 u 在区域  $ \tau $ 中有连续的二阶导数， $ \lambda $ 是参数， $ \sigma $ 是  $ \tau $ 的边界.

将(14.2.1)左边乘以-u，然后在 $ \tau $上求积分，便得到一个泛函

$$  J\left[u\right]=-\iiint_{\tau}\left(u\Delta u+\lambda u^{2}\right)\mathrm{d}\tau   \tag*{(14.2.3)}$$

我们来求这个泛函的欧拉方程. 为了能够直接应用(14.1.12)式, 先利用边界条件把泛函(14.2.3)化为只含 u 的一阶导数的积分. 由格林第一公式(10.2.3)有

<!-- page: 292 -->

$$  J[u]=-\iiint_{\tau}(u\Delta u+\lambda u^{2})\mathrm{d}\tau=-\iint_{\sigma}u\frac{\partial u}{\partial n}\mathrm{d}\sigma+\iiint_{\tau}[(\nabla u)^{2}-\lambda u^{2}]\mathrm{d}\tau   \tag*{(14.2.4)}$$

而由边界条件(14.2.2)有

 $$ \iint_{\sigma}u\frac{\partial u}{\partial n}\mathrm{d}\sigma=0 $$ 

于是

$$  J[u]=\iiint_{\tau}[(\nabla u)^{2}-\lambda u^{2}]\mathrm{d}\tau   \tag*{(14.2.5)}$$

根据（14.1.12），得这个泛函的欧拉方程为

 $$ \Delta u+\lambda u=0 $$ 

这正是原本征值问题的方程(14.2.1).

又由上节对泛函的条件极值的讨论知，泛函(14.2.5)式的变分问题和泛函

$$  J_{1}[u]=\iiint_{\tau}(\nabla u)^{2}\mathrm{d}\tau   \tag*{(14.2.6)}$$

 $$ \iiint_{\tau}u^{2}\mathrm{d}\tau=1 $$ 

在附加条件

之下的变分问题等价，因此，求解本征值问题(14.2.1)～(14.2.2)式，可归结为在一化条件(14.2.7)式和边界条件(14.2.2)式下求泛函(14.2.6)式的极值的问题.

如果方程(14.2.1)带有第二类的边界条件

$$  \left.\frac{\partial u}{\partial n}\right|_{\sigma}=0   \tag*{(14.2.8)}$$

也会使泛函(14.2.4)在边界上的积分 $ \iint_{\sigma}u\frac{\partial u}{\partial n}d\sigma $为零.故本征值问题

 $$ \left\{\begin{aligned}&\Delta u+\lambda u=0\\ &\frac{\partial u}{\partial n}\bigg|_{\sigma}=0\end{aligned}\right. $$ 

所对应的泛函亦为(14.2.5)，但由于边界条件的不同，因此在求泛函极值时，与带有第一类边界条件的情况并不相同.

若方程(14.2.1)带有第三类边界条件

$$  \left[\frac{\partial u}{\partial n}+h u\right]_{\sigma}=0   \tag*{(14.2.9)}$$

此时，由(14.2.4)式有

 $$ \begin{aligned}J\left[\boldsymbol{u}\right]=&-\iiint_{\sigma}\boldsymbol{u}\frac{\partial\boldsymbol{u}}{\partial n}\mathrm{d}\sigma+\iiint_{\tau}\left[(\nabla\boldsymbol{u})^{2}-\lambda\boldsymbol{u}^{2}\right]\mathrm{d}\tau\\=&-\iiint_{\sigma}\boldsymbol{u}\left[\frac{\partial\boldsymbol{u}}{\partial n}+h\boldsymbol{u}\right]\mathrm{d}\sigma+h\iiint_{\sigma}\boldsymbol{u}^{2}\mathrm{d}\sigma+\iiint_{\tau}\left[(\nabla\boldsymbol{u})^{2}-\lambda\boldsymbol{u}^{2}\right]\mathrm{d}\tau\\=&\iiint_{\tau}\left[(\nabla\boldsymbol{u})^{2}-\lambda\boldsymbol{u}^{2}\right]\mathrm{d}\tau+h\iiint_{\sigma}\boldsymbol{u}^{2}\mathrm{d}\sigma\end{aligned} $$

<!-- page: 293 -->

记

$$  J_{1}[u]=\iiint_{\tau}(\nabla u)^{2}\mathrm{d}\tau+h\iint_{\sigma}u^{2}\mathrm{d}\sigma   \tag*{(14.2.10)}$$

故由类似于前面的讨论知，本征值问题

 $$ \left\{\begin{aligned}&\Delta u+\lambda u=0\\ &\left(\frac{\partial u}{\partial n}+h u\right)_{\sigma}=0\end{aligned}\right. $$ 

可归结为在归一化附加条件(14.2.7)和边界条件(14.2.9)下求泛函(14.2.10)的极值问题.

对于任意的二阶常微分方程的本征值问题 $ ^{①} $

$$  \left\{\begin{aligned}&\frac{\mathrm{d}}{\mathrm{d}x}\lbrack k(x)y^{\prime}(x)\rbrack-q(x)y(x)+\lambda\varrho(x)y(x)=0,\quad a\leqslant x\leqslant b\\ &y(a)=y(b)=0,\quad 或 \quad y^{\prime}(a)=y^{\prime}(b)=0\end{aligned}\right.   \tag*{(14.2.11)}$$

类似地，我们可以证明，它们均可归结为在归一化附加条件

 $$ \int_{a}^{b}\rho(x)y^{2}(x)\mathrm{d}x=1 $$ 

和相应的边界条件下求泛函

 $$ J[y]=\int_{a}^{b}[k(x)(y^{\prime})^{2}+q y^{2}]\mathrm{d}x $$ 

的极值问题.

## 2. 本征值与泛函的极值的关系

我们当然可借助于里兹方法来求泛函的极值，从而求得本征值问题的解.为此，我们先以本征值问题(14.2.1)～(14.2.2)式为例来证明一个重要结论：

泛函(14.2.6)式的最小值 $ \lambda_{0} $，就是本征值问题(14.2.1)～(14.2.2)式的最小本征值；而使泛函(14.2.6)式在边界条件(14.2.2)式和附加条件(14.2.7)式下取这最小值的函数 $ u_{0} $，就是该本征值问题对应于本征值 $ \lambda_{0} $的本征函数.

证 设  $ u_{0} $ 是使泛函(14.2.6)式有最小值  $ \lambda_{0} $ 的极值函数，则

$$  \begin{align*}J_{1}\left[u_{0}\right]=\lambda_{0}=&\iiint_{\tau}\left(\nabla u_{0}\right)^{2}\mathrm{d}\tau\\=&\iiint_{\tau}\nabla\bullet\left(u_{0}\nabla u_{0}\right)\mathrm{d}\tau-\iiint_{\tau}u_{0}\Delta u_{0}\mathrm{d}\tau\\=&\iint_{\sigma}u_{0}\frac{\partial u_{0}}{\partial n}\mathrm{d}\sigma-\iiint_{\tau}u_{0}\Delta u_{0}\mathrm{d}\tau\end{align*}   \tag*{(14.2.12)}$$

由边界条件（14.2.2）式有，右边第一项积分为零；又由于（14.2.1）式是在条件（14.2.7）式下泛函（14.2.6）式的欧拉方程，所以 $ u_{0} $ 满足方程（14.2.1），即

 $$ \begin{aligned}\triangle u_{0}+\lambda u_{0}&=0\\\triangle u_{0}&=-\lambda u_{0}\end{aligned} $$ 

由此得

<!-- page: 294 -->

$$ \iiint_{\tau}u_{0}\Delta u_{0}\mathrm{d}\tau=-\lambda\iiint_{\tau}u_{0}^{2}\mathrm{d}\tau=-\lambda $$ 

代入14.2.12式有

 $$ J_{1}[u_{0}]=\lambda_{0}=\lambda $$ 

这说明  $ \lambda_{0} $ 是本征值. 当然, 相应的满足方程的  $ u_{0} $ 是本征函数.

其次，再证明  $ \lambda_{0} $ 是最小本征值。设  $ \lambda_{1} $ 是小于  $ \lambda_{0} $ 的本征值，相应本征函数是  $ u_{1} $，重复上述的推导（从  $ \lambda_{1} $ 倒推上去），得

 $$ J_{1}\left[u_{1}\right]=\iiint_{\tau}\left(\nabla u_{1}\right)^{2}\mathrm{d}\tau=\lambda_{1}<\lambda_{0}=J_{1}\left[u_{0}\right] $$ 

而这是与  $ J_{1}[u_{0}] $ 为泛函  $ J[u] $ 的最小值相矛盾的. 故上述结论得证.

用类似的方法可以证明，若  $ u_{1} $ 是使泛函(14.2.6)式有次小值  $ \lambda_{1} $ 的极值函数，且它除了满足边界条件(14.2.2)式和附加条件(14.2.7)式外还满足与  $ u_{0} $ 正交的条件

 $$ \iiint_{\tau}u_{1}u_{0}\mathrm{d}\tau=0 $$ 

则由它得到的泛函的次小值  $ J_{1}(u_{1})=\lambda_{1} $ 就是相应本征值问题(14.2.1)～(14.2.2)式的次小本征值，而  $ u_{1} $ 是相应的本征函数，它满足方程

 $$ \Delta u_{1}+\lambda u_{1}=0 $$ 

依此类推，若找到了使得泛函取第i个极值 $ \lambda_{i} $的极值函数 $ u_{i} $，它不仅满足（14.2.2）式和（14.2.7）式还满足与它前面所有的极值函数正交的条件

 $$ \iiint_{\tau}u_{i}u_{j}\mathrm{d}\tau=0,\quad j=0,1,\cdots,i-1 $$ 

则  $ \lambda_{i}=J_{1}[u_{i}] $ 为第 i 个本征值. 于是得到一系列本征值

 $$ \lambda_{0}\leqslant\lambda_{1}\leqslant\lambda_{2}\leqslant\cdots\leqslant\lambda_{i}\leqslant\cdots $$ 

和相应的本征函数

 $$ u_{0},u_{1},u_{2},\cdots,u_{i},\cdots $$ 

至于其他的本征值问题，不难验证上述结论同样成立。

例 用变分法求边界固定半径为 b 的圆膜横振动的本征振动.

解 圆膜的横振动满足二维的波动方程，以圆膜的中心为原点取极坐标，则定解问题为

 $$ \left\{\begin{aligned}&u_{tt}-a^{2}\frac{1}{\rho}\frac{\partial}{\partial\rho}\Big(\rho\frac{\partial u}{\partial\rho}\Big)=0\\ &u\mid_{\rho=b}=0\end{aligned}\right. $$ 

令

 $$ u(\rho,t)=R(\rho)\mathrm{e}^{i\omega t} $$ 

ω是本征圆频率，则得

$$  \left\{\begin{aligned}&\frac{1}{\rho}\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)+\lambda R=0\\ &R(b)=0\end{aligned}\right.   \tag*{(14.2.13)}$$

<!-- page: 295 -->

其中

 $$ \lambda=\frac{\omega^{2}}{a^{2}} $$ 

引进无量纲的变数  $ x=\frac{\rho}{b} $（在应用变分法时常常如此），并记这时的函数  $ R(\rho) $ 为  $ y(x) $， $ \lambda b^{2} $ 为 k，于是本征值问题（14.2.13）式化为

$$  \left\{\begin{array}{l}\frac{\mathrm{d}}{\mathrm{d}x}\Big(x\frac{\mathrm{d}y}{\mathrm{d}x}\Big)+k x y=0\\ y(1)=0\end{array}\right.   \tag*{(14.2.14)}$$

对照(14.2.11)式，此时的变分问题是在边界条件(14.2.15)和归一化条件

$$  \int_{0}^{1}b^{2}xy^{2}\mathrm{d}x=1   \tag*{(14.2.16)}$$

之下求泛函

$$  J[y]=\int_{0}^{1}x\Big(\frac{\mathrm{d}y}{\mathrm{d}x}\Big)^{2}\mathrm{d}x   \tag*{(14.2.17)}$$

的极小值问题. 为此, 用里兹方法来求解. 选取含有两个参数  $ C_{1} $ 和  $ C_{2} $ 并满足边界条件  $ y|_{x=1}=0 $ 的尝试函数 $ ^{①} $

$$  y(x)=C_{1}(1-x^{2})+C_{2}(1-x^{2})^{2}   \tag*{(14.2.18)}$$

将之代入归一化条件(14.2.16)和泛函(14.2.17)得

$$  I(C_{1},C_{2})=b^{2}\int_{0}^{1}xy^{2}\mathrm{d}x=b^{2}\left(\frac{1}{6}C_{1}^{2}+\frac{1}{4}C_{1}C_{2}+\frac{1}{10}C_{1}^{2}\right)=1   \tag*{(14.2.19)}$$

$$  J\left(C_{1},C_{2}\right)=\int_{0}^{1}x\left(\frac{\mathrm{d}y}{\mathrm{d}x}\right)^{2}\mathrm{d}x=C_{1}^{2}+\frac{4}{3}C_{1}C_{2}+\frac{2}{3}C_{2}^{2}   \tag*{（14.2.20）}$$

这是两个关于参量  $ C_{1}, C_{2} $ 的二元函数，由拉格朗日乘子法即取极值的条件

 $$ \frac{\partial}{\partial C_{1}}(J-\lambda I)=0,\quad\frac{\partial}{\partial C_{2}}(J-\lambda I)=0 $$ 

得到关于 $ C_{1},C_{2} $的齐次代数方程组

$$  \left\{\begin{aligned}&\Big(2-\frac{k}{3}\Big)C_{1}+\Big(\frac{4}{3}-\frac{k}{4}\Big)C_{2}=0\\ &\Big(\frac{4}{3}-\frac{k}{4}\Big)C_{1}+\Big(\frac{4}{3}-\frac{k}{5}\Big)C_{2}=0\end{aligned}\right.   \tag*{(14.2.21)}$$

它有非零解的条件是系数行列式为零，即

 $$ \left|\begin{array}{l l}2-\frac{k}{3}&\frac{4}{3}-\frac{k}{4}\\\frac{4}{3}-\frac{k}{4}&\frac{4}{3}-\frac{k}{5}\end{array}\right|=0 $$ 

由此解得 k=5.7841 或 k=36.8825；因此，最小本征值  $ \lambda_{1}=\frac{5.7841}{b^{2}} $，代入  $ C_{1}, C_{2} $ 的代数方程组（14.2.21）中的任一方程，并与（14.2.19）式联立，于是求得

<!-- page: 296 -->

$$ C_{1}=\frac{1.650}{b},\quad C_{2}=\frac{1.054}{b} $$ 

代入(14.2.18)，从而求得本征值问题的近似解为

 $$ y(x)=\frac{1.650}{b}(1-x^{2})+\frac{1.054}{b}(1-x^{2})^{2} $$ 

实际上本例的严格解可用分离变量法求出，其结果为

 $$ \lambda_{1}=(2.4048/b)^{2}=5.7831/b^{2} $$ 

 $$ R(\rho)=J_{0}(2.4048\rho/b)=J_{0}(\sqrt{\lambda_{1}}\rho)=J_{0}(x_{1}^{0}\rho/b) $$ 

其中， $ \lambda_{1} $ 为最小本征值， $ J_{0}(2.4048\rho/b) $ 为相应的本征函数；而  $ J_{0}(\sqrt{\lambda_{1}}\rho) $ 称为零阶贝塞尔函数， $ x_{1}^{0}=2.4048 $ 是零阶贝塞尔函数的第一个零点（见第三篇）。由此我们看到近似本征值略大于严格本征值，相差是很小的。

## 3. 边值问题与变分问题的关系

下面我们以泊松方程的边值问题为例来说明微分方程的边值问题与变分问题的关系.

先考虑第一类边值问题

$$  \int\Delta u=-f(M),\quad M\in\tau   \tag*{(14.2.22)}$$

$$  \left|u\right|_{\sigma}=g(M),\quad M\in\sigma   \tag*{(14.2.23)}$$

其中， $ \sigma $ 为区域  $ \tau $ 的边界。仿照本节对本征值问题的做法，将  $ (\Delta u + f) $ 乘以 -u 后在  $ \tau $ 上积分，得泛函

 $$ J_{1}[u]=-\iiint_{\tau}(u\Delta u+f u)\mathrm{d}\tau=-\iint_{\sigma}u\frac{\partial u}{\partial n}\mathrm{d}\sigma+\iiint_{\tau}[(\nabla u)^{2}-f u]\mathrm{d}\tau $$ 

其中后一步用了格林第一公式. 由于 g 是边界  $ \sigma $ 上的给定函数, 故在边界条件 (14.2.23) 式下

 $$ \delta u\mid_{s}=\delta g=0( 包括 g(M)=0 的情况 ) $$ 

故对  $ J_{1}[u] $ 取变分并利用(10.2.4)式有

$$  \delta J_{1}[u]=2\iiint_{\tau}\nabla u\cdot\nabla\delta u\mathrm{d}\tau-\iiint_{\tau}f\delta u\mathrm{d}\tau=-\iiint_{\tau}(2\Delta u+f)\delta u\mathrm{d}\tau   \tag*{(14.2.24)}$$

由泛函取极值的条件  $ \delta J_{1}[u]=0 $，得其欧拉方程为  $ 2\Delta u+f=0 $，这不是方程 (14.2.22)，但若将 (14.2.24) 式写为

 $$ \begin{aligned}&\delta J_{1}[u]=-2\iiint_{\tau}\left(\Delta u+f\right)\delta u\mathrm{d}\tau+\iiint_{\tau}f\delta u\mathrm{d}\tau\\&\delta\left\{J_{1}[u]-\iiint_{\tau}f u\mathrm{d}\tau\right\}=-2\iiint_{\tau}\left(\Delta u+f\right)\mathrm{d}\tau\\ \end{aligned} $$ 

则

故若取泛函

$$  J[u]=J_{1}[u]-\iiint_{\tau}f u\mathrm{d}\tau=\iiint_{\tau}[(\nabla u)^{2}-2f u]\mathrm{d}\tau   \tag*{（14.2.25）}$$

<!-- page: 297 -->

则其相应的欧拉方程正是方程(14.2.22). 由此可见，求解边值问题(14.2.22)~(14.2.23)，可归结为在边界条件(14.2.23)下求泛函(14.2.25)式的极值.

再考虑第二、三类边值问题，不妨设

$$  \left[\frac{\partial u}{\partial n}+h u\right]_{\sigma}=g   \tag*{(14.2.26)}$$

于是，当 h=0 时为第二类边界条件， $ h\neq0 $ 时为第三类边界条件。由于方程(14.2.22)对应的泛函是(14.2.25)，故自然想到令

 $$ J_{2}[u]=\iiint_{\tau}\left[(\nabla u)^{2}-2f u\right]\mathrm{d}\tau $$ 

则在边界条件(14.2.26)下有

 $$ \begin{align*}\delta J_{2}[u]&=2\iiint_{\tau}\left(\nabla u\bullet\nabla\delta u-2f\delta u\right)\mathrm{d}\tau\\&=2\iiint_{\sigma}\frac{\partial u}{\partial n}\delta u\mathrm{d}\sigma-2\iiint_{\tau}\left(\Delta u+f\right)\delta u\mathrm{d}\tau\\&=2\iiint_{\sigma}(g-hu)\delta u\mathrm{d}\sigma-2\iiint_{\tau}\left(\Delta u+f\right)\delta u\mathrm{d}\tau\end{align*} $$ 

故

 $$ \delta\left\{J_{2}[u]-2\iiint_{\sigma}g u\mathrm{d}\sigma+\iiint_{\sigma}h u^{2}\mathrm{d}\sigma\right\}=-2\iiint_{\tau}(\Delta u+f)\delta u\mathrm{d}\tau $$ 

于是，在边界条件(14.2.26)下方程(14.2.22)的泛函为

$$  \begin{align*}J[u]&=J_{2}[u]-2\iint_{\sigma}gu\mathrm{d}\sigma+\iint_{\sigma}hu^{2}\mathrm{d}\sigma\\&=\iiint_{\tau}[(\nabla u)^{2}-2fu]\mathrm{d}\tau-2\iint_{\sigma}gu\mathrm{d}\sigma+\iint_{\sigma}hu^{2}\mathrm{d}\sigma\end{align*}   \tag*{(14.2.27)}$$

即求解边值问题

$$  \left\{\begin{aligned}\Delta u=&-f\\\left.\frac{\partial u}{\partial n}\right|_{\sigma}=g\end{aligned}\right.   \tag*{(14.2.28)}$$

可归结为在第二类边界条件下求泛函

$$  J[u]=\iiint_{\tau}[(\nabla u)^{2}-2f u]\mathrm{d}\tau-2\iint_{\sigma}g u\mathrm{d}\sigma   \tag*{(14.2.29)}$$

的极值（因为此时 h=0）；而求解边值问题

$$  \left\{\begin{aligned}\Delta u=&-f\\ \left(\frac{\partial u}{\partial n}+h u\right)_{\sigma}=g\end{aligned}\right.   \tag*{（14.2.30）}$$

则可归结为在第三类边界条件下求泛函（14.2.27）的极值，亦即求泛函

$$  J[u]=-\iiint_{\tau}(u\Delta u^{2}+2f u)\mathrm{d}\tau-\iint_{\sigma}g u\mathrm{d}\sigma   \tag*{（14.2.31）}$$

的极值.

注 ① 这里选择尝试函数为 $ (1-x^{2}) $的多项式而不是 $ (1-x) $的多项式，是为了使近似解在圆

<!-- page: 298 -->

膜中心 x=0 处无尖点，即使  $ \frac{dy}{dx}\bigg|_{x=0}=0 $.

此即施图姆-刘维尔本征值问题. 见第3篇第13章.

#### 习题14.2

1\. 证明亥姆霍兹方程的本征值问题

 $$ \left\{\begin{aligned}&\Delta u+\lambda u=-f(M)\\ &\left[\frac{\partial u}{\partial n}+h u\right]_{\sigma}=g(M)\end{aligned}\right. $$ 

可化为在相同边界条件下的泛函

 $$ J[u]=\iiint_{\tau}u[\Delta u+\lambda u+2f]\mathrm{d}\tau+\iint_{\sigma}g u\mathrm{d}\sigma $$ 

的变分问题.

2. 求半径为 a 边缘固定的圆膜本征振动问题

 $$ \left\{\begin{aligned}&\frac{\mathrm{d}}{\mathrm{d}\rho}\Big(\rho\frac{\mathrm{d}R}{\mathrm{d}\rho}\Big)+\Big(\frac{\omega}{c}\Big)^{2}\rho R=0,\quad\rho<a\\ &R(a)=0\end{aligned}\right. $$ 

的最低频率 $ \omega_{0} $

提示：取尝试函数  $  R(\rho) = 1 - \left( \frac{\rho}{a} \right)^{n}  $.

3. 在矩形区域  $ D:0 \leq x \leq a, 0 \leq y \leq b $ 内用变分法求方程

 $$ \frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}=f(x,y) $$ 

具有零值边值条件的解.

提示：取试探函数

 $$ u=\sum_{p=1}^{n}\sum_{q=1}^{m}a_{pq}\sin\frac{p\pi x}{a}\sin\frac{q\pi y}{b} $$ 

并令

 $$ f(x,y)=\sum_{p=1}^{\infty}\sum_{q=1}^{\infty}\beta_{pq}\sin\frac{p\pi x}{a}\sin\frac{q\pi y}{b} $$ 

4. 求解本征值问题

 $$ \left\{\begin{aligned}y^{\prime \prime}&+\lambda y=0\\ y^{\prime}&(0)=0,y(1)=0\end{aligned}\right. $$ 

的最小本征值.

提示：取试探函数  $ y(x)=(x^{2}-1)(c_{0}x^{2}+c_{1}) $.

5. 求方程  $ \Delta u = -1 $ 在正方形  $ -a \leqslant x \leqslant a, -a \leqslant y \leqslant a $ 内的近似解，且在正方形的边界上等于 0.

提示：取试探函数  $ u(x,y)=c(x^{2}-a^{2})(y^{2}-a^{2}) $

6. 试求薛定谔方程

 $$ \begin{array}{l}-\frac{\hbar^{2}}{2m}\frac{\mathrm{d}^{2}\psi}{\mathrm{d}x^{2}}+kx^{4}\psi=E\psi,\quad-\infty<x<\infty\end{array} $$ 

的能量 E 的最小值  $ E_{0} $. 其中 k 是正常数.

提示:取试探函数  $ \phi=ce^{-ax^{2}}(a>0) $.

<!-- page: 299 -->

# 本章小结

基本问题

变分法

关于泛函极值

的问题. 求泛函

极值的方法有

间接法：解微分方程. 即解欧拉方程，

它是泛函取极值的必要条件

直接法：里兹方法



解数理方程

程步骤

1. 构造所需求解的方程或定解问题的泛函. 通常是将原方程通过用某量作用后在整个求解区间中积分, 且使之满足原定解条件



2. 适当选取试探函数，通常选择多项式或三角函数系；用里兹方法求泛函的极值，从而得到原定解问题近似解。泛函条件极值的最小值，为相应本征值问题的最小本征值

<!-- page: 300 -->

现代科学技术的发展，使人们必须改变科学研究的方法。自20世纪60年代以来，非线性科学飞跃发展，在数学物理问题中以非线性方程——KdV（Korteweg-de Vries）方程为中心所展开的关于所谓孤立子（soliton）的研究，显得十分活跃，孤立子效应在浅水波、基本粒子、激光物理以及等离子体物理等方面的研究中，已引起了广泛的注意。所以，引入本章以了解有关非线性方程的知识很有必要。

所谓非线性方程一般是指，含有未知函数和未知函数的导数的高次项的方程。非线性方程是一个广阔的领域，它和线性方程在其性质上有着很大的差异。如，对于线性方程而言解的唯一性、单值性、有限性等性质，对于某些非线性方程均可能不复存在，线性叠加原理失效。正因为如此，对非线性方程不存在一般理论和求解方法，常常是对于不同的具体问题采用不同的手段，且能求得其解析解的方程屈指可数，必须谨慎处理。常用于求解非线性方程的方法有反散射法、达布（Darboux）变换、巴克朗德（Backlund）变换等等。其中反散射法可用于求解一大类的非线性偏微分方程，但由于受篇幅和教材性质的限制本书不可能一一展开讨论。本章将仅对非线性方程的某些初等解法作简单的介绍，并以物理问题中的几个典型的非线性方程为例概略地讨论有关孤立波的问题。

### 15.1 非线性方程的某些初等解法

本节将通过对几个特例的讨论，来介绍非线性方程的某些初等解法。这些解法的指导思想是寻找、选择某一种适当的变换，使方程化为线性方程或易于求解的方程。这些特例的解法和结果，对于我们解决物理学中的一些具体问题是十分有用的。

## 1. 基尔霍夫(Kirchhoff)变换

对于方程

$$  \nabla\bullet\left[G(u)\;\nabla u\right]=0   \tag*{(15.1.1)}$$

为了使之线性化，我们试探选择函数

$$  w=w(u)   \tag*{（15.1.2）}$$

使

$$  \nabla\mathcal{w}=G(u)\;\nabla u   \tag*{（15.1.3）}$$

<!-- page: 301 -->

则由(15.1.2)式有

 $$ \nabla\mathcal{w}=\frac{\mathrm{d}\mathcal{w}}{\mathrm{d}u}\nabla u $$ 

将之与(15.1.3)式对比，易于看出w应满足

 $$ \frac{\mathrm{d}w}{\mathrm{d}u}=G(u) $$ 

即

$$  \mathcal{w}=\int_{u_{0}}^{u}G(\zeta)\mathrm{d}\zeta,\quad u_{0} 为常数   \tag*{(15.1.4)}$$

这样，方程(15.1.1)就化为了我们熟知的线性拉普拉斯方程.

 $$ \Delta w=0 $$ 

变换(15.1.4)式称为基尔霍夫变换. 显然，当方程(15.1.1)带有边界条件时，还必须对边界条件作相应变换.

## 2. 柯勒-霍普夫(Cole-Hopf)变换

方程

$$  u_{t}+u u_{x}=\delta u_{x x}   \tag*{（15.1.5）}$$

是某些研究工作中所用到的非线性耗散方程——著名的伯格斯(Burgers)方程，其中 $ \delta $是扩散系数(正实数).如果没有左边的第二项，(15.1.5)则是一线性的扩散方程.故我们试图将之变为这种线性方程来求解.

方程(15.1.5)又可写为

$$  \frac{\partial u}{\partial t}=\frac{\partial}{\partial x}\Big(\partial u_{x}-\frac{u^{2}}{2}\Big)   \tag*{（15.1.6）}$$

于是，由全微分方程存在的充要条件 $ ^{①} $有

 $$ \mathrm{d}\psi=u\mathrm{d}x+\left(\delta u_{x}-\frac{u^{2}}{2}\right)\mathrm{d}t $$ 

显然  $ \phi(x,t) $ 满足下列关系：

 $$ \psi_{x}=u $$ 

$$  \phi_{t}=\partial u_{x}-\frac{u^{2}}{2}   \tag*{（15.1.8）}$$

由（15.1.7）式和（15.1.8）式得

$$  \phi_{t}+\frac{1}{2}\psi_{x}^{2}=\delta\phi_{x x}   \tag*{（15.1.9）}$$

故求解伯格斯方程(15.1.5)的问题就转化为了求解方程(15.1.9)的问题.为了寻求方程(15.1.9)与易于求解的线性扩散方程

$$  v_{t}=\partial v_{x x}   \tag*{（15.1.10）}$$

之间的关系，令

$$  v=g(\psi)   \tag*{（15.1.11）}$$

代入(15.1.10)式，于是有

$$  \psi_{t}-\delta\frac{g^{^{\prime \prime}}(\psi)}{g^{^{\prime}}(\psi)}\psi_{x}^{2}=\delta\psi_{x x}   \tag*{（15.1.12）}$$

<!-- page: 302 -->

对比(15.1.9)式和(15.1.12)式知 $ g(\phi) $需满足方程

 $$ -\delta\frac{g^{^{\prime \prime}}(\phi)}{g^{^{\prime}}(\phi)}=\frac{1}{2} $$ 

积分得

 $$ g(\psi)=c_{1}\mathrm{e}^{-\frac{1}{2\delta}\psi}+c_{2} $$ 

取  $ c_{1}=1, c_{2}=0 $ 并将  $ g(\psi) $ 代入 (15.1.11) 式得

 $$ v=g(\psi)=\mathrm{e}^{-\frac{1}{2\delta}\psi} $$ 

即

 $$ \psi=-2\delta\mathrm{l n}v $$ 

代入15.1.7式得

$$  u(x,t)=-2\delta\frac{\partial\ln v}{\partial x}   \tag*{（15.1.13）}$$

变换(15.1.13)式称为柯勒-霍普夫变换. 在处理非线性问题时，常常会用到这种变换. 由此已看到，选取柯勒-霍普夫变换后，求解非线性方程(15.1.5)式的问题便转化为了求解线性方程(15.1.10)式的问题.

对于高维方程及方程组

$$  \frac{\partial u_{i}}{\partial t}+\sum_{j=1}^{3}u_{j}\frac{\partial u_{i}}{\partial x_{j}}=\delta\Delta u_{i},\quad i=1,2,3   \tag*{（15.1.14）}$$

类似地，可作变换

$$  u=-2\delta\nabla\ln v   \tag*{（15.1.15）}$$

则求解 $  (15.1.14)  $式便转化为了求解线性方程

$$  v_{i}=\delta\Delta v   \tag*{（15.1.16）}$$

## 3. 相似变换

对于广义热传导方程

$$  \frac{\partial u}{\partial t}=\frac{\partial}{\partial x}\Big[G(u)\frac{\partial u}{\partial x}\Big]   \tag*{（15.1.17）}$$

为了使之便于求解，我们试图使之变为关于某一新的变量如  $ \xi $ 的常微分方程。为此，作变换

$$  \left\{\begin{aligned}u&=u(\xi)\\ \xi&=x^{\alpha}t^{\beta}\end{aligned}\right.   \tag*{（15.1.18）}$$

其中  $ \alpha $ 和  $ \beta $ 为待定常数. 此时

 $$ \frac{\partial u}{\partial t}=\beta x^{\alpha}t^{\beta-1}\frac{\mathrm{d}u}{\mathrm{d}\xi} $$ 

 $$ \frac{\partial u}{\partial x}=\alpha x^{\alpha-1}t^{\beta}\frac{\mathrm{d}u}{\mathrm{d}\xi} $$ 

 $$ \begin{array}{r}{\frac{\partial}{\partial x}\Big[G(u)\frac{\partial u}{\partial x}\Big]=\alpha(\alpha-1)x^{\alpha-2}t^{\beta}G(u)\frac{\mathrm{d}u}{\mathrm{d}\xi}+\alpha^{2}x^{2(\alpha-1)}t^{2\beta}\frac{\mathrm{d}}{\mathrm{d}\xi}\Big[G(u)\frac{\mathrm{d}u}{\mathrm{d}\xi}\Big]}\end{array} $$

<!-- page: 303 -->

代入方程(15.1.17)，于是得

$$  \beta\frac{x^{2}}{t}\xi\frac{\mathrm{d}u}{\mathrm{d}\xi}=\alpha(\alpha-1)\xi G(u)\frac{\mathrm{d}u}{\mathrm{d}\xi}+\alpha^{2}\xi^{2}\frac{\mathrm{d}}{\mathrm{d}\xi}\Big[G(u)\frac{\mathrm{d}u}{\mathrm{d}\xi}\Big]   \tag*{（15.1.20）}$$

为使方程(15.1.20)变为只含变量 $ \xi $（不显含x和t）的常微分方程，显而易见只需令

$$  \frac{x^{2}}{t}=g(\xi)   \tag*{(15.1.21)}$$

即可. 其中  $ g(\xi) $ 为  $ \xi $ 的任意函数, 适当选取  $ g(\xi) $ 的形式, 可使方程 (15.1.20) 变为形式简洁易于求解的常微分方程. 比如取

 $$ \begin{aligned}&g(\xi)=\xi^{2}\\ &\xi=x/\sqrt{t}\\ \end{aligned} $$ 

即

这意味着(15.1.19)式中 $ \alpha=1,\beta=-\frac{1}{2} $.于是方程(15.1.20)亦即方程(15.1.17)变为

$$  \frac{\mathrm{d}}{\mathrm{d}\xi}\Big[G(u)\frac{\mathrm{d}u}{\mathrm{d}\xi}\Big]+\frac{\xi}{2}\frac{\mathrm{d}u}{\mathrm{d}\xi}=0   \tag*{（15.1.23）}$$

这是一易于求解的常微分方程。由变换(15.1.18)和(15.1.19)式所构成的解称为自型解，其中变换(15.1.19)式称为相似变换，而变换(15.1.22)称为玻尔兹曼(Boltzmann)变换。

## 4. 行波解

方程

$$  \frac{\partial u}{\partial t}=\frac{\partial}{\partial x}\Big[u^{n}\;\frac{\partial u}{\partial x}\Big]   \tag*{(15.1.24)}$$

是方程(15.1.17)当 $ G(u)=u^{n} $的特例，故我们当然可通过引入相似变换而求得其自型解.对于这种特例，我们也可采取下述解法：

令

其中a为常数.则

 $$ \begin{aligned}&\left\{\begin{aligned}u&=g(\hat{\xi})\\\dot{\xi}&=x+at\end{aligned}\right.\\ &\quad\frac{\partial u}{\partial t}=a\frac{\mathrm{d}g}{\mathrm{d}\xi}\\ &\quad\frac{\partial u}{\partial x}=\frac{\mathrm{d}g}{\mathrm{d}\hat{\xi}}\\ \end{aligned} $$ 

代入(15.1.24)式于是得未知函数  $ g(\xi) $ 的常微分方程

 $$ a\frac{\mathrm{d}g}{\mathrm{d}\xi}=\frac{\mathrm{d}}{\mathrm{d}\xi}\Big(g^{n}\frac{\mathrm{d}g}{\mathrm{d}\xi}\Big) $$ 

通过积分两次得

$$  u=g(\xi)=\{n[a(x+at)+c]\}^{\frac{1}{n}}   \tag*{（15.1.26）}$$

其中 c 为积分常数. 变换(15.1.25)称为行波解.

<!-- page: 304 -->

自型解和行波解对许多方程都是可以尝试的，例如对于下节将要讨论的正弦戈登方程

 $$ \varphi_{xx}-\varphi_{t}=\sin\varphi $$ 

我们亦可用行波解(15.1.25)式尝试求得其解.

## 5. 端迹变换

在流体力学等物理问题中，常常会碰到如下形式的拟线性方程 $ ^{②} $组

$$  \left\{\begin{aligned}u_{1}&\frac{\partial F}{\partial x}+u_{2}\frac{\partial F}{\partial y}+u_{3}\frac{\partial E}{\partial x}+u_{4}\frac{\partial E}{\partial y}=0\\ v_{1}&\frac{\partial F}{\partial x}+v_{2}\frac{\partial F}{\partial y}+v_{3}\frac{\partial E}{\partial x}+v_{4}\frac{\partial E}{\partial y}=0\end{aligned}\right.   \tag*{（15.1.27）}$$

其中  $ u_{i}, v_{i} (i=1,2,3,4) $ 仅仅是 F 和 E 的函数。显然，方程组 (15.1.27) 是关于未知函数  $ F(x, y) $ 和  $ E(x, y) $ 的非线性方程组。若雅可比 (Jacobi) 行列式

 $$ J\equiv\frac{\partial(F,E)}{\partial(x,y)}=F_{x}E_{y}-E_{x}F_{y}\neq0 $$ 

则可引入变换

$$  \left\{\begin{aligned}x&=x(F,E)\\ y&=y(F,E)\end{aligned}\right.   \tag*{（15.1.28）}$$

将方程组(15.1.27)化为未知函数  $ x(F,E) $ 和  $ y(F,E) $ 的方程组. 将会看到此方程组是线性齐次的. 将(15.1.28)式中的两式分别对 x 求导得

$$  \left\{\begin{aligned}1&=x_{F}F_{x}+x_{E}E_{x}\\ 0&=y_{F}F_{x}+y_{E}E_{x}\end{aligned}\right.   \tag*{（15.1.29）}$$

解此关于  $ F_{x} $ 和  $ E_{x} $ 的二元方程组得

$$  \left\{\begin{aligned}F_{x}&=\frac{y_{E}}{x_{F}y_{E}-x_{E}y_{F}}=\frac{y_{E}}{j}=Jy_{E}\\ E_{x}&=-Jy_{F}\end{aligned}\right.   \tag*{（15.1.30）}$$

其中

 $$ j=\frac{\partial(x,y)}{\partial(F,E)}=J^{-1}\neq0 $$ 

将（15.1.28）式中的两式分别对 y 求导，类似地可求得

$$  \left\{\begin{aligned}F_{y}=&-Jx_{E}\\ E_{y}=&Jx_{F}\end{aligned}\right.   \tag*{（15.1.31）}$$

将（15.1.30）式和（15.1.31）式代入（15.1.27）式于是得

$$  \left\{\begin{aligned}u_{1}\frac{\partial y}{\partial E}-u_{2}\frac{\partial x}{\partial E}-u_{3}\frac{\partial y}{\partial F}+u_{4}\frac{\partial x}{\partial F}&=0\\ v_{1}\frac{\partial y}{\partial E}-v_{2}\frac{\partial x}{\partial E}-v_{3}\frac{\partial y}{\partial F}+v_{4}\frac{\partial x}{\partial F}&=0\end{aligned}\right.   \tag*{（15.1.32）}$$

<!-- page: 305 -->

注意到  $ u_{i}, v_{i} (i=1,2,3,4) $ 只是 F 和 E 的函数（不是 x 和 y 的函数），所以此方程组当然是线性的.

变换(15.1.28)称为端迹变换，在流体力学中，它代表速度向量在 x-y 平面上的端点的轨迹.

注 ① 对于方程

$$  P(x,y)\mathrm{d}x+Q(x,y)\mathrm{d}y=0   \tag*{(1)}$$

若有

 $$ \mathrm{d}u=P(x,y)\mathrm{d}x+Q(x,y)\mathrm{d}y $$ 

则(1)式称为全微分方程.(1)式为全微分方程的充要条件是

$$  \frac{\partial P}{\partial y}=\frac{\partial Q}{\partial x}   \tag*{(2)}$$

②对于 m 阶的微分方程，若仅关于 m 阶的导数是线性的，而最高阶（m 阶）导数的系数为未知函数及其低阶导数的函数，则称该方程为 m 阶拟线性方程.

#### 习题15.1

1. 求解边值问题

 $$ \left\{\begin{aligned}\nabla\bullet\left[\sin u\nabla u\right]=0,\quad&y>0;-\infty<x<\infty\\ u\mid_{y=0}=x\end{aligned}\right. $$ 

2. 求方程  $ u_{t}=u_{xx}+u_{yy} $ 的自型解.

3. 求下述方程的广义行波解  $ u = f(\xi) $ :

(1)  $ u_{y}u_{xy} - u_{x}u_{yy} = 0, \xi = y + \varphi(x) $;

 $$ u_{t}+\frac{1}{2}(u_{x}^{2}+u_{y}^{2})=\lambda(u_{x x}+u_{y y}),\xi=t+g(x)+h(y). $$ 

其中  $ \varphi(x) $， $ g(x) $ 和  $ h(y) $ 为待定函数.

4. 求伯格斯方程的初值问题

 $$ \left\{\begin{aligned}u_{t}+u u_{x}&=\lambda u_{x x},-\infty<x<\infty,t>0\\ u(x,0)&=f(x)\end{aligned}\right. $$ 

5. 求解方程组

 $$ \left\{\begin{aligned}\frac{\partial V}{\partial x}+&\left[\frac{1}{C}+\frac{P E}{(E^{2}+V^{2})^{3/2}}\right]\frac{\partial V}{\partial t}=\frac{P V}{(E^{2}+V^{2})^{3/2}}\frac{\partial E}{\partial t}\\ \frac{\partial E}{\partial x}+&\left[\frac{1}{C}+\frac{P E}{(E^{2}+V^{2})^{3/2}}\right]\frac{\partial E}{\partial t}=-\frac{P V}{(E^{2}+V^{2})^{3/2}}\frac{\partial V}{\partial t}\end{aligned}\right. $$ 

### 15.2 孤波和孤子

## 1. KdV 方程

KdV 方程是孤波问题的模型. 所谓孤波 (solitary waves) 是指一种单峰行进的波, 它以常速传播且在传播过程中波形保持不变. 孤波最早是在 1834 年由苏格兰的科学家斯柯特·罗素 (Scott Russel) 在他沿着河边骑马追踪一个水波 $ ^{①} $ 时所看到的.

<!-- page: 306 -->

直至 1895 年荷兰的两个科学家柯特维格（Kortweg）和德弗里斯（de Vries）才导出了在一个浅水沟表面上按一个方向传播的波的运动方程。它的具体形式是

$$  \frac{\partial\eta}{\partial t}=\sqrt{\frac{3}{2}}\sqrt{\frac{g}{l}}\frac{\partial}{\partial x}\Big(\frac{2}{3}\alpha\eta+\frac{1}{2}\eta^{2}+\frac{1}{3}\sigma\frac{\partial^{2}\eta}{\partial x^{2}}\Big)   \tag*{（15.2.1）}$$

其中  $ \sigma=l^{3}/3-T l/\rho g $ 是一个任意常数，l 是沟道的深度，T 是表面张力， $ \rho $ 是流体密度。这就是著名的 KdV 方程。为了使它的形式更为简捷，我们取

 $$ \eta=8\alpha u,\quad\xi=\left(\frac{2\alpha}{\sigma}\right)^{1/2}x,\quad\tau=\left(\frac{2\alpha^{3}g}{\sigma l}\right)^{1/2}t $$ 

于是得到

$$  u_{\tau}+u_{\xi}+12u u_{\xi}+u_{\xi\xi\xi}=0   \tag*{（15.2.2）}$$

这就是常见形式的 KdV 方程。它现在在等离子体物理学、低温物理学和光学等领域中都有着广泛的应用。

为了寻找一个类似于斯柯特·罗素所观察到的孤波，我们必须求方程(15.2.2)的一个永久型的行波解.为此，作变换

$$  \left\{\begin{aligned}u&=u(\theta)\\ \theta&=a\xi-\omega\pi+\delta\end{aligned}\right.   \tag*{(15.2.3)}$$

其中 a 和  $ \delta $ 均为常数， $ \delta $ 是相位因子，且当  $ |\theta| \rightarrow \infty $ 时，要求 u 和它的各阶导数均趋于零，因为孤波要求一种渐近稳定性。将 (15.2.3) 式代入 (15.2.2) 式且为简单见取  $ \omega = a + a^{3} $ 得

 $$ u_{\theta\theta\theta}+\frac{12}{a^{2}}u u_{\theta}-u_{\theta}=0 $$ 

两边对变量 $ \theta $积分得

 $$ u_{\theta\theta}+\frac{6}{a^{2}}u^{2}-u+c_{1}=0 $$ 

用 $ u_{\theta} $乘上式再对 $ \theta $积分得

 $$ \frac{1}{2}u_{\theta}^{2}+\frac{2}{a^{2}}u^{3}-\frac{1}{2}u^{2}+c_{1}u+c_{2}=0 $$ 

由渐近稳定性立即可确定积分常数  $ c_{1}=c_{2}=0 $ ，于是得

 $$ u^{2}_{\theta}=u^{2}\Big(1-\frac{4}{a^{2}}u\Big) $$ 

即

 $$ \frac{a\mathrm{d}u}{u\ \sqrt{a^{2}-4u}}=\mathrm{d}\theta $$ 

两边积分，取积分常数为0并设a>0得

 $$ \theta=\ln\frac{a-\sqrt{a^{2}-4u}}{a+\sqrt{a^{2}-4u}} $$ 

于是

 $$ \mathrm{e}^{\theta}=\frac{a^{2}-2u-a\ \sqrt{a^{2}-4u}}{2u} $$

<!-- page: 307 -->

即

 $$ 2u(e^{\theta}+1)-a^{2}=-a\sqrt{a^{2}-4u} $$ 

两边平方并移项整理得

 $$ 4u^{2}(\mathrm{e}^{\theta}+1)^{2}-4a^{2}u\mathrm{e}^{\theta}=0 $$ 

所以

$$  \begin{aligned}u&=\frac{a^{2}\mathrm{e}^{\theta}}{(\mathrm{e}^{\theta}+1)^{2}}=\frac{a^{2}}{\mathrm{e}^{\theta}+2+\mathrm{e}^{-\theta}}\\&=\frac{a^{2}}{(\mathrm{e}^{\frac{\theta}{2}}+\mathrm{e}^{-\frac{\theta}{2}})^{2}}=\frac{1}{4}a^{2}\mathrm{sech}^{2}\frac{\theta}{2}\\&=\frac{1}{4}a^{2}\mathrm{sech}^{2}\frac{1}{2}[a\xi-(a+a^{3})\tau+\delta]\\&=\frac{1}{4}a^{2}\mathrm{sech}^{2}\frac{a}{2}\Big[\xi-(1+a^{2})\tau+\frac{\delta}{a}\Big]\\ \end{aligned}   \tag*{(15.2.4)}$$

这完全像斯柯特·罗素所观察到的孤波。其图形如图15.1所示。它是一个仅仅在小范围内向上凸的曲线。当 $ \tau $改变时该曲线以常速 $ 1+a^{2} $向右运动，且其形状保持不变，称为孤立子（soliton）。由于速度 $ 1+a^{2} $依赖于振幅，因此一个峰较高的波比一个峰较低的波运动得快些。由图15.1和（15.2.4）式还可看出，其速率大的波波宽反而小。

<div style="text-align: center;"><img src="images/p0307_img_in_image_box_248_648_709_766.jpg" alt="图15.1" width="48%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图15.1</div> </div>


1965 年萨布斯基(Zabusky)和克鲁斯卡尔(Kruskal)发现，当两个或更多的 KdV 孤波相碰撞时，它们不受干涉破坏，不消失，萨布斯基和克鲁斯卡尔把它们称为孤子(soliton). 这个词的英语的最后两个字母“on”，是希腊语的“粒子”的意思，所以孤子这个词生动地描绘了这些孤波的类粒子行径.

## 2. 正弦戈登(Gordon)方程

在场论中最早的模型之一是线性克莱因(Klein)-戈登方程

$$  \varphi_{x x}-\varphi_{t t}=m^{2}\varphi   \tag*{（15.2.5）}$$

1958年 Skyrme 提出了一个非线性场理论，得到了非线性的场方程

$$  \varphi_{xx}-\varphi_{t}=\sin\varphi   \tag*{（15.2.6）}$$

这就是著名的正弦戈登(SG)方程. 该方程现已在超导光脉冲、超导性及非线性量子力学等方面有着广泛的应用.

为了解此方程，先作坐标变换

 $$ \xi=\frac{x-t}{2},\quad\tau=\frac{x+t}{2} $$

<!-- page: 308 -->

则(15.2.6)式变为

$$  \varphi_{\hat{\tau}\tau}=\sin\varphi   \tag*{（15.2.7）}$$

继而取（15.2.7）式的两个独立解为

$$  \varphi=u+v,\quad\bar{\varphi}=u-v   \tag*{（15.2.8）}$$

并考虑一对以变量  $  u(\xi, \tau)  $ 和  $  v(\xi, \tau)  $ 表示的方程

$$  \left\{\begin{aligned}u_{\xi}&=f(v)\\ v_{\tau}&=g(u)\end{aligned}\right.   \tag*{（15.2.9）}$$

其中  $ f(v) $ 和  $ g(u) $ 的形式，可通过将方程（15.2.9）分离为分别只含未知量 u 和 v 的方程来确定。将上述两方程分别对  $ \tau $ 和  $ \xi $ 求导得

$$  \left\{\begin{aligned}u_{\xi\tau}&=g(u)f^{\prime}(v)\\ v_{\xi\tau}&=g^{\prime}(u)f(v)\end{aligned}\right.   \tag*{（15.2.10）}$$

为了使得变量 u 和 v 分离，我们将上述两方程相加和相减，于是得到

$$  \left\{\begin{aligned}(u+v)_{\hat{\tau}\tau}&=g(u)f^{\prime}(v)+g^{\prime}(u)f(v)\\ (u-v)_{\hat{\tau}\tau}&=g(u)f^{\prime}(v)-g^{\prime}(u)f(v)\end{aligned}\right.   \tag*{（15.2.11）}$$

由于 $ \varphi $和 $ \bar{\varphi} $是方程(15.2.7)的两个独立解，故有

$$  \left\{\begin{aligned}\sin(u+v)&=g(u)f^{\prime}(v)+g^{\prime}(u)f(v)\\ \sin(u-v)&=g(u)f^{\prime}(v)-g^{\prime}(u)f(v)\end{aligned}\right.   \tag*{（15.2.12）}$$

将此二式相加得

 $$ g(u)f^{\prime}(v)=\sin\mathrm{u}\cos v $$ 

分离变量得

 $$ \frac{g(u)}{\sin u}=\frac{\cos v}{f^{\prime}(v)}=\alpha $$ 

于是得

$$  g(u)=\alpha sin u   \tag*{（15.2.13）}$$

其中  $ \alpha $ 为任意常数. 类似的将(15.2.12)式中的两式相减并分离变量得

 $$ \frac{f(v)}{\sin v}=\frac{\cos u}{g^{^{\prime}}(u)}=\beta $$ 

于是得

$$  f(v)=\beta\mathrm{s i n}v=\frac{1}{\alpha}\mathrm{s i n}v   \tag*{（15.2.14）}$$

因为  $ u=\frac{1}{2}(\varphi+\bar{\varphi}) $， $ v=\frac{1}{2}(\varphi-\bar{\varphi}) $，于是现在(15.2.9)式中的两式变为

$$  \left\{\begin{aligned}&\frac{1}{2}(\varphi+\bar{\varphi})_{\xi}=\frac{1}{\alpha}\sin\frac{1}{2}(\varphi-\bar{\varphi})\\ &\frac{1}{2}(\varphi-\bar{\varphi})_{\tau}=\alpha\sin\frac{1}{2}(\varphi+\bar{\varphi})\end{aligned}\right.   \tag*{（15.2.15）}$$

这是正弦戈登方程的巴克朗德变换. 它们是一对与正弦戈登方程(15.2.7)的两个特解 $ \varphi $和 $ \bar{\varphi} $相关的方程. 显然, 若(15.2.7)有某一特解 $ \bar{\varphi} $, 则代入巴克朗德变换

<!-- page: 309 -->

(15.2.29)式后所求得的 $ \varphi $也是方程(15.2.7)的特解.易于看出 $ \bar{\varphi}=0 $就是(15.2.7)式的一特解，将之代入(15.2.15)式得

$$  \varphi_{\xi}=2\frac{1}{\alpha}\sin\frac{\varphi}{2}   \tag*{(15.2.16)}$$

$$  \varphi_{\tau}=2\alpha\sin\frac{\varphi}{2}   \tag*{(15.2.17)}$$

解方程（15.2.16）得

$$  \varphi=4\arctan\left\{\exp\left[\frac{1}{\alpha}\xi+c(\tau)\right]\right\}   \tag*{（15.2.18）}$$

将（15.2.18）式代入（15.2.17）式便可确定对变量  $ \xi $ 而言的积分常数为

 $$ c(\tau)=\alpha\tau+\delta $$ 

其中 $ \delta $为常数，于是得方程(15.2.7)的一个特解为

$$  \varphi=4arctan\Big[\exp\Big(\frac{1}{\alpha}\xi+\alpha\tau+\delta\Big)\Big]   \tag*{(15.2.19)}$$

变回原来的变量 $ (x,t) $，得正弦戈登方程（15.2.5）的一个特解为

$$  \varphi=4arctan\mathrm{exp}[a(x-bt)+\delta]   \tag*{（15.2.20）}$$

其中

 $$ a=\frac{\alpha^{2}+1}{2\alpha},\quad b=\frac{1-\alpha^{2}}{\alpha^{2}+1} $$ 

<div style="text-align: center;"><img src="images/p0309_img_in_image_box_96_689_418_913.jpg" alt="图15.2" width="33%" /></div>


这个解已被命名为一个“扭结”，因为它表示出函数  $ \varphi $ 的一个扭弯。图15.2画出了  $ \varphi(x,t) $ 随 x 的变化图。将(15.2.19)式分别对  $ \xi $ 和  $ \tau $ 求导可得

<div style="text-align: center;"><div style="text-align: center;">图15.2</div> </div>


$$  \varphi_{\xi}=4\frac{1}{\alpha}\mathrm{s e c h}\big[a(x-b t)+\delta\big]   \tag*{(15.2.21)}$$

$$  \varphi_{\tau}=4\alpha\mathrm{s e c h}\big[a(x-b t)+\delta\big]   \tag*{（15.2.22）}$$

是孤波解，在此不详细论证。都是孤波，由此易于推想正弦戈登方程的解亦



## 3. 非线性薛定谔方程

随着等离子体物理和非线性光学的物理进展产生了如下的非线性方程：

$$  \mathrm{i}\varphi_{t}+\varphi_{x x}+\beta\varphi\mid\varphi\mid^{2}=0   \tag*{（15.2.23）}$$

由于它具有一个作为势  $ \beta|\varphi|^2 $ 的量子薛定谔方程的结构，故人们称之为非线性薛定谔(NLS)方程。该方程现已用于近代量子力学、超导性、激光等方面。其中  $ \varphi $ 是一个复函数，正因为如此，我们期望求一个具有振荡调制的渐近稳定的行波解。为此，令

$$  \begin{cases}\varphi=\mathrm{e}^{\mathrm{i}(kx-vt)}u(\theta)\\\theta=x-bt\end{cases}   \tag*{（15.2.24）}$$

<!-- page: 310 -->

其中 k, v 都是待定常数. 将(15.2.24)式代入(15.2.23)式得

取

 $$ \begin{align*}u_{\varnothing}+\mathrm{i}(2k-b)u_{\varnothing}+(v-k^{2})u+\beta u^{3}&=0\\k=\frac{b}{2},\quad v=\frac{b^{2}}{4}-a^{2}\end{align*} $$ 

则上述方程化为

$$  u_{\varnothing}-a^{2}u+\beta u^{3}=0   \tag*{（15.2.25）}$$

两边乘以  $ u_{\theta} $ 再积分得

 $$ u_{\theta}^{2}=c+a^{2}u^{2}-\frac{\beta}{2}u^{4} $$ 

注意到当 $ \left|x\right|\rightarrow\infty $时 $ \varphi $及各阶导数趋于零的条件，故有积分常数c=0.于是

 $$ \frac{\mathrm{d}u}{u\sqrt{a^{2}-\frac{\beta}{2}u^{2}}}=\mathrm{d}\theta $$ 

两边积分并取积分常数为零得

 $$ \theta=-\frac{1}{a}\ln\frac{a+\sqrt{a^{2}-\frac{\beta}{2}u^{2}}}{\sqrt{\frac{\beta}{2}}u} $$ 

类似于前面(15.2.4)式导出的过程，立即可得

$$  u(\theta)=a\sqrt{\frac{2}{\beta}}sech a\theta   \tag*{（15.2.26）}$$

代入(15.2.24)可得非线性薛定谔方程的解为

$$  \varphi(x,t)=a\sqrt{\frac{2}{\beta}}\exp\left\{i\left[\frac{1}{2}b x-\left(\frac{1}{4}b^{2}-a^{2}\right)t\right]\right\}\mathrm{s e c h}\big[a(x-b t)\big]   \tag*{（15.2.27）}$$

其中 a 和 b 为任意常数. 这是一个广义孤波解.

注 ① 斯柯特的叙述为：“我正在观察一条船的运动，这条船被两匹马拉着，沿着狭窄的河道迅速前进，船突然停了，河道内被船体扰动的水团却没有停下来，而是以剧烈受激的状态聚集在船头周围，然后形成了一个巨大的圆而光滑的孤立水峰，突然离开船头以极大速度向前推进，这水峰约有30英尺（1英尺=0.3048米）长，1~1.5英尺高，在河道中行进时一直保持着起初的形状，速度也未见减慢，我骑着马紧紧跟着，发觉它以每小时8～9英里（1英里=1609.344米）的速度前进。后来波的高度渐渐减小，过了1～2英里之后，终于消失在蜿蜒的河道中。这就是我在1834年8月第一次偶然发现这奇异而美妙的现象的经过……”

#### 习题15.2

1. 粒子物理中所谓的  $ \varphi^{4} $ 方程为

 $$ \varphi_{x x}-\varphi_{u}=\lambda\varphi^{3}-m^{2}\varphi,\quad\lambda>0 $$ 

试求出它的一个行波解

<!-- page: 311 -->

$$ \varphi=\pm\tanh\biggl[\frac{1}{\sqrt{2}}\frac{1}{\sqrt{1-v^{2}}}(x-v t)+\delta\biggr] $$ 

2. 非线性光学中的麦克斯韦-布洛赫(Maxwell-Bloch)方程组为

 $$ \left\{\begin{aligned}&E_{x x}-E_{u}=-a P_{t}\\ &P_{u}+\mu^{2}P=(E N)_{t}\\ &N_{t}=-E P\end{aligned}\right. $$ 

试在边界条件：“ $ \left|x\right|\rightarrow\infty $时E，P $ \rightarrow $0；N $ \rightarrow $-1”下，求出其孤波解

 $$ E=a\mathrm{sech}\frac{1}{2}(at-\omega x+\delta) $$ 

 $$ \omega^{2}=a^{2}+\frac{2a^{2}}{\frac{a^{2}}{4}+\mu^{2}} $$ 

## 3. 方程

 $$ \varphi_{\xi\tau}=\varphi-\varphi^{3}/6 $$ 

是在特征坐标中的一种截断正弦戈登方程. 取  $ \varphi=g/f $, 证明该方程能简化为 g 和 f 的二阶齐次方程

 $$ \left\{\begin{aligned}&g^{2}=2(ff_{\xi\tau}-f_{\xi}f_{\tau})\\ &fg_{\xi\tau}+gf_{\xi\tau}-g_{\xi}f_{\tau}-g_{\tau}f_{\xi}=gf\end{aligned}\right. $$ 

用一个小参量 $ \varepsilon $展开g和f

 $$ \left\{\begin{aligned}g&=\sum_{n=0}^{\infty}\varepsilon^{2n+1}g^{(2n+1)}\\ f&=1+\sum_{n=1}^{\infty}\varepsilon^{2n}f^{(2n)}\end{aligned}\right. $$ 

证明，能求出其一个1参量的精确解为

 $$ \begin{cases}g=2\sqrt{2}\exp\theta_{1}\\f=1+\exp2\theta_{1}\\\theta=a_{i}\xi+\tau/a_{i}+\delta_{i}\end{cases} $$ 

4. 试用行波解（15.1.25）尝试，再次求解正弦戈登方程（15.2.6）.

### 15.3 解析近似法之正则摄动法

由于大多数非线性方程无法求得其解析解（即精确解），因而我们不得不借助于解析近似法来求其近似解析解（即近似解的解析表达式）。在上一章中，我们已介绍了求解方程近似解析解的变分法，本节将介绍另一种求非线性方程近似解析解的正则摄动法。

## 1. 摄动法

摄动法的解题思想是：如果非线性方程的非线性项是高阶小量，作为初步近似，可将其略去，从而非线性问题便化为了线性问题；求解该线性问题，并将所得的解作为非线性问题的零级近似；再把原非线性定解问题的解看作它的零级近似解与一个待求的含有小参量的解（即摄动解）的和，代入原定解问题，略去更高阶小

<!-- page: 312 -->

量，得到关于摄动解的线性定解问题；求解该线性问题并将求得的解作为原定解问题的高一级的近似——一级近似；仿此步骤进行下去便可得到各级近似。这种求近似解析解的方法被称为摄动法或小参数法，而以上这种带有小参量的定解问题被称为摄动问题。

摄动问题用数学式子可表示为

$$  P_{\varepsilon}:\quad\left\{\begin{aligned}&L_{\varepsilon}u=f(x,\varepsilon),x\in\sigma\\ &B_{j\varepsilon}u=\varphi_{j}(x,\varepsilon),x\in\Gamma,j=1,2,\cdots,k\end{aligned}\right.   \tag*{(15.3.1)}$$

其中  $ 0<\varepsilon\ll1 $， $ L_{\varepsilon} $ 和  $ B_{je} $ 分别为区域  $ \sigma $ 上和  $ \sigma $ 的边界或部分边界  $ \Gamma $ 上的非线性微分算子，下标上的  $ \varepsilon $ 表示算子与  $ \varepsilon $ 有关。由摄动法的思想可看出，用摄动法研究问题，首先需构造一解的小参量展开式使序列  $ \{g_{n}(\varepsilon)\} $ 满足

$$  \begin{align*}\lim_{n\to\infty}g_{n}(\varepsilon)&=0,\quad\lim_{\varepsilon\to0}\frac{g_{n+1}(\varepsilon)}{g_{n}(\varepsilon)}=0\\u(x,\varepsilon)&=u_{0}(x)+\sum_{n=1}^{N} g_{n}(\varepsilon)u_{n}(x)+R_{N}(x,\varepsilon)\end{align*}   \tag*{（15.3.2）}$$

其中  $ u_{0} $ 为零级近似， $ R_{N} $ 为余项。其次应讨论余项的值。

若

$$  R_{N}(x,\varepsilon)=O(g_{N+1}(\varepsilon))   \tag*{（15.3.3）}$$

则在摄动理论中称

$$  u_{0}(x)+\sum_{n=1}^{\infty}g_{n}(\varepsilon)u_{n}(x)   \tag*{(15.3.4)}$$

为（15.3.1）式的一致有效近似解.

## 2. 正则摄动法

下面，我们将从一个具体的例子来介绍正则摄动法的解题步骤。

例 试在单位圆内求解定解问题

$$  \left\{\begin{aligned}&\Delta u+\varepsilon\frac{\partial u}{\partial\rho}\frac{\partial u}{\partial\varphi}=0,\quad\rho<1;0<\varepsilon\leqslant1\\ &u(\rho,\varphi)\mid_{p=1}=\cos\varphi\end{aligned}\right.   \tag*{（15.3.5）}$$

解 这是一含有小参量的非线性问题. 当  $ \varepsilon=0 $ 时, 显然, (15.3.5) 式变为了线性定解问题

$$  \left\{\begin{aligned}&\Delta u=0,\quad\rho<1\\ &u(1,\varphi)=\cos\varphi\end{aligned}\right.   \tag*{（15.3.6）}$$

由分离变量法立即可以求得其解，视为零级近似，并记作  $ u_{0} $，即

$$  u_{0}=\rho\mathrm{{c o s}}\varphi   \tag*{（15.3.7）}$$

又设

$$  u=u_{0}+\varepsilon u_{1}=\rho\mathrm{c o s}\varphi+\varepsilon u_{1}   \tag*{（15.3.8）}$$

将(15.3.8)式代入(15.3.5)式，并略去 $ O(\varepsilon^{2}) $得

<!-- page: 313 -->

$$  \left\{\begin{aligned}\Delta u_{1}&=\frac{1}{2}\rho\sin2\varphi\\ u_{1}(1,\varphi)&=0\end{aligned}\right.   \tag*{（15.3.9）}$$

这是一线性的泊松方程的狄氏问题，我们可通过下述方法求得其解，即由(15.3.9)式右边函数的形式，可设(15.3.9)式的试探解为

 $$ u_{1}(\rho,\varphi)=f(\rho)\sin2\varphi $$ 

 $$ \left\{\begin{aligned}&\rho^{2}f^{\prime \prime}(\rho)+\rho f^{\prime}(\rho)-4f=\frac{1}{2}\rho^{3}\\ &f(1)=0,f(0) 有界 \end{aligned}\right. $$ 

代入15.3.9式得

又根据(15.3.10)式右边函数的形式，可令

 $$ f=c\rho^{k} $$ 

代入(15.3.10)式的方程中可求得其特解为

 $$ f_{c}=\frac{1}{10}\rho^{3} $$ 

所以通解为

 $$ f=c_{1}\rho^{2}+c_{2}\rho^{-2}+\frac{1}{10}\rho^{3} $$ 

再代入边界条件得

 $$ f=-\frac{1}{10}\rho^{2}+\frac{1}{10}\rho^{3} $$ 

故

 $$ u_{0}+\varepsilon u_{1}=\rho\mathrm{c o s}\varphi+\frac{\varepsilon}{10}(\rho^{3}-\rho^{2})\mathrm{s i n}2\varphi $$ 

此即定解问题(15.3.5)式的一级近似.

一般地，可令

 $$ u=u^{(0)}(\rho,\varphi)+\varepsilon u^{(1)}(\rho,\varphi)+\varepsilon^{2}u^{(2)}(\rho,\varphi)+\cdots $$ 

代入(15.3.5)式，比较 $ \varepsilon $的同次幂系数可得

 $$ \begin{aligned}&\left\{\begin{aligned}&\Delta u^{(0)}=0\\&u^{(0)}(1,\varphi)=\cos\varphi\end{aligned}\right.\\&\left\{\begin{aligned}&\Delta u^{(1)}=-&\frac{\partial u^{(0)}}{\partial\rho}&\frac{\partial u^{(0)}}{\partial\varphi}\\&u^{(1)}(1,\varphi)=0\end{aligned}\right.\\&\left\{\begin{aligned}&\Delta u^{(2)}=&-\frac{\partial u^{(0)}}{\partial\rho}&\frac{\partial u^{(1)}}{\partial\varphi}-\frac{\partial u^{(1)}}{\partial\rho}&\frac{\partial u^{(0)}}{\partial\varphi}\\&u^{(2)}(1,\varphi)=0\end{aligned}\right.\end{aligned} $$ 

这是一系列泊松方程的狄氏问题. 依次求解每一泊松方程的狄氏问题

 $$ \left\{\begin{aligned}\Delta u^{(k)}&=f(u^{(0)},u^{(1)},\cdots,u^{(k-1)}),k=1,2,\cdots\\ u^{(k)}(1,\varphi)&=0\end{aligned}\right. $$

<!-- page: 314 -->

从而可得到定解问题(15.3.5)式的各级近似解.

用以上的摄动法求定解问题时，若小参量 $ \varepsilon $是方程中最高阶偏导数的系数，则求解会遇到困难。因为此时略去含 $ \varepsilon $的高阶项后，就会降低方程的阶数或改变方程的类型，因此所得的线性的近似方程的解将不可能满足原来定解问题的边界条件，因而上面所叙的正则摄动法失效，需考虑所谓的奇异摄动法。正则摄动法与奇异摄动法的区别就在于所求近似解在求解区域中是否一致有效。后者所涉及的内容已超过本课程内容，在此不再赘述。

顺便提及，对于非线性方程我们也可通过数值近似法，如差分法等求得其数值近似解，关于这方面的内容在“计算方法”、“数值计算”等课程和读物中会有所涉及。

当然，无论是摄动法还是差分法，也都同样适于解线性偏微分方程。

#### 习题15.3

1. 气体平面定常无旋运动方程为

 $$ (a^{2}-u^{2})w_{xx}-2uvw_{xy}+(a^{2}-v^{2})w_{yy}=0 $$ 

其中  $ u=w_{x}, v=w_{y}, a^{2}=a_{1}^{2}+\frac{v-1}{2}(b_{1}^{2}-w_{x}^{2}-w_{y}^{2}), a_{1}, v $ 和  $ b_{1} $ 为常数， $ 0<b_{1}<a_{1} $，边界条件为

 $$ \begin{cases}w_{y}\mid_{y=\varepsilon sinx}=\varepsilon\cos x\bullet w_{x}\mid_{y=\varepsilon sinx}\\\lim_{w\rightarrow\infty}w=b_{1}x\end{cases} $$ 

试用正则摄动法求该问题的一级近似解.

2. 用正则摄动法求定解问题

 $$ \begin{cases}\Delta u=0,\rho<R+\varepsilon\cos\varphi\\u\mid_{\rho=R+\varepsilon\cos\varphi}=\sin\varphi,\varphi<\varepsilon\leqslant R\end{cases} $$ 

即令

 $$ u(\rho,\varphi)=u^{(0)}+\varepsilon u^{(1)}+\varepsilon^{2}u^{(2)}+\cdots $$ 

求  $  u^{(0)}  $,  $  u^{(1)}  $,  $  u^{(2)}  $.

### 15.4 数值解法之分步傅里叶变换法

当无法求得非线性方程解析解时，人们也常采用数值解法求得其近似解。如，传统的差分法、有限元法、蒙特卡洛方法等。这些方法在一般的计算物理、计算方法等教材中均有详述。本节将给大家将介绍在非线性光学中求解非线性薛定谔方程的分步傅里叶变换法（SSFT），它最早是在1973年开始使用的 $ ^{①} $。由于它原理简单、易于编程，比大多数有限差分法精度高、见效快，故近些年来已受到许多学者青睐。

## 1. 光传输方程

光纤中光脉冲传输的方程为

$$  \frac{\partial A}{\partial z}+\frac{\alpha}{2}A+\frac{\mathrm{i}\beta_{2}}{2}\frac{\partial^{2}A}{\partial T^{2}}-\frac{\beta_{3}}{6}\frac{\partial^{3}A}{\partial T^{3}}\\ =i\gamma\Big[\left|A\right|^{2}A+\frac{\mathrm{i}}{\omega_{0}}\frac{\partial}{\partial T}(\left|A\right|^{2}A)-T_{R}A\frac{\partial\left|A\right|^{2}}{\partial T}\Big]   \tag*{(15.4.1)}$$

<!-- page: 315 -->

称为广义非线性薛定谔方程. 其中 z 和 T 分别为光纤的长度和传播时间，A 为振幅， $ \beta_{2} $、 $ \beta_{3} $ 分别为二阶、三阶色散系数， $ \gamma $ 为非线性系数 $ ^{②} $.

高阶非线性方程(15.4.1)，除了某些特殊情况，一般不能求得其解析解.本节将介绍可对其进行数值求解的分步傅里叶变换法.

## 2. 分步傅里叶变换法的原理

记

$$  \hat{D}=-\frac{\mathrm{i}}{2}\beta_{2}\frac{\partial^{2}}{\partial T^{2}}+\frac{1}{6}\beta_{3}\frac{\partial^{3}}{\partial T^{3}}-\frac{\alpha}{2}   \tag*{(15.4.2)}$$

$$  \tilde{N}=\mathrm{i}\gamma\Big[\left|A\right|^{2}+\frac{\mathrm{i}}{\omega_{0}}\frac{1}{A}\frac{\partial}{\partial T}(\left|A\right|^{2}A)-T_{R}\frac{\partial\left|A\right|^{2}}{\partial T}\Big]   \tag*{(15.4.3)}$$

式中  $ \hat{D} $ 是微分算符，它表示线性介质的色散和吸收； $ \hat{N} $ 是非线性算符，它决定了脉冲传输过程中光纤的非线性效应。

于是方程(15.4.1)可改写为如下形式：

$$  \frac{\partial A}{\partial z}=(\hat{D}+\hat{N})A   \tag*{(15,4,4)}$$

一般而言，光在传输的过程中，其色散效应和非线性效应是同时起作用的。现假定在传输过程中，光场每通过一小段距离 h，色散效应和非线性效应是分别独立起作用，也就是从 z 到  $ z+h $ 的传输过程中，分两步进行：第一步仅有非线性起作用，即方程（15.4.4）中的  $ \hat{D}=0 $ 而变为方程（15.4.5），第二步仅有色散作用，即方程（15.4.4）中的  $ \hat{N}=0 $ 而变为方程（15.4.6）

$$  \frac{\partial A}{\partial z}=\hat{N}A   \tag*{（15.4.5）}$$

$$  \frac{\partial A}{\partial z}=\hat{D}A   \tag*{（15.4.6）}$$

方程(15.4.5)和(15.4.6)均为算符的线性(微分)方程，可用傅里叶变换法求解。我们以适当的h为步长，只要h足够的小，一步步反复循环地分别求解方程(15.4.5)和(15.4.6)，便可得到非线性方程(15.4.4)，也就是光传输方程(15.4.1)的近似解。这就是分步傅里叶变换法。对于足够小的h，它有足够的精度。

## 3. 分步傅里叶变换法的求解过程

当光脉宽大于5皮秒时，方程(15.4.1)中的三阶色散项和最后两项均可忽略，于是有如下形式的非线性薛定谔方程：

$$  \mathrm{i}\frac{\partial A}{\partial z}+\frac{\mathrm{i}\alpha}{2}A-\frac{\beta_{2}}{2}\frac{\partial^{2}A}{\partial T^{2}}+\gamma\left|A\right|^{2}A=0   \tag*{（15.4.7）}$$

它是非线性科学的一个基本方程，被广泛应用于研究孤子。

为简单起见，我们现以非线性薛定谔方程（15.4.7）为例，来了解分步傅里叶变换法的解题过程。显然，方程（15.4.7）的微分算符 $ \hat{D} $和非线性算符 $ \hat{N} $分别为

<!-- page: 316 -->

$$  \hat{D}=-\frac{\mathrm{i}}{2}\beta_{2}\frac{\partial^{2}}{\partial T^{2}}-\frac{\alpha}{2}   \tag*{（15.4.8）}$$

$$  \hat{N}{=}\mathrm{i}\gamma\mid A\mid^{2}   \tag*{（15.4.9）}$$

因而此时的方程(15.4.5)和(15.4.6)的具体形式分别为

$$  \frac{\partial A}{\partial z}=-\frac{\mathrm{i}}{2}\beta_{2}\frac{\partial^{2}A}{\partial T^{2}}-\frac{\alpha}{2}A   \tag*{（15.4.10）}$$

$$  \frac{\partial A}{\partial z}{=}\mathrm{i}\gamma\mid A\mid{}^{2}A   \tag*{（15.4.11）}$$

我们先求解色散算子方程(15.4.10)，它是变量 T 的二阶线性偏微分方程，对它的各项（关于变量 T）施行傅里叶变换，并记

 $$ \tilde{A}(z,\omega)=\int_{-\infty}^{\infty}A(z,T)\exp(-\mathrm{i}\omega T)d T $$ 

于是有

$$  \frac{\mathrm{d}\widetilde{A}}{\mathrm{d}z}=-\frac{\mathrm{i}}{2}\beta_{2}(\mathrm{i}\omega)^{2}\widetilde{A}-\frac{\alpha}{2}\widetilde{A}   \tag*{（15.4.12）}$$

 $$ \widetilde{A}(z,\omega)=\widetilde{A}(0,\omega)\exp\left(\frac{i}{2}\beta_{2}\omega^{2}-\frac{\alpha}{2}\right)z $$ 

解之得

其中  $ \widetilde{A}(0,\omega) $ 是初始输入值  $ A(0,T) $ 的傅氏变换。求逆变换，从而得线性作用方程 (15.4.10) 的解为

$$  A(z,T)=F^{-1}\left[\exp\left(\frac{i}{2}\beta_{2}\omega^{2}-\frac{\alpha}{2}\right)z\right]*\left[A(0,T)\right]   \tag*{（15.4.13）}$$

再求解非线性算子方程(15.4.11)，它是变量z的常微分方程，直接求解得

$$  A(z,T)=A(0,T)\exp(i\gamma\left|A(0,T)\right|^{2}z)   \tag*{（15.4.14）}$$

由上面的讨论可知，在设定步长 h 后，应通过以下两步循环计算 z 段光纤的色散和非线性效应

$$  A_{1}(z,T)=A(0,T)\exp(\mathrm{i}\gamma\mid A(0,T)\mid^{2}z)   \tag*{（15.4.15）}$$

$$  A(z,T)=F^{-1}\left[\exp\left(\frac{i}{2}\beta_{2}\omega^{2}-\frac{\alpha}{2}\right)z\right]*\left[A_{1}(z,T)\right]   \tag*{（15.4.16）}$$

从而得到方程(15.4.7)的数值近似解。特别要强调的是在计算过程中离散的傅里叶变换(DFT)和逆变换都应取快速傅里叶变换(FFT)和快速逆变换 $ ^{③} $，这样才能提高计算速度。体现该方法的优点。关于数值计算的编程，不属本教材内容，可参考其他计算方法教材及文献，在此不加叙述。

## 4. 对称分步傅里叶变换方法

我们知道，若以 h 为步长，方程（15.4.4）即（15.4.1）的精确解可表示为

$$  \mathrm{A}(z+h,T)=\mathrm{ext}[h(\hat{D}+\hat{N})]A(z,T)   \tag*{（15.4.17）}$$

而用分步傅里叶变换法分两步求得的（15.4.1）的近似解为

$$  \mathrm{A}(z+h,T)\simeq\mathrm{ext}(h\hat{D})\mathrm{ext}(h\hat{N})A(z,T)   \tag*{（15.4.18）}$$

<!-- page: 317 -->

对比此二式可看出，用分步傅里叶变换法求解时是忽略了算符 $ \hat{D} $和 $ \hat{N} $的非对异性的。依据非对异性公式分析知，分步傅里叶变换法精确到步长h的二阶项 $ ^{④} $。

倘若我们采用如下公式来代替（15.4.18）式：

$$  A(z+h,T)\simeq\mathrm{e x t}(\frac{h}{2}\hat{D})\mathrm{e x t}\big[\int_{z}^{z+h}\hat{N}(z^{\prime})d z^{\prime}\big]\mathrm{e x t}(\frac{h}{2}\hat{D})A(z,T)   \tag*{（15.4.19）}$$

即，使非线性包含在小区间 h 的中间，而不是边界，便可改善分步傅里叶变换法的精确度为 h 的三阶项 $ ^{⑤} $。由于方程(15.4.19)中指数算符的对称形式，该方法称为对称分步傅里叶方法。

方程(15.4.19)中间的指数项内的积分，包含了与z有关的非线性算符 $ \hat{N} $，若步长足够小，此中间项也可近似表示为 $ \mathrm{ext}(h\hat{N}) $，这与(15.4.18)式类似.

分步傅里叶变换法已广泛应用于各种光学领域，包括大气中的传播、折射梯度光纤、半导体激光器、非稳腔及波导等。它也为求解其他的非线性方程提供了一种思路和途径，是一个很好的方法和工具。

注 ①参见 A. Hasegawa and E. Tappert, Appl. Phys. Lett. 23, 142 (1973).

②参见 Govind P. Agrawal, Nonlinear Fiber Optics & Application of Nonlinear Fiber Optics

③参见张开明，顾昌鑫.计算物理，复旦大学出版社，1987

④参见G. H. Weiss and A. A. Maradudin, J. Math. Phys. 3, 771(1962)中的贝克豪斯多夫公式

⑤ 可通过将上述贝克豪斯多夫公式两次用于(15.4.19)式来证明.

<!-- page: 318 -->

# 本章小结

1. 非线性方程不同于线性方程，它没有普遍适用的解法，只能根据具体情况具体而定。对于大量的非线性方程，我们是无法求得其解析解的，只能利用解析近似法（如摄动法、变分法等）和数值计算方法（如差分法、分步傅里叶变换法等）求得其近似解析解和近似数值解。

2. 对少数非线性方程我们可通过反散射法、各种变换法等求得其解析解。本章介绍了其中的某些初等解法，它们的主要做法是：

（1）或通过引入自变量的幂次组合（如相似变换）或线性组合（如行波解）使自变量的个数减少乃至化为常微分方程，而使求解难度大为降低；

（2）或引入某些自变量或函数的变换，如基尔霍夫变换、柯勒-霍普夫变换、端迹变换等，从而将非线性偏微分方程化为线性偏微分方程求解.

3. 本章解析求解了三个具有孤波解的方程. 对孤波和孤子我们都有了一定程度的了解. 值得指出的是, 在物理学和其他实际问题中具有孤波解的当然不只是这三个方程, 目前数学物理中发现的至少就已有六个. 这些问题求解的技巧性强, 涉及的知识面广, 鉴于篇幅的限制, 在此我们不能一一详细介绍.

4. 本章介绍了求解非线性方程解析近似解的摄动法和数值近似解的分步傅里叶变换法.

<!-- page: 319 -->

积分方程是研究数学其他学科和各种物理问题的一个重要数学工具。它在弹性介质理论和流体力学中应用很广，也常见于理论物理中。本章将介绍求解积分方程的理论和方法，主要讨论非奇异积分方程求解的三个方面。首先我们介绍了几种解积分方程的直观明显的方法；其次，我们讨论了如何将施密特-希尔伯特(Schmidt-Hilbert)理论用于解积分方程；最后，我们介绍了维纳-霍普夫(Wiener-Hopf)方法，这是一种用于求解特殊类型积分方程的更简捷的变换方法。

### 16.1 积分方程的几种解法

## 1. 方程的分类

在方程中，若未知函数在积分号下出现，则称这种方程为积分方程。在这章中，我们将仅讨论一些简单类型的积分方程。一般的线性积分方程，可写为如下的形式：

$$  h(x)g(x)-\lambda\int_{a}^{b}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{(16.1.1)}$$

其中， $ h(x) $ 和  $ f(x) $ 是已知函数， $ g(x) $ 是未知函数， $ \lambda $ 是常数因子（经常起一个本征值的作用），而  $ K(x,y) $ 被称为积分方程的核，也是已知函数。

在方程(16.1.1)中，若 $ h(x)=0,\lambda=1 $，则有

$$  \int_{a}^{b}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{（16.1.2）}$$

称为第一类的弗雷德霍姆(Fredholm)方程；若 $ h(x)=1 $，则有

$$  g(x)-\lambda\int_{a}^{b}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{（16.1.3）}$$

称为第二类的弗雷德霍姆方程. 有时候, 对于 y > x 时,  $ K(x, y) = 0 $. 在这种情况下, 积分上限为 x, 即方程 (16.1.2) 和 (16.1.3) 变为

$$  \int_{a}^{x}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{(16.1.4)}$$

$$  g(x)-\lambda\int_{a}^{x}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{（16.1.5）}$$

分别称为第一类和第二类的伏特拉(Volterra)方程.

积分方程也可采用算符的形式来表示，即方程(16.1.1)可写为

$$  (h-\lambda\mathbf{K})g(x)=f(x)   \tag*{(16.1.6)}$$

<!-- page: 320 -->

其中 K 为积分算符，它表示用核相乘并对 y 从 a 到 b 的积分。将积分方程写成这种形式，易于与含有矩阵和微分算符的算符方程相比较。

以上各方程中，若  $ f(x)\equiv0 $，则为齐次方程.

## 2. 退化核的方程的解法

如果积分方程的核具有如下的形式

$$  K(x,y)=\sum_{i=1}^{n}\varphi_{i}(x)\psi_{i}(y)   \tag*{(16.1.7)}$$

则被称为是退化的。具有退化核的积分方程，可用初等的方法来求解。下面，我们将通过二个具体的例子来说明如何求解退化核方程。

#### 例 1 求解积分方程

$$  g(x)-\lambda\int_{0}^{1}(xy^{2}+x^{2}y)g(y)\mathrm{d}y=x   \tag*{（16.1.8）}$$

解令

$$  A=\int_{0}^{1}y^{2}g(y)\mathrm{d}y,\quad B=\int_{0}^{1}y g(y)\mathrm{d}y   \tag*{(16.1.9)}$$

则(16.1.8)变为

$$  g(x)=x+\lambda A x+\lambda B x^{2}   \tag*{(16.1.10)}$$

则将(16.1.10)式代入(16.1.9)式得

$$  \left\{\begin{aligned}A&=\frac{1}{4}+\frac{1}{4}\lambda A+\frac{1}{5}\lambda B\\ B&=\frac{1}{3}+\frac{1}{3}\lambda A+\frac{1}{4}\lambda B\end{aligned}\right.   \tag*{（16.1.11）}$$

方程组(16.1.11)的解是

 $$ A=\frac{60+\lambda}{240-120\lambda-\lambda^{2}},\qquad B=\frac{80}{240-120\lambda-\lambda^{2}} $$ 

代入(16.1.10)式，于是得积分方程(16.1.8)的解为

$$  g(x)=\frac{(240-60\lambda)x+80\lambda x^{2}}{240-120\lambda-\lambda^{2}}   \tag*{（16.1.12）}$$

注意，有两个  $ \lambda $ 的值可使我们的解(16.1.12)式变为无穷大。当  $ \lambda $ 取某些特殊值时，齐次积分方程有非零解，这样的  $ \lambda $ 值称为积分方程的本征值，而相应的非零解称做本征函数。

由上例我们看到，如果核是退化的，则解一个积分方程(16.1.3)的问题就简化为解一个大家非常熟悉的代数方程组的问题。如果退化核(16.1.7)有N项，显然将有N个本征值。当然它们不一定都不同。既然退化核方程的解是与相应的线性代数方程组密切相关的，所以退化核方程的许多性质可由相应的代数方程组的有关性质导出。弗雷德霍姆将之简化为一系列理论，这些理论被人们称为弗雷德霍姆定理。我们将不加证明的叙述如下，因为根据学生以往所具有的本征值和代数方程组方面的经验

<!-- page: 321 -->

验，这些理论，应是不难被接受和证明的 $ ^{①} $.

定理 16.1 如果  $ \lambda $ 不是本征值，则对于任何的非齐次项  $ f(x) $，非齐次方程 (16.1.3) 有唯一的解；如果  $ \lambda $ 是本征值，则齐次方程

$$  g(x)-\lambda\int_{a}^{b}K(x,y)g(y)\mathrm{d}y=0   \tag*{(16.1.13)}$$

至少有一个非平凡解即本征函数，而且与一个本征值相对应的、线性独立的本征函数只有一个.

定理 16.2 如果  $ \lambda $ 不是一个本征值，那么  $ \lambda $ 也不是转置方程

$$  g(x)-\lambda\int_{a}^{b}K(y,x)g(y)\mathrm{d}y=f(x)   \tag*{(16.1.14)}$$

的一个本征值；如果  $ \lambda $ 是一个本征值，则  $ \lambda $ 也是转置方程的一个本征值，即

$$  g(x)-\lambda\int_{a}^{b}K(y,x)g(y)\mathrm{d}y=0   \tag*{(16.1.15)}$$

至少有一个非平凡解.

定理 16.3 若  $ \lambda $ 是一个本征值，则非齐次方程（16.1.3）有解的充要条件是： $ f(x) $ 与转置齐次方程（16.1.15）的一切解正交. 即

$$  \int_{a}^{b}\varphi(x)f(x)\mathrm{d}x=0   \tag*{(16.1.16)}$$

其中  $ \varphi(x) $ 满足 (16.1.15) 式.

事实上，定理16.2是这样一个事实的模拟，即矩阵和它的转置具有同样的本征值。如果我们以 $ \varphi(x) $乘以(16.1.3)式并对x积分，便可得到条件(16.1.16)。

顺便提及，弗雷德霍姆定理仅严格地适用于非奇异的积分方程。奇异积分方程 $ ^{②} $的理论是一个不同的问题。

对于具有退化核的伏特拉方程，常常能通过求微分而变为微分方程。我们仍以一个具体的例子说明。

例2

$$  u(x)-\int_{0}^{x}xy u(y)\mathrm{d}y=x   \tag*{(16.1.17)}$$

解令

 $$ g(x)=\int_{0}^{x}y u(y)\mathrm{d}y $$ 

代入方程(16.1.17)，则有

 $$ u(x)=x+x g(x) $$ 

所以

 $$ g^{^{\prime}}(x)=xu(x)=x[x+xg(x)] $$ 

解此微分方程得

 $$ g(x)=-1+c\mathrm{e}^{x^{3}/3} $$ 

于是得

 $$ u(x)=c x\mathrm{e}^{x^{3}/3} $$ 

将之代入原方程(16.1.17)可求得 c=1.

<!-- page: 322 -->

## 3. 具有位移核的方程的求解

如果核仅仅是 $  (x-y)  $的一个函数，即所谓的位移核，且积分范围是一 $ \infty $到 $ +\infty $，则我们可以应用傅里叶变换来求解。考虑方程

$$  g(x)-\lambda\int_{-\infty}^{\infty}K(x-y)g(y)\mathrm{d}y=\varphi(x)   \tag*{（16.1.18）}$$

对此方程进行傅氏变换，并记

 $$ F[g(x)]=\tilde{g}(\omega),\quad F[K(x,y)]=\int_{-\infty}^{\infty}K(x,y)\mathrm{e}^{-\mathrm{i}\omega x}\mathrm{d}x=\tilde{K}(\omega),\quad F[\varphi(x)]=\tilde{\varphi}(\omega) $$ 

则由卷积定理有

 $$ F\Big[\int_{-\infty}^{\infty}K(x-y)g(y)\mathrm{d}y\Big]=\widetilde{K}(\omega)\widetilde{g}(\omega) $$ 

于是积分方程(16.1.18)变为

 $$ \tilde{g}(\omega)=\tilde{\varphi}(\omega)+\lambda\tilde{K}(\omega)\tilde{g}(\omega) $$ 

 $$ \tilde{g}(\omega)=\frac{\tilde{\varphi}(\omega)}{1-\lambda\tilde{K}(\omega)} $$ 

因此

如果我们能求上式的逆变换，则我们就能得到方程(16.1.18)的解.

如果积分区间是从 0 到 x，具有一位移核，且被积函数对于 x<0 等于 0，则我们可用拉氏变换来求解。因为在这种情况下也有相应的卷积积分定理。

## 4. 迭代解法

解积分方程

$$  g(x)=f(x)+\lambda\int_{a}^{b}K(x,y)g(y)\mathrm{d}y   \tag*{(16.1.19)}$$

的一个直接方法是迭代法，我们首先取近似

 $$ g_{0}(x)\approx f(x) $$ 

作为零级近似将此式代入方程(16.1.19)式右边的积分中，便得到第一级近似

 $$ g_{1}(x)=f(x)+\lambda\int_{a}^{b}K(x,y)f(y)\mathrm{d}y $$ 

再将一级近似代入(16.1.19)式右边，便得到二级近似

 $$ g_{2}(x)=f(x)+\lambda\int_{a}^{b}K(x,y)f(y)\mathrm{d}y+\lambda^{2}\int_{a}^{b}\mathrm{d}y\int_{a}^{b}\mathrm{d}y^{\prime}K(x,y)K(y,y^{\prime})f(y^{\prime}) $$ 

重复迭代，于是得级数

$$  g(x)=f(x)+\sum_{n=1}^{\infty}\lambda^{n}\int_{a}^{b}K_{n}(x,y)f(y)\mathrm{d}y   \tag*{（16.1.20）}$$

其中

$$  \left\{\begin{aligned}&K_{1}(x,y)=K(x,y)\\ &K_{n+1}(x,y)=\int_{a}^{b}K(x,y^{\prime})K_{n}(y^{\prime},y)\mathrm{d}y^{\prime},\quad n=1,2,\cdots\end{aligned}\right.   \tag*{(16.1.21)}$$

<!-- page: 323 -->

被称为诺伊曼级数或积分方程(16.1.19)的诺伊曼解. 可以证明, 如果核  $ K(x, y) $ 和  $ f(x) $ 在区间  $ a \leqslant x, y \leqslant b $ 上连续, 对于足够小的  $ \lambda^{\otimes} $, 该级数解将收敛.

例 3 对于粒子散射的问题，描述粒子运动的薛定谔方程是

 $$ -\frac{\hbar^{2}}{2m}\Delta\varphi(\boldsymbol{r})+V(\boldsymbol{r})\varphi(\boldsymbol{r})=E\varphi(\boldsymbol{r}) $$ 

其中， $ \varphi(r) $ 表示粒子的波函数，第一项表示粒子的动能， $ V(r) $ 表示作用势，E 表示系统的总能量，它可表为

 $$ E=\frac{\hbar^{2}k^{2}}{2m} $$ 

故方程又可写为

 $$ \Delta\varphi(\boldsymbol{r})+k^{2}\varphi(\boldsymbol{r})=\frac{2m}{\hbar^{2}}V(\boldsymbol{r})\varphi(\boldsymbol{r}) $$ 

此方程具有边界条件

 $$ \varphi(r)\mid_{r\to\infty}\to\mathrm{e}^{\mathrm{i}k\cdot r}+f(\theta,\varphi)\frac{\mathrm{e}^{\mathrm{i}k r}}{r} $$ 

此式第一项表示入射粒子的平面波，第二项表示入射粒子与 $ V(r) $的作用而散射的粒子的球面波. $ k^{2}=2mE/\hbar^{2} $，（k为波矢， $ |k|=k $）。于是，由格林函数法知亥姆霍兹方程（16.1.22）的格林函数为

 $$ G(\boldsymbol{r},\boldsymbol{r}^{\prime})=\frac{1}{-4\pi}\frac{\mathrm{e}^{i k|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|} $$ 

这样，我们可以将散射问题转变为积分方程

 $$ \varphi(\boldsymbol{r})=\mathrm{e}^{ik\cdot r}-\frac{2m}{4\pi\hbar^{2}}\int\mathrm{d}\boldsymbol{r}^{\prime}\frac{\mathrm{e}^{ik|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}V(\boldsymbol{r}^{\prime})\varphi(\boldsymbol{r}^{\prime}) $$ 

其中第一项是用来调整解使之满足边界条件的补充(修正)函数. 解可以写为诺伊曼级数(16.1.21). 由第一次迭代，即取  $ \varphi_{0}(r)=\mathrm{e}^{ik\cdot r} $，我们可以得到一非常重要的结果，被称做玻恩(Born)近似

 $$ \varphi(\boldsymbol{r})\approx\mathrm{e}^{\mathrm{i}k\cdot r}-\frac{m}{2\pi\hbar^{2}}\int\mathrm{d}\boldsymbol{r}^{\prime}\frac{\mathrm{e}^{\mathrm{i}k|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}V(\boldsymbol{r}^{\prime})\mathrm{e}^{\mathrm{i}k\cdot r^{\prime}} $$ 

记

 $$ \varphi_{1}(\boldsymbol{r})=-\frac{m}{2\pi\hbar^{2}}\int\frac{\mathrm{e}^{\mathrm{i}k\left|\boldsymbol{r}-\boldsymbol{r}^{\prime}\right|}}{\left|\boldsymbol{r}-\boldsymbol{r}^{\prime}\right|}V(\boldsymbol{r}^{\prime})\mathrm{e}^{\mathrm{i}k\cdot\boldsymbol{r}^{\prime}}\mathrm{d}\boldsymbol{r}^{\prime} $$ 

继续迭代遂有

 $$ \varphi_{2}(\boldsymbol{r})=\left(-\frac{m}{2\pi\hbar^{2}}\right)^{2}\iint\frac{\mathrm{e}^{\mathrm{i}k\left|\boldsymbol{r}-\boldsymbol{r}^{\prime}\right|}}{\left|\boldsymbol{r}-\boldsymbol{r}^{\prime}\right|}V(\boldsymbol{r}^{\prime})\frac{\mathrm{e}^{\mathrm{i}k\left|\boldsymbol{r}^{\prime}-\boldsymbol{r}^{\prime\prime}\right|}}{\left|\boldsymbol{r}^{\prime}-\boldsymbol{r}^{\prime\prime}\right|}V(\boldsymbol{r}^{\prime\prime})\mathrm{e}^{\mathrm{i}k\cdot\boldsymbol{r}^{\prime\prime}}\mathrm{d}\boldsymbol{r}^{\prime}\mathrm{d}\boldsymbol{r}^{\prime\prime} $$ 

于是解可表为级数

 $$ \varphi(\boldsymbol{r})=\varphi_{0}(\boldsymbol{r})+\varphi_{1}(\boldsymbol{r})+\varphi_{2}(\boldsymbol{r})+\cdots $$ 

这个级数解当  $ V(r) $ 较小时，便能很快收敛.

## 5. 弗雷德霍姆解法

弗雷德霍姆用下述方法，得到了方程（16.1.19）一个更完善的级数解，即通过细

<!-- page: 324 -->

分积分区间 a<x<b，用求和代替积分，解得到的代数方程，然后讨论无限多的细分的极限，结果得到积分方程(16.1.19)的解为

$$  g(x)=f(x)+\lambda\int_{a}^{b}R(x,y;\lambda)f(y)\mathrm{d}y   \tag*{（16.1.23）}$$

其中  $ R(x,y;\lambda) $ 被称为解核，是两个无穷级数的比

$$  R(x,y;\lambda)=\frac{D(x,y;\lambda)}{D(\lambda)}   \tag*{(16.1.24)}$$

$$  D(x,y;\lambda)\equiv\sum_{n=0}^{\infty}\frac{(-1)^{n}}{n!}\lambda^{n}B_{n}(x,y)   \tag*{（16.1.25）}$$

$$  D(\lambda)\equiv\sum_{n=0}^{\infty}\frac{(-1)^{n}}{n!}C_{n}\lambda^{n}   \tag*{（16.1.26）}$$

而 $ B_{n} $的定义为

$$  \left\{\begin{aligned}&B_{0}(x,y)\equiv K(x,y)\\ &B_{n}(x,y)\equiv\int_{a}^{b}\int_{a}^{b}\cdots\int_{a}^{b}K\binom{x\;t_{1}\cdots t_{n}}{y\;t_{1}\cdots t_{n}}\mathrm{d}t_{1}\mathrm{d}t_{2}\cdots\mathrm{d}t_{n},\quad n=1,2,3\cdots\end{aligned}\right.   \tag*{（16.1.27）}$$

其中，行列式

$$  K\binom{x\;t_{1}t_{2}\cdots t_{n}}{y\;t_{1}t_{2}\cdots t_{n}}\equiv\left|\begin{matrix}K(x,y)K(x,t_{1})\cdots K(x,t_{n})\\ K(t_{1},y)K(t_{1},t_{1})\cdots K(t_{1},t_{n})\\ \cdots\cdots\cdots\\ K(t_{n},y)K(t_{n},t_{1})\cdots K(t_{n},t_{n})\end{matrix}\right|   \tag*{（16.1.28）}$$

 $ C_{n} $ 的定义为

$$  C_{0}\equiv1,\quad C_{n}\equiv\int_{a}^{b}\int_{a}^{b}\cdots\int_{a}^{b}K\binom{t_{1}t_{2}\cdots t_{n}}{t_{1}t_{2}\cdots t_{n}}\mathrm{d}t_{1}\mathrm{d}t_{2}\cdots\mathrm{d}t_{n},\quad n=1,2,3\cdots   \tag*{（16.1.29）}$$

可以证明

$$  C_{n+1}=\int_{a}^{b}B_{n}(y,y)\mathrm{d}y,\quad n=0,1,2\cdots   \tag*{（16.1.30）}$$

$$  B_{n}(x,y)=C_{n}K(x,y)-n\int_{a}^{b}K(x,t)B_{n-1}(t,y)\mathrm{d}t,\quad n=1,2,\cdots   \tag*{（16.1.31）}$$

弗雷德霍姆解的重要性在于，(16.1.23)式和(16.1.25)式是收敛的，不像诺伊曼级数却常常发散.本征值可通过分母函数 $ D(\lambda) $求得.

例4 求解方程

 $$ g(x)=f(x)+\lambda\int_{0}^{1}(x+y)g(y)\mathrm{d}y $$ 

其中  $ f(x) $ 是已知函数，而  $ \lambda \neq -6 \pm 4\sqrt{3} $

解 此处核为  $ K(x,y)=x+y $，故由(16.1.29)式和(16.1.27)式有

 $$ C_{0}=1,\qquad B_{0}(x,y)=x+y $$

<!-- page: 325 -->

在此基础上利用(16.1.30)式和(16.1.31)式可计算出

 $$ C_{1}=\int_{0}^{1}(y+y)\mathrm{d}y=1 $$ 

 $$ B_{1}(x,y)=(x+y)-\int_{0}^{1}(x+t)(t+y)\mathrm{d}t=\frac{x+y}{2}-xy-\frac{1}{3} $$ 

 $$ C_{2}=\int_{0}^{1}\left(y-y^{2}-\frac{1}{3}\right)\mathrm{d}y=-\frac{1}{6} $$ 

 $$ B_{2}(x,y)=-\frac{1}{6}(x+y)-2\int_{0}^{1}(x+t)\left(\frac{t+y}{2}-ty-\frac{1}{3}\right)\mathrm{d}t=0 $$ 

从而

 $$ C_{n}\equiv0,\quad B_{n}\equiv0,\quad n\geqslant3 $$ 

故由(16.1.25)式和(16.1.26)式有

 $$ D(x,y;\lambda)=(x+y)-\left(\frac{x+y}{2}-xy-\frac{1}{3}\right)\lambda $$ 

 $$ D(\lambda)=1-\lambda+\frac{1}{2}\Big(-\frac{1}{6}\Big)\lambda^{2}=1-\lambda-\frac{\lambda^{2}}{12} $$ 

代入解核公式得

 $$ R(x,y;\lambda)=\frac{x+y-\left(\frac{x+y}{2}-xy-\frac{1}{3}\right)\lambda}{1-\lambda-\frac{\lambda^{2}}{12}} $$ 

将此结果代入(16.1.23)式，即得需求解方程的解为

 $$ g(x)=f(x)-12\lambda\int_{0}^{1}\frac{(x+y)-\left(\frac{x+y}{2}-xy-\frac{1}{3}\right)\lambda}{\lambda^{2}+12\lambda-12}f(y)\mathrm{d}y $$ 

注 ① 见参考文献[8]，第Ⅰ卷.

②如果积分方程的积分区间为无限或核有奇异性，则称为奇异积分方程.

③易于证明，当 $ \left|\lambda\right|\leqslant\frac{\rho}{M(b-a)}<\frac{1}{M(b-a)},\quad M=\max\left|K(x,y)\right| $时即可.

#### 习题16.1

1. 解积分方程

(1)  $  u(x) = \mathrm{e}^x + \lambda \int_0^1 x \, tu(t) \, \mathrm{d}t;  $

(2) $ u(x)=\lambda\int_{0}^{\pi}u(t)\sin(x-t)dt $ (两个本征值；两个解).

2. 求解

 $$ g(x)=x^{2}+\int_{0}^{1}x y g(y)\mathrm{d}y $$ 

3. 求解积分方程

 $$ (1)u(x)=x+\lambda\int_{0}^{\infty}\mathrm{e}^{-y}u(y)\mathrm{d}y;\quad(2)u(x)=\lambda\int_{-x}^{x}u(y)\cos y\mathrm{d}y. $$

<!-- page: 326 -->

4.（1）求下列积分方程的本征函数和本征值：

 $$ g(x)=\lambda\int_{0}^{1}\mathrm{e}^{x-y}g(y)\mathrm{d}y $$ 

（2）求解积分方程

 $$ g(x)=\mathrm{e}^{x}+\lambda\int_{0}^{1}\mathrm{e}^{x-y}g(y)\mathrm{d}y $$ 

5. 求解下列方程：

(1)  $ g(x) = x + \int_{0}^{x} g(y) \, dy $;

(2)  $ u(x) = x^{\varepsilon} + \lambda \int_{0}^{x} (x - y)^{\varepsilon} u(y) \, \mathrm{d}y $ （ $ \varepsilon $ 为整数）.

6. 求解积分方程

 $$ g(x)=x+\lambda\int_{0}^{1}y(x+y)g(y)\mathrm{d}y. $$ 

（1）用弗雷德霍姆方法；

（2）用诺伊曼方法（保留到 $ \lambda^{2} $项）.

7. 对  $ u(x) $ 求解

 $$ (1)u(x)=\mathrm{e}^{-x^{2}}+\lambda\int_{-\infty}^{\infty}\mathrm{e}^{-(x-y)^{2}}u(y)\mathrm{d}y;\quad(2)u(x)=\frac{1}{\cosh x}+\lambda\int_{-\infty}^{\infty}\frac{u(y)}{\cosh(x-y)}\mathrm{d}y. $$ 

8. 求解积分方程

 $$ g(x)=\mathrm{e}^{-|x|}+\lambda\int_{0}^{\infty}g(y)\cos x y\mathrm{d}y $$ 

提示：对积分方程取余弦变换.

9. 求解积分方程

 $$ g(x)=\mathrm{e}^{-|x|}+\lambda\int_{-\infty}^{\infty}\mathrm{e}^{-|x-y|}g(y)\mathrm{d}y $$ 

当 $ x\to\pm\infty $时， $ g(x) $为有限值.

### 16.2 施密特-希尔伯特理论

现在，我们考虑一种不同于诺伊曼级数和弗雷德霍姆级数的近似方法。这一近似方法是以考虑齐次积分方程的本征值和本征函数为基础的。

一个核  $ K(x,y) $，如果满足

 $$ K(x,y)=K(y,x) $$ 

则  $ K(x,y) $ 被称为对称核. 而如果

 $$ K(x,y)=\bar{K}(y,x) $$ 

则  $ K(x,y) $ 被称为厄米 (Hermite) 核。其中  $ \overline{K}(y,x) $ 表示  $ K(y,x) $ 的共轭。一个厄米核的本征值是实数，而属于不同本征值的本征函数是正交的 $ ^{①} $。这些论述的证明与矩阵的有关证明等同，我们留给学生自己证明。

## 1. 施密特-希尔伯特定理

设对称核  $ K(x,y) $ 的正交归一的本征函数族为  $ \{g_{i}(x)\}(i=1,2,3\cdots) $，相应的本

<!-- page: 327 -->

征值为 $ \lambda_{i} $，且 $ \int_{a}^{b}\left|K(x,y)\right|^{2}\mathrm{d}y $有界，则对于任何平方可积的函数 $ h(x) $，函数

$$  f(x)\equiv\int_{a}^{b}K(x,y)h(y)\mathrm{d}y   \tag*{（16.2.1）}$$

可以展开为本征函数族 $ \left\{g_{i}(x)\right\} $的绝对一致收敛的级数

$$  f(x)=\sum_{i=1}^{\infty}\frac{1}{\lambda_{i}}(g_{i},h)g_{i}(x)   \tag*{（16.2.2）}$$

其中

$$  \left(g_{i},h\right)=\int_{a}^{b}g_{i}(x)h(x)\mathrm{d}x,\quad i=1,2,3\cdots   \tag*{（16.2.3）}$$

 $ \bar{g}_{i}(x) $ 为  $ g_{i}(x) $ 的复共轭.

证 设  $ f(x)=\sum_{i=1}^{\infty}f_{i}g_{i}(x) $，则

 $$ f_{i}=(g_{i},f)=\int_{a}^{b}f(x)\overline{g}_{i}(x)\mathrm{d}x $$ 

将(16.2.1)式代入上式，并利用 $ K(y,x)=\overline{K}(y,x) $和 $ g_{i}(y)=\lambda_{i}\int_{a}^{b}K(y,x)g_{i}(x)dx $，则得

 $$ f_{i}=\int_{a}^{b}\int_{a}^{b}K(x,y)\bar{g}_{i}(x)h(y)\mathrm{d}x\mathrm{d}y=\frac{1}{\lambda_{i}}\int_{a}^{b}\bar{g}_{i}(x)h(y)\mathrm{d}y=\frac{1}{\lambda_{i}}(g_{i},h) $$ 

于是(16.2.2)得证.至于一致收敛性的证明在此略去.

## 2. 具有对称核的方程的解

定理 16.4 设对称核  $ K(x,y) $ 的正交归一的本征函数族为  $ \{g_{i}(x)\} $，相应的本征值是  $ \{\lambda_{i}\} $，如果  $ \int_{a}^{b} |K(x,y)|^{2} \, dx $ 有界，且函数  $ f(x) $ 是平方可积的，则当  $ \lambda \neq \lambda_{i} $ 时，弗雷德霍姆积分方程

$$  g(x)-\lambda\int_{a}^{b}K(x,y)g(y)\mathrm{d}y=f(x)   \tag*{(16.2.4)}$$

的解为

$$  g(x)=\lambda\sum_{i=1}^{\infty}\frac{(g_{i},f)}{\lambda_{i}-\lambda}g_{i}(x)+f(x)   \tag*{（16.2.5）}$$

并称之为施密特公式.

证 由方程(16.2.4)有

 $$ \frac{g(x)-f(x)}{\lambda}=\int_{a}^{b}K(x,y)g(y)\mathrm{d}y $$ 

这与上述的施密特-希尔伯特定理中的(16.2.1)式形式完全相同，故由施密特-希尔伯特定理中的(16.2.2)式，有

$$  \frac{g(x)-f(x)}{\lambda}=\sum_{i=1}^{\infty}\frac{(g_{i},g)}{\lambda_{i}}g_{i}(x)   \tag*{(16.2.6)}$$

<!-- page: 328 -->

以 $ \bar{g}_{j}(x) $乘以上式两边，并对x积分，则有

 $$ \frac{1}{\lambda}\left[\int_{a}^{b}g(x)\overline{g}_{j}(x)\mathrm{d}x-\int_{a}^{b}f(x)\overline{g}_{j}(x)\right]\mathrm{d}x=\sum_{i=1}^{\infty}\frac{(g_{i},g)}{\lambda_{i}}\int_{a}^{b}g_{i}(x)\overline{g}_{j}(x)\mathrm{d}x $$ 

利用本征函数的正交性，于是有

 $$ \frac{(g_{j},g)-(g_{j},f)}{\lambda}=\frac{(g_{j},g)}{\lambda_{j}} $$ 

即

 $$ (g_{j},g)=\frac{\lambda_{j}}{\lambda_{j}-\lambda}(g_{j},f),\quad j=1,2,3\cdots $$ 

将上式代入(16.2.6)式，即可得到施密特公式(16.2.5). 它可改写为

$$  g(x)=f(x)+\lambda\int_{a}^{b}R(x,y;\lambda)f(y)\mathrm{d}y   \tag*{（16.2.7）}$$

其中解核

$$  R(x,y;\lambda)=\sum_{i=1}^{\infty}\frac{1}{\lambda_{i}-\lambda}g_{i}(x)\overline{g}_{i}(y)   \tag*{(16.2.8)}$$

不难证得，解核还可以表示为如下几种形式：

$$  R(x,y;\lambda)=K(x,y)+\lambda\int_{a}^{b}K(x,\xi)R(\xi,y;\lambda)\mathrm{d}\xi   \tag*{(16.2.9)}$$

$$  R(x,y;\lambda)=K(x,y)+\lambda\sum_{i=1}^{\infty}\frac{(g_{i},K)}{\lambda_{i}-\lambda}g_{i}(x)   \tag*{（16.2.10）}$$

$$  R(x,y;\lambda)=K(x,y)+\lambda\sum_{i=1}^{\infty}\frac{\overline{g}_{i}(y)g_{i}(x)}{\lambda_{i}(\lambda_{i}-\lambda)}   \tag*{(16.2.11)}$$

## 3. 积分方程与常微分方程的关系

对于二阶常微分方程的初值问题

$$  \left\{\begin{aligned}y^{\prime \prime}(x)+p(x)y^{\prime}(x)+h(x)y(x)&=f(x)\\ y(0)=C_{0},\quad y^{\prime}(0)&=C_{1}\end{aligned}\right.   \tag*{（16.2.12）}$$

我们易于验证它与伏特拉方程

$$  g(x)+\int_{0}^{x}K(x,y)g(y)\mathrm{d}y=F(x)   \tag*{(16.2.13)}$$

是完全等价的。其中

$$  \begin{cases}g(x)=y^{\prime \prime}(x)\\K(x,y)=p(x)+h(x)(x-y)\\F(x)=f(x)-C_{1}p(x)-h(x)(C_{0}+C_{1}x)\end{cases}   \tag*{(16.2.14)}$$

也就是说，若  $ y(x) $ 是二阶常微分方程初值问题(16.2.12)的解，则  $ g(x)=y''(x) $ 必定是伏特拉方程(16.2.13)的解。反之，若已知积分方程(16.2.13)的解是  $ g(x) $，则不难证明定解问题(16.2.12)的解为

<!-- page: 329 -->

$$  y(x)=C_{0}+C_{1}x+\int_{0}^{x}(x-y)g(y)\mathrm{d}y   \tag*{（16.2.15）}$$

这只要将  $ g(x)=y''(x) $ 从  $ 0 \rightarrow x $ 积分两次即可，即

 $$ y(x)=C_{0}+C_{1}x+\int_{0}^{x}\left[\int_{0}^{a}g(y)\mathrm{d}y\right]\mathrm{d}\alpha $$ 

交换积分次序得

 $$ y(x)=C_{0}+C_{1}x+\int_{0}^{x}\left[\int_{y}^{x}g(y)\mathrm{d}\alpha\right]\mathrm{d}y=C_{0}+C_{1}x+\int_{0}^{x}(x-y)g(y)\mathrm{d}y $$ 

易于验证，将(16.2.14)式代入定解问题(16.2.12)确实满足.显然，若 $ p(x) $， $ h(x) $和 $ f(x) $均连续，定解问题(16.2.12)的解存在且唯一.

由上可见，微分方程的定解问题和积分方程间可互相转换。因此，我们可将不易求解的微分方程的问题转换为积分方程，而方便地用叠加解法求得其近似解。

注 ① 如果  $ \left|\overline{f}(x)g(x)\mathrm{d}x=0\right. $，则称此二函数是互相正交的.

② 见参考书目[8]第Ⅰ卷第三章.

#### 习题16.2

1. 试求解积分方程

 $$ g(x)-\lambda\int_{0}^{1}K(x,y)g(y)\mathrm{d}y=0,\quad0\leqslant x\leqslant1 $$ 

等价的微分方程的本征值问题，其中

 $$ K(x,y)=\left\{\begin{aligned}&\frac{x(2-y)}{2},&x\leqslant&y\\ &\frac{y(2-x)}{2},&y\leqslant&x,\end{aligned}\right. $$ 

2. 求解积分方程

(1)

 $$ g(x)-\lambda\int_{0}^{2\pi}\sin x\sin y g\left(y\right)\mathrm{d}y=f(x)\quad\left[f(x)\right. 已知 ]； $$ 

(2)

 $$ g(x)-\lambda\int_{0}^{1}(xy^{2}+x^{2}y)g(y)\mathrm{d}y=x. $$ 

### 16.3 维纳-霍普夫方法

维纳-霍普夫方法，是一种用来求解某些积分方程的特殊的积分变换方法。被称为维纳-霍普夫类型的积分方程

 $$ g(x)=\varphi(x)+\int_{0}^{\infty}K(x-y)g(y)\mathrm{d}y,\quad-\infty<x<\infty $$ 

其位移核和积分的半无限区间是重要的特色. 令  $ g(x)=g_{+}(x)+g_{-}(x) $，其中对于 x>0,  $ g_{+}(x)=0 $，而对于 x<0,  $ g_{-}(x)=0 $. 那么

 $$ g_{+}\left(x\right)+g_{-}\left(x\right)=\varphi(x)+\int_{-\infty}^{\infty}K(x-y)g_{-}\left(y\right)\mathrm{d}y $$

<!-- page: 330 -->

现在取傅里叶变换，则

 $$ \tilde{g}_{+}\left(\omega\right)+\tilde{g}_{-}\left(\omega\right)=\tilde{\varphi}\left(\omega\right)+\tilde{K}\left(\omega\right)\tilde{g}_{-}\left(\omega\right) $$ 

即

$$  \tilde{g}_{-}\left(\omega\right)\left[1-\tilde{K}\left(\omega\right)\right]+\tilde{g}_{+}\left(\omega\right)=\tilde{\varphi}\left(\omega\right)   \tag*{(16.3.1)}$$

因为对于 x>0, $ g_{+}(x)=0 $,所以  $ \tilde{g}_{+}(\omega) $ 在上半  $ \omega $ 平面中没有奇异性.同样  $ \tilde{g}_{-}(\omega) $ 在下半  $ \omega $ 平面中也没有奇异性.通常,对于某些  $ \alpha $ 和  $ \beta $ 有

 $$ \mid K(x)\mid\lesssim\left\{\begin{aligned}\mathrm{e}^{-\alpha x},x\to\infty\\ \mathrm{e}^{\beta x},x\to-\infty\end{aligned}\right. $$ 

因此 $ \widetilde{K}(\omega) $在窄条区域 $ -\beta<\mathrm{Im}\omega<\alpha $中是解析的.我们假定函数 $ \varphi(x) $在无穷远处至少也有这样的行为，则 $ \widetilde{\varphi}(\omega) $在窄条区域中也是解析的.让我们分解 $ 1-\widetilde{K}(\omega) $为两个函数

 $$ 1-\widetilde{K}(\omega)=\frac{A(\omega)}{B(\omega)} $$ 

其中  $ A(\omega) $ 在  $ \mathrm{Im}\omega<\alpha $ 中解析且不为零，而  $ B(\omega) $ 在  $ \mathrm{Im}\omega>-\beta $ 中解析且不为零.

方程(16.3.1)现在变为

$$  \tilde{g}_{-}\left(\omega\right)A(\omega)+\tilde{g}_{+}\left(\omega\right)B(\omega)=\tilde{\varphi}(\omega)B(\omega)   \tag*{（16.3.2）}$$

其中  $ \tilde{g}_{-}(\omega)A(\omega) $ 在  $ \mathrm{Im}\omega<0 $ 中没有奇点， $ \tilde{g}_{+}(\omega)B(\omega) $ 在  $ \mathrm{Im}\omega>0 $ 中没有奇点，而  $ \tilde{\varphi}(\omega)B(\omega) $ 在两个半平面中可能有奇点。现在我们将  $ \tilde{\varphi}(\omega)B(\omega) $ 按如下形式分开：

 $$ \tilde{\varphi}(\omega)B(\omega)=C(\omega)+D(\omega) $$ 

其中  $ C(\omega) $ 在上半  $ \omega $ 平面中没在奇点，而  $ D(\omega) $ 在下半  $ \omega $ 平面中没有奇点，于是方程 (16.3.2) 变为

$$  \tilde{g}_{-}\left(\omega\right)A(\omega)-D(\omega)=C(\omega)-\tilde{g}_{+}\left(\omega\right)B(\omega)   \tag*{（16.3.3）}$$

上式的左边在下半 $ \omega $平面中没有奇点，而右边在上半 $ \omega $平面没有奇点。因此，两边必须等于一个整函数。更进一步， $ \tilde{g}_{+}(\omega) $和 $ \tilde{g}_{-}(\omega) $在 $ \mathrm{Im}\omega=\pm\infty $时，趋于零。通常能证明函数 $ A,B,\cdots,D $最糟莫过于多项式。因此方程(16.3.3)的两边相当于某些多项式。这就确定了 $ g_{+}(x) $和 $ g_{-}(x) $。其中某些未知常数由物理推理或原积分方程中的代换确定。

例

$$  g(x)=\mathrm{e}^{-|x|}+\lambda\int_{0}^{\infty}\mathrm{e}^{-|x-y|}g(y)\mathrm{d}y   \tag*{（16.3.4）}$$

函数  $ e^{-|x|} $ 的傅氏变换是

 $$ \int_{-\infty}^{\infty}\mathrm{e}^{-|x|}\mathrm{e}^{-i\omega x}\mathrm{d}x=\frac{2}{1+\omega^{2}} $$ 

因而，积分方程(16.3.4)的傅氏变换是

 $$ \tilde{g}_{+}\left(\omega\right)+\tilde{g}_{-}\left(\omega\right)=\frac{2}{1+\omega^{2}}+\frac{2\lambda}{1+\omega^{2}}\tilde{g}_{-}\left(\omega\right) $$ 

或

 $$ \Big(\frac{\omega^{2}-\xi^{2}}{\omega^{2}+1}\Big)\tilde{g}_{-}\left(\omega\right)+\tilde{g}_{+}\left(\omega\right)=\frac{2}{1+\omega^{2}} $$ 

其中  $ \xi^{2}=2\lambda-1 $ 。为了明确，我们将假定  $ \xi $ 为实数  $ \left(\lambda>\frac{1}{2}\right) $

<!-- page: 331 -->

我们下一步是表达系数 $ \frac{\omega^{2}-\xi^{2}}{\omega^{2}+1} $作为 $ A(\omega)/B(\omega) $的商，其中 $ A(\omega) $在 $ \mathrm{Im}\omega<0 $中是解析的，而 $ B(\omega) $在 $ \mathrm{Im}\omega>-1 $中是解析的。很清楚，商仅可能为如下形式：

 $$ A(\omega)=\frac{\omega^{2}-\xi^{2}}{\omega-i},\quad B(\omega)=\omega+i $$ 

代入方程(16.3.2)，得

 $$ \begin{aligned}&\tilde{g}_{-}\text{(}\omega\text{)}\frac{\omega^{2}-\xi^{2}}{\omega-\mathrm{i}}+\tilde{g}_{+}\text{(}\omega\text{)}(\omega+\mathrm{i})=\frac{2}{\omega-\mathrm{i}}\\ &\\ &\tilde{g}_{-}\text{(}\omega\text{)}\Big(\frac{\omega^{2}-\xi^{2}}{\omega-\mathrm{i}}\Big)-\frac{2}{\omega-\mathrm{i}}=-\tilde{g}_{+}\text{(}\omega\text{)}(\omega+\mathrm{i})\\ \end{aligned} $$ 

即

(16.3.5)式的左边，在下半 $ \omega $平面中没有奇点；而右边在上半 $ \omega $平面中没有奇点.因此每边必须等于一个多项式.

现在我们应用基于  $ \tilde{g}_{\pm}(\omega) $ 的渐近行为的理论，来确定所需多项式的次数。设  $ P(\omega) $ 是  $ \omega $ 的某一多项式，于是

 $$ (\omega+i)\tilde{g}_{+}(\omega)=P(\omega) $$ 

 $$ \tilde{g}_{+}\left(\omega\right)=\frac{P(\omega)}{\omega+i} $$ 

如果当 $ \left|\omega\right|\rightarrow\infty $时 $ \tilde{g}_{+}\left(\omega\right) $减少，则 $ P\left(\omega\right) $仅可能是一个常数，我们称之为iA，因此

 $$ \tilde{g}_{+}\left(\omega\right)=\frac{\mathrm{i}A}{\omega+\mathrm{i}} $$ 

 $$ g_{+}\left(x\right)=A\mathrm{e}^{x},\quad x<0 $$ 

同样

 $$ \begin{aligned}\tilde{g}_{-}\left(\omega\right)&\Big(\frac{\omega^{2}-\xi^{2}}{\omega+\mathrm{i}}\Big)-\Big(\frac{2}{\omega-\mathrm{i}}\Big)=-\mathrm{i}A\\\tilde{g}_{-}\left(\omega\right)&=\frac{2}{\omega^{2}-\xi^{2}}-\frac{\mathrm{i}A\left(\omega-\mathrm{i}\right)}{\omega^{2}-\xi^{2}}\end{aligned} $$ 

故

$$  \begin{aligned}&g_{-}\left(x\right)=-\frac{2}{\xi}\sin\xi x+A\Big(\cos\xi x+\frac{1}{\xi}\sin\xi x\Big),\quad x>0\\&g(x)=\left\{\begin{aligned}&A\mathrm{e}^{x},&x<0\\&-\frac{2}{\xi}\sin\xi x+A\Big(\cos\xi x+\frac{1}{\xi}\sin\xi x\Big),&x>0\end{aligned}\right.\\ \end{aligned}   \tag*{（16.3.6）}$$

#### 习题16.3

1. 不用傅氏变换直接求解积分方程（16.3.4）

 $$ g(x)=\mathrm{e}^{-|x|}+\lambda\int_{0}^{\infty}\mathrm{e}^{-|x-y|}g(y)\mathrm{d}y,\quad-\infty<x<\infty;\lambda>\frac{1}{2} $$ 

并将求得的解与(16.3.6)相比较.

2. 如果  $ u(x) = \mathrm{e}^{-|x|} + \lambda \int_{0}^{\infty} |x - y| \mathrm{e}^{-|x - y|} u(y) \, \mathrm{d}y $，求  $ u(x) $.

<!-- page: 332 -->

# 本章小结

在求解非奇异的积分方程时，常常可采用如下的几种有用的方法：

1. 如果核是可分离的，则可用代数方法求解。在实际问题中，常常用可分离的核，近似表示一个复杂的核，这样可得到解答的途径。

2. 如果核仅仅是 $ (x-y) $的一个函数，用卷积理论可简化解的傅氏变换和拉氏变换的计算.

3. 如果有一个足够小的参数  $ \lambda $，积分的迭代法是一个有用的方法，否则需要一个弗雷德霍姆解.

4. 一旦一个厄米核的本征值和本征函数被求得，它们就能被用来构造积分算符的一个格林函数或解核。那么，任一非齐次方程就可运用这个格林函数来求解。

对于具有位移核和半无限积分区域的情况，我们讨论了维纳-霍普夫技术。许多其他的积分变换技术，在特殊情况下是有用的。

<!-- page: 333 -->

在积分变换法一章(第九章)中，我们曾引入了傅里叶变换的概念，虽然在那一章的侧重面是介绍如何用傅里叶变换法求解数理方程方程，但与此同时我们也了解到傅里叶变换是时域到频域互相转化的工具，曾经是信号处理领域应用最广泛、效果最好的一种分析手段。本章将引入信号时频分析和处理的更为理想的工具——小波变换（wavelet transform，wt）。

小波分析，是当前数学中一个迅速发展的新领域。它继承和发展了短时傅里叶变换局部化的思想，同时又克服了窗口大小不随频率变化等缺点，能够提供一个随频率改变的“时间-频率”窗口，是时间（空间）频率的局部化分析。通过伸缩平移运算对信号（函数）逐步进行多尺度细化，小波变换可聚焦到信号的任意细节，从而解决了傅里叶变换的困难问题，成为继傅里叶变换以来在科学方法上的重大突破。由于受篇幅限制，本章将只介绍小波变换的由来及相关基本概念。

### 17.1 小波变换的由来

## 1. 傅里叶变换的困难

为方便起见，本章记函数  $ f(t) $ 的傅里叶变换为  $ \tilde{f}(\omega) $，则傅里叶变换和逆变换的表达式为

$$  \tilde{f}(\omega)=\int_{-\infty}^{\infty}f(t)\mathrm{e}^{-\mathrm{i}\omega t}\mathrm{d}t   \tag*{（17.1.1）}$$

$$  f(t)=\frac{1}{2\pi}\int_{-\infty}^{\infty}\tilde{f}(\omega)\mathrm{e}^{\mathrm{i}\omega t}\mathrm{d}\omega   \tag*{(17.1.2)}$$

众所周知，如果把  $ f(t) $ 理解为信号的描述，则信号的傅里叶变换能给出信号的频率特性，即其频谱分析。但是傅里叶变换仅适用于确定性的平稳信号。从定义可以看出，为了应用傅里叶变换去研究一个信号的频谱特性，必须获得在整个时域  $ -\infty < t < \infty $ 中信号的全部信息。由于  $ |e^{\pm i\omega t}| = 1 $，即傅里叶变换的积分核在任何情形下的模都是1，所以信号  $ f(t) $ 的频谱  $ \tilde{f}(\omega) $ 的任一频点值都是由  $ f(t) $ 在整个时间域上的贡献决定的；反之，信号  $ f(t) $ 在任一时刻的状态，也是由频谱  $ \tilde{f}(\omega) $ 在整个频域  $ -\infty < \omega < \infty $ 上的贡献决定的。所以在时域中傅里叶变换没有任何分辨能力，通过有限频段上的  $ \tilde{f}(\omega) $ 不能获得信号  $ f(t) $ 在任何有限时间间隔内的频率信息。因为一个信号在某个时刻的一个小的邻域中发生了变化，那么整个频域都要受到影响。这就是说，傅里叶变

<!-- page: 334 -->

换在时域没有局域特性.

为研究信号在局部时间范围的频域特征，1946年盖柏（Gabor）提出了著名的盖柏变换，之后又进一步发展为窗口傅里叶变换，窗口傅里叶变换是在傅里叶变换的框架内，将非平稳过程看成是一系列短时平稳信号的叠加，通过在时域上加上窗口来实现短时性。从而弥补了傅里叶变换的一些不足。

## 2. 窗口傅里叶变换

设函数  $  g(t)  $ 平方绝对可积，则称  $  f(t) g(t - \tau)  $ 的傅里叶变换为  $  f(t)  $ 的窗口 Fourier 变换，也称  $  f(t)  $ 的盖柏变换，并记

$$  G_{f}(\omega,\tau)=\int_{-\infty}^{\infty}f(t)g(t-\tau)\mathrm{e}^{-\mathrm{i}\omega t}\mathrm{d}t   \tag*{(17.1.3)}$$

而称

 $$ f(t)=\frac{1}{2\pi}\int_{-\infty}^{\infty}\mathrm{d}\tau\int_{-\infty}^{\infty}G_{f}(\omega,\tau)\mathrm{e}^{\mathrm{i}\omega t}g(t-\tau)\mathrm{d}\omega $$ 

为窗口傅里叶变换的逆变换或反演公式，g(t)称为时窗函数，以下均取时窗函数g(t)满足

$$  \int_{-\infty}^{\infty}\mid g(t)\mid^{2}\mathrm{d}t=1   \tag*{（17.1.5）}$$

窗口傅里叶变换的逆变换公式(17.1.4)的得到是因为由傅里叶变换的反演公式，有

 $$ f(t)g(t-\tau)=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{f}(\omega,\tau)\mathrm{e}^{\mathrm{i}\omega t}\mathrm{d}\omega $$ 

于是

 $$ f(t)[g(t-\tau)]^{2}=\frac{1}{2\pi}\int_{-\infty}^{\infty}G_{f}(\omega,\tau)\mathrm{e}^{i\omega t}g(t-\tau)\mathrm{d}\omega $$ 

从而

 $$ f(t)\int_{-\infty}^{\infty}\left[g(t-\tau)\right]^{2}\mathrm{d}\tau=\frac{1}{2\pi}\int_{-\infty}^{\infty}\mathrm{d}\tau\int_{-\infty}^{\infty}G_{f}(\omega,\tau)\mathrm{e}^{\mathrm{i}\omega t}g(t-\tau)\mathrm{d}\omega $$ 

而

 $$ \int_{-\infty}^{\infty}\left[g(t-\tau)\right]^{2}\mathrm{d}\tau=\int_{-\infty}^{\infty}\mid g(t)\mid^{2}\mathrm{d}\tau=1 $$ 

代入上式即得到(17.1.4)式，记

$$  t^{*}=\int_{-\infty}^{\infty}t\mid g(t)\mid^{2}\mathrm{d}t   \tag*{(17.1.6)}$$

$$  \Delta t=\sqrt{\int_{-\infty}^{\infty}(t-t^{*})^{2}\mid g(t)\mid^{2}\mathrm{d}t}   \tag*{(17.1.7)}$$

分别称为时窗函数  $ g(t) $ 的时窗中心和时窗半径. 于是时窗函数  $ g(t) $ 的窗口为  $ \left[t^{*}-\Delta t, t^{*}+\Delta t\right] $, 窗口的宽度为  $ 2\Delta t $. 若记时窗函数  $ g(t-\tau) $ 的时窗中心和时窗半径分别为  $ t_{\tau}^{*} $ 和  $ \Delta t_{\tau} $, 则

 $$ t_{\tau}^{*}=\int_{-\infty}^{\infty}t\mid g(t-\tau)\mid^{2}\mathrm{d}t=\int_{-\infty}^{\infty}(u+\tau)\mid g(u)\mid^{2}\mathrm{d}u $$

<!-- page: 335 -->

$$ \begin{aligned}=&\int_{-\infty}^{\infty}u\mid g(u)\mid^{2}\mathrm{d}u+\tau\int_{-\infty}^{\infty}\mid g(u)\mid^{2}\mathrm{d}u=t^{*}+\tau\\\Delta t_{\tau}=&\sqrt{\int_{-\infty}^{\infty}(t-t_{\tau}^{*})^{2}\mid g(t-\tau)\mid^{2}\mathrm{d}t}=\sqrt{\int_{-\infty}^{\infty}(u+\tau-t_{\tau}^{*})^{2}\mid g(u)\mid^{2}\mathrm{d}u}\\=&\sqrt{\int_{-\infty}^{\infty}(u-t^{*})^{2}\mid g(u)\mid^{2}\mathrm{d}u}=\Delta t\end{aligned} $$ 

由此可见，时窗中心在平移，而时窗半径不变。

我们称时窗函数  $  g(t)  $ 的傅里叶变换， $ \tilde{g}(\omega) = F[g(t)] $ 为频窗函数并记

$$  \omega^{*}=\frac{\int_{-\infty}^{\infty}\omega\mid\widetilde{g}(\omega)\mid^{2}\mathrm{d}\omega}{\int_{-\infty}^{\infty}\mid\widetilde{g}(\omega)\mid^{2}\mathrm{d}\omega}   \tag*{(17.1.8)}$$

$$  \Delta\omega=\sqrt{\frac{\int_{-\infty}^{\infty}(\omega-\omega^{*})^{2}\mid\tilde{g}(\omega)\mid^{2}\mathrm{d}\omega}{\int_{-\infty}^{\infty}\mid\tilde{g}(\omega)\mid^{2}\mathrm{d}\omega}}   \tag*{(17.1.9)}$$

分别称为频窗中心和频窗半径. 当频窗函数是  $ \tilde{g}(\omega-\eta) $ 时，类似地可以推导出相应的频中心和频窗半径为

 $$ \omega_{\eta}^{*}=\omega^{*}+\eta,\quad\Delta\omega_{\eta}=\Delta\omega $$ 

因此频窗中心在平移，频窗半径不变，在时-频坐标系中，时窗和频窗共同作用，形成时-频窗。窗口傅里叶变换把时域上的信号  $ f(t) $ 映射到时-频域平面  $ (\tau, \omega) $ 中的一个二维函数  $ G_{f}(\omega, \tau) $。

例

$$  g(t)=\frac{b}{2\sqrt{\pi a}}\mathrm{e}^{-\frac{t^{2}}{4a}},\quad a,b>0   \tag*{（17.1.10）}$$

是一个常用的窗口函数称为高斯函数。试求其时窗中心、时窗半径以及频窗函数和时-频窗面积。

解 易于求得其时窗中心为

 $$ t^{*}=\int_{-\infty}^{\infty}t\mid g(t)\mid^{2}\mathrm{d}t=0 $$ 

并且时窗半径为

 $$ \Delta t=\sqrt{\int_{-\infty}^{\infty}(t-t^{*})^{2}\mid g(t)\mid^{2}\mathrm{d}t}=\sqrt{a} $$ 

相应的频窗函数  $ \tilde{g}(\omega)=be^{-\omega\omega^{2}} $，因此可以计算频窗中心  $ \omega^{*}=0 $，频窗半径  $ \Delta\omega=\frac{1}{2\sqrt{a}} $。所以时-频窗面积为  $ (2\Delta t)(2\Delta\omega)=2 $。

众所周知，高频信号波长较短，即在时间轴上的扩展较窄，因此为了提取高频分量的信息，时窗应该尽量地调窄一些，并允许频窗适当地宽；而低频信号波长较长，即在时间轴上的扩展较宽，因此时窗应尽量地调宽一些，频窗应当尽量缩小，以保证有较高的频率分辨率。然而，窗口傅里叶变换的窗函数一旦选定以后，其时-频窗口大小

<!-- page: 336 -->

和形状就固定不变了，与时间和频率无关，所以并没有很好地解决时-频局部化问题，这样就限制了窗口傅里叶变换的实际应用。

## 3. 小波变换的诞生

为了克服窗口傅里叶变换的不足，法国的地球物理学家 J. Morlet 在 1974 年首先提出了小波变换的概念。当时 Morlet 在分析地震数据时提出将地震波按一个确定函数的伸缩平移系展开。然后数学家 Meyer 对 Morlet 提出的方法进行系统研究，并与其他一些人的工作联合奠定了小波分析的基础。

### 17.2 小波变换

## 1. 连续小波变换

设  $ \psi(t) $ 及其傅里叶变换  $ \tilde{\psi}(\omega) $ 均为平方绝对可积函数，其宽度均为有限值，且满足相容性条件

$$  C_{\psi}=\int_{-\infty}^{\infty}\frac{\mid\tilde{\psi}(\omega)\mid^{2}}{\omega}\mathrm{d}\omega<\infty   \tag*{(17.2.1)}$$

则称  $ \phi(t) $ 为基小波或小波母函数，对于基小波  $ \phi(t) $，定义  $ f(t) $ 的小波变换。为

$$  (w_{\psi}f)(a,b)=\int_{-\infty}^{\infty}f(t)\psi_{a,b}^{*}(t)\mathrm{d}t   \tag*{(17.2.2)}$$

其中

$$  \psi_{a,b}(t)=\frac{1}{\sqrt{\left|\begin{matrix}a\\ \end{matrix}\right|}}\psi\Big(\frac{t-b}{a}\Big),\quad a,b\in R,a\neq0   \tag*{（17.2.3）}$$

为由基小波  $ \psi(t) $ 通过平移和伸缩生成的一族小波或小波基函数，a 和 b 为参数，分别为伸缩因子（或尺度因子）和平移因子（或位移因子）.

小波就是小的波形。所谓“小”是指它具有衰减性；而称之为“波”则是指它的波动性，如图17.1所示。具有其振幅正负相间的震荡形式。条件(17.2.1)意味着 $ \tilde{\psi}(0)=0 $。即， $ \int_{-\infty}^{\infty}\tilde{\psi}(t)dt=0 $。可见 $ \psi(t) $具有一定的振荡性，这正是称为小波的原因。

<div style="text-align: center;"><img src="images/p0336_img_in_chart_box_553_813_857_1048.jpg" alt="图17.1" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图17.1</div> </div>


连续小波  $ \psi_{a,b}(t) $ 的作用与窗口傅里叶变换中的  $ g(t-\tau)\mathrm{e}^{-\omega t} $ 作用类似，其中 b 与  $ \tau $ 一样都起着时间平移的作用，而 a 在连续小波变换中是一个尺度参数，它既能改变窗口的大小与形状，同时也能改变连续小波的频谱结构。

#### 常用的基本小波有

<!-- page: 337 -->

哈尔(Haar)小波  $ \psi(t)=\left\{\begin{aligned}&1,&0\leqslant t<\frac{1}{2}\\ &-1,&\frac{1}{2}\leqslant t<1\\ &0,& 其他 \end{aligned}\right. $

Morlet 小波  $ \psi(t)=\mathrm{e}^{\frac{t^{2}}{2}}\mathrm{e}^{\mathrm{i}\omega_{0}t},\quad-\infty<t<\infty,\quad\omega_{0}\leqslant5 $ (1)

墨西哥草帽小波(Marr 小波)  $ \psi(t)=(1-t^{2})\left(\frac{1}{\sqrt{2\pi}}\right)\mathrm{e}^{\frac{t^{2}}{2}},-\infty<t<\infty $

图 17.2 给出了部分小波的波形：

<div style="text-align: center;"><img src="images/p0337_img_in_chart_box_116_457_849_1141.jpg" alt="图17.2" width="76%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图17.2</div> </div>

<!-- page: 338 -->

## 2. 离散小波变换

在实际应用中，需要对伸缩因子a和平移因b进行离散化处理，可以取 $ a=a_{0}^{m} $， $ b=nb_{0}a_{0}^{m} $，m,n为整数， $ a_{0} $为大于1的常数， $ b_{0} $为大于0的常数，a和b的选取与小波 $ \phi(t) $的具体形式有关。离散小波函数表示为

$$  \psi_{m,n}(t)=\frac{1}{\sqrt{a_{0}^{m}}}\psi\Big(\frac{t-n b_{0}a_{0}^{m}}{a_{0}^{m}}\Big)=\frac{1}{\sqrt{a_{0}^{m}}}\psi(a_{0}^{-m}t-n b_{0})   \tag*{(17.2.7)}$$

相应的离散小波变换可以表示为

$$  (w_{\psi}f)(m,n)=\int_{-\infty}^{\infty}f(t)\psi_{m,n}^{*}(t)\mathrm{d}t   \tag*{(17.2.8)}$$

当 $ a_{0}=2,b_{0}=1 $时，离散少波变换为二进离散小波变换，这样便于分析，并适合于在计算机上进行高效的运算.

## 3. 小波变换的性质

设  $ f(t) $,  $ g(t) $ 平方绝对可积,  $ k_{1} $,  $ k_{2} $ 是任意常数, 则小波变换具有如下一些主要性质：

$$  (1) 线性性质 \quad(\mathcal{w}_{\psi}(k_{1}f+k_{2}g))(a,b)=k_{1}(\mathcal{w}_{\psi}f)(a,b)+k_{2}(\mathcal{w}_{\psi}g)(a,b)   \tag*{(17.2.9)}$$

$$  (2) 平移性质 \quad(\mathcal{w}_{\psi}f(t-t_{0}))(a,b)=(\mathcal{w}_{\psi}f(t))(a,b-t_{0})   \tag*{(17.2.10)}$$

$$  (3) 尺度法则 \quad(\mathcal{w}_{\psi}f(\lambda t))(a,b)=\frac{1}{\sqrt{\lambda}}(\mathcal{w}_{\psi}f(t))(\lambda a,\lambda b),\quad\lambda>0   \tag*{(17.2.11)}$$

与窗口傅里叶变换类似，在小波变换中，也可称  $ \psi_{a,b}(t) $ 是窗函数，小波变换的时频窗表现了小波变换的时-频局部化能力。其时窗中心  $ t^{*} $，时窗半径  $ \Delta t $，频窗中心  $ \omega^{*} $ 和频窗半径  $ \Delta\omega $ 分别为

$$  t^{*}=\frac{\int_{-\infty}^{\infty}t\mid\psi_{a,b}(t)\mid^{2}\mathrm{d}t}{\int_{-\infty}^{\infty}\mid\psi_{a,b}(t)\mid^{2}\mathrm{d}t},\qquad\Delta t=\sqrt{\frac{\int_{-\infty}^{\infty}(t-t^{*})^{2}\mid\psi_{a,b}(t)\mid^{2}\mathrm{d}t}{\int_{-\infty}^{\infty}\mid\psi_{a,b}(t)\mid^{2}\mathrm{d}t}}   \tag*{(17.2.12)}$$

$$  \omega^{*}=\frac{\int_{-\infty}^{\infty}\omega\mid\tilde{\psi}_{a,b}(\xi)\mid^{2}\mathrm{d}\omega}{\int_{-\infty}^{\infty}\mid\tilde{\psi}_{a,b}(\omega)\mid^{2}\mathrm{d}\omega},\qquad\Delta\omega=\sqrt{\frac{\int_{-\infty}^{\infty}(\omega-\omega^{*})^{2}\mid\tilde{\psi}_{a,b}(\omega)\mid^{2}\mathrm{d}\omega}{\int_{-\infty}^{\infty}\mid\tilde{\psi}_{a,b}(\omega)\mid^{2}\mathrm{d}\omega}}   \tag*{(17.2.13)}$$

小波变换中的窗函数  $ \psi_{a,b}(t) $ 是由  $ \psi(t) $ 的平移和缩放得来的，分别记对应于  $ \psi_{a,b}(t) $ 的有关量为：时窗中心  $ t_{\psi}^{*} $ 、时窗半径  $ \Delta t_{\psi} $ 、频窗中心  $ \omega_{\psi}^{*} $ 和频窗半径  $ \Delta\omega_{\psi} $

 $$ t^{*}=a t_{\psi}^{*}+b,\quad\Delta t=a\Delta t_{\psi},\quad\omega^{*}=a\omega_{\psi}^{*},\quad\Delta\omega=a\Delta\omega_{\psi} $$ 

虽然  $ \phi_{a,b}(t) $ 的时窗和频窗的中心与宽度随着 a, b 在变化，但是在时-频面上，窗口的面积不变，这是因为

<!-- page: 339 -->

$$ (2\Delta t)(2\Delta\omega)=(2a\Delta t_{\psi})\Bigl(2\frac{1}{a}\Delta\omega_{\psi}\Bigr)=(2\Delta t_{\psi})(2\Delta\omega_{\psi}) $$ 

由  $ f(t) $ 的小波变换  $ (w_{\phi}f)(a,b) $ 我们可得到其反演公式.

小波变换克服了傅里叶变换和窗口傅里叶变换的缺点，在时域和频域同时具有良好的局域化性质，被誉为“数学显微镜”。小波变换是泛函分析、调和分析和数值分析等数学分支发展的综合结晶，作为一种数学理论和方法在科学技术领域引起了越来越多的关注和重视。

小波变换联系了应用数学、物理学、计算机科学、信号与信息处理、图像处理、地震勘探等多个学科。数学家认为，小波分析是一个新的数学分支，它是泛函分析、傅里叶分析、样条分析、数值分析的完美结晶；信号和信息处理专家认为，小波分析是时间-尺度分析和多分辨分析的一种新技术，它在信号分析、语音合成、图像识别、计算机视觉、数据压缩、地震勘探、大气与海洋波分析等方面的研究都取得了有科学意义和应用价值的成果。

小波变换同样也可用于求解数理方程，特别是用于数值求解。在数字计算中，要把连续小波及其变换离散化。一般对小波变换进行二进制离散，这种离散化的小波和相应的小波变换叫做二进小波和二进小波变换。受篇幅限制，本书对这些内容都不再一一叙述。感兴趣的读者，可参看相关书籍及论文 $ ^{①} $。

#### 注 ① 可供参考的书籍：

1. Barbara Burke Hubbard. The Word according to Wavelets. A K Peters, Wellesley, MA, 1996.

2. Mark A. Pinsky. Introduction to Fourier Analysis and Wavelets. Pacific Grove, CA: Brooks/Cole., 2002.

3. David K. Ruch, Wavelet Theory: an Elementary Approach with Applications, Hoboken, NJ: Wiley, 2009.

4. C. Sidney Burrus, Ramesh A. Gopinath, Haitao Guo, Introduction to wavelet Transforms: A Primer.

<!-- page: 340 -->

### 第 一 篇

##### 习题1.1

4. (1)  $ 1 - \cos\alpha, \sin\alpha, 2\sin\frac{\alpha}{2}, \frac{\pi}{2} - \frac{\alpha}{2} $ (2)  $ \frac{16}{25}, \frac{8}{25}, \frac{8\sqrt{5}}{25}, \arctan\frac{1}{2} $

(3)  $ 0, -\frac{1}{8}, \frac{1}{8}, -\frac{\pi}{2} $

(4) ecos1, esin1, e, 1

5.  $ \cos n\theta = \sum_{l=0}^{\left[\frac{n}{2}\right]}\frac{(-1)^{l} n!}{(2l)!(n-2l)!}\sin^{2l}\theta\cos^{n-2l}\theta $

 $ \sin n\theta = \sum_{l=0}^{\left[\frac{n}{2}\right]}\frac{(-1)^{l} n!}{(2l+1)!(n-2l-1)!}\sin^{2l+1}\theta\cos^{n-2l-1}\theta $

 $ \left[\frac{n}{2}\right]=\left\{\begin{aligned}&\frac{n}{2}, 当 n 为偶数 \\&\frac{n-1}{2}, 当 n 为奇数\end{aligned}\right. $

6. (1)  $ \pm\frac{1}{\sqrt{2}}(\sqrt{\sqrt{2}+1}+\mathrm{i}\sqrt{\sqrt{2}-1}) $ (2)  $ -16\sqrt{3}-16\mathrm{i} $

(3) $ -\frac{\pi}{4}+2k\pi(k=0,\pm1,\pm2,\cdots) $ (4) $ 2^{-11}(-1+\sqrt{3})\mathrm{i} $

7. (1)  $ 1, -\frac{1}{2} \pm i \frac{\sqrt{3}}{2} $ (2)  $ 1 + 2i, 1 + i $

8. 大小： $ \sqrt{2} $; 方向： $ \frac{\pi}{4} $

10. (1)  $ z^{2} + \bar{z}^{2} = 2 $

(2)  $ \left(\frac{1}{4a^{2}}-\frac{1}{4b^{2}}\right)z^{2}+\left(\frac{1}{2a^{2}}+\frac{1}{2b^{2}}\right)z\cdot\bar{z}+\left(\frac{1}{4a^{2}}-\frac{1}{4b^{2}}\right)\bar{z}^{2}-1=0 $

(3)  $ z\bar{z}+z_{0}\bar{z}_{0}-z_{0}\bar{z}-z\bar{z}_{0}=R^{2} $

(4) $ (A-iB)z+(A+iB)\bar{z}+2C=0 $

##### 习题1.2

1. (1)  $ \frac{x^{2}+y^{2}-1}{(x+1)^{2}+y^{2}} $,  $ \frac{2y}{(x+1)^{2}+y^{2}} $ (2)  $ x^{3}-3xy^{2} $,  $ 3x^{2}y-y^{3} $

3. (1)  $ \lim_{n \to \infty} a_n = \lim_{n \to \infty} \left( \frac{2}{5} \right)^n \cos \frac{n\pi}{3} + i \lim_{n \to \infty} \left( \frac{2}{5} \right)^n \sin \frac{n\pi}{3} = 0 $

<!-- page: 341 -->

(2)  $ \lim_{n\to\infty}a_n = \lim_{n\to\infty}\frac{1}{n}\cos\frac{n-1}{2}\pi + i \lim_{n\to\infty}\frac{1}{n}\sin\frac{n-1}{2}\pi = 0 $

##### 习题1.3

2.（1）在复平面可导、解析（2）在z=0可导、全平面不解析

（3）每一单值支解析 （4）在 z=0 可导，全平面不解析

4. (1)  $ \left(1-\frac{1}{2}\mathrm{i}\right)z^{2}+\frac{1}{2}\mathrm{i} $ (2)  $ -\mathrm{i}(1-z)^{2} $ (3)  $ \frac{1}{2}-\frac{1}{z} $ (4)  $ \ln z $

5. 与虚轴相切于原点的圆族，复势  $ \omega=\frac{C_{1}}{z}+C_{2}+iC_{3}(C_{1},C_{2},C_{3} $ 为实数)

6. 抛物线族  $ y^{2}=C^{2}-2Cx(C>0) $. 复势  $ \omega=C_{1}\sqrt{z}+C_{2}+iC_{3}(C_{1},C_{2},C_{3} $ 为实数)

7. 不能

##### 习题1.4

## 5. 均为无穷多值函数

6. (1)  $ \mathrm{i}k\pi(k=0,\pm1,\pm2,\cdots) $ (2)  $ \ln2+\mathrm{i}\left(\frac{\pi}{3}+2k\pi\right)(k=0,\pm1,\cdots) $

(3)  $ \left(2k+\frac{1}{2}\right)\pi-\mathrm{i}\ln\left(2\pm\sqrt{3}\right) $ (k=0, $ \pm1 $,…) (4)  $ k\pi+\mathrm{i}\frac{1}{2}\ln2 $ (k=0, $ \pm1 $,…)

7.（1）2值；1, $ \infty $ （2）单值 （3）6值；2，-2, $ \infty $，1,-1

(4) 2值; $ (2k+1)\frac{\pi}{2}(k=0,\pm1,\pm2,\cdots) $ (5) 单值 (6) 2值;0, $ \infty $

(7)无穷多值； $ 0,\pm\pi,\pm2\pi,\cdots $ (8)2值；1,2

8.  $ -\frac{1}{2}(\sqrt{3}+i) $

9.  $ \sqrt{2}i $

10. (1)  $ \mathrm{e}^{\mathrm{i}\ln\sqrt{2}}\mathrm{e}^{-\left(\frac{\pi}{4}+2k\pi\right)}(k=0,\pm1,\cdots) $ (2)  $ 25\mathrm{e}^{-6k\pi}\mathrm{e}^{\mathrm{i}3\ln5}(k=0,\pm1,\cdots) $

(3)  $ \cos^{5}\varphi-10\cos^{3}\varphi\sin^{2}\varphi+5\cos\varphi\sin^{4}\varphi $ (4)  $ \ln\sqrt{2}+\mathrm{i}\left(\frac{1}{4}+2k\right)\pi(k=0,\pm1,\cdots) $

##### 习题1.5

1. 是  $ w(=u+iv) $ 平面中，由 v=0,  $ v^{2}=4(1-u) $ 和  $ v^{2}=4(1+u) $ 三条曲线所组成的图形

2.  $ 1, \pi; \frac{1}{2}, -\frac{\pi}{2} $

3. (1)  $ u^{2} + v^{2} = \frac{1}{4} $ (2)  $ v = -u $ (3)  $ u = \frac{1}{2} $ (4)  $ \left(u - \frac{1}{2}\right)^{2} + v^{2} = \frac{1}{4} $

4. (1)  $ w = z^n $ 将  $ z $ 平面与正实轴夹角为  $ \alpha $ 的角形区域:  $ 0 < \arg z < \alpha $ ( $ 0 < \alpha \leq \frac{2\pi}{n} $), 保角变换为  $ w $ 平面与正实轴夹角  $ n\alpha $ 的角形区域:  $ (0 < \arg z \leq n\alpha) $, 其反函数  $ z = \sqrt[n]{w} $ 当然正好反过来 (见图 1.15)

(2)  $ w = e^z $ 将  $ z $ 平面的带形区域:  $ 0 < \mathrm{Im}z < h $ ( $ 0 < h \leq 2\pi $) 保角变换为  $ w $ 平面的角域:  $ 0 < \arg w < h $, 而其后函数  $ y = \log x $ 正好结束 (见图 1.16)

 $$ z=\ln w $$ 

 $ ^{*} $5. 提示：可选变换  $ w=\sqrt{z} $. 等势线和电场线分别由一族开口向右的抛物线族（见图1.17中实线族）和开口向左的抛物线族（见图1.17中虚线族）给出

6. 提示：作变换 w =  $ \ln z $。等势线是由 O 点出发的矢径： $ \theta = 常数 $， $ 0 < r < \infty $（见图 1.18（a）中的实

<!-- page: 342 -->

线. 其中  $ r=|z| $. 电场线是 r= 常数  $ (0<\theta<\pi) $，它们是一些半圆（见图1.18(a)中的虚线）

<div style="text-align: center;"><img src="images/p0342_img_in_image_box_168_176_401_392.jpg" alt="图1.15" width="24%" /></div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_427_179_790_392.jpg" alt="图1.16" width="37%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.15</div> </div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_172_444_423_624.jpg" alt="(2)" width="26%" /></div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_470_542_533_592.jpg" alt="(b)" width="6%" /></div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_575_445_786_624.jpg" alt="图1.17" width="22%" /></div>


<div style="text-align: center;"><div style="text-align: center;">图1.16</div> </div>


<div style="text-align: center;"><div style="text-align: center;">(2)</div> </div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_173_666_515_949.jpg" alt="(a)" width="35%" /></div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_553_670_786_878.jpg" alt="图1.18" width="24%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图1.17</div> </div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_172_1005_471_1215.jpg" alt="(b)" width="31%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(a)</div> </div>


<div style="text-align: center;"><div style="text-align: center;">图1.18</div> </div>


<div style="text-align: center;"><img src="images/p0342_img_in_image_box_538_1005_786_1220.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><div style="text-align: center;">(b)</div> </div>

<!-- page: 343 -->

##### 习题2.1

1.  $ -\frac{1}{3}(1-i) $

2.（1）1（2）2（3）2

5.  $ \left\{\begin{array}{l}\pi\mathrm{i},n=1\\\frac{r^{1-n}}{1-n}[(-1)^{1-n}-1],n\neq1\end{array}\right. $

#### 习题2.2

1. (1) 0 (2)  $ 4\pi $

2. (1)  $ -\frac{\mathrm{i}}{3} $ (2)  $ 2\mathrm{ch}1 $ (3)  $ -\frac{\pi}{2}\mathrm{e} $

#### 习题2.3

1. (1)  $ 4\pi i $ (2)  $ \sqrt{2}\pi i $ (3)  $ 2\pi i $ (4) 0

2. (1)  $ \frac{\pi}{3} $ (2)  $ -\frac{\pi}{3} $ (3) 0

3. (1)  $ -\frac{\pi^{5}}{12}\mathrm{i} $ (2)  $ \mathrm{i}\pi\sqrt{2}\sin\left(1-\frac{\pi}{4}\right) $ (3)  $ -\frac{2\pi\mathrm{i}}{5!} $ (4)  $ 4\pi\mathrm{i} $

4.  $ 2\pi(-6+13i) $

6. (1) 1 (2)  $ -\frac{e}{2} $ (3)  $ 1-\frac{e}{2} $

##### 习题3.2

1. (1)  $ \infty $ (2) 2 (3) e (4) 若  $ \left|a\right|\leqslant1,1; $ 若  $ \left|a\right|>1,\frac{1}{\left|a\right|} $ (5)  $ \frac{1}{3} $

2. (1) R (2) 0 (3)  $ R^{n} $

3.（1）除 z = -1 外，在所有点上收敛（非绝对） （2）绝对收敛

4.（1）收敛，不绝对收敛（2）不绝对收敛.

##### 习题3.3

1. (1) 提示： $ \frac{1}{(1-z)^2} = \left(\frac{1}{1-z}\right)^x $ (2)  $ \sum_{k=0}^{\infty} (-1)^k \frac{a^k}{b^{k+1}} z^k $,  $ |z| < \left|\frac{b}{a}\right| $

(3)  $ \mathrm{e}\left(1+z+\frac{3}{2!}z^{2}+\frac{13}{3!}z^{3}+\cdots\right) $ (4)  $ \sum_{k=0}^{\infty}\frac{(-1)^k}{(2k+1)}z^{2k+1} $ (5)  $ \sum_{k=0}^{\infty}z^{3k}-\sum_{k=0}^{\infty}z^{3k+1} $ ( $ |z|<1 $)

(6)  $ \sum_{n=1}^{\infty}\sum_{m=0}^{\left\lbrack(n-1)/2\right\rbrack}\frac{(-1)^m}{(2m+1)!}z^n $ ( $ |z|<1 $)

2. (1) 提示： $ \cos z = \cos(z - 1 + 1) $ (2)  $ \frac{1}{4} + \sum_{k=1}^{\infty}(-1)^k \frac{(k-3)(z-1)^k}{2^{k+2}} $ ( $ |z-1|<2 $)

（3）提示： $ \frac{z}{z+2}=1-\frac{2}{3}\frac{1}{1+\frac{z-1}{2}}\quad(|z-1|<3)\quad(4)\sum_{k=0}^{\infty}\frac{\sin\left(1-\frac{k\pi}{2}\right)}{k!}(z-1)^{2k}\quad(|z-1|<\infty) $

3. (1)  $ \sum_{k=1}^{\infty}(-1)^{k-1}\frac{z^{4k-1}}{(4k-1)(2k-1)!} $,  $ \sum_{k=0}^{\infty}(-1)^{k}\frac{z^{4k+1}}{(4k+1)(2k)!} $

<!-- page: 344 -->

(2)  $ \frac{2}{\sqrt{\pi}}\sum_{k=0}^{\infty}(-1)^k\frac{z^{2k+1}}{(2k+1)k!} $ (3)  $ \sum_{k=1}^{\infty}(-1)^{k-1}\frac{z^{2k-1}}{(2k-1)(2k-1)!} $

 $$ 2k\pi\mathrm{i}+\sum_{k=1}^{\infty}(-1)^{k-1}\frac{z^{k}}{k}\quad(\mid z\mid<1) $$ 

6. (1) 4 级 (2) 15 级

 $ ^{*}7.\ \frac{z(1+z)}{(1-z)^{3}} $

 $ ^{*} $8.  $ \ln(1-\mathrm{e}^{-t})\sin h t+\frac{1}{2}+\frac{\mathrm{e}^{-t}}{4} $

##### 习题3.4

1. (1) 对于 $0 < |z| < 1$, $\frac{1}{z^2} - 2\sum_{k=0}^{\infty} z^{k-2}$; 对于 $1 < |z| < \infty$, $\frac{1}{z^2} + 2\sum_{k=0}^{\infty} \frac{1}{z^{k+3}}$

(2) $2\sum_{k=1}^{\infty}(-1)^k \frac{1}{z^{2k}} - \sum_{k=0}^{\infty} \frac{z^k}{2^{k+1}}$

(3) $\sum_{k=0}^{\infty} c_k z^k + \sum_{k=1}^{\infty} c_{-k} z^{-k}$ 其中 $c_k = c_{-k} = \sum_{n=0}^{\infty} \frac{1}{n!(n+k)!}$ ($k=0,1,2,\cdots$)

(4) $\sum_{k=0}^{\infty} c_{2k} z^{2k} + \sum_{k=1}^{\infty} c_{-2k} z^{-2k}$ 其中 $c_{2k} = c_{-2k} = (-1)^k \sum_{n=0}^{\infty} \frac{1}{(2n+1)!(2n+2k+1)!}$ ($k=0,1,2,\cdots$)

2. (1) $\sum_{k=0}^{\infty}(-1)^k (k+1)\frac{(z-i)^{k-2}}{(2i)^{k+2}}$ ($0 < |z-i| < 2$)

(2) $(z-1)^2 \sum_{k=0}^{\infty}(-1)^k \frac{1}{k!} \frac{1}{(z-1)^k}$ ($0 < |z-1| < \infty$)

(3) $\frac{(-1)^k}{a^k} \sum_{n=0}^{\infty}\binom{n+k-1}{k-1}\left(\frac{z}{a}\right)^n$ ($|z| < a$)

(4) $\frac{1}{2} + z + z^2 + \sum_{k=1}^{\infty}\frac{1}{(k+2)!z^k}$ ($0 < |z| < \infty$)

(5) $-\sum_{k=0}^{\infty}\frac{\sin\left(1+\frac{k\pi}{2}\right)}{k!(z-1)^k}$ ($0 < |z-1| < \infty$)

(6) $\sum_{n=-\infty}^{\infty} J_n(a)\left(\frac{z}{a}\right)^n (0 < |z| < \infty)$ 其中 $J_m(a) = \begin{cases} \sum_{k=0}^{\infty}\frac{(-1)^k}{k!(k+m)!}\left(\frac{a}{2}\right)^{2k+m}, & m=0,1,2,\cdots \\ \sum_{k=-m}^{\infty}\frac{(-1)^k}{k!(k+m)!}\left(\frac{a}{2}\right)^{2k+m}, & m=-1,-2,\cdots \end{cases}$

3. $|z|<a$ : $\frac{1}{b-a}\sum_{k=0}^{\infty}\frac{b^{k+1}-a^{k+1}}{a^{k+1}b^{k+1}}z^k$

$0 < |z-a| < |b-a| : \frac{1}{a-b}\left[\frac{1}{z-a} + \sum_{k=0}^{\infty}\frac{(z-a)^k}{(b-a)^{k+1}}\right]$

$|a|<z|<b|, \frac{1}{z-b}\sum_{k=0}^{\infty}\left(\frac{z^k}{z^{k+1}} + \frac{d^k}{z^{k+1}}\right)$

5. (1)  $ \sum_{k=0}^{\infty}z^{k-1} $ (2)  $ -\sum_{k=0}^{\infty}\frac{1}{z^{k+2}} $ (3)  $ \sum_{k=-1}^{\infty}(-1)^k(z-1)^k $ (4)  $ \sum_{k=2}^{\infty}(-1)^{k-1}\frac{1}{(z-1)^k} $

<!-- page: 345 -->

(5)  $ \sum_{k=0}^{\infty}\left[-1+\frac{1}{2^{k+1}}\right](z+1)^k $ (6)  $ \sum_{k=0}^{\infty}\frac{1}{(z+1)^{k+1}}+\frac{1}{2}\sum_{k=0}^{\infty}\left(\frac{z+1}{2}\right)^k $

(7)  $ \sum_{k=0}^{\infty}(1-2^k)\frac{1}{(z+1)^{k+1}} $

##### 习题3.5

4.（1）z=0 为一阶极点， $ z=\pm2i $ 为二阶极点

(2) $ z=1 $ 为二阶极点， $ z=\infty $ 为三阶极点

(3) $ z=k\pi-\frac{\pi}{4}\quad(k=0,\pm1,\cdots) $ 各为一阶极点； $ z=\infty $ 为非孤立奇点

(4) $ z=(2k+1)\pi i\quad(k=0,\pm1,\cdots) $ 各为一阶极点； $ z=\infty $ 为非孤立奇点

(5) $ z=\left(k+\frac{1}{2}\right)\pi $  $ (k=0,\pm1,\cdots) $ 各为二阶极点； $ z=\infty $ 为非孤立奇点

(6) $ z=\infty $为二阶极点

(7) $ z=-1 $为一阶极点， $ z=\infty $为可去奇点

(8) $ z=\pm i $为一阶极点， $ z=\infty $为本性奇点

(9) $ z=\infty $为本性奇点

(10) z=0 为本性奇点,  $ z=\infty $ 为一阶极点

(11)  $ z = \frac{1}{k\pi} (k = \pm 1, \pm 2, \cdots) $ 为本性奇点, z = 0 为非孤立奇点,  $ z = \infty $ 为本性奇点

(12) z = -2 为二阶极点，z = 2 为非孤立奇点， $ z = \infty $ 为三阶极点， $  z = \frac{1}{(k+1/2)\pi} + 2  $ 为一阶极点

5.（1）对一支为正则点，对另一支为二阶极点

（2）对一支为一阶极点，对另外五支为正则点

（3）对一支为正则点，对另一支为本性奇点

（4）对两支都为一阶极点

6. (1) 当  $ m \neq n $ 时为  $ \max(m, n) $ 阶极点，当 m = n 时为 k 阶极点 ( $ k \leq m $) 或可去奇点或零点

(2) $ m+n $ 阶极点

（3）当 m>n 时为 m-n 阶极点，m<n 时为 n-m 阶零点，m=n 时为可去奇点

7.（1）能（2）能（3）否（4）否

##### 习题4.1

4.  $ F(z)=\frac{1}{(z-1)(z-2)} $

习题4.2

3. (1) 6 (2)  $ \frac{1}{2^7}6! $ (3)  $ \Gamma(1-\alpha)\cos\frac{\alpha\pi}{2} $ (4)  $ \Gamma(1-\alpha)\sin\frac{\alpha\pi}{2} $

(5)  $ \Gamma(\alpha)\cos\alpha\theta $ (6)  $ \Gamma(\alpha)\sin\alpha\theta $

4.  $ \frac{(2n)!}{2^{2n}(n!)^2} $

 $$ *5.\ \frac{\pi^{2}}{2} $$

<!-- page: 346 -->

##### 习题4.3

3. (1)  $ 2^{2n+1}B(n+1,n+1)=2^{2n+1}\frac{(n!)^2}{(2n+1)!} $ (2)  $ 2^{p+q+1}B(p+1,q+1) $

(3)  $ \frac{1}{2}B\left(\frac{1-\alpha}{2},\frac{1+\alpha}{2}\right)=\frac{\pi}{2\cos\frac{\alpha\pi}{2}} $

##### 习题5.1

1. (1)  $ \pm\frac{1}{4},0 $ (2) 1,-1 (3)  $ \frac{1}{2} $ (4)  $ (-1)^{k-1}\frac{(2k+1)}{2}\pi $

(5)  $ -\sum_{k=0}^{\infty}\frac{(-1)^{k}}{k!(k+1)!}\left(\frac{a}{2}\right)^{2k+1}=-\mathrm{J}_{1}(a),\mathrm{J}_{1}(a) $ 为一阶贝塞尔函数（见第三篇）

(6) $ (-1)^{n}\frac{1}{n!} $

2. (1)  $ \mathrm{resf}(-1)=(-1)^{m+1}\frac{(2m)!}{(m-1)!(m+1)!} $,  $ \mathrm{resf}(\infty)=(-1)^m\frac{(2m)!}{(m-1)!(m+1)!} $

 $$ \mathrm{resf}(0)=\frac{1}{9},\mathrm{resf}(\pm3\mathrm{i})=-\frac{1}{54}(\sin3\mp\mathrm{i}\cos3),\mathrm{resf}(\infty)=\frac{1}{27}(\sin3-3) $$ 

(3)  $ \mathrm{resf}(-1)=2\sin2,\mathrm{resf}(\infty)=-2\sin2 $ (4)  $ \mathrm{resf}(2)=-\mathrm{resf}(\infty)=-\frac{143}{24} $

(5)  $ \mathrm{resf}(\infty)=0 $ (6)  $ \mathrm{resf}(0)=-\frac{1}{2} $,  $ \mathrm{resf}(\infty)=\frac{1}{2} $

3. (1)  $ -\frac{\pi i}{\sqrt{2}} $ (2)  $ -2\pi i $ (3)  $ -\frac{\pi i}{121} $ (4)  $ 1 $

 $ ^{*} $5.  $ \frac{i\pi}{2} $

##### 习题5.2

1. (1)  $ \sqrt{2}\pi $ (2)  $ \frac{\pi}{\mu} e^{-r\mu} $ (3)  $ \frac{\pi \exp(-a/\sqrt{2})}{2\sqrt{2}} \left( \cos \frac{a}{\sqrt{2}} + \sin \frac{a}{\sqrt{2}} \right) $ (4)  $ \frac{\pi}{2} e^{-ab} $

2. (1)  $ \frac{2\pi}{1-b^2} $ (2)  $ \sqrt{2}\pi $ (3)  $ \frac{\pi}{2\sqrt{a(a+1)}} $ (4)  $ \frac{\pi}{2\sqrt{2}} $

 $ ^{*} $5. (1)  $ \frac{\pi^{2}}{6} $ (2)  $ \frac{\pi^{4}}{15} $

 $ ^{*} $6. (1)  $ \pi $ (2)  $ \frac{\pi}{2} $

 $$ \pi^{1/2} $$ 

 $ ^{*}8.\frac{1}{\cos(\alpha/2)} $

 $ ^{*}10.\ (1)\ 2\pi(a^{2}-1)^{-1/2}\ (2)-2\pi i(1-a_{0}^{2})^{-1/2} $

11. 当  $ |a| > |b| $ 时，I = 0；当  $ |a| < |b| $ 时， $ I = \frac{2\pi}{b} $

##### 习题5.3

3. (1)  $ -\frac{\pi}{2} $ (2)  $ -\frac{\pi}{2} $

<!-- page: 347 -->

4. (1)  $ \frac{\pi}{2}\left(1-\frac{3}{2\mathrm{e}}\right) $ (2)  $ \frac{\pi}{2a^{2}}(1-\mathrm{e}^{-a}) $ * (3)  $ \frac{3}{4}\pi $

(4) $ \frac{b-a}{2}\pi $ (5) $ \frac{\pi}{2}\mathrm{e}^{-4}(2\cos2+\sin2) $ (6) $ \frac{\pi}{2}\mathrm{e}^{-4}(-\cos2+2\sin2) $

5.  $ *(1) $  $ \frac{\pi}{\sin a\pi} $ (2)  $ \frac{\pi\sin(b-a)\pi}{\sin a\pi\sin b\pi} $ (3)  $ \frac{\pi}{2} $ th  $ \frac{\pi}{2} $ (4)  $ \frac{\pi}{2}\frac{1}{\cosh\frac{m\pi}{2}} $

7.  $ *\frac{1}{2}\pi^{2}R^{4} $

##### 习题5.4

1. (1)  $ \pi $ (2)  $ \frac{\pi}{2} $

2. (1)  $ -\frac{\pi}{\sqrt{3}} $ (2)  $ \frac{\pi(1-\alpha)}{4\cos\frac{\pi\alpha}{2}} $ (3)  $ -\frac{\pi}{4} $ (4)  $ -\frac{7}{128}\pi^{4} $

3. (1)  $ \sqrt{\frac{\pi}{2}} $ (2)  $ \frac{\pi}{4} $

 $ ^{*} $4.  $ \frac{\pi}{\sqrt{2}} $

 $ ^{*} $5.  $ \frac{\pi^{2}}{2\sqrt{2}} $

### 第 二 篇

##### 习题6.2

6.  $ u_{tt}=\frac{1}{2}\omega^{2}\frac{\partial}{\partial x}[(l^{2}-x^{2})u_{x}] $ （以水平线为 x 轴，原点取在竖轴上）

7.  $ u_{tt}=g\frac{\partial}{\partial x}[(l-x)u_{x}]+\omega_{x}^{2}u $ （以绳的上端为原点，沿竖直轴取 x 轴向下）

##### 习题6.3

1.  $ \left\{\begin{aligned}u|_{x=0}=0\\ u|_{x=l}=0\end{aligned}\right.\quad\left\{\begin{aligned}u|_{t=0}=\varphi(x)\\ u_{t}|_{t=0}=\psi(x)\end{aligned}\right. $

2.  $ \left\{\begin{aligned}u_{u}&=a^{2}u_{xx},&x\geqslant0,t>0\\ u|_{x=0}&=A\sin\omega t,&t>0\\ u|_{t=0}&=\varphi(x),&u_{t}|_{t=0}=\psi(x),&x\geqslant0\end{aligned}\right. $

3.  $ \left\{\begin{aligned}u_{x}|_{x=0}=&\frac{F(t)}{ES}\\ u_{x}|_{x=l}=&\frac{F(t)}{ES}\end{aligned}\right.\quad\left(\begin{aligned}E& 为杨氏模量 \\ S& 为杆的横截面积\end{aligned}\right) $

4.  $ -u_{x}|_{x=0}=u_{x}|_{x=l}=\frac{q_{0}}{k} $ （k为热导率）

5.  $ \left\{\begin{array}{l} u|_{x=0}=0, u_{x}|_{x=l}=0 \\ u|_{t=0}=\frac{b}{l}x, u_{t}|_{t=0}=0 \end{array}\right. $

<!-- page: 348 -->

6. 两端受压： $ \left\{\begin{aligned}u|_{t=0}&=\varepsilon(l-2x)\\ u_{t}|_{t=0}&=0\end{aligned}\right. $，一端受压： $ \left\{\begin{aligned}u|_{t=0}&=-2\varepsilon x\\ u_{t}|_{t=0}&=0\end{aligned}\right. $

 $$ \begin{align*}7.\begin{cases}u_{t}^{\mathrm{I}}=&\frac{k_{1}}{c_{1}\rho_{1}}u_{xx}^{\mathrm{I}}\quad(0<x<x_{0})\\u^{\mathrm{I}}(0,t)=0\\u^{l}(x,0)=&u_{0}\end{cases},&\begin{cases}u_{t}^{\mathrm{II}}=&\frac{k_{2}}{c_{2}\rho_{2}}u_{xx}^{\mathrm{II}}\quad(x_{0}<x<l)\\u^{\mathrm{II}}(l,t)=&0\\u^{\mathrm{II}}(x,0)=&u_{0}\end{cases}\end{align*} $$ 

连接条件： $ \left\{\begin{aligned}u^{\mathrm{I}}\mid_{x_{0}-0}=u^{\mathrm{II}}\mid_{x_{0}+0}\\ k_{\mathrm{I}}\frac{\partial u^{\mathrm{I}}}{\partial x}\bigg|_{x_{0}-0}=k_{2}\frac{\partial u^{\mathrm{II}}}{\partial x}\bigg|_{x_{0}+0}\end{aligned}\right. $

 $$ \left.u\right|_{t=0}\!=\!\left\{\begin{aligned}{}&{{}\frac{F_{0}(l\!-\!h)}{T_{0}l}x}&{(0\leqslant x\leqslant h)}\\ {}&{{}\frac{F_{0}h}{T_{0}l}(l\!-\!x)}&{(h\leqslant x\leqslant l)}\\ \end{aligned}\right. $$ 

*9. (1)  $ \begin{cases} u|_{x=0}=0 \\ u_x|_{x=l+b}=-\dfrac{P}{ESg}u_{tt}(l+b,t) \end{cases} $ (2)  $ \begin{cases} u|_{x=0}=0 \\ P\left[1-\dfrac{1}{g}u_{tt}(l,t)\right] \\ u_x|_{x=l}=\dfrac{ES}{ }\end{cases} $

(E为杨氏模量，S为杆的横截面积)

##### 习题7.1

1. (1)  $ t $ (2)  $ \sin x \cos at + x^2 t + \frac{1}{3} a^2 t^3 $ (3)  $ x^3 + 3a^2 xt^2 + xt $ (4)  $ \cos x \cos at + t / e $

 $$ \varphi(x-at) $$ 

3.  $ \varphi\left(\frac{x-t}{2}\right)+\psi\left(\frac{x+t}{2}\right)-\varphi(0) $

 $$ V(x,t)=A\cos k(x-at),I(x,t)=\sqrt{\frac{C}{L}}A\cos k(x-at) $$ 

5.  $ \frac{1}{x}[f_1(x+at)+f_2(x-at)] $

 $$ \begin{array}{r l}&{6.\ \frac{(h-x-a t)\varphi(x+a t)+(h-x+a t)\varphi(x-a t)}{2(h-x)}+\frac{1}{2a(h-x)}\int_{x-a t}^{x+a t}(h-\xi)\psi(\xi)\mathrm{d}\xi}\end{array} $$ 

7. (1)  $ f(3x+y)+g(x-y) $ (2)  $ f(x+y)+g(y) $

8.  $ \frac{1}{4}\sin(y+x)+\frac{3}{4}\sin(-y/3+x)+y^{2}/3+xy $

10.  $ u(x,t)=\left\{\begin{aligned}&\frac{1}{2}\left[\varphi(x+at)+\varphi(x-at)\right]+\frac{1}{2a}\int_{x-at}^{x+at}\psi(a)\mathrm{d}\alpha\quad\left(t\leqslant\frac{x}{a}\right)\\&\frac{1}{2}\left[\varphi(x+at)-\varphi(at-x)\right]+\frac{1}{2a}\int_{at-x}^{x+at}\psi(a)\mathrm{d}\alpha\quad\left(t\geqslant\frac{x}{a}\right)\end{aligned}\right. $

 $ t \leqslant \frac{x}{a} $ 时，端点影响未传到； $ t \geqslant \frac{x}{a} $ 时，端点影响已传到，产生反射波

11.  $ u(x,t)=\begin{cases}0 & \left(t\leqslant\frac{x}{a}\right)\\A\sin\omega\left(t-\frac{x}{a}\right) & \left(t>\frac{x}{a}\right)\end{cases} $

<!-- page: 349 -->

$$ u(x,t)=\left\{\begin{aligned}&\frac{1}{2}\big[\varphi(x+at)+\varphi(x-at)\big]+\frac{1}{2a}\int_{x-at}^{x+at}\psi(a)\mathrm{d}a\quad\left(t\leqslant\frac{x}{a}\right)\\ &\frac{1}{2}\big[\varphi(x+at)+\varphi(at-x)\big]+\frac{1}{2a}\int_{0}^{x+at}\psi(a)\mathrm{d}a\\ &\quad+\frac{1}{2a}\int_{0}^{at-x}\psi(a)\mathrm{d}a+\frac{A a}{\omega E S}\Big[\cos\omega\Big(t-\frac{x}{a}\Big)-1\Big]\quad\left(t>\frac{x}{a}\right)\end{aligned}\right. $$ 

(E为杨氏模量，S为杆的横截面积)

13. 反射波:  $  g \left( t + \frac{n_{1} x}{a} \right) = \left\{ \begin{aligned} & 0 & \left( t + \frac{n_{1} x}{a} < 0, x < 0 \right) \\ &\frac{n_{1} - n_{2}}{n_{1} + n_{2}} E_{0} \sin \omega \left( t + \frac{n_{1} x}{a} \right) & \left( t + \frac{n_{1} x}{a} > 0, x > 0 \right) \\ &0 & \left( t < \frac{n_{2} x}{a}, x > 0 \right) \\ &\frac{2n_{1} E_{0}}{n_{1} + n_{2}} \sin \left( t - \frac{n_{2} x}{a} \right) & \left( t > \frac{n_{2} x}{a}, x > 0 \right) \end{aligned} \right. $

##### 习题7.2

1. (1)  $ \frac{xt^{2}}{2} + \frac{at^{3}}{6} $ (2)  $ -4y^{2} $

2. (1)  $ t\sin x $ (2)  $ \sin x\cos y + xy - \frac{y^2}{2} $ (3)  $ 3at + \frac{1}{2}axt^2 $ (4)  $ \sin x\cos at + (e^t - 1)(xt + x) - xte^t $

习题 7.3

 $$ S(r,t)=\left\{\begin{aligned}&0,&0\leqslant&t<r-R\\ &\frac{S_{0}(r-t)}{2r},&r-R<&t<r+R\\ &0,&r+&R<t<\infty\end{aligned}\right. $$ 

 $$ x^{2}t+\frac{1}{3}a^{2}t^{3}+y z t $$ 

5.  $ x^{2}(x+y)+a^{2}t^{2}(3x+y) $

##### 习题8.1

 $$ \sum_{n=1}^{\infty}\left[\frac{2}{l}\int_{0}^{l}\varphi(\alpha)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha\right]\mathrm{e}^{-\left(\frac{\pi r}{l}\right)^{2}D t}\sin\frac{n\pi x}{l} $$ 

 $$ \begin{array}{r}{\frac{a_{0}}{2}+\displaystyle\sum_{n=1}^{\infty}a_{n}\mathrm{e}^{-(\frac{n\pi}{l})^{2}D t}\cos\frac{n\pi x}{l},\quad a_{n}=\frac{2}{l}\int_{0}^{l}\varphi(\alpha)\cos\frac{n\pi\alpha}{l}\mathrm{d}\alpha(n=0,1,\cdots)}\end{array} $$ 

 $$ \sum_{n=0}^{\infty}a_{n}\mathrm{e}^{\frac{\left(n+\frac{1}{2}\right)^{2}\pi^{2}}{l^{2}}D_{t}}\sin\frac{n+\frac{1}{2}}{l}\pi x,\quad a_{n}=\frac{2}{l}\int_{0}^{l}\varphi(a)\sin\frac{n+\frac{1}{2}}{l}\pi a\mathrm{d}a $$ 

2.  $ \sum_{n=1}^{\infty}\frac{8h}{n^{2}\pi^{2}}\sin\frac{n\pi}{2}\cos\frac{n\pi a}{2}t\sin\frac{n\pi x}{2} $

3. (1)  $ 3\cos\alpha\sin x $

 $$ \sum_{n=1}^{\infty}\frac{6}{\pi}\left(\frac{2}{2n-1}\right)^{2}\left\lbrack\pi^{2}-\frac{8}{(2n-1)^{2}}\right\rbrack\sin\frac{2n-1}{2}\pi\cos\frac{(2n-1)}{2}at\sin\frac{(2n-1)}{2}x $$

<!-- page: 350 -->

(3)

 $$ N_{0}-\frac{4N_{0}}{\pi}\sum_{k=0}^{\infty}\frac{1}{(2k+1)}\mathrm{e}^{-4(2k+1)^{2}\pi^{2}}\sin(2k+1)\pi x $$ 

 $$ \mathrm{(4)}\sum_{n=1}^{\infty}\frac{4\left[1-(-1)^{n}\right]}{(n\pi)^{3}\operatorname{sh}n\pi}\operatorname{s i n}n\pi x\operatorname{s h}n\pi(y-1) $$ 

4.  $ \sum_{n=1}^{\infty}a_{n}T(t)\sin\frac{n\pi x}{l} $，其中 $ a_{n}=\frac{2}{l}\int_{0}^{l}g(x)\sin\frac{n\pi x}{l}dx $

 $$ T_{n}(t){=}\left\{\begin{aligned}{}&{{}\frac{2\mathrm{e}^{-a t/2}}{\sqrt{a^{2}-a}}\operatorname{s h}\frac{\sqrt{a^{2}-a}}{2}t}&{(a^{2}>a)}\\ {}&{{}t\mathrm{e}^{-a t/2}}&{(a^{2}=a)}\\ {}&{{}\frac{2\mathrm{e}^{-a t/2}}{\sqrt{a-a^{2}}}\operatorname{s i n}\frac{\sqrt{a-a^{2}}}{2}t}&{(a^{2}<a)}\\ \end{aligned}\right. $$ 

 $$ \alpha=\left(\frac{2cn\pi}{l}\right)^{2} $$ 

5.  $ \frac{8Ql}{E\sigma\pi^{2}}\sum_{n=0}^{\infty}\frac{(-1)^{n}}{(2n+1)^{2}}\cos\frac{\left(n+\frac{1}{2}\right)\pi a}{l}t\sin\frac{\left(n+\frac{1}{2}\right)\pi}{l}x $ （E为杨氏模量； $ \sigma $为杆的横截面积）

7.  $ \sin\pi x\sin\pi y\sin\pi z\cos\sqrt{3}\pi at $


 $$ u_{0}-\frac{4u_{0}}{\pi}\sum_{n=0}^{\infty}\frac{1}{(2n+1)}\mathrm{e}^{-\frac{(2n+1)^{2}}{4t^{2}}\pi^{2}a^{2}t}\sin\frac{2n+1}{2l}\pi x $$ 

 $$ \sum_{n=1}^{\infty}\left(A_{n}\cos\frac{n^{2}\pi^{2}a}{l}t+B_{n}\sin\frac{n^{2}\pi^{2}a}{l}t\right)\sin\frac{n\pi}{l}x, 其中 \left\{\begin{aligned}A_{n}&=\frac{2}{l}\int_{0}^{l}\varphi(\alpha)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha\\ B_{n}&=\frac{2l}{n^{2}\pi^{2}a}\int_{0}^{l}\varphi(\alpha)\sin\frac{n\pi\alpha}{l}\mathrm{d}\alpha\end{aligned}\right. $$ 


 $$ \begin{align*}u(x,y,t)&=\frac{16A b^{4}}{\pi^{6}}\sum_{n=0}^{\infty}\sum_{m=0}^{\infty}\frac{1}{(2n+1)^{3}(2m+1)^{3}}\bullet\sin\frac{(2n+1)\pi x}{b}\sin\frac{(2m+1)\pi y}{b}\\&\quad\bullet\cos\left[\sqrt{(2n+1)^{2}+(2m+1)^{2}}\frac{\pi at}{b}\right]\end{align*} $$ 


 $$ E_{n}=\frac{n^{2}\pi^{2}\hbar^{2}}{8a^{2}\mu},n=1,2,3,\cdots;\quad\psi(x,t)=\frac{1}{\sqrt{a}}\mathrm{e}^{-\mathrm{i}\frac{E_{2}}{\hbar}t}\sin\frac{\pi}{a}(x+a) $$ 


 $$ V(x,y,z)=\sum_{n,m=1}^{\infty}A_{nm}\sin(\alpha_{n}x)\sin(\beta_{m}y)\sinh(\gamma_{nm}z) $$ 

 $$  其中 A_{nm}=\frac{4}{a b\sinh(\gamma_{nm}C)}\int_{0}^{a}\mathrm{d}x\int_{0}^{b}\mathrm{d}y f(x,y)\sin(\alpha_{n}x)\sin(\beta_{m}y) $$ 

 $$ a_{n}=\frac{n\pi}{a},\beta_{m}=\frac{m\pi}{b},\gamma_{mn}=\pi\sqrt{\frac{n^{2}}{a^{2}}+\frac{m^{2}}{b^{2}}} $$ 

13. 一般解为： $ u(x,t)=\sum_{n=1}^{\infty}(C_{n}\cos\omega_{n}t+D_{n}\sin\omega_{n}t)\sin\frac{n\pi}{l}x $ 其中  $ \omega_{n}=\sqrt{\left(\frac{n\pi a}{l}\right)^{2}+c} $

 $$ C_{n}=\frac{2}{l}\int_{0}^{l}\varphi(x)\sin\frac{n\pi}{l}x\mathrm{d}x,D_{n}=\frac{b}{\omega_{n}}C_{n}+\frac{2}{l\omega_{n}}\int_{0}^{l}\psi(x)\sin\frac{n\pi}{l}x\mathrm{d}x $$ 

##### 习题8.2

 $$ \mathbf{1}.u(x,t)=\sum_{n=1}^{\infty}\left\{\frac{2T_{0}}{n\pi}\left[1-(-1)^{n}\right]\mathrm{e}^{-\left(\frac{n\pi u}{l}\right)^{2}t}-\frac{2A}{a^{2}n\pi}\frac{\left[1-(-1)^{n}\mathrm{e}^{-u l}\right]}{a^{2}+\left(\frac{n\pi}{l}\right)^{2}}\left[\mathrm{e}^{-\left(\frac{n\pi u}{l}\right)^{2}t}-1\right]\right\}_{\substack{\mathrm{f}}}\sin\frac{n\pi}{l}x $$

<!-- page: 351 -->

$$ 2.\frac{b l t^{3}}{12\rho}+\frac{2b l^{3}}{\rho a^{2}\pi^{4}}\sum_{n=1}^{\infty}\frac{(-1)^{n}-1}{n^{4}}\left[t-\frac{l}{n\pi a}\sin\frac{n\pi a}{l}t\right]\cos\frac{n\pi x}{l}+\frac{l}{2}t+\frac{2l^{2}}{a\pi^{3}}\sum_{n=1}^{\infty}\frac{1-(-1)^{n}}{n^{3}}\sin\frac{n\pi a}{l}t\cos\frac{n\pi x}{l}, $$ 

其中 $ \rho $为弦密度，a为波传播速度

3. (1)

 $$ \sum_{n=1}^{\infty}\frac{2A(-1)^{n}}{a^{2}}\left(\frac{l}{n\pi}\right)^{3}\left\lbrack\cos\frac{n\pi a}{l}t-1\right\rbrack\sin\frac{n\pi}{l}x $$ 

 $$ \sum_{n=0}^{\infty}\frac{2A}{\left(n+\frac{1}{2}\right)\pi}\bullet\frac{\left[\frac{\left(n+\frac{1}{2}\right)}{l}\pi a\right]^{2}\sin\omega t-\omega\cos\omega t+\omega\mathrm{e}^{\frac{\left(n+\frac{1}{2}\right)^{2}\pi^{2}a^{2}t}{l}}}{\left[\frac{\left(n+\frac{1}{2}\right)\pi a}{l}\right]^{4}+\omega^{2}}\bullet\sin\frac{\left(n+\frac{1}{2}\right)\pi}{l}x $$ 

(2)

(3)

 $$ \begin{aligned}3)\ &\frac{4A a^{2}}{\pi^{3}}\sum_{k=0}^{\infty}\frac{1}{(2k+1)^{3}}\bullet\frac{\mathrm{sh}\Big[(2k+1)\pi\frac{y}{a}\Big]+\mathrm{sh}\Big[(2k+1)\pi\frac{b-y}{a}\Big]-\mathrm{sh}\Big[(2k+1)\pi\frac{b}{a}\Big]}{\mathrm{sh}\Big[(2k+1)\pi\frac{b}{a}\Big]}\\ &\bullet\sin\frac{(2k+1)}{a}\pi x\end{aligned} $$ 

 $$ (4)\frac{A}{1+\omega^{2}a^{2}}\Big(\mathrm{e}^{-t}-\cos\omega a t+\frac{1}{\omega a}\sin\omega a t\Big)\cos\omega x,\quad\omega=\frac{\pi}{2l} $$ 

 $$ \mathbf{5}.~{\frac{4I^{2}r}{c\rho\pi}}\sum_{n=0}^{\infty}{\frac{\sin{\frac{2n+1}{l}\pi x}}{(2n+1)\left[{\frac{(2n+1)^{2}\pi^{2}a^{2}}{l^{2}}}+{\frac{h}{c\rho}}\right]}}\bullet\{1-\mathrm{e}^{-\left[{\frac{(2n-1)^{2}\pi^{2}a^{2}}{l^{2}}}+{\frac{h}{c\rho}}\right]t}\} $$ 

##### 习题8.3

 $$ \mathbf{1}.\frac{Q}{E}x+\frac{8Q l}{E\pi^{2}}\sum_{n=0}^{\infty}\frac{(-1)^{n+1}}{(2n+1)^{2}}\cos\frac{\left(n+\frac{1}{2}\right)\pi a}{l}t\sin\frac{\left(n+\frac{1}{2}\right)\pi a}{l}x $$ 

 $$ \begin{array}{r l}{\mathbf{2}.}&{-\frac{2c l^{2}}{a^{2}\pi^{3}}\displaystyle\sum_{n=1}^{\infty}\frac{1}{n^{3}}(1-\mathrm{e}^{-\frac{n^{2}\pi^{2}a^{2}}{l^{2}}}t)\sin\frac{n\pi}{l}x+\frac{c t}{l}(l-x)}\end{array} $$ 

3.  $ u(x,t)=v(x,t)+w(x,t) $，其中

 $$ \begin{align*}v(x,t)&=\frac{2\omega A l}{a\pi^{2}}\sum_{n=1}^{\infty}\frac{(-1)^{n}}{n^{2}}\sin\frac{n\pi a}{l}t\sin\frac{n\pi x}{l}\\&\quad+\frac{2\omega^{2}A}{a\pi^{2}}\sum_{n=1}^{\infty}\frac{(-1)^{n}}{n^{2}\left[\omega^{2}-\left(\frac{n\pi a}{l}\right)^{2}\right]}\left(n\pi a\sin\omega t-\omega l\sin\frac{n\pi}{l}a t\right)\sin\frac{n\pi}{l}x\end{align*} $$ 

 $$ w(x,t)=\frac{A x}{l}\sin\omega t $$ 

 $$ u(x,t)=x+\frac{4}{a^{2}}\cos\frac{x}{2}+\left(1-\frac{4}{a^{2}}\right)\exp\left(\frac{a^{2}}{4}t\right)\cos\frac{x}{2} $$ 

##### 习题8.4

 $$ u(\rho,\varphi)=\left\{\begin{aligned}&\frac{A}{a}\rho\cos\varphi\quad(\rho<a)\\ &\frac{Aa}{\rho}\cos\varphi\quad(\rho>a)\end{aligned}\right. $$ 

2.  $ \sum_{n=1}^{\infty}A_{n}\rho^{\frac{n\pi}{\beta-\alpha}}\sin\frac{n\pi}{\beta-\alpha}(\varphi-\alpha) $，其中 $ A_{n}=\frac{2}{\beta-\alpha}\cdot\alpha^{\frac{-n\pi}{\beta-\alpha}}\int_{\alpha}^{\beta}f(\varphi)\sin\frac{n\pi(\varphi-\alpha)}{\beta-\alpha}\mathrm{d}\varphi $

<!-- page: 352 -->

$ ^{*} $3.

 $$ a^{2}-\rho^{2} $$ 

 $$ u(r,\varphi)=-E_{0}r\cos\varphi+E_{0}\frac{a^{2}}{r}\cos\varphi $$ 

5.  $ u = \frac{r_1}{r_1^2 - r_2^2} \cdot \frac{r^2 - r_2^2}{r} \cdot \sin\theta $

 $$ u(r,\varphi)=\frac{u_{1}+u_{2}}{2}+\frac{2(u_{1}-u_{2})}{\pi}\sum_{n=0}^{\infty}\left(\frac{r}{a}\right)^{2n+1}\cdot\frac{\sin(2n+1)\varphi}{2n+1} $$ 

 $$ {}^{*}\mathbf{8}. \quad \frac{\cos2\varphi}{a^{4}+b^{4}}\bigg[(a^{4}+b^{4})\rho^{4}-(a^{6}+2b^{6})\rho^{2}-(a^{2}-2b^{2})\frac{a^{4}b^{4}}{\rho^{2}}\bigg] $$ 

 $$ \bullet \quad u_{1}+\frac{4(u_{0}-u_{1})}{\pi}\sum_{k=0}^{\infty}\frac{1}{2k+1}\Big(\frac{\rho}{a}\Big)^{2k+1}\sin(2k+1)\varphi $$ 

 $$ \frac{q}{\pi H}+\frac{q}{2(k+Ha)}\sin\varphi+\frac{2q}{\pi}\sum_{n=1}^{\infty}\frac{\rho^{2n}\cos^{2}n\varphi}{a^{2n-1}(2kn+Ha)(1-4n^{2})} $$ 

##### 习题9.1

 $$ \left\{\begin{aligned}&\pi,&&\left|\omega\right|<a\\ &\frac{\pi}{2},&&\left|\omega\right|=a\\ &0,&&\left|\omega\right|>a\end{aligned}\right.(2)\sqrt{\frac{\pi}{\eta}}\mathrm{e}^{\frac{\omega^{2}}{-4\eta}} $$ 

 $$ -\sqrt{\frac{\pi}{\eta}}\sin\left(\frac{\omega^{2}}{4\eta}-\frac{\pi}{4}\right),\quad\sqrt{\frac{\pi}{\eta}}\cos\left(\frac{\omega^{2}}{4\eta}-\frac{\pi}{4}\right) $$ 

(4)  $ \frac{2a}{a^{2}+\omega^{2}} $ (5)  $ -\frac{\mathrm{i}\omega}{2a}\sqrt{\frac{\pi}{a}}\mathrm{e}^{-\frac{\omega^{2}}{4a}} $

3.  $ \frac{a(b-a)}{\pi b[x^{2}+(b-a)^{2}]} $

5.  $ \frac{C}{2\pi}\int_{-\infty}^{\infty}e^{\frac{\omega^{3}}{3}+i\omega x}d\omega $

 $ ^{*} $9.  $ asin(at) $

 $ ^{*} $10. (1) 当  $ t \leqslant -\tau $ 时,  $ x(t) = 0 $

(2) 当  $ |t| < \tau $ 时,  $ x(t) = f_{0}\left[\frac{\mathrm{e}^{\mathrm{i}\omega_{1}(t-\tau)}}{(\omega_{2}-\omega_{1})\omega_{1}} + \frac{\mathrm{e}^{\mathrm{i}\omega_{2}(t+\tau)}}{(\omega_{1}-\omega_{2})\omega_{2}} - \frac{1}{\omega_{1}\omega_{2}}\right] $

(3) 当  $ t \geqslant \tau $ 时， $ x(t) = f_{0}\left[\frac{\mathrm{e}^{\mathrm{i}\omega_{1}(t-\tau)}}{\omega_{1}(\omega_{2}-\omega_{1})} + \frac{\mathrm{e}^{\mathrm{i}\omega_{2}(t+\tau)}}{\omega_{2}(\omega_{2}-\omega_{1})} - \frac{\mathrm{e}^{\mathrm{i}\omega_{1}(t+\tau)}}{\omega_{1}(\omega_{1}-\omega_{2})} - \frac{\mathrm{e}^{\mathrm{i}\omega_{1}(t+\tau)}}{\omega_{2}(\omega_{2}-\omega_{1})}\right] $

其中  $ \omega_{1}=ia+\omega_{0}\sqrt{1-\frac{a^{2}}{\omega_{0}^{2}}},\omega_{2}=ia-\omega_{0}\sqrt{1-\frac{a^{2}}{\omega_{0}^{2}}} $

##### 习题9.2

1.  $ \frac{1}{\pi}\int_{-\infty}^{\infty}\frac{y}{(x-\xi)^2+y^2}f(\xi)\mathrm{d}\xi $

 $$ 3.u(x,t)=\frac{1}{2\sqrt{\pi at}}\int_{-\infty}^{\infty}\varphi(x-\xi)\cos\left(\frac{\pi}{4}-\frac{\xi^{2}}{4at}\right)\mathrm{d}\xi-\frac{1}{2\sqrt{\pi at}}\int_{-\infty}^{\infty}\varphi(x-\xi)\sin\left(\frac{\pi}{4}-\frac{\xi^{2}}{4at}\right)\mathrm{d}\xi $$ 

 $$ u(x,t)=\frac{1}{2}\mathrm{e}^{D\beta^{2}t}\left[\mathrm{e}^{-\beta x}\operatorname{e r f c}\left(\frac{2D\beta t-x}{2\sqrt{D t}}\right)-\mathrm{e}^{\beta x}\operatorname{e r f c}\left(\frac{2D\beta t+x}{2\sqrt{D t}}\right)\right] $$

<!-- page: 353 -->

$$ \mathrm{e}^{-a^{2}t}\sin x $$ 

 $$ x^{2}+1+2a^{2}t $$ 

 $$ u(x,t){=}\sqrt{\frac{\pi}{2}}\mathrm{e}^{-\mid x+t\mid}\qquad\mathrm8. $$ 

 $$ u(x,t)=f\Big(x-\frac{t^{2}}{2}\Big) $$ 

##### 习题9.3

1. (1)  $ \frac{1}{p+2} $ (Rep>-2)

(2)  $ \frac{p^{3}+2p^{2}-4p+2}{p^{3}(p-1)^{2}} $ (3)  $ \frac{p^{2}+2pa-a^{2}}{(p^{2}+a^{2})^{2}} $

(4)  $ \frac{-5p^{2}-14p-188}{(p+2)(p^{2}+4p+40)} $ (5)  $ \frac{[np^{n}-(p-a)^{n+1}]\Gamma(n)}{(p-a)^{n+1}p^{n}} $ (n>0)

2. (1)  $ e^{-2t} \cos t + 6e^{-2t} \sin t $ (2)  $ \frac{t \sin at}{2a} $

3. (1)  $ \frac{1}{ab} + \frac{1}{a-b}\left(\frac{e^{-at}}{a} - \frac{e^{-bt}}{b}\right) $ (2)  $ \frac{e^{-t}}{2} (\sin t - t\cos t) $

4. (1)  $ e^{t} + e^{-2t} $ (2)  $ \frac{1}{4}[(7+2t)e^{-t}-3e^{-3t}] $

(3)  $ 3 + 4t - 2e^t $ (4)  $ \begin{cases} y = \int_0^t (1 - 2\cos\tau) f(t - \tau) \, \mathrm{d}\tau \\ z = -\int_0^t \cos\tau f(t - \tau) \, \mathrm{d}\tau \end{cases} $

 $$ \begin{aligned}&\cdot\frac{1}{m\omega_{0}}\int_{0}^{t}f(\tau)\sin\omega_{0}(t-\tau)\mathrm{d}\tau,\quad\omega_{0}=\sqrt{\frac{k}{m}}\\&\cdot\left\{\begin{aligned}&\frac{E_{0}}{L}\Big(1-\frac{R}{2L}t\Big)\mathrm{e}^{-\frac{R}{2L}t},& 当 R^{2}=&\frac{4L}{C}\\&\frac{E_{0}}{\sqrt{R^{2}-\frac{4L}{C}}}\mathrm{e}^{-\frac{R}{2L}t}\left[\frac{\sqrt{R^{2}-\frac{4L}{C}}}{L}\mathrm{ch}\frac{\sqrt{R^{2}-\frac{4L}{C}}}{2L}t-\frac{R}{L}\mathrm{sh}\frac{\sqrt{R^{2}-\frac{4L}{C}}}{2L}t\right],& 当 R^{2}>\frac{4L}{C}\\&\frac{E_{0}}{\sqrt{\frac{4L}{C}-R^{2}}}\mathrm{e}^{-\frac{R}{2L}t}\left[\frac{\sqrt{\frac{4L}{C}-R^{2}}}{L}\cos\frac{\sqrt{\frac{4L}{C}-R^{2}}}{2L}t-\frac{R}{L}\sin\frac{\sqrt{\frac{4L}{C}-R^{2}}}{2L}t\right],& 当 R^{2}<\frac{4L}{C}\end{aligned}\right.\end{aligned} $$ 

##### 习题9.4

1.  $ xy + y + 1 $

2.  $ u(x,t)=u_0\operatorname{erfc}\left(\frac{x}{2a\sqrt{t}}\right)=u_0\left(1-\operatorname{erf}\frac{x}{2a\sqrt{t}}\right) $，其中  $ \operatorname{erfc}(x)=\frac{2}{\sqrt{\pi}}\int_{x}^{\infty}\mathrm{e}^{-u^2}\mathrm{d}u $ 称为余误差函数，而  $ \operatorname{erf}(x)=\frac{2}{\sqrt{\pi}}\int_{0}^{x}\mathrm{e}^{-\xi^2}\mathrm{d}\xi $ 称为误差函数

 $$ \frac{a A\omega}{E}\left\{\frac{\sin\frac{\omega x}{a}\sin\omega t}{\omega^{2}\cos\frac{\omega l}{a}}-\frac{16l^{2}}{\pi}\sum_{n=1}^{\infty}(-1)^{n}\cdot\frac{\sin\frac{(2n-1)a\pi t}{2l}\sin\frac{(2n-1)\pi t}{2l}}{(2n-1)\left[4\omega^{2}l^{2}-(2n-1)^{2}a^{2}\pi^{2}\right]}\right\} $$ 

 $$ \begin{cases}\frac{2}{\omega^{2}}\Big[\sin^{2}\frac{\omega t}{2}-\sin^{2}\frac{1}{2}\omega\big(t-\frac{x}{a}\big)\Big]&\big(t\geqslant\frac{x}{a}\big)\\\frac{2}{\omega^{2}}\sin^{2}\frac{\omega t}{2}&\big(0<t<\frac{x}{a}\big)\end{cases} $$

<!-- page: 354 -->

$$ u(x,t)=u_{0}\frac{x}{l}+\frac{2u_{0}}{\pi}\sum_{k=1}^{\infty}\frac{(-1)^{k}}{k}\bullet\sin\frac{k\pi x}{l}\mathrm{e}^{-(\frac{k\pi u}{l})^{2}/t} $$ 

 $$ \mathbf{6}.u(x,t)=\frac{\varphi(x+at)+\varphi(x-at)}{2}+\frac{1}{2a}\int_{x-at}^{x+at}\psi(\xi)\mathrm{d}(\xi)+\frac{1}{2a}\int_{0}^{l}\left[\int_{x-a(t-\tau)}^{x+a(t-\tau)}f(\xi,\tau)\mathrm{d}\xi\right]\mathrm{d}\tau $$ 

7.  $ u(x,t)=\sin\frac{\pi x}{l}\exp\left[-\left(\frac{a\pi}{l}\right)^2t\right] $

 $$ u(x,t)=\frac{1}{\sqrt{\pi(4a^{2}+1)}}\exp\left[-\frac{(x-kt)^{2}}{4a^{2}t+1}\right] $$ 

9.  $ u(x,t)=t\sin x $

##### 习题10.1


 $$ 1,\frac{1}{2\pi}\int_{-\infty}^{\infty}\mathrm{e}^{\mathrm{i}\omega x}\mathrm{d}\omega $$ 

6. (1) 0 (2)  $ -\frac{1}{2}\cos2 $ (3)  $ -\cos\frac{1}{3} $ (4) -1

7.  $ \Delta v = -\frac{q}{\varepsilon_0} \delta(x - x_0, y - y_0, z - z_0) $

 $$ f(t)=\left\{\begin{aligned}&0,&(t<0)\\ &\frac{1}{2}&(t=0)\\ &1&(t>0)\end{aligned}\right. $$ 

 $$ \mathbf{10.}(1)\left\{\begin{aligned}&-\frac{1}{2}\sin x(x<0)\\ &\frac{1}{2}\sin x\quad(x>0)\end{aligned}\right.\quad(2)\left\{\begin{aligned}&-\frac{1}{2}\cos x(x<0)\\ &0\quad(x=0)\\ &\frac{1}{2}\cos x\quad(x>0)\end{aligned}\right. $$ 

##### 习题10.3

2.  $ 2l \sum_{n=1}^{\infty} \frac{\sin \frac{n\pi}{l} x \sin \frac{n\pi}{l} x_0}{(n\pi)^2} $

 $$ \frac{i}{2k}\mathrm{e}^{ik\mid x-x_{0}}\mid $$ 

 $$ G(x,x^{\prime})=\left\{\begin{aligned}&-\frac{1}{2\cos2}\sin2x\cos(2x^{\prime}-2)&(x<x^{\prime})\\ &-\frac{1}{2\cos2}\cos(2x-2)\sin2x^{\prime}&(x>x^{\prime})\end{aligned}\right. $$ 

(2)

 $$ u(x)=\frac{b+2a\sin2}{2\cos2}\sin2x+a\cos2x+\int_{0}^{1}G(x,x^{\prime})f(x^{\prime})\mathrm{d}x^{\prime} $$ 

*5. (1)  $  y = \begin{cases} \frac{\sinh(x_1 - b) \sinh(x - a)}{k \sinh(b - a)} & (x < x_1) \\ \frac{\sinh(x_1 - a) \sinh(x - b)}{k \sinh(b - a)} & (x > x_1) \end{cases}  $

(2) 设(1)的解为  $  g(x, x_1)  $ 则  $  y(x) = \int_a^b g(x, \xi) f(\xi) \, \mathrm{d}\xi  $

<!-- page: 355 -->

##### 习题10.4

4.  $ \frac{1}{\pi}\int_{-\infty}^{\infty}\frac{yf(\xi)}{(\xi-x)^2+y^2}d\xi $

 $$ u(x,y,z)=\frac{z}{2\pi}\iint_{-\infty}^{\infty}\frac{f(\xi,\eta)\mathrm{d}\xi\mathrm{d}\eta}{\left[(\xi-x)^{2}+(\eta-y)^{2}+z^{2}\right]^{3/2}} $$ 

 $$ u(x,y)=\frac{x}{\pi}\int_{0}^{\infty}f(\eta)\left[\frac{1}{x^{2}+(\eta-y)^{2}}-\frac{1}{x^{2}+(\eta+y)^{2}}\right]\mathrm{d}\eta $$ 

 $$ -\frac{1}{12}xy(x^{2}+y^{2}-a^{2}) $$ 

8.  $ 3\rho^{2}\cos2\theta+\rho^{2} $

9. (1)  $ \frac{1}{2\pi}\left(\ln\frac{\rho_0 r_1}{ar} - \ln\frac{\rho_0 r_1'}{ar'}\right)\quad(0 \leqslant \theta \leqslant \pi) $

 $$ \frac{1}{4\pi}\Big[\left(\frac{1}{r}-\frac{a}{\rho_{0}}\frac{1}{r_{1}}\right)-\left(\frac{1}{r^{^{\prime}}}-\frac{a}{\rho_{0}}\frac{1}{r^{^{\prime}}}\right)\Big]\quad\left(0\leqslant\theta\leqslant\frac{\pi}{2},0\leqslant\varphi\leqslant2\pi\right) $$ 

##### 习题10.5

1.  $ \frac{A}{\omega}(1-\cos\omega t) $

3. 解的积分公式为： $ u(x,t)=\frac{\partial}{\partial t}\int_{0}^{t}\varphi(x_{0})G(x,t\mid x_{0},0)\mathrm{d}x_{0}+\int_{0}^{t}\psi(x_{0})G(x,t\mid x_{0},0)\mathrm{d}x_{0} $

 $ \int_{0}^{t}\int_{0}^{t}f(x_{0},\tau)G(x,t\mid x_{0},\tau)\mathrm{d}x_{0}\mathrm{d}\tau $

 $ G(x,t\mid x_{0},t_{0}) $ 满足的定解问题为： $ \left\{\begin{aligned}&G_{tt}-a^{2}G_{xx}=0\\&G|_{x=0}=G|_{x=t}=0\\&G|_{t=t_{0}}=0,G_{t}|_{t=t_{0}}=\delta(x-x_{0})\end{aligned}\right. $

4. 提示：先令  $ u(x,t)=v(x,t)+g(t)+\frac{x}{l}[h(t)-g(t)] $，再用格林函数法求解  $ v(x,t) $ 的定解问题

 $$ \mathrm{i}.\int_{a}^{t}\mathrm{d}t_{0}\iiint_{-\infty}^{\infty}f(r_{0}t_{0})\left\{\frac{1}{\left[2a\sqrt{\pi(t-t_{0})}\right]^{3}}\mathrm{e}^{-\frac{(r-r_{0})^{2}}{4a^{2}(t-t_{0})}}\right\}\mathrm{d}r_{0} $$ 

 $$ \begin{align*}u(\boldsymbol{r},t)=&\frac{1}{4\pi a}\Biggl[\frac{\partial}{\partial t}\iiint\frac{\varphi(\boldsymbol{r}^{\prime})}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}\delta(|\boldsymbol{r}-\boldsymbol{r}^{\prime}|-at)\mathrm{d}\boldsymbol{r}^{\prime}+\iiint\frac{\psi(\boldsymbol{r}^{\prime})}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}\delta(|\boldsymbol{r}-\boldsymbol{r}^{\prime}|-at)\mathrm{d}\boldsymbol{r}^{\prime}\Biggr]\\&+\frac{1}{4\pi a}\int_{0}^{t}\mathrm{d}\tau\iiint\frac{f(\boldsymbol{r}^{\prime},\tau)}{|\boldsymbol{r}-\boldsymbol{r}^{\prime}|}\delta[|\boldsymbol{r}-\boldsymbol{r}^{\prime}|-a(t-\tau)]\mathrm{d}\boldsymbol{r}^{\prime}\end{align*} $$ 

化简得： $ u(r,t)=\frac{1}{4\pi a}\left[\frac{\partial}{\partial t}\iint_{S_{at}^{M}}\frac{\varphi(r^{\prime})}{at}\mathrm{d}s^{\prime}+\iint_{S_{at}^{M}}\frac{\psi(r^{\prime})}{at}\mathrm{d}s^{\prime}\right] $

 $ + \frac{1}{4\pi a^{2}} \iint_{T_{at}^{M}} \frac{1}{|r - r^{\prime}|} f(r, t - \frac{|r - r^{\prime}|}{a}) \, \mathrm{d}r^{\prime} \text{)} $

#### 第 三 篇

##### 习题11.1


 $$ y(x)=c_{0}\cos\omega x+\frac{c_{1}}{\omega}\sin\omega x $$

<!-- page: 356 -->

$$ y_{1}=x+\sum_{n=1}^{\infty}\frac{x^{3n-1}}{3\bullet4\bullet6\bullet7\cdots3n(3n+1)} $$ 

 $$ y_{2}=1+\sum_{n=1}^{\infty}\frac{x^{3n}}{2\cdot3\cdot5\cdot6\cdots(3n-1)3n} $$ 


 $$ y=a_{0}y_{0}\left(x\right)+a_{1}y_{1}\left(x\right) $$ 

 $$ y_{0}(x)=1+\frac{1-\lambda}{2!}x^{2}+\frac{(1-\lambda)(5-\lambda)}{4!}x^{4}+\cdots+\frac{(1-\lambda)(5-\lambda)\cdots(4k-3-\lambda)}{(2k)!}x^{2k}+\cdots $$ 

 $$ y_{1}(x)=x+\frac{3-\lambda}{3!}x^{3}+\frac{(3-\lambda)(7-\lambda)}{5!}x^{5}+\cdots+\frac{(3-\lambda)(7-\lambda)\cdots(4k-1-\lambda)}{(2k+1)!}x^{2k+1}+\cdots $$ 

当 $ \lambda=4k-3 $和 $ \lambda=4k-1(k=1,2,\cdots) $时， $ y_{0}(x) $和 $ y_{1}(x) $分别退化为多项式

 $$  H_{0}(x)=1;H_{1}(x)=2x;H_{2}(x)=(2x)^{2}-2;H_{3}(x)=(2x)^{3}-12x $$ 

4.  $ \sum_{n=0}^{\infty}C_{n}x^{n} $，其中 $ C_{0}, C_{1} $是任意常数，且

 $$ C_{k+2}=\frac{(k-\lambda)(k+\alpha+\beta+\lambda+1)}{(k+2)(k+1)}C_{k}+\frac{\alpha-\beta}{k+2}C_{k+1}\quad(k=0,1,2,\cdots) $$ 

 $$ \mathbf{5}.y_{1}=\sum_{n=0}^{\infty}\frac{\Gamma(3/4)}{n!\Gamma(n+3/4)}\left(\frac{x}{2}\right)^{4n},\qquad y_{2}=\sum_{n=0}^{\infty}\frac{\Gamma(5/4)}{n!\Gamma(n+5/4)}\left(\frac{x}{2}\right)^{4n+1} $$ 

##### 习题11.2

 $$ 2.\quad(1)\quad\frac{2(l+1)(l+2)}{(2l+1)(2l+3)(2l+5)}\quad(2)\quad\frac{2(l+1)}{(2l+1)(2l+3)}\quad(3)0\quad(4)\quad\frac{2l(l+1)}{2l+1} $$ 

 $$ \frac{3}{5}P_{1}(x)+\frac{2}{5}P_{3}(x) $$ 

(2)

 $$ \sum_{k=0}^{\infty}(-1)^{k+1}\frac{(2k)!}{(2^k k!)^2}\frac{4k+1}{2(2k-1)(k+1)}P_{2k}(x) $$ 

 $$ (3)\frac{1}{2}P_{1}(x)+\sum_{k=0}^{\infty}(-1)^{k+1}\frac{(2k)!}{(2^{k}k!)^{2}}\cdot\frac{4k+1}{4(2k-1)(k+1)}P_{2k}(x) $$ 

 $$ \sum_{k=0}^{\infty}\Big(\frac{t^{k+2}}{2k+3}-\frac{t^k}{2k-1}\Big)P_{k}\left(x\right) $$ 

 $$ \mathbf{5}.~\frac{1}{5}r\cos\theta(5r^{2}\cos^{2}\theta-3r^{2}+3) $$ 


 $$ V_{i}(r,\theta)=\frac{q}{b}\sum_{l=0}^{\infty}\frac{2l+1}{(\varepsilon+1)l+1}\left(\frac{r}{b}\right)^{l}\mathrm{P}_{l}(\cos\theta)\quad(r<a) $$ 

 $$ V_{e}(r,\theta)=\frac{q}{R}-\frac{q(\varepsilon-1)}{a}\sum_{l=0}^{\infty}\frac{l}{(\varepsilon+1)l+1}\left(\frac{a^{2}}{br}\right)^{l+1}P_{1}(\cos\theta)\quad[r>a,R=(r^{2}+b^{2}-2br\cos\theta)^{\frac{1}{2}}] $$ 

 $$ 7.V_{i}(r,\theta)=\frac{v_{1}+v_{2}}{2}+\frac{v_{1}-v_{2}}{2}\cdot\sum_{k=0}^{\infty}(-1)^{k}\frac{(4k+3)(2k)!}{(2k+2)!!(2k)!!}\left(\frac{r}{a}\right)^{2k+1}\cdot P_{2k+1}(\cos\theta) $$ 

 $$ V_{e}(a,\theta)=\frac{v_{1}+v_{2}}{2}\frac{a}{r}+\frac{v_{1}-v_{2}}{2}\cdot\sum_{k=0}^{\infty}(-1)^{k}\frac{(4k+3)(2k)!}{(2k+2)!!(2k)!!}\left(\frac{a}{r}\right)^{2k+2}\cdot P_{2k+1}(\cos\theta) $$ 


 $$ \begin{aligned}&\cdot\frac{m}{a}+\frac{m}{a}\sum_{n=1}^{\infty}(-1)^{n}\frac{(2n-1)!!}{(2n)!!}\Big(\frac{r}{a}\Big)^{2n}P_{2n}(\cos\theta)\quad(r<a)\\&\quad\frac{m}{r}+\frac{m}{a}\sum_{n=1}^{\infty}(-1)^{n}\frac{(2n-1)!!}{(2n)!!}\Big(\frac{a}{r}\Big)^{2n+1}P_{2n}(\cos\theta)\quad(r>a)\\&\quad 其中 (2n-1)!!\quad=(2n-1)(2n-3)\cdots3\times1,(2n)!!\quad=2n(2n-)\end{aligned} $$

<!-- page: 357 -->

$$ u(r,\theta)=2v_{0}\left[1+rP_{1}\left(\cos\theta\right)+r^{2}P_{2}\left(\cos\theta\right)\right] $$ 

 $$ \mathbf{10.}u(r,\theta)=u_{0}\sum_{n=1}^{\infty}(-1)^{n}\frac{(4n+3)(2n-1)!!}{(2n+2)!!}\left(\frac{r}{a}\right)^{2n+1}P_{2n+1}(\cos\theta) $$ 


 $$ \begin{aligned}1.\quad&u(x,t)=\sum_{k=1}^{n}[a_{k}\cos\sqrt{2k(2k-1)}at+b_{k}\sin\sqrt{2k(2k-1)}at]\bullet P_{2k+1}\left(\frac{x}{l}\right)\\&a_{k}=\frac{4k-1}{l}\int_{0}^{1}\varphi(x)P_{2k-1}\left(\frac{x}{l}\right)\mathrm{d}x\\&b_{k}=\frac{4k-1}{al\sqrt{2k(2k-1)}}\int_{0}^{1}\varphi(x)P_{2k-1}\left(\frac{x}{l}\right)\mathrm{d}x\\&12.\quad u(r,\theta)=\left\{\begin{matrix}\frac{2q}{b^{2}-a^{2}}\Biggl[(b-a)P_{0}(\cos\theta)+\frac{1}{2}\left(\frac{1}{b}-\frac{1}{a}\right)r^{2}P_{2}(\cos\theta)\\-\frac{1}{8}\left(\frac{1}{b^{3}}-\frac{1}{a^{2}}\right)r^{4}P_{4}(\cos\theta)+\cdots\Biggr],& 当 r<a\\\frac{2q}{b^{2}-a^{2}}\Biggl[\cdots\frac{1}{16}\frac{a^{6}}{r^{5}}P_{4}(\cos\theta)+\frac{1}{8}\frac{a^{4}}{r^{3}}P_{2}(\cos\theta)\\-\frac{1}{2}\frac{a^{2}}{r}P_{0}(\cos\theta)+bP_{0}(\cos\theta)-r\left|P_{1}(\cos\theta)\right|\\+\frac{1}{2}\frac{r^{2}}{b}P_{2}(\cos\theta)-\frac{1}{8}\frac{r^{4}}{b^{3}}P_{4}(\cos\theta)+\cdots\Biggr],& 当 a<r<b\\\frac{2q}{b^{2}-a^{2}}\Biggl[\frac{1}{2}\frac{b^{2}-a^{2}}{r}P_{0}(\cos\theta)-\frac{1}{8}\frac{b^{4}-a^{4}}{r^{3}}P_{2}(\cos\theta)\\+\frac{1}{16}\frac{b^{6}-a^{6}}{r^{5}}P_{4}(\cos\theta)+\cdots\Biggr],& 当 r>b\\\end{matrix}\right.\end{aligned} $$ 


 $$ \frac{2v_{0}}{\pi}\left[\frac{\pi}{2}+\sum_{n=0}^{\infty}(-1)^{n+1}\frac{1}{2n+1}\left(\frac{r}{a}\right)^{2n+1}\mid P_{2n+1}(\cos\theta)\mid\right], 当 r<a $$ 

 $$ \frac{2v_{0}}{\pi}\sum_{n=0}^{\infty}(-1)^{n}\frac{1}{2n+1}\left(\frac{a}{r}\right)^{2n+1}P_{2n}(\cos\theta), 当 r>a $$ 

##### 习题11.3

1. (1)

 $$ 2\sqrt{\pi}Y_{0,0}\left(\theta,\varphi\right)-2\sqrt{\frac{\pi}{5}}Y_{2,0}\left(\theta,\varphi\right)+3\sqrt{\frac{2\pi}{15}}\left[Y_{2,2}\left(\theta,\varphi\right)+Y_{2,-2}\left(\theta,\varphi\right)\right] $$ 

 $$ (2)\sqrt{\frac{2\pi}{3}}[-Y_{1,1}(\theta,\varphi)+Y_{1,-1}(\theta,\varphi)]+\sqrt{\frac{6\pi}{5}}[-Y_{2,1}(\theta,\varphi)+Y_{2,-1}(\theta,\varphi)] $$ 

2.（1）

 $$ u_{0}\bigg[-\frac{1}{3}+\frac{r}{a}\cos\theta-\frac{1}{3}\frac{r^{2}}{a^{2}}(3\cos^{2}\theta-1)\bigg] $$ 

(2)

 $$ \cos\varphi\left[-\frac{r}{a}\frac{\sin\theta}{5}+\frac{r^{3}}{a^{3}}\frac{1}{5}(\sin\theta+5\sin3\theta)\right] $$ 

6.  $ \psi(\gamma,\theta,\varphi)=R(r)Y_{l,m}(\theta,\varphi) $

 $$ \frac{\mathrm{d}}{\mathrm{d}r}[r^{2}R^{\prime \prime}(r)]-\left[l(l+1)+\frac{2\mu r^{2}}{\hbar^{2}}V(r)-\frac{2\mu r^{2}}{\hbar}E\right]R(r)=0 $$ 

##### 习题12.1


 $$ y=a_{0}\left[1+\frac{-\lambda}{(1!)^{2}}x+\frac{(-\lambda)(1-\lambda)}{(2!)^{2}}x^{2}+\cdots+\frac{(-\lambda)(1-\lambda)\cdots(k-1-\lambda)}{(k!)^{2}}x_{k}\right] $$ 

当 $ \lambda=0,1,2,\cdots $时，级数解退化为多项式：

<!-- page: 358 -->

$$ L_{0}(x)=1 $$ 

 $$ L_{1}(x)=-x+1 $$ 

 $$ L_{2}(x)=(-x)^{2}-4x+2 $$ 

 $$ L_{3}(x)=(-x)^{3}+9x^{2}-18x+6 $$ 

2. (1)  $ y = c_{0} \frac{\sin x}{\sqrt{x}} + c_{1} \frac{\cos x}{\sqrt{x}} $ (2)  $ c_{1} y_{1}(x) + c_{2} y_{2}(x) $

 $$ y_{1}=x\left(1+\frac{1}{2\cdot5}x^{2}+\frac{1}{2\cdot4\cdot5\cdot9}x^{4}+\cdots\right),\\ y_{2}=\sqrt{x}\left(1+\frac{1}{2\cdot3}x^{2}+\frac{1}{2\cdot4\cdot3\cdot7}x^{4}+\cdots\right) $$ 

(3)

 $$ y_{1}=x;\quad y_{2}=x\ln x-1+\sum_{k=2}^{\infty}\frac{1}{(k-1)k!}x^{k} $$ 

(4)

 $$ y(x)=c_{0}x^{2}+d_{0}\frac{1}{x} $$ 

（5）取 $ \rho=0 $，得 $ y_{1}=\frac{\sin mx}{mx} $；取 $ \rho=-2 $，得 $ y_{2}=\frac{\cos mx}{mx} $

 $$ y_{1}=J_{0}(x);y_{2}=J_{0}(x)\ln x+\sum_{k=0}^{\infty}\frac{(-1)^{k}}{(k!)^{2}}\left[\frac{1}{k}+\frac{1}{k-1}+\cdots+1\right]\left[\frac{x}{2}\right]^{2k} $$ 

 $$ y_{1}=\sum_{k=0}^{\infty}\frac{\Gamma(k+1+l)}{(k!)^{2}\Gamma(-k+1+l)}\left(\frac{x-1}{2}\right)^{k};y_{2}=\sum_{k=0}^{\infty}\frac{(n+k)!}{(k!)^{2}(n-k)!}\left(\frac{x-1}{2}\right)^{k} $$ 

##### 习题12.2

 $$ 1=\sum_{m=1}^{\infty}\frac{2}{x_{m}^{0}J_{1}(x_{m}^{0})}J_{1}(x_{m}^{0}\rho),\rho=\sum_{m=1}^{\infty}\frac{2}{x_{m}^{1}J_{2}(x_{m}^{1})}J_{1}(x_{m}^{1}\rho) $$ 

 $$ \sum_{m=0}^{\infty}(A_{m}\cos m\varphi+B_{m}\sin m\varphi)\mathrm{J}_{m}(k\varphi) $$ 

7.  $ 2u_0 \sum_{m=1}^{\infty} e^{-D\left(\frac{x_m^0}{a}\right)^2 t} \cdot \frac{\mathrm{J}_0\left(\frac{x_m^0}{a}\rho\right)}{x_m^0 \mathrm{J}_1(x_m^0)} $

 $$ \begin{array}{r l}{8H\displaystyle\sum_{m=1}^{\infty}\frac{1}{\left(x_{m}^{0}\right)^{3}\mathrm{J}_{1}\left(x_{m}^{0}\right)}\mathrm{J}_{0}\left(\frac{x_{m}^{0}}{R}\rho\right)\cos\frac{x_{m}^{0}}{R}a t}\end{array} $$ 

9. (1)  $ -x^{-n}J_{n}(x)+\frac{1}{2^{n}n!} $ (2)  $ 2\sin\frac{t}{2} $

 $$ a^{4}\mathrm{J}_{2}(a)-2a^{3}\mathrm{J}_{3}(a) $$ 

 $$ \sum_{k=0}^{\infty}\frac{(-1)^{k}a^{2k+1}}{(k!\alpha^{k})^{2}(2k+1)} $$ 

 $$ b(a^{2}+b^{2})^{-\frac{3}{2}} $$ 

 $$ \frac{1}{\sqrt{a^{2}+b^{2}}} $$ 

11.  $ A_{0} + \sum_{n=1}^{\infty} A_{n} J_{0} \left( \frac{x_{n}^{1}}{l} x \right) \cos \frac{x_{n}^{1} a t}{l} $，其中  $ A_{0} = \frac{2}{l^{2}} \int_{0}^{l} \varphi(x) \, dx $

 $$ A_{n}=\frac{2}{l^{2}\left[\mathrm{J}_{0}\left(x_{n}^{1}\right)\right]^{2}}\int_{0}^{l}\varphi(x)\mathrm{J}_{0}\left(\frac{x_{n}^{1}x}{l}x\right)x\mathrm{d}x $$ 

 $$ \frac{4}{\sigma\omega^{2}}\Biggl\{\frac{b a^{2}}{R^{2}\omega^{2}}\Biggl[\frac{\mathrm{J}_{0}\left(\frac{\omega}{a}\rho\right)}{\mathrm{J}_{0}\left(\frac{\omega}{a}R\right)}-1\Biggr]+\left(\frac{\rho^{2}}{R^{2}}-1\right)\Biggr\}\sin\omega t $$ 

##### 习题12.3

 $$ u(\rho,z)=u_{0}+\frac{2}{k\pi}\sum_{n=1}^{\infty}\frac{1}{nI_{0}\left(\frac{n\pi a}{h}\right)}\int_{0}^{h}q(\xi)\sin\frac{n\pi\xi}{h}\mathrm{d}\xi I_{0}\left(\frac{n\pi}{h}\rho\right)\bullet x\sin\frac{n\pi z}{h} $$

<!-- page: 359 -->

$$ u=u_{2}+\frac{u_{1}-u_{2}}{h}z+v,v=\sum_{n=1}^{\infty}A_{n}I_{0}\left(\frac{n\pi}{h}\rho\right)\sin\frac{n\pi}{h}z $$ 

 $$ A_{n}=\left\{\begin{aligned}&\frac{-16u_{1}}{(n\pi)^{3}I_{0}(n\pi a/h)}&(n=2k+1,k=0,1,2,\cdots)\\ &0&(n=2k,k=0,1,2,\cdots)\end{aligned}\right. $$ 


 $$ u=\frac{1}{r}\sum_{n=1}^{\infty}A_{n}\sin\frac{n\pi r}{2a_{0}}\mathrm{e}^{-(\frac{n\pi a}{2a_{0}})^{2}t} $$ 

 $$ A_{2k}=(-1)^{k+1}\frac{u_{0}a_{0}}{k\pi}\quad(k=1,2,3,\cdots) $$ 

 $$ A_{2k+1}=(-1)^{k}\frac{4u_{0}a_{0}}{(2k+1)2\pi^{2}}\quad(k=0,1,2,\cdots) $$ 

 $ ^{*}7.\ (1)\ \omega_{0}=\frac{k_{0}^{2}}{a^{2}\sqrt{b}}\quad(2)\ u=AJ_{0}(ar)+BI_{0}(cr) $

 $$ 3)\frac{\mathrm{J}_{0}(k_{0})}{\mathrm{J}_{1}(k_{0})}=-\frac{I_{0}(k_{0})}{I_{1}(k_{0})}\quad(4)\left.\frac{\partial^{2}u}{\partial r^{2}}\right|_{r=a}=0,\left.\frac{\partial^{3}u}{\partial r^{3}}\right|_{r=a}=0 $$ 

 $$ \mathbf{\Psi}^{*}\mathbf{8}.\left(2\right)D=\left(\frac{\pi}{2}\right)^{1/2} $$ 

 $$ {}^{*}\mathbf{9}.\quad\sum_{n=1}^{\infty}\frac{1}{x_{n l}^{2}}=\frac{1}{2(2l+3)} $$ 

习题13.1

 $$ \left(2\right)\lambda=\left[\frac{n+\frac{1}{2}}{b}\right]^{2} $$ 

 $$ \mathbf{5}.\ \psi(x)=\frac{\sqrt{ma}}{h}\exp\left(-\frac{ma}{h^{2}}\left|\ x\right|\right) $$ 

##### 习题14.1

 $$ (1)\delta J=2\int_{x_{0}}^{x_{1}}(-y^{\prime \prime}+y-\mathrm{ch}x)\delta y\mathrm{d}x+2y^{\prime}\delta y\bigg|_{x_{0}}^{x_{1}}\quad(2)\delta J=x^{4}\delta y\bigg|_{x_{0}}^{x_{1}}-3\int_{x_{0}}^{x_{1}}x^{3}\delta y\mathrm{d}x $$ 

4.  $ u_{xx} + u_{yy} = f(x, y) $;  $ u_{xx} - u_{yy} = 0 $

5.  $ y=c_{1}x+c_{2} $，其中常数  $ c_{1} $ 和  $ c_{2} $ 由两定点的坐标定出

6. (1)  $ \frac{\mathrm{d}}{\mathrm{d}t}\frac{mv}{\sqrt{1-\left(\frac{v}{c}\right)^2}}=0 $ (2)  $ m\frac{\mathrm{d}v}{\mathrm{d}t}=-\nabla U $

7. (1)  $ \sin x $

（2）欧拉方程为： $ y^{(4)}-16y=0 $；通解： $ y=c_{1}e^{2x}+c_{2}e^{-2x}+c_{3}\cos2x+c_{4}\sin2x $；其中任意常数 $ c_{1}, c_{2}, c_{3}, c_{4} $由边界条件确定

8. 所求的曲线是圆： $ (x-a)^{2}+(x-b)^{2}=\left(\frac{l}{2\pi}\right)^{2} $

9. 准确解  $ y=\frac{2\sin x}{\sin 2}-x $

11. (1)  $ y' = \frac{1}{k} \sqrt{n^2(y) - k^2} $ (2)  $ d = \frac{\pi \cos \varphi}{\Omega} $，当  $ n \to \infty $， $ m \to \infty $ 时得准确解

<!-- page: 360 -->

##### 习题14.2

2.  $ \omega_{0}=2.414\frac{c}{a} $

3. 近似解： $ \frac{-1}{\pi^{2}}\sum_{p=1}^{n}\sum_{q=1}^{m}\frac{B_{pq}}{\left(\frac{p^{2}}{a^{2}}+\frac{q^{2}}{b^{2}}\right)}\sin\frac{p\pi x}{a}\sin\frac{q\pi y}{b} $

4.  $ \lambda=2.468 $

5.  $ u=\frac{5}{16a^{2}}(x^{2}-a^{2})(y^{2}-b^{2}) $，如需更准确，则解可由下形式来求，即取

 $$ u=\left(x^{2}-a^{2}\right)\left(y^{2}-b^{2}\right)\left[c_{0}+c_{1}\left(x^{2}+y^{2}\right)\right] $$ 

6.  $ E_{0} = -\frac{3}{64}k $

##### 习题15.1

1.  $ u = \arccos\left(\frac{C_1e^y + C_2e^{-y}}{C_1 + C_2}\cos x\right) $

 $$ u=C_{1}\int_{\xi_{0}}^{y/\sqrt{t}}\mathrm{e}^{\frac{\xi^{2}}{4}}\mathrm{d}\xi+C_{2}\int_{\eta_{0}}^{y/\sqrt{t}}\mathrm{e}^{\frac{\eta^{2}}{4}}\mathrm{d}\eta $$ 

3. (1)  $  g(y + \varphi(x))  $; (2)  $  u = -2\lambda\ln|\mathrm{e}^{\frac{\xi}{\lambda(a^2 + b^2)}} - C_1| + C_2  $, 其中  $ \xi = t + at + by $

4.  $ u(x,t)=-2\lambda\frac{\partial\ln v}{\partial x} $，其中  $ v(x,t)=\frac{1}{2\sqrt{\lambda\pi t}}\int_{-\infty}^{\infty}\mathrm{e}^{\frac{1}{-2\lambda}\int_{0}^{\xi_{0}}f(\eta)\mathrm{d}\eta}\mathrm{e}^{\frac{(x-\xi)^{2}}{4\lambda t}}\mathrm{d}\xi $

##### 习题15.2

 $$ \varphi(x,t)=\pm\sqrt{\frac{n^{2}}{\lambda}}\tanh\left(\frac{1}{2}\sqrt{\frac{2}{v^{2}-1}}n(x-vt)\right) $$ 

2.  $ E=2C_{2}\operatorname{sech}(C_{2}t+C_{1}x+C_{3}) $

4.  $ \varphi=g(\xi) $，其中 $ g(\xi) $由等式 $ \int\frac{dg}{\sqrt{|\frac{2\cos g}{a^{2}}-1}+C_{0}|}=\pm\xi+C_{1} $给出， $ \xi=x+at $

##### 习题15.3

 $$ w(x,y)=b_{1}x-\frac{\varepsilon a_{1}b_{1}\sin\left(x-\frac{\sqrt{b_{1}^{2}-a_{1}^{2}}}{a_{1}}y\right)}{\sqrt{b_{1}^{2}-a_{1}^{2}}} $$ 

 $$ u^{(0)}=\frac{\rho}{R}\sin\varphi,\quad u^{(1)}=-\frac{\rho^{2}\sin2\varphi}{2R^{3}},\quad u^{(2)}=\frac{\rho^{3}\sin3\varphi}{4R^{5}}-\frac{\rho\sin\varphi}{4R^{3}} $$ 

##### 习题16.1

1. (1)  $ u(x)=e^{x}+\frac{3\lambda}{3-\lambda}x $ (2)  $ u(x)=\pm\frac{2i}{\pi}(A\sin x-B\cos x) $，A，B为任意常数

2.  $ g(x)=x^{2}+\frac{3}{8}x $

3. (1)  $ u(x)=x+\frac{\lambda}{1-\lambda} $

(2)  $ u(x) $ 只有零解

4.（1）本征值为 $ \lambda=1 $，本征函数为 $ g(x)=Ae^{x} $ （2） $ g(x)=\frac{e^{x}}{1-\lambda} $

5. (1)  $ g(x) = \mathrm{e}^x - 1 $; (2)  $ u(x) = \frac{1}{2\pi\mathrm{i}}\int_{\beta-i\infty}^{\beta+i\infty} \frac{\varepsilon!}{p^{\varepsilon-1}(p^2 - \lambda)}\mathrm{e}^{px} \, \mathrm{d}p $

<!-- page: 361 -->

$$ )g(x)=x+144\lambda\int_{0}^{1}\frac{y(x+y)-\lambda\left[\frac{xy^{2}}{2}+\frac{y(x+3y)}{3}+\frac{y}{4}\right]}{144-96\lambda+53\lambda^{2}}y\mathrm{d}y $$ 

(2)

 $$ g(x)=g_{0}(x)+g_{1}(x)+g_{2}(x)=\frac{\lambda}{4}+\frac{\lambda^{2}}{12}+\left(3+\frac{2}{3}\lambda+\frac{17}{72}\lambda^{2}\right)x+\left(\frac{\lambda}{2}+\frac{6}{\lambda^{2}}\right)x^{2} $$ 

7. (1)  $ \tilde{u}(\omega)=\frac{\sqrt{\pi}\mathrm{e}^{-\frac{\omega}{4}}}{1-\lambda\sqrt{\pi}\mathrm{e}^{-\frac{\omega}{4}}} $，求其逆变换，即为原方程的解

(2) $ \bar{u}(\omega)=\frac{\pi\mathrm{sech}\left(\frac{\pi\omega}{2}\right)}{1-\lambda\pi\mathrm{sech}\left(\frac{\pi\omega}{2}\right)} $，求其逆变换，即为原方程的解

8.  $  g(x) = \frac{\left( e^{-|x|} + \frac{\lambda}{1+x^2} \right)}{1 - \frac{\lambda^2 \pi}{2}}  $

9.  $ g(x)=\sqrt{\frac{1}{1-2\lambda}}e^{-\frac{|x|}{\sqrt{1/(1-2\lambda)}}} $

##### 习题16.2

1.  $ g(x) = C \sin 2\sqrt{\lambda} $

 $$ g(x)=\lambda\frac{\frac{1}{\pi^{2}}\int_{0}^{2\pi}\sin x f(x)\mathrm{d}x}{\frac{1}{\pi}-\lambda}\sin x+f(x) $$ 

(2)

 $$ g(x)=\lambda\bigg[\frac{\displaystyle\int_{0}^{1}x\lambda_{1}(x+x^{2})\mathrm{d}x}{\lambda_{1}-\lambda}\lambda_{1}(x+x^{2})+\frac{\displaystyle\int_{0}^{1}x\lambda_{2}(x+x^{2})\mathrm{d}x}{\lambda_{2}-\lambda}\lambda_{2}(x+x^{2})\bigg]+x $$

<!-- page: 362 -->

## 参考文献

1. 梁昆森. 数学物理方法. 2 版. 北京：人民教育出版社，1979

2. 姚端正. 数学物理方法学习指导. 北京：科学出版社，2001

3. 普里瓦洛夫 И И. 复变函数引论. 闵嗣鹤等译. 北京：人民教育出版社，1956

4. 吉洪诺夫 A H，萨马尔斯基 A A. 数学物理方程. 黄克欧等译. 北京：高等教育出版社，1959

5. 斯米尔诺夫 B.H. 高等数学教程. 第三卷（第三分册）. 叶彦谦译. 北京：人民教育出版社，1956

6. 王竹溪，郭敦仁. 特殊函数概论. 北京：科学出版社，1979

7. 郭敦仁. 数学物理方法. 北京：人民教育出版社，1978

8. Courant R, Hilbert D. Methods of Mathematical Physics, Parts I and II. New York: McGraw-Hill, 1953, 1962

9. Sveshnikov A, Tikhonov A. The Theory of Functions of A Complex Variable. Moscow: Mir Publishers, 1978

10. Wyld H W. Mathematical Methods for Physics. W. A. Benjamin, New York: University of Illinois at Urbana Champaign, 1976

11. Bradbury T C. Mathematical Methods with Applications to Problems in the Physics Sciences. New York: John Wiley & Sons, 1984

12. Dodd R K, Eineck J C, Gibbon J D, Morris H C. Solitons and Nonlinear Wave Equations, London, New York: Academic Press, 1982

13. Tranter C J. Integral Transforms in Mathematical physics. New York: John Wiley & Sons, 1951

14. Jackson J D. Classical Electrodynamics. 2nd ed. New York: John Wiley & Sons, 1976

15. Riley K F, Hobson M P, Bence S J. Mathematical Metheods for Physics and Engineering. Cambridge: Cambridge University Press, 2002

<!-- page: 363 -->

### Ⅰ．矢量微分算子与拉普拉斯算符

## 1. 矢量微分算符 $ \nabla $

$$  \nabla=\frac{\partial}{\partial x}\boldsymbol{i}+\frac{\partial}{\partial y}\boldsymbol{j}+\frac{\partial}{\partial z}\boldsymbol{k}   \tag*{(Ⅰ.1)}$$

称子

如果函数  $ u(x,y,z) $ 和矢量 A $ (x,y,z) $ 具有连续的一阶偏导数，则定义

（1）函数  $ u(x,y,z) $ 的梯度为

$$  \nabla u=\frac{\partial u}{\partial x}\mathbf{i}+\frac{\partial u}{\partial y}\mathbf{j}+\frac{\partial u}{\partial z}\mathbf{k}   \tag*{(I.2)}$$

(2) 矢量 A(x,y,z) 的散度为

$$  \nabla\cdot\boldsymbol{A}=\left(\frac{\partial}{\partial x}\boldsymbol{i}+\frac{\partial}{\partial y}\boldsymbol{j}+\frac{\partial}{\partial z}\boldsymbol{k}\right)\cdot(\boldsymbol{A}_{x}\boldsymbol{i}+\boldsymbol{A}_{y}\boldsymbol{j}+\boldsymbol{A}_{z}\boldsymbol{k})=\frac{\partial\boldsymbol{A}_{x}}{\partial x}+\frac{\partial\boldsymbol{A}_{y}}{\partial y}+\frac{\partial\boldsymbol{A}_{z}}{\partial z}   \tag*{(I.3)}$$

（3）矢量 $ A(x,y,z) $的旋度为

$$  \begin{aligned}\nabla\times\boldsymbol{A}=&\begin{vmatrix}\boldsymbol{i}&\boldsymbol{j}&\boldsymbol{k}\\\frac{\partial}{\partial x}&\frac{\partial}{\partial y}&\frac{\partial}{\partial z}\\A_{x}&A_{y}&A_{z}\end{vmatrix}=\begin{vmatrix}\frac{\partial}{\partial y}&\frac{\partial}{\partial z}\\A_{y}&A_{z}\end{vmatrix}\boldsymbol{i}-\begin{vmatrix}\frac{\partial}{\partial x}&\frac{\partial}{\partial z}\\A_{x}&A_{z}\end{vmatrix}\boldsymbol{j}+\begin{vmatrix}\frac{\partial}{\partial x}&\frac{\partial}{\partial y}\\A_{x}&A_{y}\end{vmatrix}\boldsymbol{k}\\=&\big(\frac{\partial A_{z}}{\partial y}-\frac{\partial A_{y}}{\partial z}\big)\boldsymbol{i}+\big(\frac{\partial A_{x}}{\partial z}-\frac{\partial A_{z}}{\partial x}\big)\boldsymbol{j}+\big(\frac{\partial A_{y}}{\partial x}-\frac{\partial A_{x}}{\partial y}\big)\boldsymbol{k}\end{aligned}   \tag*{(Ⅰ.4)}$$

2. 拉普拉斯算符  $ \Delta $

$$  \Delta=\nabla^{2}=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}}   \tag*{(I.5)}$$

称为拉普拉斯算符，

$$  \Delta u=\nabla\cdot(\nabla u)=\frac{\partial^{2}u}{\partial x^{2}}+\frac{\partial^{2}u}{\partial y^{2}}+\frac{\partial^{2}u}{\partial z^{2}}   \tag*{(Ⅰ.6)}$$

$$  \Delta\mathbf{A}=(\Delta A_{x})\mathbf{i}+(\Delta A_{y})\mathbf{j}+(\Delta A_{z})\mathbf{k}   \tag*{(I.7)}$$

## 3.  $ \nabla $ 和  $ \Delta $ 的运算公式

设函数  $  u(x, y, z)  $,  $  v(x, y, z)  $ 和矢量  $  A(x, y, z)  $,  $  B(x, y, z)  $ 的一阶偏导数存在，则

<!-- page: 364 -->

有

$$  \nabla(u+v)=\nabla u+\nabla v   \tag*{(I.8)}$$

$$  (2)\nabla\cdot(\boldsymbol{A}+\boldsymbol{B})=\nabla\cdot\boldsymbol{A}+\nabla\cdot\boldsymbol{B}   \tag*{(I.9)}$$

$$  (3)\nabla\times(\boldsymbol{A}+\boldsymbol{B})=\nabla\times\boldsymbol{A}+\nabla\times\boldsymbol{B}   \tag*{(Ⅰ.10)}$$

$$  \nabla\cdot(u\mathbf{A})=(\nabla u)\cdot\mathbf{A}+u(\nabla\cdot\mathbf{A})   \tag*{(Ⅰ.11)}$$

$$  \nabla\times(u\mathbf{A})=(\nabla u)\times\mathbf{A}+u(\nabla\times\mathbf{A})   \tag*{(Ⅰ.12)}$$

$$  (6)\nabla\cdot(\mathbf{A}\times\mathbf{B})=\mathbf{B}\cdot(\nabla\times\mathbf{A})-\mathbf{A}\cdot(\nabla\times\mathbf{B})   \tag*{(Ⅰ.13)}$$

$$  \nabla\times(\boldsymbol{A}\times\boldsymbol{B})=(\boldsymbol{B}\cdot\nabla)\boldsymbol{A}-\boldsymbol{B}(\nabla\cdot\boldsymbol{A})-(\boldsymbol{A}\cdot\nabla)\boldsymbol{B}+\boldsymbol{A}(\nabla\cdot\boldsymbol{B})   \tag*{(Ⅰ.14)}$$

$$  \nabla(\boldsymbol{A}\cdot\boldsymbol{B})=(\boldsymbol{B}\cdot\nabla)\boldsymbol{A}+(\boldsymbol{A}\cdot\nabla)\boldsymbol{B}+\boldsymbol{B}\times(\nabla\times\boldsymbol{A})+\boldsymbol{A}\times(\nabla\times\boldsymbol{B})   \tag*{(I.15)}$$

(9) $ \nabla\times(\nabla u)=0 $（当u的二阶偏导连续时）

（10） $ \nabla\cdot(\nabla\times\boldsymbol{A})=0 $（当A的二阶偏导连续时）

$$  (11)\nabla\times(\nabla\times\boldsymbol{A})=\nabla(\nabla\cdot\boldsymbol{A})-\Delta\boldsymbol{A}( 当 \boldsymbol{A} 的二阶偏导连续时 )   \tag*{(Ⅰ.18)}$$

## 4. 常用的矢量定理和矢量公式

（1）高斯定理：对于空间中以s为边界面的任意体积v有

$$  \oint_{s}\boldsymbol{A}\cdot\mathrm{d}\boldsymbol{s}=\oint_{v}\nabla\cdot\boldsymbol{A}\mathrm{d}v   \tag*{(Ⅰ.19)}$$

（2）斯托克斯定理：对于空间中以 l 为边界线的任意曲面积 s 有

$$  \oint_{l}\boldsymbol{A}\cdot\mathrm{d}\boldsymbol{l}=\oint_{s}\nabla\times\boldsymbol{A}\cdot\mathrm{d}s   \tag*{(Ⅰ.20)}$$

（3）格林公式：对于平面上以 l 为边界围线的闭区域  $ \bar{s} $ 中一阶连续可微的标量函数 u, v 有

$$  \oint_{l}u\mathrm{d}x+v\mathrm{d}y=\iint_{\bar{s}}\left(\frac{\partial v}{\partial x}-\frac{\partial u}{\partial y}\right)\mathrm{d}s   \tag*{(Ⅰ.21)}$$

<!-- page: 365 -->

<div style="text-align: center;"><div style="text-align: center;">Ⅱ．傅里叶变换简表</div> </div>




<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>像原函数</td><td style='text-align: center; word-wrap: break-word;'>像函数</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ f(x) = \frac{1}{2\pi}\int_{-\infty}^{\infty} G(\omega) e^{i\omega x} d\omega $</td><td style='text-align: center; word-wrap: break-word;'>$ G(\omega) = \int_{-\infty}^{\infty} f(x) e^{-i\omega x} dx $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \frac{\sin ax}{x} $</td><td style='text-align: center; word-wrap: break-word;'>$ \pi (|\omega| \leq a) $\n $ 0 (|\omega| &gt; a) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{\mathrm{j}\omega x} (a &lt; x &lt; b) $\n $ 0 (x &lt; a \text{ 或 } x &gt; b) $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{\mathrm{i}}{\beta - \omega} [\mathrm{e}^{\omega(\beta - \omega)} - \mathrm{e}^{\mathrm{j}\omega(\beta - \omega)}] $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{-cx + \mathrm{j}\omega x} (x &gt; 0) $\n $ 0 (x &lt; 0) $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{\mathrm{i}}{\beta - \omega + i\bar{c}} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{-\eta r^2} (\mathrm{Re}\eta &gt; 0) $</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{\frac{\pi}{\eta}} \mathrm{e}^{-\frac{\omega^2}{4\eta}} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \cos\eta x^2 $</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{\frac{\pi}{\eta}} \cos\left(\frac{\omega^2}{4\eta} - \frac{\pi}{4}\right) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \sin\eta x^2 $</td><td style='text-align: center; word-wrap: break-word;'>$ -\sqrt{\frac{\pi}{\eta}} \sin\left(\frac{\omega^2}{4\eta} - \frac{\pi}{4}\right) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ |x|^{-s} (0 &lt; \mathrm{Re}s &lt; 1) $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{2}{|\omega|} \Gamma(1 - s) \sin \frac{1}{2} \pi s $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{|x|} $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{\sqrt{2\pi}}{|\omega|} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{-a|x|} $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{2a}{\omega^2 + a^2} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{x^2 + a^2}, a &gt; 0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{\pi}{a} \mathrm{e}^{-a|x|} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \left\{\begin{array}{l} \mathrm{e}^{-ax}, \quad x \geq 0, \\ 0, \quad x &lt; 0, \end{array}\right.\ a &gt; 0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{a + i\omega} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \frac{\mathrm{e}^{\pi x}}{(1 + \mathrm{e}^{\pi x})^2} $</td><td style='text-align: center; word-wrap: break-word;'>$ \pi^2 \frac{\omega}{\sin\omega} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \ln \frac{x^2 + a^2}{x^2 + b^2}, a, b \geq 0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{2\pi}{|\omega|} (\mathrm{e}^{b|x| - a|x|}) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{-\frac{x^2}{4a^2}}, a &gt; 0 $</td><td style='text-align: center; word-wrap: break-word;'>$ 2a \sqrt{\pi} \mathrm{e}^{-a^2 \omega^2} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \arctan \frac{x}{a}, a &gt; 0 $</td><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{i} 2 \frac{\mathrm{e}^{-a|x|}}{\omega} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \delta(x - x_0) $</td><td style='text-align: center; word-wrap: break-word;'>$ \mathrm{e}^{-i\omega x_0} $</td></tr></table>

<!-- page: 366 -->

### Ⅲ．拉普拉斯变换简表



<table border="1" style="margin: auto; word-wrap: break-word;"><tr><td style="text-align: center; word-wrap: break-word;">像原函数</td><td style="text-align: center; word-wrap: break-word;">像函数</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ f(t)=\frac{1}{2\pi i}\int_{p-i\infty}^{p+i\infty}F(p)\mathrm{e}^{pt}\mathrm{d}p $</td><td style="text-align: center; word-wrap: break-word;">$ F(p)=\int_{0}^{+\infty}f(t)\mathrm{e}^{-pt}\mathrm{d}t $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">1或H(t)</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{n},\ n $是正整数</td><td style="text-align: center; word-wrap: break-word;">$ \frac{n!}{p^{n+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{a},\ a&gt;-1 $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{\Gamma(\alpha+1)}{p^{\alpha+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ e^{a t} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p-a} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">sinbt</td><td style="text-align: center; word-wrap: break-word;">$ \frac{b}{p^{2}+b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">cosbt</td><td style="text-align: center; word-wrap: break-word;">$ \frac{p}{p^{2}+b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">shbt</td><td style="text-align: center; word-wrap: break-word;">$ \frac{b}{p^{2}-b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">chbt</td><td style="text-align: center; word-wrap: break-word;">$ \frac{p}{p^{2}-b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{a}e^{a t},\ a&gt;-1 $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{\Gamma(\alpha+1)}{(p-c)^{\alpha+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{a}\sin bt,\ a&gt;-1 $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{\Gamma(\alpha+1)[(p+ib)^{\alpha+1}-(p-ib)^{\alpha+1}]}{2i(p^{2}+b^{2})^{\alpha+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{a}\cos bt,\ a&gt;-1 $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{\Gamma(\alpha+1)[(p+ib)^{\alpha+1}+(p-ib)^{\alpha+1}]}{2(p^{2}+b^{2})^{\alpha+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ e^{-a t}\sin bt $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{b}{(p+a)^{2}+b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ e^{-a t}\cos bt $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{p+a}{(p+a)^{2}+b^{2}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \delta(t) $</td><td style="text-align: center; word-wrap: break-word;">1</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi t}}\sin2\sqrt{at} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p}\sqrt{p}\mathrm{e}^{-\frac{a}{p}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi t}}\cos2\sqrt{at} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{p}}\mathrm{e}^{-\frac{a}{p}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi t}}\mathrm{e}^{-\frac{a^{2}}{4t}} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{p}}\mathrm{e}^{p/p} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi t}}\mathrm{e}^{-2a\sqrt{t}} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{p}}\mathrm{e}^{\frac{a^{2}}{p}}\mathrm{erfc}\left(\frac{\alpha}{\sqrt{p}}\right) $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">erf( $ \sqrt{at} $)</td><td style="text-align: center; word-wrap: break-word;">$ \frac{\sqrt{a}}{p}\sqrt{p+a} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">erf $ \left(\frac{a}{2\sqrt{t}}\right) $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p}\mathrm{e}^{-a\sqrt{p}}(a\geq0) $</td></tr><tr><td colspan="2">续表</td></tr><tr><td style="text-align: center; word-wrap: break-word;">像原函数</td><td style="text-align: center; word-wrap: break-word;">像函数</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ e^{t}erf(\sqrt{t}) $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p+\sqrt{p}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ J_{n}(t),\ n&gt;-1 $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{(\sqrt{p^{2}+1}-p)^{2}}{\sqrt{p^{2}+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{2}J_{v}(t),\ \nu&gt;-\frac{1}{2} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{2^{2}\Gamma\left(\nu+\frac{1}{2}\right)}{\sqrt{\pi}}\frac{1}{(p^{2}+1)^{\nu+\frac{1}{2}}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ t^{\frac{4}{2}}J_{n}(2\sqrt{t}) $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{p^{n+1}}e^{-\frac{1}{p}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{e^{bt}-e^{at}}{t} $</td><td style="text-align: center; word-wrap: break-word;">$ \ln\frac{p-a}{p-b} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi}t}\sin\frac{1}{2t} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{p}}e^{-\sqrt{p}}\sin\sqrt{p} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{\pi}t}\cos\frac{1}{2t} $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{\sqrt{p}}e^{-\sqrt{p}}\cos\sqrt{p} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \int_{0}^{t}\frac{\sin\xi}{\sqrt{2\pi\xi}}d\xi $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{2\sqrt{2}pi}\frac{\sqrt{p+i}-\sqrt{p-i}}{\sqrt{p^{2}+1}} $</td></tr><tr><td style="text-align: center; word-wrap: break-word;">$ \int_{0}^{t}\frac{\cos\xi}{\sqrt{2\pi\xi}}d\xi $</td><td style="text-align: center; word-wrap: break-word;">$ \frac{1}{2\sqrt{2}p}\frac{\sqrt{p+i}+\sqrt{p-i}}{\sqrt{p^{2}+1}} $</td></tr></table>

<!-- page: 367 -->

<!-- page: 368 -->

### 索引

英文关键词    
    
A    
    
阿贝尔定理    
Abel theorem    
    
B    
    
贝塔函数    
B function    
    
巴克朗德变换    
Backlund transformation    
    
半纯函数    
meromorphic function    
    
保角变换    
conformal transformation    
    
贝塞尔方程    
Bessel equation    
153, 234    
    
贝塞尔方程通解    
general solution of Bessel equation    
    
球贝塞尔方程    
spherical Bessel equation    
156, 248    
    
虚宗量贝塞尔方程    
modified Bessel equation    
157, 250    
    
贝塞尔函数    
Bessel function    
234, 236    
    
球贝塞尔函数    
spherical Bessel function    
    
虚宗量贝塞尔函数    
modified Bessel function    
    
贝塞尔函数递推公式    
recursion formula of Bessel function    
    
贝塞尔函数加法公式    
addition formula of Bessel function    
    
贝塞尔函数渐近行为    
asymptotic behavior of Bessel function    
    
贝塞尔函数母函数    
generating function of Bessel function    
    
本征函数    
eigenfunction    
132, 260    
    
本征函数法    
eigenfunction method    
    
本征函数族展开    
eigenfunction expansion    
197, 260    
    
本征值    
eigenvalue    
132, 260    
    
本征值问题    
eigenvalue problem    
    
比值判别法    
ratio test method    
    
变分法    
variational method    
    
变分问题    
variational problem    
    
波动方程    
wave equation    
    
一维齐次波动方程    
one dimensional homogeneous wave equation    
    
三维齐次波动方程    
three dimensional homogeneous wave equation    
    
玻恩近似    
Born approximation    
    
玻尔兹曼变换    
Boltzmann transformation

<!-- page: 369 -->

边界条件 boundary conditions 107    
边界条件齐次化 homogeneous boundary conditions 144    
边值问题 boundary problem 110    
C    
超几何级数 hypergeometric series 264    
冲量原理 impulse principle 118    
窗口傅里叶变换 windowed Fourier transform 321    
超越支点 transcend branch point 22    
初始条件 initial conditions 107    
D    
达朗贝尔解 D'Alembert solution 113    
大弧引理 Large arc lemma 90    
单极点 simple pole 63    
单叶变换 univalent transform 24    
单叶函数 univalent function 19    
单值分支 single valued branch 19    
单值函数 single valued function 7    
多值函数 multi-valued function 7,18    
倒易性 reciprocity 194    
δ函数 δ function 185    
狄利克雷边界条件 Dirichlet boundary condition 108    
狄利克雷积分 Dirichlet integral 87    
狄利克雷条件 Dirichlet condition 160    
狄氏格林函数 Dirichlet Green function 192    
球狄氏格林函数 Dirichlet Green function of sphere 202    
圆狄氏格林函数 Dirichlet Green function of circle 202    
狄氏积分公式 Dirichlet integral formula 192    
电报方程 telegram equation 105    
叠加原理 superposition principle 120    
对数函数 logarithmic function 21    
棣摩弗公式 DeMoivre formula 6    
电像法 method of images 202    
迭代解法 iteration method 309    
对称核 symmetric kernel 313    
E    
厄米多项式 Hermite polynomial 220,26    
厄米方程 Hermite equation 220,26    
厄米核 Hermitian kernel 313    
二次谐波 secondary harmonic wave 135

<!-- page: 370 -->

##### F

反三角函数 inverse trigonometric function 22    
泛函 functional 269    
泛函变分 variation of functional 270    
泛函核 kernel of functional 270    
泛函极值 extremum of functional 270,280    
非线性方程 nonlinear equation 287    
非线性薛定谔方程 nonlinear Schrodinger equation 296    
非涅耳积分 Fresnel integral 88    
分离变量法 method of separation of viables 135    
弗雷德霍姆定理 Fredholm theorem 307    
弗雷德霍姆方程 Fredholm equation 306    
弗雷德霍姆解法 Fredholm method 310    
伏特拉方程 Volterra equation 306    
复变函数 complex variable function 7    
复积分 complex integral 30    
三角函数复积分 complex integral of trigonometrical functions 83    
对数函数复积分 complex integral of logarithmic functions 92    
复级数 complex series 46    
复平面 complex plane 4    
复球面 complex sphere 5    
复数 complex number 3    
复数辐角 argument of complex number 4    
复数辐角的主值 principal argument of complex number 4    
复数模 modulus of complex number 4    
复数实部 real part of complex number 3    
复数虚部 imaginary part of complex number 3    
傅里叶变换傅里叶变换乘积定理 product theorem of Fourier transformation 169    
傅里叶变换性质 properties of Fourier transformation 164-166,168    
三维傅里叶变换 three dimensional Fourier transformation 163    
傅里叶积分 Fourier integration theorem 161    
傅里叶积分定理 Fourier integration theorem 161    
傅里叶逆变换 inverse Fourier transformation 162    
傅里叶实验定律 Fourier experimental law 103    
傅氏级数 Fourier series 160    
广义傅氏展开 generalized Fourier expansion 224,243    
腹点 antinode 135    
复势 complex potential 14

<!-- page: 371 -->

##### G

伽玛函数 Γ function 71      
格林公式 Green formula 190      
格林函数 Green function 185      
无界区域格林函数 Green function on unbounded region 195      
格林函数法 Green's function method 190      
根式函数 root function 18      
共轭复数 complex conjugate 3      
共轭调和函数 conjugate harmonic function 15      
孤波 solitary wave 292      
固有频率 eigen frequency 135      
广义函数 generalized function 186      
高斯判别法 Gaussian test method 47      
高斯方程 Gauss equation 259      
盖柏变换 Gabor transformation 321      
H      
亥姆霍兹方程 Helmholtz equation 151      
汉开尔函数 Hankel function 248      
行波解 traveling wave solution 290      
合流超几何方程 confluent hypergeometric equation 264      
合流超几何函数 confluent hypergeometric function 264      
混合边界条件 mixed boundary condition 108      
积分变换 integral transformation 160      
积分方程 integral equation 306      
积分方程核 kernel of integral equation 306      
积分方程本征值 eigenvalue of integral equation 307      
积分主值 principal value of the integral 85      
积分算符 integral operator 307      
级数解 series solution 215,234      
简单的闭曲线 simply closed curve 8      
阶梯函数 Heaviside step function 167      
节点 node 135      
解析函数 analytic function 12      
解析函数的唯一性定理 uniqueness theorem of analytic function 70      
解析延拓 analytic extension 70      
界点 boundary point 8      
卷积 convolution 166      
绝对收敛 absolute convergence 47

<!-- page: 372 -->

基波 fundamental wave 135    
    
基尔霍夫变换 Kirchhoff transformation 287    
    
渐进稳定性 asymptotic stability 293    
    
解核 solution kernel 311

解核 solution kernel 311    
K    
KdV方程 KdV equation 105,293    
开普勒积分 Kepler integral 86    
柯勒-霍普夫变换 Cole-Hopf transformation 288    
柯西不等式 Cauchy inequality 42    
柯西定理 Cauchy-thereom 33    
复通区域的柯西定理 Cauchy-thereom for multiply connected region 36    
柯西积分公式 Cauchy integral formula 38    
无界区域的柯西积分公式 Cauchy integral formula for unbounded region 40    
柯西-黎曼条件 Cauchy-Riemann condition 11    
柯西判别法 Cauchy test method 47    
柯西问题 Cauchy problem 110    
柯西型积分 Cauchy type integration 41    
扩散系数 diffusion coefficient 106    
克罗内克尔  $ \delta $ 符号 Kronecker  $ \delta $ symbol 198    
克莱因-戈登方程 Klein-Gorden equation 294    
L    
拉格朗日乘子法 Lagrangian multiplier method 273    
拉普拉斯变换 Laplace transformation 173    
拉普拉斯变换存在定理 existence theorem of Laplace transformation 173    
拉普拉斯变换性质 properties of Laplace transformation 175    
拉普拉斯变换法 Laplace transformation method 180    
拉普拉斯方程 Laplace equation 105    
拉普拉斯算符 Laplace operator 99    
拉普拉斯逆变换 inverse Laplace transformation 174    
勒让德多项式 Legendre polynomial 218    
勒让德多项式递推关系 recursion relation of Legendre polynomial 222    
勒让德多项式归一因子 normalization factor of Legendre polynomial 224    
勒让德多项式生成函数 generating function of Legendre polynomial 222    
勒让德多项式的正交性 orthogonality of Legendre polynomial 222    
勒让德方程 Legendre equation 215    
黎曼面 Riemann surface 20    
黎曼球面 Riemann sphere 5    
里兹方法 Ritz method 274    
连带勒让德方程 associated Legendre equation 156

<!-- page: 373 -->

连带勒让德函数 associated Legendre function 228    
    
刘维尔定理 Liouville theorem 42    
    
留数 residue 78    
    
留数定理 residue theorem 77    
    
罗德里格斯公式 Rodrigues formula 219    
    
洛朗级数 Laurent series 56    
    
洛朗展开系数 Laurent expansion coefficient 56    
    
拉盖尔方程 Laguerre equation 239    
    
拉盖尔多项式 Laguerre polynomial 239    
    
M    
    
m 阶极点 pole of order m 63    
    
m 阶零点 zero of order m 55    
    
M 判别法 M test method 48    
    
幂级数 power series 49    
    
模数原理 maximal modulus principle 43    
    
摩勒那定理 Morera theorem 43    
    
母函数 generating function 221    
    
Morlet 小波 Morlet wavelet 324    
    
墨西哥草帽小波/Marr 小波 Marr wavelet 324    
    
N    
    
内点 internal point 7    
    
诺伊曼函数 Neumann function 246    
    
诺伊曼条件 Neumann condition 108    
    
诺依曼级数 Neumann series 310    
    
诺依曼解 Neumann solution 310    
    
能斯特定律 Nernst law 106    
    
扭结 knot 296    
    
O    
    
欧拉方程 Euler equation 272    
    
欧拉积分 Euler integral 91    
    
第一类欧拉积分 Euler integral of the first kind 74    
    
第二类欧拉积分 Euler integral of the second kind 71    
    
欧拉公式 Euler formula 16    
    
P    
    
帕塞瓦尔等式 Parseval equation 169    
    
抛物型方程 parabolic equation 100    
    
泊松方程 Poisson equation 104    
    
泊松公式 Poisson formula 125    
    
泊松积分公式 Poisson integral formula 158

<!-- page: 374 -->

频窗函数

frequency window function 322

频窗中心

frequency window center 322

频窗半径

frequency window radius 322

##### Q

奇点    
singularity 61    
本性奇点    
essential singularity 63    
非孤立奇点    
non-isolated singularity 61    
孤立奇点    
isolated singularity 61    
可去奇点    
removable singularity 62    
正则奇点    
canonical singularity 238    
强迫振动    
forced vibration 117    
纯强迫振动    
purly forced vibration 118    
一般强迫振动    
general forced vibration 119    
球(谐)函数    
spherical (harmonic) function 230    
球坐标    
spherical coordinates 151    
区域    
region 7    
闭区域    
closed region 8    
单连通区域    
simply connected region 8    
复连通区域    
multiply connected region 8    
区域边界    
region boundary 8    
区域边界的正向    
positive orientation of region boundary 8    
权函数    
weight function 258    
齐次边界条件    
homogeneous boundary condition 109    
R    
热传导方程    
heat conduction equation 99    
若尔当引理    
Jordan lemma 85    
S    
振动法    
perturbation method 299    
奇异摄动法    
singular perturbation method 301    
正则摄动法    
regular perturbation method 299    
施密特公式    
Schmidt formula 314    
施密特-希尔伯特定理    
Hilbert-Schmidt theorem 313    
施图姆-刘维尔方程    
Sturm-Liouville equation 258    
收敛    
convergence 46    
收敛半径    
radius of convergent 49    
收敛圆    
circle of convergent 49    
双曲函数    
hyperbolic function 17    
双曲型方程    
hyperbolic equation 100    
施瓦茨反射原理    
Schwartz reflection principle 71

<!-- page: 375 -->

时窗函数 time window function 321    
时窗中心 time window center 321    
时窗半径 time window radius 321    
伸缩因子 scale factor 323    
施拉夫利公式 Schlafli formula 219    
T    
泰勒定理 Taylor theorem 51    
泰勒级数 Taylor series 51    
泰勒展开 Taylor expansion 51    
特殊函数 special function 260    
调和函数 harmonic function 13    
推迟势 retarded potential 128    
退化核 degenerate kernel 307    
椭圆型方程 elliptic equation 100    
外点 external point 8    
魏尔斯特拉斯定理 Weierstrass theorem 48    
无穷远点的留数 residue at infinity 78    
无限远点 infinity point 5    
误差函数 error function 264    
维纳-霍普夫方法 Wiener-Hopf method 316    
振动方程 vibration equation 102    
衔接条件 joint condition 109    
相似变换 similar transform 290    
小波变换 wavelet transform 323    
小波母函数 wavelet generating function 323    
小波基函数 wavelet basefunction 323    
小圆弧引理 small arc lemma 90    
薛定谔方程 Schrodinger equation 105    
行波法 traveling wave method 112    
一致收敛 uniform convergence 48    
柯西一致收敛判据 Cauchy test of uniform convergence 48    
有界性边界条件 bounded boundary condition 155    
有界问题 bounded problem 131    
输运问题 transportation problem 170    
雅可比方程 Jacobian equation 220

<!-- page: 376 -->

## 2

正弦戈登方程 sine Gordon equation 294      
支点 branch point 18      
支割线 branch cut 19      
中值（平均值）定理 median value theorem 43      
周期性边界条件 periodical boundary condition 154      
逐项可积性 termwise integrability 48      
柱函数 cylindrical function 236      
第一类柱函数 cylindrical function of the first kind 236      
第二类柱函数 cylindrical function of the second kind 246      
第三类柱函数 cylindrical function of the third kind 248      
柱坐标 cylindrical coordinates 150      
自然边界条件 natural boundary condition 110,259      
最速落径 brachistochrone 269      
主值支 principle value branch 21      
指标方程 indicial equation 239

<!-- page: 377 -->

(O-8118.31)

本书第一版荣获国家教委优秀教材二等奖

本书第二版荣获教育部科技进步二等奖

# 数学物理方法（第四版）

<div style="text-align: center;"><img src="images/p0377_img_in_image_box_94_1065_182_1151.jpg" alt="Image" width="9%" /></div>


科学出版社互联网入口

高教数理分社：（010）64015178 销售：（010）64031535

E-mail: mph@mail.sciencep.com

www.sciencep.com

销售分类建议：数学物理方法

<div style="text-align: center;"><img src="images/p0377_img_in_image_box_687_1091_863_1225.jpg" alt="Image" width="18%" /></div>


定价：59.00元
